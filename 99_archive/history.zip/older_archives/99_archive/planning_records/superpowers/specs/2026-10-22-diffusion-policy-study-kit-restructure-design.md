# Diffusion Policy 学习资料重构设计

**日期：** 2026-10-22  
**状态：** 待用户审阅  
**范围：** `G:\毕设` 工作区及其全部学习资料

## 1. 目标与原则

把全部现有资料重构成一套精简、可线性学习、也可按疑问回查的中文 Markdown 学习手册。

“保留所有问答”不是逐句保留聊天记录，而是保留每个提问对应的：问题、正确结论、必要推导、常见误解和复习入口。相同内容只留一处完整解释，其他位置只做链接。

设计原则：

1. **目录少：** 主学习资料只分四个区域。
2. **每篇职责单一：** 不再出现三个文件都在讲同一套 DDPM 或训练流程。
3. **先理解、再公式、再代码：** 零基础读者沿数字顺序即可完成学习。
4. **原论文与学习解释分开：** 原文译读用于查证；学习章节负责讲懂。
5. **证据可追溯：** 论文事实回链本地 PDF；代码事实回链官方仓库；解释与论文事实明确区分。

不会把 Diffusion Policy 写成强化学习论文：它的主线是行为克隆（BC）；RL 只作为背景知识。

## 2. 工作区根目录

最终的 `G:\毕设` 只保留按用途划分的五项。**目录与文件名均使用英文小写和下划线；文档正文使用中文。**

```text
G:\毕设\
├── README.md                    # 论文、学习资料、代码与复现的总入口
├── 01_papers\                  # 原始 PDF、补充材料；不放学习笔记
├── 02_learning\                # 本设计第 3 节中的精简学习手册
├── 03_code\                    # 官方仓库及后续自己的实验代码
└── 99_archive\                 # 迁移前资料与设计记录，不参与日常学习
```

当前 `paper/`、`diffusion_policy_study_kit/`、`code/` 将分别迁移为 `01_papers/`、`02_learning/`、`03_code/`。`docs/` 中的本设计和迁移前文档将归入 `99_archive/`。

`tmp/` 已核实只含 4 张未被引用的 PDF 预览 PNG，属于可删除的临时文件。当前执行环境拦截了递归删除命令；重构实施时会再次以已验证的绝对路径清理，或由用户在资源管理器中删除 `G:\毕设\tmp`。

## 3. 最终学习文档目录

```text
02_learning/
├── README.md                              # 唯一入口：如何按目的使用本学习包
├── 00_learning_map.md                     # 首学、复习、答辩、代码四条路线
│
├── 01_foundations/
│   ├── 01_ml_dl_and_imitation.md           # 样本、MSE、梯度、特征、BC、多峰
│   ├── 02_ddpm_from_intuition_to_formula.md # 唯一完整 DDPM 推导与 DDIM 基础
│   └── 03_robot_control_and_rl.md          # 观测/动作/RHC/控制；RL 与本文边界
│
├── 02_paper_study/
│   ├── 00_paper_chinese_reading.md         # 按论文原顺序的译读与阅读提示
│   ├── 01_problem_and_full_pipeline.md     # 任务、BC、动作序列、训练和推理全图
│   ├── 02_action_diffusion_and_formulas.md # 式(1)--(9)、DDIM、KL、EBM、score
│   ├── 03_control_network_and_design.md    # RHC、视觉、FiLM、Transformer、EMA、日程
│   └── 04_experiments_appendix_limits.md   # 第4--9节、附录、证据与局限
│
├── 03_code_and_practice/
│   ├── 01_paper_to_official_code.md        # 符号、张量、模块与仓库命名映射
│   └── 02_minimal_reproduction_and_debug.md # 低维→视觉路线、评估、安全、排障
│
└── 04_review/
    ├── 01_symbols_and_formula_cards.md     # 一页查变量、时间、随机量和公式角色
    ├── 02_faq_and_question_index.md        # “我当时不懂什么”到主解释处的索引
    └── 03_paper_recap_and_self_test.md     # 2/5/10分钟复述、答辩题、学习循环
```

这套结构共 15 份学习文档（含入口），不再保留平行的 `03/04/05/06/07/08/09` 多套目录。读者通常只会看到：基础、论文精读、代码实践、复习自测。

## 4. 每份文档的职责

### 入口

| 文件 | 读者何时打开 | 必须回答什么 |
|---|---|---|
| `README.md` | 第一次进入或忘记资料如何用 | 这是什么论文、学习包边界、四条路径、原论文与官方代码入口 |
| `00_learning_map.md` | 开始一轮学习前 | 首学、公式复习、答辩准备、代码实践分别按什么顺序读，读完算不算掌握 |

### 基础

| 文件 | 权威内容 | 覆盖的历史疑问 |
|---|---|---|
| `01_ml_dl_and_imitation.md` | ML/DL、神经网络、张量、MSE、反向传播、学习率、BC | 图片特征从何而来；为什么正负误差不抵消；分布偏移；多峰为何不能直接平均；BC 和 RL 的区别 |
| `02_ddpm_from_intuition_to_formula.md` | DDPM 唯一完整推导；日程；DDIM 基础 | 高斯分布是否是数字；噪声怎样加到图片；为何平方根；贝叶斯后验；`mu_theta`；`sigma_t`；为什么能生成；square cosine；DDPM/DDIM 差异 |
| `03_robot_control_and_rl.md` | 观测/状态/动作、位置和速度控制、闭环/RHC、DQN/策略梯度的必要背景 | 动作序列为什么只执行一部分；控制延迟；RL 的“打分”与本文模仿的边界 |

### 论文精读

| 文件 | 论文范围 | 权威内容 |
|---|---|---|
| `00_paper_chinese_reading.md` | 全文第 1--9 节、附录 A--D | 按原文顺序译读；每章增加阅读目的、前置章节和易误读注释；用于查证而不替代教学主线 |
| `01_problem_and_full_pipeline.md` | 摘要、第 1--2 节 | `p(A_t^0|O_t)`、动作序列、训练和推理逐步流程、观察为何不加噪、随机动作如何产生 |
| `02_action_diffusion_and_formulas.md` | 第 2 节、第 3.4 节、第 4.4--4.5 节 | 论文式 (1)--(9)；KL 作为推导背景；EBM 对比；DDIM 跳步；score 的阶段、隐式计算和为什么除以 `sqrt(1-alpha_bar)`；区分训练梯度与动作空间 score |
| `03_control_network_and_design.md` | 第 3 节、第 4.1--4.3 节与实现细节 | `T_o,T_p,T_a`、warm start 的已知边界、视觉编码和特征拼接、物体关系如何通过误差学习、FiLM、Transformer、EMA/BN/GN、噪声日程、归一化、旋转、增强 |
| `04_experiments_appendix_limits.md` | 第 5--9 节、附录 B--D | 数据集、指标、消融、相对提升、真实机器人、双臂、超参数、控制频率、局限和“实验能/不能证明什么” |

### 代码与实践

| 文件 | 职责 |
|---|---|
| `01_paper_to_official_code.md` | 论文变量与 `n_obs_steps`、`n_action_steps`、`horizon` 的映射；数据集→normalizer→policy→采样→RHC→评估的单条数据流；每处给张量形状 |
| `02_minimal_reproduction_and_debug.md` | 官方低维 Colab→Push-T→视觉任务的最小路线；如何记录实验、解释训练损失与闭环成功率、检查常见错误和真实机器人安全边界 |

### 复习与自测

| 文件 | 职责 |
|---|---|
| `01_symbols_and_formula_cards.md` | 只用于快速查阅；把数据、时间、随机量分组；显示实际形状、所在阶段和最易混淆对象 |
| `02_faq_and_question_index.md` | 用“疑问→最短回答→为什么→权威章节→自检题”保留所有学习过程中的疑惑，不重写长教材 |
| `03_paper_recap_and_self_test.md` | 2、5、10 分钟论文复述；从概念、机制、证据三层自测；提供每次重新学习论文的固定流程 |

## 5. 内容去重规则

| 主题 | 唯一完整解释处 | 其他位置仅做什么 |
|---|---|---|
| DDPM 的贝叶斯推导、`mu_theta`、`sigma_t` | `01_foundations/02_ddpm_from_intuition_to_formula.md` | 论文精读只说明如何替换成动作与观测 |
| BC、多峰和分布偏移 | `01_foundations/01_ml_dl_and_imitation.md` | 精读应用到动作序列 |
| 动作条件扩散、DDIM、score | `02_paper_study/02_action_diffusion_and_formulas.md` | 公式卡仅列角色与链接 |
| RHC、视觉、网络、EMA、日程 | `02_paper_study/03_control_network_and_design.md` | 基础文档只给前置定义 |
| 论文证据与附录 | `02_paper_study/04_experiments_appendix_limits.md` | 译读保留原章节/表图对应 |
| 代码映射与实际复现 | `03_code_and_practice/` 两篇 | 论文精读仅指出概念来源 |

## 6. 历史问答覆盖清单

以下问题必须在 `04_review/02_faq_and_question_index.md` 一跳可定位，并在对应权威文档获得完整回答：

1. 高斯噪声、`N(0,I)`、噪声张量、平方根、方差/标准差；
2. `x_0,x_t,A^0,A^k,epsilon,z,alpha,beta,alpha_bar,mu,sigma` 的实际含义、形状和阶段；
3. 前向闭式式、高斯相加、最终高斯、贝叶斯后验、反向均值与 `sigma_t z`；
4. DDPM 为什么可以生成；iDDPM/square cosine 日程；DDIM 为什么可跳步；
5. ML/DL、视觉特征、MSE、梯度、反向传播、学习率；
6. BC 与 RL、分布偏移、多峰/多模态、随机动作；
7. 条件动作扩散训练/推理、KL、EBM、score 和除法来源；
8. `T_o,T_p,T_a`、RHC、warm start、位置/速度控制；
9. 图像如何影响动作、特征拼接、FiLM、Transformer、EMA、BN/GN；
10. 消融、实验指标、视觉编码器、真实任务、附录细节、局限；
11. 论文符号到官方代码、张量维度、最小复现与排障。

## 7. 迁移与保留策略

现有各目录的内容先融合、校正和重写到上述 15 份文档。为避免新旧版本同时出现造成困惑，旧目录不会留在 `02_learning` 的主目录中。

在正式迁移前，将现有学习资料复制到 `G:\毕设\99_archive\learning_before_restructure_2026-10-22\` 作为只读历史备份；之后 `02_learning` 仅保留新目录。原论文 PDF 不做任何修改。

## 8. 写作与验证标准

每章都采用：**学完能回答什么 → 前置提醒 → 主解释（先直觉/例子，后公式） → 常见误解 → 自测与下一步**。

每个公式都要回答：变量是什么、在哪个阶段用、为何是这个结构、不能误解成什么。论文事实、本人的解释和由公式可作出的推论必须使用不同措辞。

完成前执行以下验证：

1. 检查工作区根目录严格匹配第 2 节、学习文档目录匹配第 3 节；
2. 用关键词核对第 6 节所有历史疑问都有权威解释；
3. 检查所有 Markdown 链接的目标存在；
4. 按“首学、复习公式、准备答辩、准备运行代码”四条路线完整走读；
5. 对照原论文目录，核对第 1--9 节与附录 A--D 都有译读或学习解释入口。

## 9. 完成定义

完成时，用户无需再阅读聊天记录，就能：从目录按顺序学完论文；通过高频索引找回每个曾经的疑问；通过复述/自测检验是否真正理解；并能从论文概念进入官方代码和最小复现。学习包的主目录保持精简，不存在重叠的平行专题或“写得不好但不得不看”的旧文档。
