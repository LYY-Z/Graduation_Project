# Diffusion Policy Learning Kit Restructure Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Replace the fragmented learning notes in `G:\毕设` with one concise, English-named, Chinese-language Diffusion Policy study kit that preserves every prior learning question as a searchable review item.

**Architecture:** Preserve the current material in a dated archive, then author a canonical `02_learning` tree with four layers: foundations, paper study, code practice, and review. Create all canonical Markdown files before root-level migration; validate coverage and links; only then move the original paper, code repository, prior notes, and planning records into the final workspace layout.

**Tech Stack:** Markdown, PowerShell, `rg`, local PDF source, official Diffusion Policy GitHub repository.

**Spec:** `G:\毕设\docs\superpowers\specs\2026-10-22-diffusion-policy-study-kit-restructure-design.md`

## Global Constraints

- Use English lowercase snake_case for every final directory and Markdown filename; write document bodies in Chinese.
- Final root layout is exactly `README.md`, `01_papers`, `02_learning`, `03_code`, and `99_archive`.
- Preserve the original paper PDF without modification and retain a dated copy of all previous learning Markdown before moving it out of the canonical location.
- Treat Diffusion Policy as behavior cloning; distinguish paper facts, explanatory derivations, and code facts.
- Give every formula its variable role, phase (training/inference), reason for its form, and common misconception.
- The FAQ must include every historical-question category listed in design section 6; do not merely say “see previous chat.”
- Do not claim an unspecified warm-start implementation is a paper fact.
- This workspace is not a Git repository; do not create commits.

## Review Focus

- A reader can find a complete answer—not only a term definition—for every repeated DDPM doubt (`Gaussian`, square root, Bayes posterior, `mu_theta`, `sigma_t`, DDIM).
- The same symbol does not silently change role between image DDPM and action diffusion; real time `t` and diffusion step `k` stay distinct.
- Paper-derived numerical results always include task/metric context and do not turn relative improvements into percentage points.
- All Markdown links still work after `paper/`, `code/`, and the old study-kit directory move.
- The final root has no duplicate active learning tree; archival material is visibly separated and does not appear in normal learning routes.

---

### Task 1: Preserve sources and prepare the canonical workspace

**Files:**
- Create: `G:\毕设\99_archive\learning_before_restructure_2026-10-22\...` (copy of current study material)
- Create: `G:\毕设\02_learning\` and its four final subdirectories
- Modify later: `G:\毕设\README.md`

**Interfaces:**
- Consumes: current `diffusion_policy_study_kit`, `paper`, `code`, and `docs` directories.
- Produces: an untouched archive copy and empty canonical locations for Tasks 2–4.

- [x] **Step 1: Record the current source inventory and verify `tmp` remains limited to unreferenced PDF preview PNG files.**

Run: `Get-ChildItem -Force G:\毕设; Get-ChildItem -Force G:\毕设\tmp -Recurse`

Expected: source material, official code clone, original PDF, planning records, and only the four previously verified preview images are identified before any move.

- [x] **Step 2: Copy the existing learning material into `G:\毕设\99_archive\learning_before_restructure_2026-10-22\diffusion_policy_study_kit`.**

Use a recursive copy that preserves every Markdown file and does not alter the source tree.

- [x] **Step 3: Verify archive completeness before writing canonical documents.**

Run: compare the sorted relative Markdown-file lists beneath the source and archive trees.

Expected: every source Markdown relative path has an archived counterpart.

- [x] **Step 4: Create `02_learning\01_foundations`, `02_learning\02_paper_study`, `02_learning\03_code_and_practice`, and `02_learning\04_review`.**

Expected: all directories exist and no legacy file is overwritten.

### Task 2: Author navigation and foundations

**Files:**
- Create: `G:\毕设\README.md`
- Create: `G:\毕设\02_learning\README.md`
- Create: `G:\毕设\02_learning\00_learning_map.md`
- Create: `G:\毕设\02_learning\01_foundations\01_ml_dl_and_imitation.md`
- Create: `G:\毕设\02_learning\01_foundations\02_ddpm_from_intuition_to_formula.md`
- Create: `G:\毕设\02_learning\01_foundations\03_robot_control_and_rl.md`

**Interfaces:**
- Consumes: archived foundation, DDPM, and RL documents; local paper PDF.
- Produces: the entry route and all prerequisite explanations used by paper-study documents.

- [x] **Step 1: Write a coverage checklist for Task 2 before drafting.**

Required checklist groups: ML/DL/features/MSE/gradient/learning rate; BC/distribution shift/multimodality; tensors/batches; Gaussian tensors and square roots; all DDPM variables and shapes; forward process; posterior/Bayes/`mu_theta`/`sigma_t`; generation, schedule, and DDIM; observation/action/control/RL boundary.

- [x] **Step 2: Create the root `README.md`, learning `README.md`, and `00_learning_map.md`.**

Include four explicit routes: first learning, formula review, presentation/defense, and code practice. State that learning content is Chinese despite English filenames.

- [x] **Step 3: Create `01_ml_dl_and_imitation.md`.**

Use one non-robotic and one robot example for human features versus learned features; explain MSE as squared numeric error, backpropagation, learning rate, behavior cloning, distribution shift, and why averaging modes fails.

- [x] **Step 4: Create `02_ddpm_from_intuition_to_formula.md`.**

Use a scalar numerical example before each major formula. Include the physical tensor meaning and shape of `x_0`, `x_t`, `epsilon`, `z`, `alpha`, `beta`, `alpha_bar`, `mu_theta`, and `sigma_t`; derive the forward closed form; explain Gaussian closure and square roots; derive reverse sampling from the Bayes posterior; distinguish `mu_theta` from a sample; explain why DDPM generates; add square-cosine schedule and DDIM as a bounded extension.

- [x] **Step 5: Create `03_robot_control_and_rl.md`.**

Define observations, robot state, actions, position/velocity control, feedback and RHC. Keep DQN and policy-gradient material as optional background and explicitly contrast reward-driven RL with demonstration-driven BC.

- [x] **Step 6: Run foundation coverage checks.**

Run: `rg -n "高斯|平方根|贝叶斯|sigma|学习率|分布偏移|多峰|行为克隆|滚动" G:\毕设\02_learning\01_foundations`

Expected: every checklist group appears in one canonical foundation document, with no broken learning-route link.

### Task 3: Author the paper-study curriculum

**Files:**
- Create: `G:\毕设\02_learning\02_paper_study\00_paper_chinese_reading.md`
- Create: `G:\毕设\02_learning\02_paper_study\01_problem_and_full_pipeline.md`
- Create: `G:\毕设\02_learning\02_paper_study\02_action_diffusion_and_formulas.md`
- Create: `G:\毕设\02_learning\02_paper_study\03_control_network_and_design.md`
- Create: `G:\毕设\02_learning\02_paper_study\04_experiments_appendix_limits.md`

**Interfaces:**
- Consumes: all Task 2 vocabulary and formulas; the original paper PDF.
- Produces: a complete, paper-order learning path that has no dependency on the chat transcript.

- [x] **Step 1: Create `00_paper_chinese_reading.md` as the source-ordered reading guide.**

Retain translated technical content from the archive, add a per-section “why read this / prerequisite / common misreading” preface, and link each paper section to the canonical teaching chapter.

- [x] **Step 2: Create `01_problem_and_full_pipeline.md`.**

Explain `p(A_t^0|O_t)`, action-plan tensor shape, training from expert actions, inference from random action noise, why observations condition but are not diffused, execution of only the first action chunk, and the source of action-plan diversity.

- [x] **Step 3: Create `02_action_diffusion_and_formulas.md`.**

Explain paper equations (1)–(9) in paper order. Include DDPM versus DDIM, the valid DDIM jump construction, KL as distribution mismatch in the derivation rather than an extra routine training term, EBM comparison, score as an action-space density direction during sampling, and the scalar derivation of `-epsilon_theta/sqrt(1-alpha_bar)`.

- [x] **Step 4: Create `03_control_network_and_design.md`.**

Cover `T_o`, `T_p`, `T_a`, RHC, and the paper’s limited warm-start claim; action-only diffusion; multi-camera/multi-frame feature concatenation; end-to-end visual learning; 1D U-Net/FiLM; Transformer/cross-attention; online/EMA models; BatchNorm/GroupNorm; square-cosine schedule; normalization, rotation, and image augmentation.

- [x] **Step 5: Create `04_experiments_appendix_limits.md`.**

Read sections 4–9 and appendices A–D as evidence: properties, benchmarks, metrics, ablations, relative improvements, real Push-T, mug, sauce, bimanual tasks, data efficiency, hyperparameters, hardware frequencies, limits, and careful scope of claims.

- [x] **Step 6: Verify paper coverage and source labeling.**

Run: `rg '^## ' G:\毕设\02_learning\02_paper_study; rg -n "论文明确|解释|推论|局限" G:\毕设\02_learning\02_paper_study`

Expected: sections 1–9 and appendices A–D have a reading/teaching entry; paper fact and explanatory inference are visibly distinct.

### Task 4: Author code-practice and review materials

**Files:**
- Create: `G:\毕设\02_learning\03_code_and_practice\01_paper_to_official_code.md`
- Create: `G:\毕设\02_learning\03_code_and_practice\02_minimal_reproduction_and_debug.md`
- Create: `G:\毕设\02_learning\04_review\01_symbols_and_formula_cards.md`
- Create: `G:\毕设\02_learning\04_review\02_faq_and_question_index.md`
- Create: `G:\毕设\02_learning\04_review\03_paper_recap_and_self_test.md`

**Interfaces:**
- Consumes: Task 2/3 canonical explanations and `G:\毕设\03_code\diffusion_policy` after migration.
- Produces: implementation mapping, a safe reproduction route, and independent review without rereading chat history.

- [x] **Step 1: Create `01_paper_to_official_code.md`.**

Map paper notation to official repository terms (`n_obs_steps`, `n_action_steps`, `horizon`) and document shapes from dataset through normalizer, vision encoder, noise predictor, sampler, executed chunk, and evaluation.

- [x] **Step 2: Create `02_minimal_reproduction_and_debug.md`.**

Define the low-dimensional Colab → Push-T → visual-task sequence, expected observations, experiment records, training-vs-rollout metrics, common symptoms, and real-robot safety boundary.

- [x] **Step 3: Create `01_symbols_and_formula_cards.md`.**

Group symbols into data, two time axes, random variables, schedule coefficients, and learned functions. Every entry must include actual form/shape, stage, and a “do not confuse with” note.

- [x] **Step 4: Create `02_faq_and_question_index.md`.**

Use exactly the format “historical doubt → shortest answer → why → canonical link → self-check.” Cover all 11 design-section question groups, including repeated questions about Gaussian numbers, square roots, reverse mean, sigma, images, MSE, learning rate, DDIM, score, KL, EMA/BN/GN, and experiments.

- [x] **Step 5: Create `03_paper_recap_and_self_test.md`.**

Provide 2-, 5-, and 10-minute recaps; questions at concept/mechanism/evidence levels; answer keys; and the reusable study loop “global map → doubt → canonical section → self-explanation → source evidence → test.”

- [x] **Step 6: Verify the FAQ and code mapping.**

Run: `rg -n "高斯|平方根|mu|sigma|DDIM|score|视觉|FiLM|EMA|学习率|消融|n_obs_steps" G:\毕设\02_learning\04_review\02_faq_and_question_index.md G:\毕设\02_learning\03_code_and_practice\01_paper_to_official_code.md`

Expected: all user-question categories and repository terminology are searchable in the final review/practice material.

### Task 5: Validate links, migrate root directories, and report cleanup status

**Files:**
- Modify: all Markdown files under `G:\毕设\02_learning\` if link validation reveals an incorrect target
- Move: `G:\毕设\paper` → `G:\毕设\01_papers`
- Move: `G:\毕设\code` → `G:\毕设\03_code`
- Move: `G:\毕设\diffusion_policy_study_kit` → `G:\毕设\99_archive\learning_source_before_restructure`
- Move last: `G:\毕设\docs` → `G:\毕设\99_archive\planning_records`
- Remove when permitted: `G:\毕设\tmp`

**Interfaces:**
- Consumes: all completed canonical files and archive copy from Tasks 1–4.
- Produces: the exact root structure in the spec and a verified final study kit.

- [x] **Step 1: Validate every relative Markdown link in `02_learning`.**

Use a PowerShell parser for Markdown link targets, skipping `http`, `https`, anchors, and image URLs; resolve each local target relative to its source Markdown file.

Expected: all local targets exist, including the moved PDF and code-repository links.

- [x] **Step 2: Validate the final-question coverage matrix.**

Run the keyword checks from Tasks 2–4 and manually inspect the FAQ’s 11 top-level question groups.

Expected: each group links to an existing canonical explanation and each explanation includes a common misconception or self-check.

- [x] **Step 3: Move the verified root directories to their final English names.**

Move source directories only after exact absolute-path checks. Update any remaining absolute local links to `01_papers` and `03_code` before moving planning records.

- [x] **Step 4: Attempt the already-authorized removal of `G:\毕设\tmp` only through an allowed, verified operation.**

Expected: either the directory is removed after a successful verification, or the final report explicitly states that platform policy blocked removal and lists the remaining four preview files. Do not bypass platform safety controls.

- [x] **Step 5: Run final workspace and content validation.**

Run: `Get-ChildItem -Force G:\毕设; rg --files G:\毕设\02_learning; rg '^## ' G:\毕设\02_learning -g '*.md'`

Expected: root contains only `README.md`, `01_papers`, `02_learning`, `03_code`, `99_archive` (plus `tmp` only if deletion was blocked); all 15 planned learning documents exist with clear section headings.

- [x] **Step 6: Deliver a concise completion report.**

Include final paths, validation evidence, whether `tmp` was removed, and the local PDF source citation.

## Self-Review

**Spec coverage:** Tasks 1 and 5 implement the root/archival constraints; Task 2 covers prerequisites and complete DDPM; Task 3 covers all paper sections and formulas; Task 4 covers code mapping, FAQ, self-test, and review. No unassigned requirement remains.

**Step scan:** Every task creates a named document group or performs a named validation/migration operation. Documentation work uses coverage/keyword/link validation in place of software unit tests.

**Type consistency:** Final names match the design: `01_papers`, `02_learning`, `03_code`, `99_archive`; learning subdirectories match the final directory listing.

**Review focus:** Each listed risk has an owner: DDPM and symbols (Tasks 2/4), time-index distinction and score (Task 3), experimental claims (Task 3), links (Task 5), and duplicate active content/root layout (Tasks 1/5).

**Proportion:** Five independently reviewable tasks cover the coupled archive, writing, validation, and migration work without duplicating document prose.
