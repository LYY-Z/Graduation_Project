# SDD ledger — plan: G:\毕设\docs\superpowers\plans\2026-10-22-diffusion-policy-learning-kit-restructure.md

Ruling: Execute in the current `G:\毕设` workspace — it is not a Git repository, so a Git worktree and Git-based SDD workspace cannot be created; a complete dated archive will provide recovery instead — cost if wrong: file migration is reversible from the archive but lacks Git commits.

Pre-flight: Task 1 produces archived source material and canonical directories consumed by Tasks 2–4 — consistent with the spec.

Pre-flight: Tasks 2 and 3 produce the canonical concepts consumed by Task 4’s code map and FAQ — consistent with the spec.

Pre-flight: Task 5 consumes every Task 1–4 output and only moves source directories after validation — consistent with the spec.

Task 1: complete (non-Git workspace; verification: source/archive file comparison → 25 source files, 25 archived files, 0 differences; canonical directory checks → 5/5 true).

Task 2: complete (verification: foundation keyword search covers Gaussian noise, square roots, Bayes, sigma, learning rate, distribution shift, multimodality, behavior cloning, and receding control; placeholder-marker search → 0 matches).

Task 3: complete (verification: paper-study headings include paper sections 1–9 and appendices A–D through the translation guide; targeted search confirms KL, DDIM, score, FiLM, EMA/GroupNorm, warm start, ablations, real tasks, bimanual tasks, and limits).

Task 4: complete (verification: final learning tree has 15 Markdown documents; FAQ keyword search confirms Gaussian noise, square roots, reverse mean/sigma, DDIM, score, vision, FiLM, EMA, learning rate, ablations, and official-code n_obs_steps coverage; placeholder-marker search → 0 matches).

Task 5 migration ruling: `paper` and `code` could not be renamed or moved after two verified attempts because Windows reported that the paths were in use or access was denied. The operation was not forced or circumvented. Instead, each was copied byte-for-byte into the canonical `01_papers` and `03_code` locations so every document link resolves. Cost: the original `paper` and `code` directories remain temporarily at the workspace root until the user closes the process holding them and chooses to remove the duplicates. The user-authorized `tmp` removal was also blocked by the host policy after its exact four unreferenced preview PNG targets were verified; it remains untouched.

Task 5: complete (fresh final validation: 15/15 expected learning Markdown files present; 0 missing local Markdown links; 0 placeholder markers; 0 stale active paths; FAQ coverage matrix 7/7 true; canonical paper copy matches its source byte length; canonical code copy has 0 relative-file differences versus source; canonical PDF and repository README exist; old active learning kit absent; planning records archived. The root intentionally retains `paper`, `code`, and `tmp` only for the documented lock/policy rulings.)
