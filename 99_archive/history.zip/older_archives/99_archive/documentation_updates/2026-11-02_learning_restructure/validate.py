from pathlib import Path
from urllib.parse import unquote
import hashlib,json,re,sys,math

sys.stdout.reconfigure(encoding='utf-8')
ROOT=Path(r'G:\毕设\02_learning')
OUT=Path(__file__).parent
files=list((ROOT/'locoformer').glob('*.md'))+list((ROOT/'diffusion_policy').rglob('*.md'))
files+=list(ROOT.glob('*.md'))+list((ROOT/'04_review').glob('*.md'))+list((ROOT/'04_review'/'deliverables').glob('*.md'))
files=sorted(set(files))
pattern=re.compile(r'!?\[[^\]\n]*\]\((<[^>\n]+>|(?:\\.|[^()\n]|\([^()\n]*\))+?)\)')
broken=[]; anchor_errors=[]; checked=0

def unfence(s):return re.sub(r'^```[^\n]*\n.*?^```\s*$', '', s, flags=re.M|re.S)
def anchors(p):
 s=p.read_text(encoding='utf-8-sig')
 result=set(re.findall(r'<a\s+id=[\'"]([^\'"]+)',s))
 occurrences={}
 for heading in re.findall(r'^#{1,6}\s+(.+?)\s*$',s,re.M):
  h=re.sub(r'<[^>]+>','',heading).lower()
  h=re.sub(r'[^\w\- ]','',h).replace(' ','-')
  n=occurrences.get(h,0);occurrences[h]=n+1
  result.add(h if not n else h+'-'+str(n))
 return result

for p in files:
 text=unfence(p.read_text(encoding='utf-8-sig'))
 for m in pattern.finditer(text):
  token=m.group(1).strip()
  if token.startswith('<') and token.endswith('>'):token=token[1:-1]
  if re.match(r'^(?:https?|mailto|data|app|plugin|codex):',token,re.I):continue
  token=re.sub(r'\s+"[^"]*"$','',token)
  raw,_,frag=token.partition('#')
  raw=re.sub(r':\d+$','',raw)
  raw=unquote(raw).replace('\\','/')
  target=(Path(raw) if re.match(r'^[A-Za-z]:/',raw) else p.parent/raw).resolve() if raw else p
  checked+=1
  record={'file':str(p.relative_to(ROOT)),'link':token,'resolved':str(target)}
  if not target.exists():broken.append(record)
  elif frag and target.suffix.lower()=='.md' and unquote(frag) not in anchors(target):anchor_errors.append(record)

faq=(ROOT/'locoformer/05_questions_and_review.md').read_text(encoding='utf-8')
questions=re.findall(r'^### Q(\d\d) ',faq,re.M)
assert questions==[f'{i:02d}' for i in range(1,91)], questions
for p in (ROOT/'locoformer').glob('*.md'):
 s=p.read_text(encoding='utf-8')
 assert s.count('```')%2==0,p
 assert s.count(r'\[')==s.count(r'\]'),p
 assert s.count(r'\(')==s.count(r'\)'),p

# Independently recompute documented toy calculations. This is not model inference.
deltas=[0+5-2,1+1-5,3-1]
a=[0.,0.,0.];carry=0.
for i in range(2,-1,-1):carry=deltas[i]+carry;a[i]=carry
assert a==[2.,-1.,2.]
assert [a[i]+[2,5,1][i] for i in range(3)]==[4.,4.,3.]
for adv,rho,expected in [(1,1.4,-1.2),(1,.6,-.6),(-1,.6,.8),(-1,1.4,1.4)]:
 assert abs(-min(rho*adv,max(.8,min(1.2,rho))*adv)-expected)<1e-12
w,b,theta=0.,2.,0.
samples=[(-1.,2.,4.),(1.,-1.,1.)]
numerical=[]
for epoch in range(2):
 ps=[1/(1+math.exp(-theta*x)) for x,_,_ in samples]
 errors=[w*x+b-y for x,_,y in samples]
 actor_grad=sum(-adv*2*p*(1-p)*x for p,(x,adv,_) in zip(ps,samples))/2
 dw=sum(e*x for e,(x,_,_) in zip(errors,samples))/2
 db=sum(errors)/2
 w-=.1*dw;b-=.1*db;theta-=.1*actor_grad
 numerical.append({'epoch':epoch+1,'critic_w':w,'critic_b':b,'actor_theta':theta})
assert abs(w+.285)<1e-12 and abs(b-2.095)<1e-12
assert abs(theta+.14989463004821824)<1e-12
assert abs(sum(.5*(w*x+b-y)**2 for x,_,y in samples)/2-.820125)<1e-12
attention_weight=math.exp(2/math.sqrt(2))/(math.exp(2/math.sqrt(2))+1)
assert abs(attention_weight-.8044296825069569)<1e-12
assert abs(attention_weight*10+(1-attention_weight)*4-8.826578095041742)<1e-12

migration=json.loads((OUT/'migration.json').read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert all((ROOT/new).exists() for new in migration['file_moves'].values())
repairs=json.loads((OUT/'intentional_link_repairs.json').read_text(encoding='utf-8'))
for p,digest in migration['protected_report_sha256'].items():
 if p in repairs:
  assert repairs[p]['before']==digest
  assert sha(Path(repairs[p]['backup']))==digest
  assert sha(Path(p))==repairs[p]['after']
 else:assert sha(Path(p))==digest
nonmd=[(old,new) for old,new in migration['file_moves'].items() if not old.endswith('.md')]
assert all(sha(ROOT/new)==migration['before_sha256'][old] for old,new in nonmd)
report={'documents_checked':len(files),'local_links_checked':checked,'broken_files':broken,'broken_anchors':anchor_errors,'question_ids':questions,'new_locoformer_characters':{p.name:len(p.read_text(encoding='utf-8')) for p in (ROOT/'locoformer').glob('*.md')},'numerical_examples_verified':numerical,'source_files_preserved':len(migration['file_moves']),'unchanged_non_markdown_files':len(nonmd),'protected_reports_unchanged':len(migration['protected_report_sha256'])-len(repairs),'intentional_report_markdown_link_repairs':repairs}
(OUT/'validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
assert not broken and not anchor_errors, 'Unresolved local documentation links.'
