"""Reorganize learning documents, preserving source snapshots and local links."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import hashlib, json, os, re, shutil

ROOT = Path(r'G:\毕设\02_learning').resolve()
ARCHIVE = Path(__file__).parent.resolve()
DP = ROOT / 'diffusion_policy'
FOLDERS = ['01_foundations','02_paper_study','03_code_and_practice','05_deployment','06_refactored_code']
REVIEW = ['01_symbols_and_formula_cards.md','02_faq_and_question_index.md','03_paper_recap_and_self_test.md']
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def inside(p):
    p = p.resolve()
    assert p != ROOT and p.is_relative_to(ROOT), str(p)
    return p

assert not DP.exists(), 'Target topic directory already exists; do not merge implicitly.'
maps = {ROOT/f:DP/f for f in FOLDERS}
maps.update({ROOT/'04_review'/f:DP/'04_review'/f for f in REVIEW})
maps.update({ROOT/'README.md':DP/'README.md', ROOT/'00_learning_map.md':DP/'00_learning_map.md'})
sources = []
for old in maps:
    inside(old)
    assert old.exists(), str(old)
    sources.extend([p for p in old.rglob('*') if p.is_file()] if old.is_dir() else [old])
before = {str(p.relative_to(ROOT)):sha(p) for p in sources}
ARCHIVE.mkdir(parents=True,exist_ok=True)
backup = ARCHIVE/'learning_documents_before.zip'
if backup.exists():
    with ZipFile(backup) as z:
        for p in sources:
            assert hashlib.sha256(z.read(str(p.relative_to(ROOT)).replace('\\','/'))).hexdigest()==sha(p)
else:
    with ZipFile(backup,'w',ZIP_DEFLATED) as z:
        for p in sources:z.write(p,str(p.relative_to(ROOT)))

other_md = list((ROOT/'04_review').glob('*.md')) + list((ROOT/'04_review'/'deliverables').glob('*.md'))
md_sources = {p:p.read_text(encoding='utf-8-sig') for p in set(sources+other_md) if p.suffix=='.md'}
protected = {str(p):sha(p) for p in list((ROOT/'04_review').glob('*.pptx'))+list((ROOT/'04_review'/'deliverables').glob('*')) if p.is_file() and not p.name.startswith('~$')}

def remap(p):
    p=p.resolve()
    for old,new in sorted(maps.items(),key=lambda a:len(str(a[0])),reverse=True):
        if p==old:return new
        if old.is_dir() and p.is_relative_to(old):return new/p.relative_to(old)
        # After moving old directories no longer exist; use the known directory list.
        if old.name in FOLDERS and p.is_relative_to(old):return new/p.relative_to(old)
    return p

for old,new in maps.items():
    inside(new)
    new.parent.mkdir(parents=True,exist_ok=True)
    assert not new.exists(), str(new)
    shutil.move(str(old),str(new))

link_re = re.compile(r'(!?\[[^\]\n]*\]\()(<[^>\n]+>|(?:\\.|[^()\n]|\([^()\n]*\))+?)(\))')
rewrites=[]
for old,text in md_sources.items():
    new=remap(old)
    def replace(m):
        token=m.group(2).strip()
        angle=token.startswith('<') and token.endswith('>')
        target=token[1:-1] if angle else token
        if re.match(r'^(?:https?|mailto|data|plugin|app|codex):',target,re.I) or target.startswith('#'):
            return m.group(0)
        title=''
        title_match=re.match(r'^(.*?)(\s+"[^"]*")$',target)
        if title_match:target,title=title_match.groups()
        raw,sep,fragment=target.partition('#')
        line=''
        lm=re.search(r':\d+$',raw)
        if lm:raw,line=raw[:lm.start()],lm.group(0)
        raw=raw.replace('\\','/')
        if not raw:return m.group(0)
        resolved=(Path(raw) if re.match(r'^[A-Za-z]:/',raw) else old.parent/raw).resolve()
        mapped=remap(resolved)
        # Public project rename: preserve legacy-vs-refactored provenance.
        if old.is_relative_to(ROOT/'06_refactored_code') or old.is_relative_to(ROOT/'05_deployment'):
            code=Path(r'G:\毕设\03_code')
            if mapped==code/'diffusion_policy_ur7e_refactored' or mapped.is_relative_to(code/'diffusion_policy_ur7e_refactored'):
                mapped=code/'diffusion_policy_ur7e'/mapped.relative_to(code/'diffusion_policy_ur7e_refactored')
            elif mapped==code/'diffusion_policy_ur7e' or mapped.is_relative_to(code/'diffusion_policy_ur7e'):
                mapped=code/'diffusion_policy_ur7e_v1'/mapped.relative_to(code/'diffusion_policy_ur7e')
        if new==old and mapped==resolved:return m.group(0)
        try:relative=os.path.relpath(mapped,new.parent).replace('\\','/')
        except ValueError:relative=str(mapped).replace('\\','/')
        relative+=line+(sep+fragment if sep else '')
        if any(c in relative for c in [' ','(',')']):relative='<'+relative+'>'
        return m.group(1)+relative+title+m.group(3)
    result=link_re.sub(replace,text)
    # Adjust plain learning-directory references, not evidence JSON or project code.
    for f in FOLDERS:
        result=result.replace('02_learning/'+f,'02_learning/diffusion_policy/'+f)
        result=result.replace('02_learning\\'+f,'02_learning\\diffusion_policy\\'+f)
    if old.is_relative_to(ROOT/'06_refactored_code'):
        # Labels and code examples were written before the project rename.
        # Links already distinguish the current project and v1, so replace labels only.
        result=re.sub(r'(?<![/\\])\bdiffusion_policy_ur7e_refactored\b','diffusion_policy_ur7e',result)
    new.write_text(result,encoding='utf-8')
    rewrites.append(str(new.relative_to(ROOT)))

after_targets={str(old.relative_to(ROOT)):str(remap(old).relative_to(ROOT)) for old in sources}
assert all((ROOT/new).is_file() for new in after_targets.values())
assert all(sha(Path(p))==digest for p,digest in protected.items()), 'A protected report changed.'
report={'root':str(ROOT),'backup':str(backup),'source_file_count':len(sources),'before_sha256':before,'file_moves':after_targets,'markdown_links_rebased':rewrites,'protected_report_sha256':protected}
(ARCHIVE/'migration.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'moved_files':len(sources),'rewritten_markdown_files':len(rewrites),'protected_reports':len(protected),'backup':str(backup)},ensure_ascii=True))
