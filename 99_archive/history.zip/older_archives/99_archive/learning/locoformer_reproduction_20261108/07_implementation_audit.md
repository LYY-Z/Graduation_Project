# LocoFormer 参考实现审查与路线选择

> 实施路线于 2026-11-08 修订，优先验证本地 locoformer 的直接复用。本文保留静态审查证据，早期候选选型以[当前工作计划](01_reproduction_plan.md)为准。

审查日期为 2026-11-07。本文逐项回答身体生成、统一观测、历史策略、动作提取、算力与部署的选择问题。结论来自本地源码、固定 GitHub 快照和 GenBot1K 压缩包内容的静态检查。训练效果、安装兼容性与实时性等待服务器验证。

[导航](00_start_here.md) · [执行计划](01_reproduction_plan.md) · [硬件参数](02_go2_hardware_and_interfaces.md)

## 1. 选定的总体路线

采用 Isaac Sim 5.1.0、Isaac Lab v2.3.2 和 Robot Lab v2.3.2 建立 Go2-W 基线。在独立项目扩展中实现统一槽位、TXL 策略接入、序列 PPO 与任务边界。身体生成首先参考 BabyLocoFormer 的四足参数化方法，后续引入筛选后的 GenBot1K 资产，增加轮足变体。

| 环节 | 本项目首选 | 其它资料的定位 |
| --- | --- | --- |
| 仿真与 Go2-W 基线 | Isaac Lab + Robot Lab | MuJoCo 供资产检查与跨仿真器验证 |
| 首轮多体型生成 | BabyLocoFormer 的参数化四足思路 | GenBot1K 作为后续筛选资产 |
| 固定语义槽位 | 项目自有映射，借鉴原文及源文件注释 | MetaMorph 参考补齐、掩码与动作过滤 |
| 历史网络 | 移植审查后的 Baby TXL 基础计算，建立最小配置 | 本地 lucidrains 参考缓存、因果遮罩和一致性检查 |
| 强化学习 | 与 Isaac Lab 配套的 RSL-RL 基线，增加序列训练模块 | Baby 自定义分支参考序列接口，逐处修正 |
| 动作解码 | 项目统一动作 → 各机体适配器 | Robot Lab/rl_sar 参考腿位置和轮速度 |
| 实机 | Unitree SDK2 与 Go2-W 专用接口 | 校验日志、坐标、增益与控制周期 |

上述选型是静态审查后确定的工程路线。Baby 子模块与本地 locoformer 均有不适合整体直接移入主环境的地方，详见下文。服务器动态检查失败时，应修复小模块或接口，并保存差异，不依赖试装多个完整框架解决。

## 2. BabyLocoFormer 实现了什么

### 2.1 项目与论文的关系

这是非官方简化实现。README 明确说明使用修改的 TXL、有限随机化和四足多形态训练，并说明模型使用单张 RTX 5090 训练、结果仍较弱。网络采用 SDPA、RoPE、SwiGLU 等设计，和论文的标准 Transformer 描述存在差异。它适合追踪一条接近 LocoFormer 的实现链，公开说明尚不能证明其达到原文性能。[README](https://github.com/linden713/BabyLocoFormer/blob/f2dadf8eb13826f449387ecc9970593a9af141bc/README.md)

### 2.2 已核对的实现链

| 代码 | 已观察到的实现 | 可参考部分 |
| --- | --- | --- |
| model/generate_quad.py | 调用 Xacro，变化机身长、宽与腿长，生成 URDF | 将参数表批量变成机器人资产 |
| model/quad.urdf.xacro | 参数化四足结构模板 | 连杆和关节的可控变化 |
| model/convert_to_usd.py | URDF 转 USD 入口 | Isaac Lab 资产准备 |
| assets/quadruped.py | MultiUsdFileCfg 读取多份 USD，random_choice=False | 同拓扑多体型场景组织 |
| babylocoformer_env_cfg.py | 观测、位置动作、奖励、重置、地形与课程配置 | Isaac Lab 任务接线 |
| agents/rsl_rl_ppo_cfg.py | ActorCriticTransformerXL 配置及 PPO 参数 | 网络、采集和优化参数的组织 |
| rsl_rl 子模块 | 自定义 Actor/Critic、TXL、PPO、storage、runner | 历史策略的训练接口 |
| go2_env_cfg.py、play.py | Go2 评测配置与运行入口 | 训练身体与目标身体的配置分离 |

主仓库固定为 f2dadf8eb13826f449387ecc9970593a9af141bc。网络与 PPO 在子模块 linden713/rsl_rl_transformer_xl，固定提交为 ca906f2161e9a7244d1bfee923cf57f6da0a259b。仅下载主仓库会遗漏关键算法。[子模块声明](https://github.com/linden713/BabyLocoFormer/blob/f2dadf8eb13826f449387ecc9970593a9af141bc/.gitmodules)

### 2.3 参数和实际覆盖

生成脚本设置机身长 [0.25,0.45) m、步长 0.02，宽 [0.15,0.35) m、步长 0.02，腿长 [0.15,0.25) m、步长 0.01。浮点 arange 的实际计数应运行确认。主要增加几何变化，不能据此认为覆盖任意关节数量、双足或轮足。

所选 PPO 配置覆盖默认类值，实际指定 model_dim=128、3 层、4 头、memory_length=32，每环境采集 32 步，学习率 3e-4，学习轮数和 minibatch 均为 1。环境物理步长 0.005 s、降采样 4，即策略 50 Hz。这些为该快照配置。[任务代码](https://github.com/linden713/BabyLocoFormer/tree/f2dadf8eb13826f449387ecc9970593a9af141bc/source/babylocoformer/babylocoformer/tasks/manager_based/babylocoformer)

### 2.4 发现的问题与采用方式

| 源码证据 | 对复现的影响 | 本项目处理 |
| --- | --- | --- |
| ActorCriticTransformerXL.reset() 为 pass，清理缓存的代码被注释 | 物理结束时历史保留，但缺少可确认的任务边界隔离，不能当作完整跨 Trial 协议 | 独立维护 trial_end、task_end 与时间截断，按 task_end 清理缓存 |
| transformerxl_batch_generator() 保留整段 rollout，只 yield 一批，mask 返回 None | 没有形成通用的多轮、多 minibatch 有序训练接口 | 实现明确的序列分块、有效位、缓存初始化和多轮语义 |
| PPO 调用策略 reset(dones)，但策略 reset 为空 | 若任务变化可能错误共享历史 | 为任务标记增加单独通路，不能直接复用一个 done |
| 训练阶段沿用状态缓存 | 更新后的参数与已有缓存的对应关系需要复核 | 固定并验证重算/burn-in 规则 |
| setup 声明 Isaac Sim 4.5/5.0，未提供本项目 5.1 的验证证据 | API 兼容需要检查 | 基于所选平台移植模块，先过接口与初始化测试 |
| README 的转换命令写成 convert_to_usd.py.py，实际文件为 convert_to_usd.py | 文档命令不可逐行照搬 | 依据固定源码确认入口 |

这次是静态检查，以上问题尚未通过运行验证。选择其 TXL 基本计算作为首选参考，是因为它与 Isaac Lab/RSL-RL 的数据接口接近。借用的部分须保留许可证、来源和修改记录。[Actor/Critic](https://github.com/linden713/rsl_rl_transformer_xl/blob/ca906f2161e9a7244d1bfee923cf57f6da0a259b/rsl_rl/modules/actor_critic_transformerxl.py) · [storage](https://github.com/linden713/rsl_rl_transformer_xl/blob/ca906f2161e9a7244d1bfee923cf57f6da0a259b/rsl_rl/storage/rollout_storage.py)

## 3. GenBot1K 能否只复用资产

可以。资产描述身体，观测、策略、奖励和动作接口可由本项目实现。采用其身体文件不要求使用其专家蒸馏训练方法。

### 3.1 本轮压缩包检查结果

已通过内存读取固定提交的 GenBot1K.zip，检查目录和配置，未运行仿真。压缩文件 19,057,535 字节，条目 12,145 个，解压内容总计 64,575,569 字节。包含 1,012 份 URDF、2,022 份 USD、4,048 份 JSON；USD 包含附属资源，数量不能当作机器人数量。

顶层为 gen_dogs、gen_humanoids、gen_hexapods。样例四足配置 action_space=16，包含额外膝关节，说明 16 动作也可能是纯腿式身体。不能仅根据动作维数判断是否轮足。

包中有 robot.urdf、robot_description_vec.json、train_cfg.json、train_cfg_v2.json、usd_file/robot.usd 等。检查了一个配置样例，全部资产的拓扑、相对依赖和可加载性仍需批量核验。[固定资产包](https://github.com/BoAi01/embodiment-scaling-laws/blob/62e43ce01b07487f83a108122de66e56c428549e/exts/embodiment_scaling_laws/embodiment_scaling_laws/assets/Robots/GenBot1K.zip)

### 3.2 接入需要做什么

1. 扫描关节数量、轴、父子关系、限值、质量和初始姿态，生成资产清单。
2. 筛选四腿、每腿能映射到已定义语义槽的子集。多膝、六足和不能匹配的关节先排除并说明原因。
3. 检查 USD 相对资源，必要时用所选版本重新从 URDF 导入。
4. 将参考姿态、控制增益和关节限值迁移到当前资产配置。
5. 为每个身体建立映射，统一观测与动作解码。
6. 按拓扑分组建仿真环境，各组统一编码后汇集到共享策略训练。
7. 留出完整身体进行评测，防止只检验相同身体的参数扰动。

上游 go2_cfg.py 仍使用 omni.isaac.lab 命名，不能保证直接导入本项目的 isaaclab 命名版本。生成脚本存在作者机器的绝对路径，需要改为参数。主训练路线借鉴资产与元数据，不整体迁移其旧训练框架。[生成器](https://github.com/BoAi01/embodiment-scaling-laws/tree/62e43ce01b07487f83a108122de66e56c428549e/generation)

### 3.3 难度与工作量

对经过筛选的少量同拓扑四足，资产检查、导入、映射与初步控制约需 5–10 个主动工作日，前提是基线和接口已经可用。若扩展到不同关节拓扑、双足与复杂碰撞，需额外数周以上。估计包含调试，不包含训练等待，也不保证收敛。

GenBot 解决的是资产与部分元数据准备，剩余训练工程仍需实现。上游约 4 TB 的数字指蒸馏采集数据，不是本轮检查的模型资产包；采用直接 PPO 路线无需先生成这份蒸馏数据。资产和代码的再分发许可需在发布前逐项核对，不能从论文公开推定所有文件可任意重发。

## 4. 三种统一观测方案怎样选

| 项目 | 原始对象与方式 | 与 LocoFormer 的距离 | 本项目选择 |
| --- | --- | --- | --- |
| MetaMorph | Unimal 多形态模块机器人，逐肢体输入、结构信息、padding 和掩码 | 提供补齐与动作过滤的具体实现，但原有节点/结构输入与固定语义向量有差异 | 首选接口参考，借鉴掩码与有效动作概率处理 |
| URMA | 多种足式身体，含 Go2 等；逐关节状态和形态描述，经共享编码与解码 | 显式使用身体结构描述，网络设计与 LocoFormer 有差异 | 作为结构感知对照和元数据参考 |
| 本地 lucidrains/locoformer | README 用虚构 32/16 维观测和 12/6 动作；不同 MLP 路由到共享特征 | 输入适配器演示清楚，但不能代表原文固定槽位实现 | 用于理解适配器和输出 selectors |

本项目选择统一语义槽位加存在掩码，MetaMorph 用来参考工程处理。保留一个共享输入 MLP，避免每新增一类身体就新增未训练的输入分支。映射由设备配置完成，首轮 Actor 不额外输入型号 ID。

MetaMorph、URMA 和 lucidrains 分别固定快照为 d49826475d4d22d8e63df694785833dc127c4e8d、7c1819444028c529b0a964fe3f32878333b1310a，以及本地文件哈希（见第 7 节）。[MetaMorph 封装](https://github.com/agrimgupta92/metamorph/blob/d49826475d4d22d8e63df694785833dc127c4e8d/metamorph/envs/wrappers/multi_env_wrapper.py) · [URMA](https://github.com/nico-bohlinger/one_policy_to_run_them_all/tree/7c1819444028c529b0a964fe3f32878333b1310a)

## 5. 自己定义输入合同难在哪里

写填槽和取槽的代码较容易，确定每个槽的物理意义并保证训练部署一致更费时。关节名字相似不等于轴向、零位和正方向相同。存在任意倾斜关节轴时，简单乘一个正负号可能不够，应做坐标审查或将该身体排除出当前合同范围。

项目合同 v1 拟采用 FR、FL、RR、RL 四个腿块，每块依次为 hip_roll、hip_pitch、hip_yaw、knee_pitch、ankle_roll、ankle_pitch、wheel，共 28 槽。顺序属于项目选择。源文件注释支持四腿七槽的思路，作者逐项顺序与最终权重规格仍未确认。

| 字段 | 维度 | 合同规则 |
| --- | --- | --- |
| 机身角速度 | 3 | 统一机身坐标与缩放 |
| 投影重力 | 3 | 统一姿态约定，先用静止数据检查 |
| 速度命令 | 3 | x/y 线速度和 yaw 角速度，单位与范围固定 |
| 相对关节位置 | 28 | 统一方向，减参考姿态后缩放；连续轮位置先置零 |
| 关节速度 | 28 | 按语义槽填入并缩放 |
| 上一原始策略动作 | 28 | 轮、腿使用各自无量纲槽，缺失位为零 |
| 存在掩码 | 28 | 存在为 1，缺失为 0 |
| Trial 重置标记 | 1 | 标记新一次身体尝试，Episode 内历史可保留 |
| 合计 | 122 | 项目自定输入；与作者注释中的 117 维区分 |

确定性物理缩放优先于在线运行均值作为首轮基线，参数写入 checkpoint 元数据。缺失值在所有变换后保持零，mask 不参与数值标准化。可学习/运行归一化后续作为独立改动，避免缺失槽被均值污染。

对 Go2 的三个腿关节，分别映射到 hip_roll、hip_pitch、knee_pitch。Go2-W 再加入 wheel。设备配置同时保存 axis/sign、offset、q_ref、position_scale、velocity_scale、action_scale、限值与控制类型。

验收包括随机数编码解码往返、单关节扰动、缺失槽不变、符号与零位对齐、仿真和实机日志同输入同输出。第一对 Go2/Go2-W 的合同约需 3–7 个主动工作日；额外身体按拓扑复杂度追加。此为规划估计。

## 6. 中间网络与动作输出的最终选择

主网络为共享观测编码 → TXL → Actor/Critic。先做小网络和短序列的正确性验证，再增加到论文示例的层数与段长。网络宽度、层数和记忆长度作为项目参数记录，原文示例的 6 层和 128 段长不等于启动时必须使用的规模。

| 候选 | 可复用部分 | 需要改造 | 结论 |
| --- | --- | --- | --- |
| Baby TXL/RSL-RL | 因果注意力、KV 状态、流式/序列形状、Actor/Critic 接口 | 任务隔离、序列 PPO、多轮缓存与掩码 | 首选小模块参考 |
| 本地 lucidrains | XL 缓存、episode_id 遮罩、StateEmbedder、动作 selectors、PPO 示例 | 包依赖、非标准损失/附加模块、Isaac Lab 接线 | 对照参考，首轮不整体安装 |
| 配套 RSL-RL 普通策略 | 采集、GAE、PPO、保存加载和分布式基础设施 | TXL 与顺序序列接口 | 保留为稳定基线 |
| URMA 策略 | 可变关节共享编码/解码 | 结构描述输入、网络和训练目标路线不同 | 后续对照 |

输出固定 28 维无量纲动作，adapter 按表提取。腿经尺度与参考姿态得到位置目标，轮经独立尺度得到速度目标。该混合动作合同用于项目 Go2-W 基线，作者轮槽解码仍以未知项记录。

动作提取可参考 MetaMorph 的 action()、本地 selectors，以及 Robot Lab 的 JointPositionAction/JointVelocityAction。首选使用项目映射表和 Robot Lab 物理动作解码。训练时按有效维度计算 log-prob、熵和 KL；Actor 输出无效维度可置零，未使用动作惩罚另设可选项。变更损失规则必须明确归为项目实现。

动作取索引一般 1–3 天可完成，包含轮腿单位、概率掩码、缩放、限值和验证的完整接口更接近 3–7 个主动工作日。与输入合同同时开发可减少重复工作，估计不能简单相加。

## 7. 本地 locoformer 到底实现了什么

审查对象为 G:/毕设/03_code/locoformer，pyproject 版本 0.4.0，作者 Phil Wang/lucidrains，MIT 元数据。它是第三方通用研究库，包含比原论文更多的可选机制。

| 部分 | 本地位置 | 已观察到的作用 |
| --- | --- | --- |
| StateEmbedder | locoformer.py，1153 行起 | 不同输入维度用不同 MLP，state_id 路由 |
| Attention / TransformerXL | 554 / 725 行起 | 因果与 Episode 遮罩、KV 缓存、段间 detached 状态 |
| Locoformer | 1406 行起 | Actor/Critic、动作分布与附加模型组合 |
| ppo() | 1898 行起 | 策略、价值和熵等训练计算，包含多种可选更新规则 |
| get_stateful_forward() | 2373 行起 | 带状态的逐步推理入口 |
| train_microduck.py | 588 行起 | MuJoCo 并行采集、PPO、多轮更新、评估与存档 |
| tests/test_locoformer.py | 测试文件 | 库级行为检查，不能替代 Go2-W 控制验收 |

Microduck 默认 12 环境、每环境 256 步、4 轮更新、1 层 dim=64、段长 16。它使用 Beta 连续动作和 HLGauss 价值损失，入口还有 forced_swing=0.45 的辅助设置。不能把示例训练结果直接归为标准 LocoFormer 的自主多本体适应。

Microduck 采集时 term|trunc 后增加 ep_id，并在每批 update 开始重建 stateful_forward。默认路径不构成论文式跨 Trial、同任务保留历史的完整训练协议。库的 use_cross_episode_attention 默认 False，该开关还关联独立 Actor 分支，不能简单打开后允许跨任意任务读取。

pyproject 要求 torch>=2.8，而已选 Isaac Lab 分支的安装脚本使用 torch 2.7.0。直接安装可能升级 PyTorch 并改变仿真依赖，因此选取算法思路与必要小模块，先保留一致的软件栈。

本地快照 SHA-256 如下，后续文件变更需重新记录。

| 文件 | SHA-256 |
| --- | --- |
| pyproject.toml | 598becfbeee9496a071028f38a85c54cd330a10f5bb88718db3eeb4e68620766 |
| locoformer/locoformer.py | d32e02348efb5d9ea4c580b7e3e51e5d6d65c28c8daa14101947b5d0387741a8 |
| train_microduck.py | a96a5a89921e3b63223d6191075810f17b1bece9bba6e53838243a8e9ef90534 |

价值在于帮助理解网络和训练细节，并提供实现对照。Go2-W 环境、28 槽语义表、原文形态生成器、作者 checkpoint、精确评测协议和 SDK 部署仍需本项目实现。[本地库](../../../03_code/locoformer/locoformer/locoformer.py) · [训练入口](../../../03_code/locoformer/train_microduck.py)

## 8. 算力、最终效果与部署难度

服务器双 RTX PRO 5000 Blackwell 各约 48 GB，适合做模型验证、普通 PPO 和逐步扩大的长历史实验。未运行 GPU 仿真与训练前，能承载多少环境、多久收敛尚无实测依据。

| 目标 | 判断 | 原因 |
| --- | --- | --- |
| 平台与统一接口正确 | 可安排明确验收 | 大部分是确定性工程检查 |
| 缩小规模历史训练 | 有可实施路线 | 需实验确认训练稳定性和资源 |
| 跨 Trial 收益 | 研究结果待验证 | 记忆、任务分布、奖励与训练预算共同决定 |
| 未见身体泛化 | 难度高 | 形态覆盖和留出测试决定结论 |
| 原论文完整效果 | 目前不能承诺 | 原作者训练规模和配套配置尚未对齐 |
| Go2-W 实机闭环 | 独立工程阶段 | 依赖输入对齐、控制参数、实时性和实际策略质量 |

训练环境数和资产数分别登记。先以小规模身体集验证，再增加覆盖；全部 GenBot 资产同时加载并非必要。不同拓扑按组仿真，统一编码后共享策略参数，跨组汇集 PPO 数据；不能假设把文件放进同一场景就能自动得到一致关节张量。

实时部署只运行必要策略与缓存，训练用 Critic 和优化器通常不进入控制路径。以 50 Hz 为目标时，每周期 20 ms 要容纳数据处理、推理、通信与执行。服务器 SSH 穿透用于管理，实机需要可验证的设备网络和本地控制周期。

## 9. 对作者缺失资料的处理决定

作者原版资源继续保留已核实的缺口清单。下一阶段开发以公开描述和本项目合同推进，不以取得作者代码作为开工前提。作者实现、第三方参考和项目设计在报告中分别标注。

可保证的交付是可审查实现、清晰实验协议与可复测结果。能否达到原论文的泛化和适应性能，需要训练与评测证据。相关任务和工作量见[执行计划](01_reproduction_plan.md)。

## 10. 十个问题的定位

| 用户问题 | 对应章节 |
| --- | --- |
| Baby 实现及论文关系 | 2 |
| GenBot 资产接入、难度与工作量 | 3 |
| 三种观测方案与首选 | 4 |
| 方向、归一化与输入合同 | 5 |
| 策略层参考与最终效果 | 6、8 |
| 动作选择参考与难度 | 6 |
| 兼容审查与最终路线 | 1、2.4、7、执行计划 |
| 缺失项的替代决定 | 9 |
| 本地 locoformer 实现与价值 | 7 |
| 最终文档和计划 | 本文及执行计划 |
