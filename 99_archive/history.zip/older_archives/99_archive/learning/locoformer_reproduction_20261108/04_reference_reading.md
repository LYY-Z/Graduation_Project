# LocoFormer 与 Go2-W 复现参考资料

实验主平台为 **Go2-W**。最新逐项目审查与最终选择见[实现审查](07_implementation_audit.md)，本文保留按主题查阅的资料。阅读顺序为 **原论文证据 → 统一关节接口 → 多本体训练 → 在线适应 → Go2-W 仿真和评测**。普通 Go2 资料用于足式对照。权重条目表示已定位文件或作者给出的下载入口，运行和兼容性仍需验证。

环境还没搭好时，先读[从零搭建与接口入门](00_start_here.md)。指南从服务器上加载 Go2-W 模型开始，接着试跑参考策略、准备 Isaac Lab，再在设备网络可用时读取实机状态。本文用于查词和按问题读论文。各资源的出处、复用边界与检索状态集中见[资源核查](06_resource_audit.md)。

## 0. 先读懂文档中的英文和方法名

想象你给 Go2-W 一个「向前走」的指令。程序会读机身和关节数据，再计算腿怎么摆、轮子怎么转。下面的术语分别指这条链路中的不同部分。

| 文档里的词 | 用 Go2-W 理解 |
| --- | --- |
| **Observation，观测** | 策略这一步拿到的一组数字，比如机身角速度、关节角度、轮速、前进指令和上一次的动作。57 维表示配置里排列了 57 个数字。 |
| **Action，动作** | 策略给出的控制数值。Go2-W 的参考策略输出 16 个数，程序按配套配置换算为 12 个腿位置目标和 4 个轮速度目标。这个换算叫**动作解码**。 |
| **Policy，策略** | 从观测和可用历史算出动作的规则。一次实际控制中，它每隔一段固定时间重新算动作。 |
| **Training / Inference，训练 / 推理** | 训练时，程序根据大量试跑结果更新策略参数。推理时，使用已有参数给当前观测算动作。 |
| **Checkpoint，训练存档；权重文件** | 保存学到的模型参数。训练存档有时还保存优化器等恢复训练所需的内容。用公开策略时，同时要看配套配置，确认每个输入和输出的含义。 |
| **URDF / MJCF / MuJoCo / Isaac Lab** | URDF 和 MJCF 是描述机器人结构的文件格式。MuJoCo 是可以加载 MJCF 并计算机器人运动的仿真器。Isaac Lab 提供训练环境和工具。 |
| **SDK / IMU / PD** | SDK 是程序与设备通信的开发接口。IMU 是机身惯性传感器，能提供角速度和加速度等信号。PD 是底层控制的一种方式，根据位置或速度偏差等信息生成电机控制量。 |
| **Slot / Mask / Padding，槽位 / 掩码 / 补齐** | 槽位是指定关节应填入的固定位置。掩码记录该格是否有效。普通 Go2 缺轮，轮槽补零并标为缺失。Go2-W 的轮子即使静止，也有轮关节，存在掩码标为有效。 |
| **Trial / Episode / Segment / KV cache** | 在 LocoFormer 的任务组织中，Trial 是一次尝试，Episode 可包含同一任务下的多次尝试。Segment 是为网络计算切出的连续数据段。KV cache 保存注意力计算需要的近期历史表示。 |
| **Baseline / Benchmark / Ablation** | Baseline 是拿来比较的对照策略。Benchmark 是规定测试任务和计分方法的一套流程。Ablation 是只改一个因素的对照，例如用同一权重比较保留或清空历史。 |
| **Domain randomization / Sim-to-real** | 前者是训练时在仿真中变换质量、摩擦等条件。后者是把仿真里训练好的策略迁移到实机运行。 |
| **Zero-shot / Few-shot** | 在 LocoFormer 的主表中，zero-shot 直接进入正式计分，few-shot 先给 5 秒交互机会，再开始计分。这里的交互通过历史影响动作，模型权重固定。读其他论文时，要核对 few-shot 指额外交互还是用少量数据微调权重。 |

### 其他策略方法分别在解决什么

这些名字出现在不同层面。比如 **PPO 是训练方法**，**MLP、GRU、Transformer-XL 是可以用来搭建策略的网络**。因此，同一个项目可以用 PPO 训练 Transformer-XL 策略。

| 方法 | 先这样理解 | 阅读重点 |
| --- | --- | --- |
| **普通 PPO 对照** | 仿真里先让机器人试走，根据走得稳不稳、速度跟得准不准给奖励。PPO 用这一批经历更新策略，再采新经历。第一份对照可用 MLP，即多层感知机，把当前观测直接算成动作。 | 先看仿真怎样给奖励、策略怎样更新。[PPO 原论文](https://arxiv.org/abs/1707.06347) |
| **GRU / Conditioning / Expert** | 这是 LocoFormer 主表里的三个对照。GRU 把过去的信息逐步压进隐藏状态。Conditioning 把已知运动学信息给策略，并限制历史窗口为 64 步。Expert 针对目标机器人单独训练。 | 比较时问清三件事。它知道什么、能看多长历史、训练时是否见过目标机器人。[LocoFormer §3.1](https://arxiv.org/html/2509.23745v1) |
| **RMA / LocoFormer** | 都可用过去的反馈调整下一步。RMA 用一个额外模块从近期历史估计一组表示当前条件的数字，再把结果交给基础策略。LocoFormer 用 Transformer-XL 读取历史，同一任务里还可以带着之前尝试的记忆。 | 想象轮子驱动能力改变。先看策略拿到哪些反馈，再看它怎样用这些反馈改变动作。[RMA](https://arxiv.org/abs/2107.04034) · [LocoFormer](https://arxiv.org/html/2509.23745v1) |
| **XHugWBC / H-Zero / MetaMorph / URMA** | XHugWBC 和 H-Zero 按关节含义做固定位置映射。MetaMorph 的代码展示如何补齐不同长度的肢体数据、再过滤无效动作。URMA 给实际关节逐个提供状态和结构描述，并逐关节产生动作。 | 先看 XHugWBC 的索引表，再看 MetaMorph 的 `observation()` 和 `action()`。源码位置在第 2 节。 |
| **GenLoco / Embodiment Scaling Laws** | GenLoco 在不同形态的四足上训练共享控制。后者先给各机器人训练专用的「教师」策略，再把教师的行为教给一个共享的「学生」策略，这叫蒸馏。 | 想弄懂「训练时怎样让策略见过不同身体」，再看第 3 节。 |
| **Multi-Loco / MoE** | Multi-Loco 用扩散模型产生一份候选动作，再用强化学习训练的小策略修正它，修正量叫残差。MoE 是混合专家模型，由一个选择模块决定输入更依赖哪些子网络。RoboGauge 配套 Go2 策略是后者的一个例子。 | 扩散动作可联系你学过的 Diffusion Policy。Go2 对照权重和评测入口见第 5 节。[Multi-Loco](https://multi-loco.github.io/) · [RoboGauge 配套论文](https://arxiv.org/abs/2602.00678) |

第一次可以先读完本节，接着做[执行计划的里程碑](01_reproduction_plan.md#5-分阶段任务与验收)。读到历史策略时，再回来看第 4 节。遇到某个项目名，可以先只看它在表里对应解决的问题。

## 1. 先确定原论文已经交代了什么

| 资料 | 可以确认的内容 |
| --- | --- |
| [CoRL 正式论文](https://proceedings.mlr.press/v305/liu25a.html) · [项目页](https://generalist-locomotion.github.io/) · [Skild AI 技术博客](https://www.skild.ai/blogs/omni-bodied) | 共享策略使用统一关节空间，各机器人取自己的动作。Transformer-XL 使用交互历史，同一任务的多次尝试可以共享记忆。 |
| [arXiv v1 LaTeX 源包](https://arxiv.org/src/2509.23745v1) | `main_camready.tex` 第 114、152 行的注释记载最多 4 条腿，每条 7 个关节槽位，缺失关节状态填零并提供存在掩码。网络规格写为 117 维观测、256 维 token、8 个注意力头和 28 维动作。最终评测权重是否沿用这组规格仍需作者或配套配置确认。 |
| [OpenReview 官方附件](https://openreview.net/attachment?id=VqmAvBkFhw&name=supplementary_material) · [本地附录](<../../../03_code/50_LocoFormer_Generalist_Locom_Supplementary Material/LocoFormer_Appendix.pdf>) · [本地视频](<../../../03_code/50_LocoFormer_Generalist_Locom_Supplementary Material/CoRL_locoformer.mp4>) | 附录 §A.1–A.4 说明四类本体如何生成，给出域随机化最大范围、未使用关节动作惩罚及训练规模。训练共 128 张 GPU，每卡 2,048 个并行环境，四足、轮足四足、双足、轮足双足按 1∶1∶3∶3 分配。附录列了 13 项共享奖励和 14 个系数，逐项配对需要原配置。视频展示跨次尝试、轮锁止和 Go2 单膝锁止等案例。 |

原策略运行仍缺作者权重、Go2／Go2-W 的槽位索引、观测字段顺序与归一化，以及动作解码。对齐主论文 Table 1 还需要十种未见本体的测试资产、评测脚本及位移归一化定义。主表统计朝目标方向的归一化位移，few-shot 使用 5 秒预评估交互。会议报告另有[官方日程](https://2025.corl.org/program/main-conference)和[当天回放](https://www.youtube.com/watch?v=9lzFVQoc4Do)，报告段落与问答待核对。[论文 §3.1](https://arxiv.org/html/2509.23745v1)

## 2. 统一接口怎样写

先给每个槽位规定关节语义，再为每台机器人建立实际关节与槽位的映射。输入时按表填位置、速度和存在掩码，输出时按表取有效动作，并依据该机器人配置解码。**关节位置恰好为零和关节缺失，可以通过存在掩码区分。** 同一槽位还要统一正方向和零位。

| 阅读顺序 | 参考资料 | 重点 |
| --- | --- | --- |
| 1 | [XHugWBC §3.2、§3.3、v3 表 8](https://arxiv.org/html/2602.05791v3) | 最直接的固定槽位例子。作者公开了 32 个全局关节索引及转轴方向，缺位填零，再按逆映射恢复实际动作。表中的编号用于该人形系统。 |
| 2 | [MetaMorph 环境封装](https://github.com/agrimgupta92/metamorph/blob/d49826475d4d22d8e63df694785833dc127c4e8d/metamorph/envs/wrappers/multi_env_wrapper.py#L85-L160) · [PPO 模型](https://github.com/agrimgupta92/metamorph/blob/d49826475d4d22d8e63df694785833dc127c4e8d/metamorph/algos/ppo/model.py#L187-L245) | 实际代码按肢体补零，生成 padding 掩码，过滤动作，并在求和前清除无效维度的对数概率贡献。这里的 padding 掩码用 `True` 表示填充位。训练时忽略无效动作的概率项，与 LocoFormer 附录中惩罚未使用动作属于两项设计。 |
| 3 | [H-Zero §IV-A，公式（2）–（3）](https://arxiv.org/html/2512.00971v1#S4.SS1) | 同一张映射如何完成状态填入与动作取回，以及如何处理关节正方向和零位偏差。 |
| 4 | [宇树 Go2 映射配置](https://github.com/unitreerobotics/unitree_rl_mjlab/blob/1425b15f73bd4095f0df53709d7c389c3eb9e790/deploy/robots/go2/config/policy/velocity/v0/params/deploy.yaml#L1) · [读取状态](https://github.com/unitreerobotics/unitree_rl_mjlab/blob/1425b15f73bd4095f0df53709d7c389c3eb9e790/deploy/include/unitree_articulation.h#L37) · [写回电机](https://github.com/unitreerobotics/unitree_rl_mjlab/blob/1425b15f73bd4095f0df53709d7c389c3eb9e790/deploy/robots/go2/src/State_RLBase.cpp#L28) | 真实部署中的双向索引。配置第一项为 `3`，策略第 0 格读取 SDK 3 号电机状态，解码后的第 0 项再写回同一电机。 |
| 5 | [Multi-Loco §2.1、图 2](https://proceedings.mlr.press/v305/yang25a.html) · [方法图](https://multi-loco.github.io/) · [URMA 论文](https://arxiv.org/html/2409.06366v4) · [URMA 策略源码](https://github.com/nico-bohlinger/one_policy_to_run_them_all/blob/7c1819444028c529b0a964fe3f32878333b1310a/one_policy_to_run_them_all/algorithms/uni_ppo/ppo/policy.py#L40-L97) | Multi-Loco 用补零、掩码扩散训练与残差 PPO，适合联系 Diffusion Policy。URMA 用关节描述和共享的逐关节计算处理可变数量的关节。两篇分别给出了补齐维度和逐关节解码的例子。 |

**Go2-W 的轮子需要单独核对动作含义。** 所核对的 Robot Lab 配置中，腿关节使用目标位置，轮关节使用目标速度。轮关节在该配置中命名为 `*_foot_joint`。LocoWheeledLegged 也提供 Go2-W 速度动作和部署配置。写映射表时可以把**槽位索引、实际关节名、控制类型、比例和偏移**一起记录。上述轮速接口属于这两个参考实现，LocoFormer 原版轮槽的解码规则仍待确认。[Robot Lab 源码](https://github.com/fan-ziqi/robot_lab/blob/26acb225aad129e222da7a34ba11f39e29b73e39/source/robot_lab/robot_lab/tasks/manager_based/locomotion/velocity/config/wheeled/unitree_go2w/rough_env_cfg.py#L98-L108) · [LocoWheeledLegged 中文说明](https://github.com/zhaozijie2022/LocoWheeledLegged/blob/main/README_CN.md)

## 3. 多本体策略怎样训练

| 资料 | 从哪里读起 |
| --- | --- |
| [GenLoco 论文](https://arxiv.org/abs/2209.05309) · [作者源码与权重](https://github.com/HybridRobotics/GenLoco#adding-new-robots) | 从 A1 关节命名、方向和初始姿态配置入手，再看程序化生成四足及参考步态训练。适合理解相近的四足之间怎样共享控制。 |
| [Embodiment Scaling Laws 论文](https://proceedings.mlr.press/v305/ai25a.html) · [GenBot1K 与训练说明](https://github.com/BoAi01/embodiment-scaling-laws#expert-training) · [生成器](https://github.com/BoAi01/embodiment-scaling-laws/tree/main/generation) | 有约千种本体的资产包、URDF 生成和评测脚本。先分别训练专家，再蒸馏到一个共享策略。仓库列出专家与共享策略权重入口，适合学习如何划分训练机体和整机留出测试。 |
| [BabyLocoFormer](https://github.com/linden713/BabyLocoFormer/tree/f2dadf8eb13826f449387ecc9970593a9af141bc) · [第三方 LocoFormer 本地源码](../../../03_code/locoformer/README.md) | BabyLocoFormer 可读四足生成、Isaac Lab、Transformer-XL 风格训练与 Go2 评测入口，公开快照未见权重。lucidrains 仓库可读 Microduck 的 PPO 训练、历史处理及 `selectors` 示例，示例的输入编码和输出索引属于其第三方设计。 |
| [Legged Gym 论文](https://proceedings.mlr.press/v164/rudin22a.html) · [训练源码](https://github.com/leggedrobotics/legged_gym) | 先追一遍普通四足如何并行采集、计算奖励和更新 PPO，作为读长历史训练代码的基础。 |

与可变关节表示相关的拓展包括 [MetaMorph 与 Unimal-100](https://github.com/agrimgupta92/metamorph#benchmark) 的多形态基准、[SMP](https://github.com/huangwl18/modular-rl) 的执行器模块和消息传递、[AnyMorph](https://github.com/montrealrobotics/AnyMorph) 的形态推断和 [Body Transformer](https://sferrazza.cc/bot_site/) 的身体图注意力。先完成统一槽位与历史适应的主线，再按研究需要扩展阅读。

## 4. 怎样让历史影响动作，并验证它真的有用

| 资料 | 要解决的问题 |
| --- | --- |
| [RMA 原论文](https://arxiv.org/abs/2107.04034) · [Walk These Ways 历史窗口](https://github.com/Improbable-AI/walk-these-ways/blob/0e7236bdc81ce855cbe3d70345a7899452bdeb1c/go1_gym/envs/wrappers/history_wrapper.py#L17-L41) · [推理源码](https://github.com/Improbable-AI/walk-these-ways/blob/0e7236bdc81ce855cbe3d70345a7899452bdeb1c/go1_gym_learn/ppo_cse/actor_critic.py#L128-L139) | 历史如何变成网络输入。先看 Go1 的实现如何每步移出最旧观测、加入最新观测，再看适应模块如何把窗口压成向量供 Actor 使用。 |
| [RL²](https://arxiv.org/abs/1611.02779) · [Transformer-XL](https://arxiv.org/abs/1901.02860) | RL² 解释为什么同一任务重置环境后仍可保留策略记忆。Transformer-XL 解释怎样把上一段的表示传给下一段。回到 LocoFormer 时，分别检查 Trial 边界、任务边界和计算分段边界。 |
| [MetaLoco](https://arxiv.org/abs/2407.17502) · [SGMA](https://arxiv.org/abs/2502.01521) · [SGMA 实验与实现说明](https://sites.google.com/view/eth-sgma) | MetaLoco 将程序化四足、记忆和动作模仿结合，适合看记忆的消融。SGMA 用对称性增强交互数据及记忆状态，适合参考关节故障实验和少交互条件下的训练。 |
| [Rapid Embodiment Adaptation 论文](https://arxiv.org/abs/2608.01506) · [Go2 实验页](https://embodiment-adaptation.github.io/) | Go2 上如何设计关节活动范围变化和负载扰动对照。该方法先用短历史估计硬件参数，再让策略使用估计结果。项目页提供实验，未见官方代码入口。 |

**同一 Go2-W 改变负载、关节活动范围或轮驱动条件**，检验在线适应。**换成训练中留出的整机**，检验跨本体泛化。验证跨 Trial 记忆时，固定同一 checkpoint、初始条件和计分时间，只切换物理重置后保留或清空历史，记录位移、跌倒、恢复时间和试验数。[复现计划](01_reproduction_plan.md)

## 5. 从哪份代码开始看 Go2 和 Go2-W

| 用途 | 可以打开的资源 |
| --- | --- |
| 仿真模型与官方接口 | [宇树 Go2 MJCF](https://github.com/unitreerobotics/unitree_mujoco/tree/1eb6642e3f3fdfb7fb13a9794fd6a2dd93ea0e7d/unitree_robots/go2) · [Go2-W MJCF](https://github.com/unitreerobotics/unitree_mujoco/tree/1eb6642e3f3fdfb7fb13a9794fd6a2dd93ea0e7d/unitree_robots/go2w) · [Go2 URDF](https://github.com/unitreerobotics/unitree_ros/tree/4005a1b0c3f464f515f380be4145cc617fbca725/robots/go2_description) · [Unitree SDK2](https://github.com/unitreerobotics/unitree_sdk2)。优先核对关节名、仿真驱动器顺序与 SDK 电机编号。 |
| Go2 平地策略和训练入口 | [NVIDIA Isaac Sim 策略示例](https://docs.isaacsim.omniverse.nvidia.com/6.1.0/robot_simulation/ext_isaacsim_robot_policy_example.html#policies-files) 列出 PhysX、Newton 各自的 Go2 策略和参数。训练环境可对照 [Unitree RL Lab](https://github.com/unitreerobotics/unitree_rl_lab) 与 [Unitree RL Mjlab](https://github.com/unitreerobotics/unitree_rl_mjlab)。 |
| Go2-W 策略和配置 | [Robot Lab 训练配置](https://github.com/fan-ziqi/robot_lab/tree/26acb225aad129e222da7a34ba11f39e29b73e39/source/robot_lab/robot_lab/tasks/manager_based/locomotion/velocity/config/wheeled/unitree_go2w) · [rl_sar 策略目录](https://github.com/fan-ziqi/rl_sar/tree/376d42c9b128f963ab08579762d5a216a976ce39/policy/go2w/robot_lab)。仓库树有 `policy.pt` 与 `config.yaml`，配置列出 57 维观测、16 个自由度及轮槽索引。该策略是 Go2-W 专用参考。另可对照 [LocoWheeledLegged](https://github.com/zhaozijie2022/LocoWheeledLegged) 和 [DreamWaQ Go2-W 的 Isaac Gym 实现](https://github.com/ShengqianChen/DreamWaQ_Go2W)。 |
| Go2 评测和现成对照策略 | [RoboGauge 论文](https://roboticsproceedings.org/rss22/p156.html) · [评测代码](https://github.com/wty-yy/RoboGauge) · [配套训练源码](https://github.com/wty-yy/go2_rl_lab) · [Go2 权重与配置](https://huggingface.co/wty-yy/go2_rl_gym_data)。可以参考不同地形、扰动下的速度跟踪、安全与动作质量指标，评分协议与 LocoFormer Table 1 分别记录。 |

第一次跟读可只打开 **XHugWBC 表 8、MetaMorph 的 `observation()` 和 `action()`、宇树 Go2 的 `joint_ids_map`、Robot Lab 的 Go2-W 动作配置**。先顺着一个膝关节和一个轮关节追完输入、输出，再看 PPO、长历史和评测。硬件细节与原论文证据分别见[Go2 硬件接口](02_go2_hardware_and_interfaces.md)和[教师追问](03_paper_questions_and_evidence.md)。

## 6. 与当前复现阶段对应的阅读任务

| 阶段 | 必读资料 | 应产出的理解或检查 |
| --- | --- | --- |
| M0–M1 | LocoFormer 正文与补充、官方 Go2-W MJCF/URDF | 区分原文目标和平台条件，解释 16/23/22 维 |
| M2–M3 | Robot Lab Go2-W、rl_sar config/base 与动作解码 | 追完一帧观测、一个膝动作和一个轮动作 |
| M4 | Transformer-XL、第三方 LocoFormer、序列 PPO | 说明缓存、SG、采集和多轮更新的关系 |
| M5 | RL²、RMA、LocoFormer 适应实验 | 明确 Trial 重置与任务重置，设计保留/清空配对 |
| M6 | BabyLocoFormer、GenLoco、URMA、MetaMorph | 比较生成器与共享关节接口，确定整机留出 |
| M7–M8 | Unitree SDK2、官方 Go2-W 示例 | 核对实机通信、单位、通道、延迟和控制模式 |

上述其它论文用于补充实现思路。LocoFormer 的 baseline 与 benchmark 仍按原文表格解释。原文未比较的相关方法，若加入自行实验，需要独立报告训练预算与输入条件。
