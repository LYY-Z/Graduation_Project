# 服务器环境与仿真启动

更新日期为 2026-11-07。本文记录服务器条件、软件分工、独立环境及后续验证步骤。已执行的结果列在第 2 节，安装方案列在第 3 节。

[文档导航](00_start_here.md) · [工作计划](01_reproduction_plan.md) · [资源证据](06_resource_audit.md)

## 1. 软件之间的关系

| 软件 | 作用 | 接收什么、产生什么 | 本项目用途 |
| --- | --- | --- | --- |
| Conda | 管理 Python 解释器和软件依赖 | 环境定义 → 独立 Python 环境 | 隔离个人实验依赖 |
| PyTorch | 搭建网络、计算梯度和更新参数 | 观测、动作、训练目标 → 推理结果和参数更新 | 实现 Actor、Critic、Transformer 与 PPO |
| Isaac Sim 5.1.0 | NVIDIA 机器人仿真器，含 PhysX 物理计算和渲染 | 机器人资产、控制目标 → 新状态、接触和传感器数据 | 计算身体在虚拟世界中的响应 |
| Isaac Lab v2.3.2 | 建立在 Isaac Sim 上的机器人学习框架 | 场景、观测、动作、奖励、重置配置 → 可并行运行的训练任务 | 组织大量环境，连接强化学习算法 |
| Robot Lab v2.3.2 | 基于 Isaac Lab 的第三方任务扩展 | Go2-W 资产配置与任务定义 → 平地、复杂地形速度跟踪任务 | 提供轮足机器人基线和接口参考 |
| RSL-RL | 强化学习训练库 | 仿真采集数据 → PPO 更新和 checkpoint | 先验证普通 PPO，再评估接入历史网络所需改造 |
| MuJoCo 3.3.7 | 另一种机器人动力学仿真器 | MJCF 模型、控制力矩 → 状态变化 | 模型检查和后续跨仿真器测试 |
| rl_sar | 第三方策略部署框架 | 机器人状态、策略权重、映射配置 → 电机目标 | 参考策略的 MuJoCo 闭环验证 |
| Unitree SDK2 | 宇树实机通信库 | DDS 状态与命令消息 | 读取实机并部署关节控制策略 |

例如训练一次 Go2-W 任务，Robot Lab 规定机器人、输入、输出和奖励；Isaac Lab 组织环境；Isaac Sim 计算物理变化；PyTorch 与 RSL-RL 用采到的经历更新网络。Isaac Lab 与 Robot Lab 的版本号恰好相同，它们由不同项目维护。

Robot Lab 提供的 Go2-W PPO 任务可以验证仿真平台。LocoFormer 的程序化身体、多 Trial Episode、跨 Trial 历史、Transformer-XL 与序列 PPO 仍需接入并验证。[Isaac Lab](https://github.com/isaac-sim/IsaacLab/tree/v2.3.2) · [Robot Lab 版本与任务说明](https://github.com/fan-ziqi/robot_lab/tree/v2.3.2)

## 2. 已核查的服务器与环境

| 项目 | 实际结果 | 核查时间与限制 |
| --- | --- | --- |
| 主机标识 | 服务器 3，RTXPro5000x2 | 2026-11-06 SSH 核查 |
| 系统 | Ubuntu 22.04.5 LTS，x86_64 | 同上 |
| GPU | 2 × NVIDIA RTX PRO 5000 Blackwell，各 48,935 MiB 显存 | 每卡约 47.8 GiB，标称约 48 GB |
| 驱动 | 580.178.04 | GPU 仿真初始化待验 |
| CPU | 96 个逻辑 CPU | 逻辑线程数，物理核心数待补录 |
| 内存 | 251 GiB 总量，检查时约 245 GiB 可用 | 可用量随其它作业变化 |
| 存储 | 工作目录所在卷检查时约 445 GiB 可用 | SSD 类型与磁盘配额待核对 |
| 解释器 | 系统 Python 3.10.12，共享 Conda base 为 Python 3.13.12 | 训练使用下面的个人环境 |
| Conda | /opt/miniconda3 | 默认 SSH PATH 未包含该目录 |
| 专用环境 | lyy_locoformer_go2w_py311 | 2026-11-07 通过 Conda 建立 |
| 环境位置 | ~/.conda/envs/lyy_locoformer_go2w_py311 | 位于当前账号目录 |
| 软件状态 | Python 3.11.18 与 pip 26.2.2 已验证 | MuJoCo、PyTorch、Isaac Sim 和 Isaac Lab 的安装属于后续步骤 |

环境通过 conda-forge 创建。名称由个人标识、研究主题、平台和 Python 版本组成。Conda 环境只隔离软件依赖，GPU 和内存仍由服务器作业共享。

本次创建命令如下，供环境重建时使用。

```bash
source /opt/miniconda3/etc/profile.d/conda.sh
conda create --prefix "$HOME/.conda/envs/lyy_locoformer_go2w_py311" \
  python=3.11 pip --override-channels --channel https://conda.anaconda.org/conda-forge
```

每次 SSH 登录后执行以下两行。

```bash
source /opt/miniconda3/etc/profile.d/conda.sh
conda activate lyy_locoformer_go2w_py311
```

核对所调用的 Python。

```bash
python -c "import sys; print(sys.executable); print(sys.version)"
python -m pip --version
```

解释器路径应指向该个人环境。工作目录用于存放代码和日志，当前激活的 Conda 环境决定运行代码的 Python。切换目录与切换环境是两种操作。

本次复核得到 Python 3.11.18、pip 26.2.2，解释器位于上述环境，`python -m pip check` 通过。

## 3. 后续安装与最小验证

以下为待执行方案。命令均在服务器上运行，先激活第 2 节环境。拟使用个人工作区 `~/dog_projects/locoformer_go2w`。下载完整仿真软件前，先核对磁盘余量、下载源和 GPU 占用。

### 3.1 先检查 MuJoCo 资产

```bash
mkdir -p ~/dog_projects/locoformer_go2w
cd ~/dog_projects/locoformer_go2w
python -m pip install mujoco==3.3.7
git clone --filter=blob:none --sparse https://github.com/unitreerobotics/unitree_mujoco.git
git -C unitree_mujoco sparse-checkout set unitree_robots/go2w
git -C unitree_mujoco checkout --detach 1eb6642e3f3fdfb7fb13a9794fd6a2dd93ea0e7d
```

加载模型、计算一步，检查 16 个执行器和浮动基座状态维度。

```bash
python - <<'PY'
import mujoco

model = mujoco.MjModel.from_xml_path(
    "unitree_mujoco/unitree_robots/go2w/scene.xml"
)
data = mujoco.MjData(model)
mujoco.mj_step(model, data)
print("actuators", model.nu, "qpos", model.nq, "qvel", model.nv)
for index in range(model.nu):
    name = mujoco.mj_id2name(model, mujoco.mjtObj.mjOBJ_ACTUATOR, index)
    print(index, name)
PY
```

预期维度为 16、23、22。成功后保存执行器名称和顺序。物理单步可在 SSH 中完成，模型查看器需要可用的图形会话；离屏录制则需另行验证 EGL 等渲染依赖。

### 3.2 准备训练框架

选用 Python 3.11、Isaac Sim 5.1.0、Isaac Lab v2.3.2、Robot Lab v2.3.2。PyTorch 版本按 Isaac Lab 对应分支的安装规则固定，Blackwell 还需验证 CUDA 构建支持。下列 PyTorch 2.7.0/cu128 与所核对 Isaac Lab 脚本相符，实际以安装结果和 CUDA 运算测试为准。

```bash
cd ~/dog_projects/locoformer_go2w
python -m pip install --upgrade pip
python -m pip install torch==2.7.0 torchvision==0.22.0 --index-url https://download.pytorch.org/whl/cu128
python -m pip install "isaacsim[all,extscache]==5.1.0" --extra-index-url https://pypi.nvidia.com
git clone --branch v2.3.2 --depth 1 https://github.com/isaac-sim/IsaacLab.git
cd IsaacLab
./isaaclab.sh --install rsl_rl
```

先通过 PyTorch 检查 CUDA 运算，再启动单卡无界面仿真。GPU 编号按执行时的空闲情况选取。

```bash
CUDA_VISIBLE_DEVICES=0 python -c "import torch; print(torch.__version__, torch.version.cuda); print(torch.cuda.get_device_name(0)); print((torch.ones(4, device='cuda') * 2).cpu())"
CUDA_VISIBLE_DEVICES=0 ./isaaclab.sh -p scripts/tutorials/00_sim/spawn_prims.py --headless
```

官方场景打印 `Setup complete` 后结束该进程。记录初始化日志和 GPU 显存。然后安装 Go2-W 任务扩展。

```bash
cd ~/dog_projects/locoformer_go2w
git clone --branch v2.3.2 --depth 1 https://github.com/fan-ziqi/robot_lab.git
cd robot_lab
python -m pip install -e source/robot_lab
CUDA_VISIBLE_DEVICES=0 python scripts/tools/list_envs.py --keyword Go2W
```

任务资产的配置引用 `source/robot_lab/data/Robots/unitree/go2w_description`。安装时须检查该目录中的 URDF 与网格是否齐全，并遵循该版本资产下载说明。任务成功注册与机器人资产成功加载分别验收。

```bash
CUDA_VISIBLE_DEVICES=0 python scripts/reinforcement_learning/rsl_rl/train.py \
  --task RobotLab-Isaac-Velocity-Flat-Unitree-Go2W-v0 \
  --num_envs 16 --max_iterations 2 --headless
```

两轮训练用于检查环境、采集、PPO 更新和 checkpoint 写入。之后还要重新加载 checkpoint，验证输入输出及闭环控制。单卡通过后，再测吞吐与峰值显存并决定并行规模。[Robot Lab 任务与安装](https://github.com/fan-ziqi/robot_lab/tree/v2.3.2) · [Isaac Lab 安装脚本](https://github.com/isaac-sim/IsaacLab/blob/v2.3.2/isaaclab.sh)

### 3.3 参考策略的 MuJoCo 验证

参考权重来自 rl_sar 的 Go2-W Robot Lab 目录。使用该权重时同时保留 base.yaml、config.yaml、模型资产和控制实现。

```bash
cd ~/dog_projects/locoformer_go2w
git clone --recursive https://github.com/fan-ziqi/rl_sar.git
cd rl_sar
git checkout --detach 376d42c9b128f963ab08579762d5a216a976ce39
git submodule update --init --recursive
./build.sh -mj
./cmake_build/bin/rl_sim_mujoco go2w scene
```

这一路线还依赖系统编译库与图形显示。先按该提交 README 核对依赖，实际编译和运行尚待完成。[rl_sar](https://github.com/fan-ziqi/rl_sar/tree/376d42c9b128f963ab08579762d5a216a976ce39)

## 4. 仿真、训练和部署各需要什么硬件

| 工作 | 条件 | 当前判定 |
| --- | --- | --- |
| 单个 MuJoCo 模型加载与物理单步 | Linux CPU、Python、模型与网格；此步骤不需要 RTX 渲染 | 服务器可作为验证平台，运行待验 |
| MuJoCo 交互显示 | 上述条件加 OpenGL 与图形会话 | 远程显示待配置 |
| Isaac Sim 5.1 | 官方 x86 最低表为 4 核、32 GB RAM、50 GB SSD、RTX 4080、16 GB VRAM、Linux 驱动 580.65.06 | 服务器资源和驱动满足列出的主要条件；CPU型号、存储类型与启动兼容性待验 |
| Isaac Lab PPO 训练 | 上述条件加训练的网络、采集缓存和优化器资源 | 初始 16 环境、2 次更新为本项目检查设置 |
| LocoFormer 长历史训练 | 还要为序列、历史缓存、网络宽度与更新轮数留预算 | 用实测吞吐、峰值显存估算，作者规模与双卡服务器分别记录 |
| Go2-W 实机推理 | 能稳定执行策略的计算设备、SDK 支持环境、机器人专用网络、可验证的控制周期 | 板载或外置计算尚未选定，需测推理与通信延迟 |

以上 NVIDIA 数据来自指定版本文档。双卡显存按每卡计算，分布式训练还需软件支持。服务器满足资源检查并不证明能承载作者全部训练规模。[Isaac Sim 5.1 系统要求](https://docs.isaacsim.omniverse.nvidia.com/5.1.0/installation/requirements.html)

## 5. 保存环境证据

每个里程碑保存环境与依赖清单。共享环境前检查导出文件中的个人路径。

```bash
conda env export --from-history > environment.yml
python -m pip freeze > requirements-resolved.txt
nvidia-smi
```

运行记录另外保存仓库提交、资产版本、checkpoint 哈希、命令、随机种子、GPU 编号和日志。SSH 登录口令由凭据管理工具保存。
