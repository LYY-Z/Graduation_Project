# Go2-W 硬件、关节与统一接口参数表

更新日期为 2026-11-07。本文供参数核对、研究汇报和后续部署使用。数据分为产品规格、模型声明、参考控制配置和实机实测四类。实机尚未核验的字段保留待确认。

[文档导航](00_start_here.md) · [工作计划](01_reproduction_plan.md) · [服务器条件](05_server_environment.md)

## 1. 数据来源与单位

| 来源 | 核对版本 | 用途 |
| --- | --- | --- |
| 宇树 Go2-W 产品页 | 2026-11-07 页面 | 外形、质量、速度、载荷与标配信息 |
| 宇树 Go2-W MJCF | unitree_mujoco，1eb6642e3f3fdfb7fb13a9794fd6a2dd93ea0e7d | 仿真拓扑、关节范围、执行器与传感器 |
| 宇树 Go2-W URDF | unitree_ros/master，2026-11-07 读取 | 关节类型、速度和力矩声明；该链接随上游更新 |
| 宇树 SDK2 Python | 814556d15970dd2ecf1c9984e845ca02ab07e206 | Go2-W 专用示例中的电机编号与消息接口 |
| Robot Lab | v2.3.2 | Isaac Lab 中的电机模型与动作配置 |
| rl_sar | 376d42c9b128f963ab08579762d5a216a976ce39 | 公开 Go2-W 策略观测、缩放与控制配置 |

角度用 rad，角速度用 rad/s，力矩用 N·m，长度用 m，质量用 kg。角度换算为 度=rad×180/π。URDF 与 MJCF 的坐标和命名通过对应表核对，数值差异见第 5 节。

原始入口为 [产品页](https://www.unitree.com/go2-w/)、[MJCF](https://github.com/unitreerobotics/unitree_mujoco/blob/1eb6642e3f3fdfb7fb13a9794fd6a2dd93ea0e7d/unitree_robots/go2w/go2w.xml)、[URDF](https://github.com/unitreerobotics/unitree_ros/blob/master/robots/go2w_description/urdf/go2w_description.urdf)、[SDK 编号](https://github.com/unitreerobotics/unitree_sdk2_python/blob/814556d15970dd2ecf1c9984e845ca02ab07e206/example/go2w/low_level/unitree_legged_const.py)。

## 2. 整机与计算条件

| 项目 | 公开数据 | 使用限制 |
| --- | --- | --- |
| 站立外形 | 约 0.70 × 0.43 × 0.50 m | 产品规格 |
| 含电池质量 | 约 18 kg | 装配后实测质量另记 |
| 载荷 | 约 8 kg，最大约 12 kg | 产品能力，具体实验载荷另定 |
| 整机速度 | 0–2.5 m/s | 产品能力，首测命令范围需单独设定 |
| 最大爬坡角 | 35° | 条件依厂商说明 |
| 越障高度 | 小于 70 cm | 产品能力，依地形与控制条件 |
| 电机 | 16 个 | 12 个腿关节、4 个轮关节 |
| 最大关节力矩 | 约 45 N·m | 指最大电机，16 路实际能力不同 |
| 轮胎 | 7 英寸充气轮胎 | 名义直径 0.1778 m，滚动半径受胎压和载荷影响 |
| 供电 | 33.6 V，电池 15,000 mAh | 续航标称 1.5–3 h |
| 基础计算 | 8 核 CPU | 具体型号与推理性能待实机登记 |
| 扩展计算 | 可选 Orin NX 等 | 本设备是否安装待确认 |
| 对外连接 | 产品页列 Wi-Fi 6、4G、蓝牙 | 低层控制网络与延迟另测 |
| 训练服务器 | 双 RTX PRO 5000 Blackwell，各约 48 GB；Ubuntu 22.04.5 | 详细资源与软件见环境文档 |

以上来自厂商[Go2-W 规格](https://www.unitree.com/go2-w/)。产品能力、仿真限值和实验允许范围分别保存。

## 3. 自由度与固定结构

每条腿包含髋外展/内收、髋俯仰、膝俯仰三个主动转动关节，以及一个主动轮电机。四条腿共有 16 个独立控制通道。固定外壳、相机和雷达连接不增加主动关节。所核对模型中没有需要另行驱动的随动腿关节。

机身在空间中有 6 个浮动自由度，依靠腿轮接触间接控制。MuJoCo 用 3 维位置和 4 维四元数表示基座姿态，因此模型 qpos 为 7+16=23 维，qvel 为 6+16=22 维，控制输入为 16 维。

轮关节可连续旋转。其累计角度和速度分别表示转过多少角、转得多快。采用速度控制的基线通常更关注轮角速度；输入中轮位置如何处理必须按训练实现固定。

## 4. 完整 16 路通道映射

下表将官方 MuJoCo 执行器顺序、SDK 示例编号与 Robot Lab 参考动作顺序对应。URDF 文件中的元素排列不作为策略顺序依据。FL/FR/RL/RR 依次表示左前、右前、左后、右后。

| 基线动作索引 | SDK 参考索引 | 物理部位 | URDF / Robot Lab 关节名 | MJCF 关节名 | 基线目标 |
| --- | --- | --- | --- | --- | --- |
| 0 | 0 | 右前髋外展 | FR_hip_joint | FR_hip_joint | 位置 |
| 1 | 1 | 右前髋俯仰 | FR_thigh_joint | FR_thigh_joint | 位置 |
| 2 | 2 | 右前膝 | FR_calf_joint | FR_calf_joint | 位置 |
| 3 | 3 | 左前髋外展 | FL_hip_joint | FL_hip_joint | 位置 |
| 4 | 4 | 左前髋俯仰 | FL_thigh_joint | FL_thigh_joint | 位置 |
| 5 | 5 | 左前膝 | FL_calf_joint | FL_calf_joint | 位置 |
| 6 | 6 | 右后髋外展 | RR_hip_joint | RR_hip_joint | 位置 |
| 7 | 7 | 右后髋俯仰 | RR_thigh_joint | RR_thigh_joint | 位置 |
| 8 | 8 | 右后膝 | RR_calf_joint | RR_calf_joint | 位置 |
| 9 | 9 | 左后髋外展 | RL_hip_joint | RL_hip_joint | 位置 |
| 10 | 10 | 左后髋俯仰 | RL_thigh_joint | RL_thigh_joint | 位置 |
| 11 | 11 | 左后膝 | RL_calf_joint | RL_calf_joint | 位置 |
| 12 | 12 | 右前轮 | FR_foot_joint | FR_wheel_joint | 速度 |
| 13 | 13 | 左前轮 | FL_foot_joint | FL_wheel_joint | 速度 |
| 14 | 14 | 右后轮 | RR_foot_joint | RR_wheel_joint | 速度 |
| 15 | 15 | 左后轮 | RL_foot_joint | RL_wheel_joint | 速度 |

SDK 编号属于官方示例的参考值，实机方向、零位与有效通道须验证。LocoFormer 作者的统一关节表尚未公开确认，上表用于已定位 Go2-W 基线。[SDK 表](https://github.com/unitreerobotics/unitree_sdk2_python/blob/814556d15970dd2ecf1c9984e845ca02ab07e206/example/go2w/low_level/unitree_legged_const.py) · [Robot Lab 关节列表](https://github.com/fan-ziqi/robot_lab/blob/v2.3.2/source/robot_lab/robot_lab/tasks/manager_based/locomotion/velocity/config/wheeled/unitree_go2w/rough_env_cfg.py)

## 5. 限位、限速与力矩

### 5.1 官方 URDF 声明

| 适用关节 | 位置下限 rad | 位置上限 rad | 约合角度 | 速度上限 rad/s | effort N·m |
| --- | --- | --- | --- | --- | --- |
| 四腿 hip | −1.0472 | 1.0472 | −60° 至 60° | 30.1 | 23.7 |
| 前腿 thigh | −1.5707963 | 3.4907 | −90° 至 200° | 30.1 | 23.7 |
| 后腿 thigh | −0.5236 | 4.5379 | −30° 至 260° | 30.1 | 23.7 |
| 四腿 calf | −2.7227 | −0.83776 | −156° 至 −48° | 20.07 | 35.55 |
| 四个 foot 连续轮 | 无有限位置端点 | 无有限位置端点 | 连续转动 | 30.1 | 23.7 |

该表按所读官方 URDF 的 limit 字段整理。限位是否与当前实机固件一致、速度是否由控制器主动裁剪，都需要验证。[官方 URDF](https://github.com/unitreerobotics/unitree_ros/blob/master/robots/go2w_description/urdf/go2w_description.urdf)

### 5.2 模型和控制配置存在的差异

| 来源 | 髋/大腿力矩 | 膝力矩 | 轮力矩 | 速度限制 |
| --- | --- | --- | --- | --- |
| 官方 URDF 声明 | 23.7 | 35.55 | 23.7 | 腿 hip/thigh 30.1，calf 20.07，轮 30.1 |
| 官方 MJCF motor ctrlrange | ±23.7 | ±45.43 | ±15 | 上述 motor 定义未给出同等的关节速度上限 |
| Robot Lab v2.3.2 | 23.5 | 23.5 | 23.5 | 所配腿、轮均 30.0 |
| rl_sar 基线配置 | 23.5 | 23.5 | 23.5 | 需要结合动作解码与电机控制实现判断 |
| 当前实机 | 待核验 | 待核验 | 待核验 | 待核验 |

Robot Lab 中这些数值来自 effort_limit_sim 与 velocity_limit_sim。MJCF 中 motor 的单位齿轮配置需结合执行器定义核验，此处为所读默认直接驱动设置。部署允许值应综合固件、机械范围、任务和实测确认。

[官方 MJCF](https://github.com/unitreerobotics/unitree_mujoco/blob/1eb6642e3f3fdfb7fb13a9794fd6a2dd93ea0e7d/unitree_robots/go2w/go2w.xml) · [Robot Lab 电机配置](https://github.com/fan-ziqi/robot_lab/blob/v2.3.2/source/robot_lab/robot_lab/assets/unitree.py) · [rl_sar 配置](https://github.com/fan-ziqi/rl_sar/blob/376d42c9b128f963ab08579762d5a216a976ce39/policy/go2w/robot_lab/config.yaml)

### 5.3 已查基线的控制参数

| 参数 | Robot Lab v2.3.2 | rl_sar 配套策略 |
| --- | --- | --- |
| 物理/底层时间步 | 0.005 s | base.yaml 为 0.005 s |
| 控制降采样 | 4 | 4 |
| 策略周期 | 0.020 s，即 50 Hz | 同为 50 Hz |
| 腿目标缩放 | hip 0.125，其余腿 0.25 | 对应动作缩放相同 |
| 轮目标缩放 | 5.0 | 5.0 |
| 腿刚度 | 25.0 | 策略模式 kp=20.0 |
| 腿阻尼 | 0.5 | kd=0.5 |
| 轮刚度/阻尼 | 0 / 0.5 | kp=0 / kd=0.5 |
| 初始 thigh | 四腿 0.8 rad | 前腿 0.5、后腿 0.8 rad |
| 初始 calf | −1.5 rad | −1.5 rad |
| Robot Lab 初始基座高度 | 0.45 m | 由部署/场景决定 |
| 原始动作裁剪 | 配置为 [−100,100] | 配置为 [−100,100] |

原始动作的数值裁剪在物理缩放前后如何应用，应以实际解码代码核对；宽范围裁剪本身不足以定义实机运行限值。上表中的相同项与差异项都要随权重配套保存。参数来自 [Robot Lab](https://github.com/fan-ziqi/robot_lab/tree/v2.3.2/source/robot_lab/robot_lab/tasks/manager_based/locomotion/velocity) 与 [rl_sar Go2-W](https://github.com/fan-ziqi/rl_sar/tree/376d42c9b128f963ab08579762d5a216a976ce39/policy/go2w)。

## 6. 传感器、位置与信号

| 硬件/信号 | 分布或位置 | 可用信息 | 当前需要核实 |
| --- | --- | --- | --- |
| 编码器与电机反馈 | 16 个电机通道 | q、dq、力矩估计与温度等，以消息定义为准 | 编号、方向、零位、有效率与字段来源 |
| 机身 IMU | 机身内部；模型 site 相对 base 为 (−0.02557,0,0.04232) m | 姿态四元数、角速度、加速度；SDK 另有 RPY 等 | 实机外参、轴向、四元数顺序、重力与单位 |
| 3D LiDAR | 产品标配，位于机身前部 | 点云 | 本机型号、话题、频率、外参、时间戳 |
| 广角相机 | 产品标配，机身前部 | 图像/视频 | 分辨率、帧率、编码和获取接口 |
| 足端力/接触 | 消息含四路足端字段 | foot_force、foot_force_est 等 | 当前轮足设备是否有独立力传感器，字段是否有效 |
| 深度相机或扩展模块 | 选配，按实物安装登记 | 深度、RGB 或额外计算 | 是否装配、型号、序列号与标定 |
| 电池管理 | 机身电池 | BMS 状态 | 低电量、温度与诊断字段 |
| 基座线速度 | 仿真可直接读取；实机通常需要估计来源 | 机身或世界系线速度 | 来自运动状态估计、里程计或其它估计器 |

MJCF 内的 frame_pos/frame_vel 属于仿真可直接计算的状态。实机基座状态的获得方式需单独说明。厂商消息含某字段，只能说明消息结构提供位置，不能据此确认实物装有相应传感器。

第一轮 LocoFormer 接口工作优先核验本体感知、速度命令、关节和历史动作。相机与雷达记录在硬件清单，是否进入网络由所复现的观测合同决定。[产品规格](https://www.unitree.com/go2-w/) · [SDK 消息](https://github.com/unitreerobotics/unitree_sdk2/tree/main/include/unitree/idl/go2) · [MJCF sensor](https://github.com/unitreerobotics/unitree_mujoco/blob/1eb6642e3f3fdfb7fb13a9794fd6a2dd93ea0e7d/unitree_robots/go2w/go2w.xml)

## 7. 57 维基线观测与 16 维动作

| 输入块 | 维度 | 配置中的缩放/说明 |
| --- | --- | --- |
| 机身角速度 | 3 | 0.25 |
| 投影重力 | 3 | 必须统一坐标和姿态约定 |
| 速度命令 | 3 | 平面两轴、偏航，配置 scale 均为 1 |
| 相对关节位置 | 16 | scale=1，轮位置处理需按源码核对 |
| 关节速度 | 16 | scale=0.05 |
| 上一动作 | 16 | 与当前策略动作顺序一致 |
| 合计 | 57 | 3+3+3+16+16+16 |

这是 rl_sar 参考策略的配置。轮位置对应 4 个槽在不同实现中可能置零或专门处理，须检查与权重配套的观测构造函数。57 维不作为 LocoFormer 作者输入维数。

动作先分出 12 个腿通道和 4 个轮通道。腿通道经缩放和参考姿态变成目标角度，轮通道变成目标角速度。腿控制可按 PD 结构计算力矩，轮以速度误差驱动。增益和目标需与训练保持一致。[参考策略配置](https://github.com/fan-ziqi/rl_sar/blob/376d42c9b128f963ab08579762d5a216a976ce39/policy/go2w/robot_lab/config.yaml)

## 8. 不同机器人怎样统一关节

论文提出统一关节超集。arXiv 源文件注释进一步描述四腿七槽、补零与存在掩码，但最终逐关节表和轮槽解码仍未确认。以下为本项目合同，维度与字段见选型审查。

合同 v1 采用 28 个语义槽，按 FR、FL、RR、RL 四个腿块组织，每块为 hip_roll、hip_pitch、hip_yaw、knee_pitch、ankle_roll、ankle_pitch、wheel。第 4 节的 16 路仍表示 Go2-W 基线动作/SDK 顺序。统一槽位与硬件顺序通过映射连接，详见[选型审查](07_implementation_audit.md#5-自己定义输入合同难在哪里)。

每种机器人有一张“实际关节 ↔ 语义槽”的映射。输入把对应关节值放到固定槽，缺失槽使用约定填充值并提供有效位。输出按同一映射取出有效分量，再按腿或轮控制类型解码。

例如左前膝在合同 v1 中为槽 10。Go2 与 Go2-W 都把左前膝的 q/dq 写进槽 10，并从槽 10 取动作。缺少某关节时保留空槽，后续关节不向前挤占。软件已知道加载哪种设备配置，因此能选择映射表。网络通过训练学习这些固定语义，并利用历史响应调整行为。

| 合同字段 | 必须记录的内容 |
| --- | --- |
| 输入 | 字段名、维数、排列、坐标、单位、标准化、缺失值和有效位 |
| 关节映射 | 资产名、SDK 索引、语义槽、方向、零位 |
| 输出 | 目标位置/速度/力矩、缩放、参考姿态、上下限和变化率 |
| 时间 | 控制频率、采样延迟、上一动作更新顺序 |
| 历史 | Trial 保留规则、Episode 清空规则、异常复位规则 |
| 训练 | 无效动作是否惩罚，概率、熵与损失是否按有效维度处理 |

缺失位的 0 与实际关节角度等于 0 含义不同，有效位提供区分。引入有效位会改变网络输入，必须从训练起统一使用。若采用无效动作惩罚，它与概率掩码属于不同设计，需按所选算法一致实现。

验证方法是为每个真实关节填入不同数字，检查编码后位置，再将不同动作数字解码，逐项检查返回相同的实际关节。该检查先于策略闭环。

## 9. SDK 接口与部署网络

| 接口 | 主要用途 | 边界 |
| --- | --- | --- |
| SportClient | 给整机前进、转向等速度指令 | 由厂商内置控制器驱动腿轮 |
| rt/lowstate | 读取 IMU 和电机状态 | 接口权限、频率和有效字段需实机检查 |
| rt/lowcmd | 发送 q、dq、kp、kd、tau 等目标 | 需确认控制模式和其它控制器的占用 |
| ROS 2 接口 | 状态与传感器桥接 | 按当前驱动版本核对实际话题名 |

服务器穿透地址用于 SSH 登录。SDK2 的 DDS 需要设备网络和网卡配置，跨网访问服务器不能证明可直接控制机器人。最终部署位置在测得推理与通信延迟后决定。

MotorState 数组容量与有效电机数量分别处理，不能按消息容量推断机器狗自由度。[SDK2 Python](https://github.com/unitreerobotics/unitree_sdk2_python) · [Go2-W 开发入口](https://support.unitree.com/home/en/Go2-W_developer/Quick_Start)

## 10. 实机登记表

| 项目 | 公开参考 | 当前实机 |
| --- | --- | --- |
| 铭牌、固件、SKU、改装 | Go2-W | 待登记 |
| 主动电机数 | 16 | 待逐路确认 |
| 各路方向、零位与位置范围 | 官方模型与 SDK 表 | 待核验 |
| 各路速度、力矩及温度限制 | 第 5 节分来源参数 | 待厂商/固件核验 |
| 控制增益、周期与停止动作 | 参考策略配置 | 待实测 |
| 相机、雷达、IMU 与选配件 | 第 6 节 | 待清点和记录外参 |
| 推理计算模块 | 基础 CPU、可选扩展模块 | 待清点 |
| 网络与权限 | 专用网口、DDS 低层接口 | 待验证 |
| 数据质量 | 时间戳、频率、丢包、延迟 | 待采集 |

汇报时分别说明已核对的公开参数和实机尚待验证项。完整物理模型还需保存连杆质量、惯量、关节轴、碰撞形状及接触参数，随选定资产版本导出。
