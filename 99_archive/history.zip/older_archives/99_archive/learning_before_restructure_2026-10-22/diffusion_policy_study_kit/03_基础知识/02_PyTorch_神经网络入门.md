# PyTorch 与神经网络入门：为读代码准备

## 最少但够用的 PyTorch 心智模型

`torch.Tensor` 是带有形状（shape）、数据类型和设备信息的多维数组。深度学习代码中，最重要的阅读习惯是：每看到一个张量，先问它的形状和每一维含义。

本文常见的批量动作张量可写为：

```text
[B, Tp, Da]
 B  : batch 中的演示片段数
 Tp : prediction horizon，预测的未来动作步数
 Da : 每步动作维度（如末端位置、姿态、夹爪）
```

视觉观测常有类似 `[B, To, C, H, W]` 的形状，分别是批量、历史帧数、颜色通道、高、宽。实际仓库会因相机数/键名不同而略有变化；不要猜，打印形状确认。

## 训练循环的共同骨架

```python
for batch in dataloader:
    prediction = model(batch_input)
    loss = loss_fn(prediction, target)
    optimizer.zero_grad()
    loss.backward()
    optimizer.step()
```

在 Diffusion Policy 中，`target` 通常不是动作本身，而是人为加到动作上的噪声。`loss.backward()` 会把 MSE 对所有可训练参数的梯度回传，包含视觉编码器（端到端训练时）和去噪网络。

## 必须会读的模块

- `nn.Module`：模型基类；`forward` 定义一次前向计算。
- `nn.Linear`：全连接层；常用来嵌入状态、时间步或 token。
- `nn.Conv1d`：沿动作时间轴卷积；论文的 CNN backbone 用它处理动作序列。
- `nn.Conv2d`：图像卷积；ResNet 视觉编码器用它处理图像。
- `nn.MSELoss`：均方误差，论文训练目标的核心。
- `torch.no_grad()`：推理时关闭梯度记录，降低显存和开销。
- `model.train()` / `model.eval()`：切换训练/推理行为；尤其会影响 dropout、BatchNorm。论文以 GroupNorm 降低与 EMA/BatchNorm 的冲突。

## 从官方教程学到什么即可

按以下顺序完成 PyTorch 的官方 **Learn the Basics**：Tensors → Datasets & DataLoaders → Build the Neural Network → Autograd → Optimization。学习入口：<https://docs.pytorch.org/tutorials/beginner/basics/intro.html>。

完成后应能独立写一个线性回归训练循环，并解释：`requires_grad`、`backward`、`optimizer.step()` 各自做什么。此时再看 Diffusion Policy 代码，不会因为语法细节失去主线。

## 初学者的三条调试纪律

1. 先打印一个 batch 的键、shape、dtype、min/max，再训练。
2. 先让极小数据集过拟合，确认损失能降，再扩大数据量。
3. 检查输入/动作归一化。官方仓库也特别指出 normalizer 与序列起止 padding 是常见出错点。

