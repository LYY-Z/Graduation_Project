# UR7e Diffusion Policy：部署学习与复现指南

本套文档解释已经完成的部署工作，供本人学习、团队交接，以及续写既有 *Technical Report on Manipulator UR7e* 和后续发表使用。内容以当前源文件和原始实机日志为依据，不把实施计划当作已经完成的功能。

**本轮仅新增本目录文档，不改现有代码、参数、权重、环境或历史日志，不连接硬件。** 文件名使用英文，正文使用中文。代码规整仅提出方案，尚未实施。

## 1. 先确定我们实际完成了什么

已完成一次：真实腕部 RGB 与 UR7e 状态采集 → 原官方模型推理 → 工程坐标转换 → 平滑与限幅 → 真实末端运动 → 控制柜实测反馈确认。

成功运行 `20261025T085457Z_live` 中完成了 3 条小幅目标，净实测位移约 2.022 mm；夹爪没有动作。它证明部署链路可运行，**没有证明真实 Push-T 任务成功，也没有完成算法创新或完整论文实验**。

当前有效限制为单步 1 mm、累计命令距离 3 mm、初始位置周围 3 mm、命令速度 2 mm/s，最多三条。之后提出过的 3 mm 单步方案已经取消，未部署或实机执行。不要把讨论中的参数写进当前实验设置。

## 2. 六章阅读顺序

| 顺序 | 文档 | 读完应能回答 |
|---|---|---|
| 1 | [系统与代码来源](01_system_and_code.md) | 整条链路如何分工？原论文代码到底改了什么？ |
| 2 | [硬件与观测构造](02_hardware_and_observations.md) | 图片和机械臂数据如何变成模型需要的数组？ |
| 3 | [推理与动作输出](03_inference_and_actions.md) | checkpoint 如何加载？100 次去噪在什么地方？8 步输出如何选择？ |
| 4 | [受限执行与操作手册](04_execution_and_operation.md) | 输出怎样成为实体运动？怎样手动启动、停止和检查日志？ |
| 5 | [代码规整计划](05_code_organization_plan.md) | 现在哪些地方混乱？以后如何整理而不破坏已验收行为？ |
| 6 | [实验依据与报告衔接](06_evidence_and_publication.md) | 既有 technical report 应补在哪里？哪些结论已有证据，还缺什么实验？ |

第一次按顺序阅读；以后查形状与单位看第 2、3 章，操作设备看第 4 章，组织项目看第 5 章，写报告与论文看第 6 章。每章末尾有回顾题，答案可直接在本章定位。

另附 [technical_report_insert.md](technical_report_insert.md)：沿用现有报告的英文技术说明风格，提供拟放入 Software Stack 与 Experiment 的正文。它是待主报告源工程合并的内容稿，不是已经修改或编译好的报告 PDF。

## 3. 一张图串起全部内容

```mermaid
flowchart LR
    C[腕部相机 RGB] --> B[ROS 图像桥接]
    B --> F[原子帧文件]
    R[UR7e 只读状态] --> O[两帧因果观测窗口]
    F --> O
    O --> P[原官方策略与 EMA 权重]
    P --> A[二维动作序列]
    A --> G[映射、平滑、限幅与状态检查]
    G --> M[受限 moveL]
    M --> U[真实 UR7e]
    U --> E[末端与六关节实测反馈]
    E --> G
```

这里的循环是“看一次 → 推理 → 完成一条小目标 → 再看”，不是已经验证的连续 10 Hz 策略控制。

## 4. 需要知道的最少术语

| 术语 | 在本系统中的具体含义 |
|---|---|
| 接口 | 一段代码对外提供的输入、输出及调用规则，例如 `predict_action(obs)` |
| 适配层 | 在已有设备和已有模型之间转换格式、单位、时序及动作语义的新增代码 |
| 张量 | 带形状和数据类型的多维数字数组；图片也以数组存储 |
| checkpoint | 已训练参数及相应配置、normalizer 等状态的保存文件 |
| 推理 | 用已有参数算输出；本阶段没有更新参数或训练 |
| TCP | 工具中心点；当前机器人返回的实际末端位姿已经考虑其激活 TCP |
| 坐标系 | 数值相对于哪个原点和方向；UR base 坐标和仿真动作坐标不能混用 |
| 进程／线程 | 进程可使用不同 Python 环境；线程在同一进程内并行采集数据 |
| 反馈 | 从控制柜重新读取的实际位置、关节、速度等，不是把目标原样打印出来 |
| 验收 | 按预先定义的条件确认某一级链路通过，不代表所有任务都已解决 |

## 5. 资料的角色与位置

- 当前工程：[diffusion_policy_ur7e](../../../03_code/diffusion_policy_ur7e_v1/README.md)。服务器对应 `/home/robotic_arm/lyy_ws/diffusion_policy_ur7e`。
- 原论文：[本地 PDF](../../../01_papers/chi-et-al-2024-diffusion-policy-visuomotor-policy-learning-via-action-diffusion.pdf)。算法知识主要在既有论文学习资料中，本套重点是实际部署。
- 平台依据：[technical report](../../../03_code/diffusion_policy_ur7e_v1/references/technical_report_manipulator.pdf)。报告中的值仍须与当前代码和现场读回区分。
- 实机证据：[成功运行 README](../../../03_code/diffusion_policy_ur7e_v1/runs/guarded_execution/20261025T085457Z_live/README.md) 与原始 JSON/JSONL。
- 本次核对快照：[evidence_snapshot.json](evidence_snapshot.json)，用于记录版本、来源和文档核验范围，不替代原始日志。

旧工程文档记录了准备、影子推理、实机执行等不同阶段；其中“尚未运行”“没有执行器”等描述可能只适用于当时。阅读当前状态以本目录、当前源文件和对应时间的日志交叉核对，历史文档不在本轮覆盖。
