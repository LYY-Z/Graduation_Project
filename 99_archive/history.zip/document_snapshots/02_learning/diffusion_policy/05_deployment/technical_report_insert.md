# Technical-report insertion draft

Editorial scope: this text extends the supplied *Technical Report on Manipulator UR7e*. It does not describe a new diffusion algorithm. The proposed locations are Section 4.3 and Section 5.3, with a supporting update to Section 5.2. The host LaTeX document should assign final section, table, figure and reference numbers. The original PDF has not been edited.

## Proposed Section 4.3: Diffusion Policy Deployment

### Model and Hardware Interfaces

The manipulation platform was extended with a Diffusion Policy deployment branch for the UR7e and a single wrist-mounted Orbbec Gemini 335L camera. The purpose of this stage was to validate the data-to-motion interface using an existing policy, rather than to establish real-world Push-T performance. This branch uses direct RTDE control and does not invoke the cuRobo motion-generation backend described in Section 4.2.

The implementation retains the original Diffusion Policy source at commit `5ba07ac6661db573af695b419a7947ecb704690f`. A separate Python package provides camera acquisition, robot-state processing, observation construction, policy loading, constrained target generation and execution logging. The selected public checkpoint is the image-based Transformer policy trained on simulated Push-T. Its EMA parameters, embedded normalizer and DDPM sampling configuration are retained without additional training.

Table: Deployment configuration used in the validation experiment.

| Parameter | Configured value |
|---|---|
| Manipulator | UR7e; direct RTDE state and motion interfaces |
| Visual input | One wrist RGB stream; 640 × 480 source images |
| Policy input | Two RGB images, each 3 × 96 × 96; two planar position vectors |
| Prediction horizon / returned action segment | 10 / 8 steps |
| Sampling configuration | 100 DDPM iterations; squared-cosine schedule; noise prediction |
| Checkpoint parameters | EMA model and original normalizer |
| Deployment software | Python 3.9.18; PyTorch 1.12.1; diffusers 0.11.1 |
| Robot-state acquisition | Requested RTDE rate of 125 Hz |
| TCP offset | Translation (0, 0, 244) mm; zero rotational offset |
| Gripper command | None |

### Observation Construction

The ROS 2 camera bridge runs in the system Python environment, separately from the policy environment. It validates the image encoding, optical frame and timestamp, performs a centre-square crop and resizes the RGB image to 96 × 96. The completed frame and its metadata are exchanged through an atomically replaced NPZ file. The policy input uses floating-point CHW arrays in the range [0, 1]. The checkpoint also retains its internal 84 × 84 evaluation crop.

Robot states are acquired independently of camera processing. The recorded state includes the active TCP pose, six joint positions, controller timestamp and operating modes. The controller TCP pose already incorporates the active tool offset; the 244 mm offset must therefore not be added a second time. The declared offset is checked against the controller before motion execution.

The simulated checkpoint expects a planar position observation. A session-relative engineering map converts the TCP position in the robot base frame into that coordinate representation:

$$u=u_0+\operatorname{diag}(s)E(p-p_0),$$

where $p_0$ is the initial TCP position, $u_0=(256,256)$, $s=(1000,1000)$ px/m, and $E$ selects the base-frame X and Y axes. This map establishes a numerical interface; it is not a calibrated camera-to-workspace projection or evidence of successful sim-to-real transfer.

Two historical images are selected on a nominal 0.1 s observation grid. Each image is paired with a preceding robot state using monotonic timestamps on the same workstation. The configured maximum acquisition-time mismatch is 0.05 s, and the maximum sample age at observation construction is 0.5 s. ROS image age before the bridge callback is checked separately. These checks provide host-side causal pairing, not hardware-triggered synchronization.

### Policy Inference and Constrained Execution

For each inference call, the original observation encoder produces the conditioning features. A Gaussian action tensor is then iteratively denoised by the Transformer and the DDPM scheduler. The policy returns a complete sequence of shape [1, 10, 2] and an action segment of shape [1, 8, 2]. With two observation steps, the segment starts at index 1 of the complete sequence. The deployment test uses only the first element of the returned action segment; it does not execute all eight actions in open loop.

The planar output is inverse-mapped into a candidate base-frame position. Its displacement is norm-limited, exponentially smoothed and checked again against the single-target and cumulative distance budgets. The commanded height and orientation remain fixed at the initial measured TCP pose. The validation configuration limits each target to 1 mm, the cumulative commanded distance to 3 mm and the startup position envelope to a radius of 3 mm. Commanded speed and acceleration are 2 mm/s and 5 mm/s², respectively. At most three targets are permitted in one run.

Before dispatch, the executor checks operating modes, active TCP offset, inverse kinematics, controller safety limits, stationary feedback and input freshness. Readiness is obtained through a cached read-only control-state interface before the final state and age checks. The oldest effective input timestamp must remain within 1.5 s of dispatch. The first prediction is used for warm-up and discarded; subsequent targets use newly acquired observations.

A project-private ur_rtde 1.6.5 control extension removes automatic reconnection and stale-command replay, adds bounded runtime writes and command waits, and reports unacknowledged stop operations. MOVEL commands are not queued when the control script or socket is unavailable. The original installed library is not replaced. This modification constrains the communication failure behavior; it is not a safety certification, and pre-motion initialization still retains parts of the upstream connection procedure.

Motion is monitored using TCP pose, joint position, speed and force feedback. Completion requires a changed asynchronous completion state, low measured speed and three consecutive position checks within the arrival tolerance. The next observation and prediction follow completion of the current target. This sequential validation loop must not be interpreted as a demonstrated 125 Hz policy controller. No gripper commands are generated.

## Suggested experiment-specific update to Section 5.2

For the Diffusion Policy deployment experiment, robot proprioceptive states were read through RTDE rather than a ROS joint-state topic. The policy consumed one wrist RGB stream and a planar TCP-derived position history. Six joint positions, TCP poses, timestamps and operating modes were retained as observation evidence; execution monitoring additionally recorded TCP speed and force/torque. Depth images and gripper states were not used by this policy input. Image-state alignment used host-side causal pairing and was not hardware-triggered synchronization.

## Proposed Section 5.3: End-to-End Deployment Validation

### Procedure

Validation proceeded from real-input capture to shadow inference, numerical target preview and a supervised constrained execution run. The robot was stationary at initialization, the active TCP was confirmed, Remote Control mode was enabled, and the relevant arm, tool, camera and cable motion space was checked by the operator. No initialization motion, training or automatic return-to-start motion was performed.

The successful execution run was recorded as `20261025T085457Z_live` on 25 October 2026. Its initial TCP translation was approximately (0.252937, 0.422997, 0.697225) m in the robot base frame. Each target was generated from newly acquired inputs. Original observations, raw policy outputs, filtered targets, command acknowledgements and measured motion feedback were retained with configuration and source hashes.

### Results and Scope

Table: Results of the three-target constrained execution run.

| Metric | Target 1 | Target 2 | Target 3 |
|---|---:|---:|---:|
| Commanded displacement (mm) | 0.5004 | 0.7740 | 0.8446 |
| Measured start-to-end displacement (mm) | 0.4950 | 0.7510 | 0.8314 |
| Final position error to target (mm) | 0.0139 | 0.0250 | 0.0178 |
| Policy inference time (s) | 0.6024 | 0.6008 | 0.6025 |
| Oldest effective input age at dispatch (s) | 1.0177 | 0.8587 | 0.8915 |
| Completion check | Passed | Passed | Passed |

All three targets received command acknowledgements and satisfied the feedback-based completion criteria. The run retained 132 motion-feedback records. The cumulative commanded displacement was 2.1190 mm, while the net measured displacement from the first pre-motion pose to the final pose was approximately 2.0223 mm. The worker, camera bridge and camera driver started for the run exited normally, with no remaining processes owned by the trial. The primary platform configuration and protected environment metadata remained unchanged.

These observations validate a bounded real-input-to-motion deployment chain. They do not establish real-world Push-T success, long-duration robustness, calibrated workspace correspondence or six-dimensional learned action generation. The three targets belong to one short run and must not be reported as three independent task episodes or a 100% task success rate. The inference timings exclude acquisition, control checks and physical execution, and are not end-to-end control latency measurements. Additional calibration, independent repeated trials and task-level evaluation remain necessary.

## Source references to append to the host report

- Chi et al., *Diffusion Policy: Visuomotor Policy Learning via Action Diffusion*. Use the bibliographic entry corresponding to the paper already included in the project.
- Original implementation: https://github.com/real-stanford/diffusion_policy ; fixed commit recorded above.
- Public checkpoint: https://diffusion-policy.cs.columbia.edu/data/experiments/image/pusht/diffusion_policy_transformer/train_0/checkpoints/epoch=0100-test_mean_score=0.748.ckpt . Its filename score refers to the original simulation experiment.
- ur_rtde API and quick start: https://sdurobotics.gitlab.io/ur_rtde/pages/reference/api.html and https://sdurobotics.gitlab.io/ur_rtde/pages/getting_started/quick_start.html . The private patch and binary manifest are retained with the deployment artifacts.

The exact source paths, checkpoint SHA256, private-backend build record and run-level evidence are indexed in the accompanying Chinese guide and `evidence_snapshot.json`. When merging, use the host document's reference and automatic numbering system rather than copying provisional editorial headings.
