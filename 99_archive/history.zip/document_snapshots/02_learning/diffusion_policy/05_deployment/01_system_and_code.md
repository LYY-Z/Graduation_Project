# 01 系统与代码来源

本章先回答“已有模型与真实设备之间缺了什么”，再给出代码阅读地图。阅读前只需知道：函数接收输入、执行处理、返回输出；文件可以把有关联的函数放在一起。

## 1. 已训练的策略不是完整设备驱动

Diffusion Policy 学习的是给定观察后生成动作分布。它不会自动知道新相机的话题、UR7e 的 IP、工具长度、时间戳来源或现场运动边界。

因此，部署不是把论文中的机器人名称换成 UR7e。必须同时接通三类契约：

| 契约 | 要明确的问题 | 本次做法 |
|---|---|---|
| 数据 | 图片颜色、尺寸、状态维度、历史帧如何组织？ | 单路 RGB、两帧、二维位置，匹配公开 checkpoint |
| 空间与时间 | 相对于哪个坐标系？单位是什么？观察是否仍然有效？ | 显式工程映射、TCP 转换、主机 monotonic 因果配对及年龄检查 |
| 执行 | 二维输出怎样成为六轴机器人的实际运动？ | 固定高度与姿态，生成小幅绝对 TCP 目标，检查后调用 `moveL` |

本次“适配完成”的含义是这三类接口已连通并通过一次受限短测。腕部视角与仿真图像之间的视觉差异、任务语义一致性仍未解决。

## 2. 分清三份来源

| 位置 | 性质 | 本次处理 |
|---|---|---|
| `03_code/diffusion_policy/` | 原始论文仓库 | 未直接修改 |
| `03_code/diffusion_policy_ur7e/upstream/` | 原论文完整受版本固定的副本 | 369 个文件按清单保留，算法代码未改 |
| `03_code/diffusion_policy_ur7e/src/dp_ur7e/` | 新增部署适配包 | 18 个 Python 文件，负责新设备与既有模型之间的连接 |
| `03_code/diffusion_policy_ur7e/vendor/ur_rtde_guarded/` | 第三方 `ur_rtde` 的私有副本 | 独立修改控制通信行为；不是论文策略网络 |

上游提交固定为 `5ba07ac6661db573af695b419a7947ecb704690f`，清单见 [upstream_manifest.json](../../../03_code/diffusion_policy_ur7e_v1/artifacts/upstream_manifest.json)。所以准确说法是“保留论文算法实现，增加部署包并维护一个私有控制后端”，不能说“完全没有修改任何代码”，也不能说“重新实现了 Diffusion Policy”。

## 3. 程序实际分成哪些部分

```text
相机驱动进程：Orbbec ROS 驱动发布 Image
          ↓ ROS 话题
图像桥接进程：系统 Python 3.10 + ROS Humble
          ↓ 原子 .npz 文件
推理/执行进程：独立 Python 3.9 环境
          ├─ 采集线程：相机帧与 RTDE 只读状态持续进入缓冲区
          ├─ 主线程：组观察 → GPU 推理 → 过滤动作
          └─ 执行期间：读反馈 → 验证到位 → 再开始下一轮
```

分进程是为了隔离 ROS 与旧版深度学习依赖。并行采集线程则避免 GPU 推理阻塞时停止积累新帧。原子帧文件是当前跨进程交换方式，不是训练数据集，也不是长期录制视频。

## 4. 新增 Python 文件逐个对应到职责

链接均指向实际实现，建议先看左列的主流程，再沿函数调用阅读辅助模块。

| 文件 | 主要职责／入口 | 阅读时关注 |
|---|---|---|
| [execution.py](../../../03_code/diffusion_policy_ur7e_v1/src/dp_ur7e/execution.py) | `run_execution`、`predict`、`prepare_candidate` | 预演与真实执行的完整流程 |
| [cli.py](../../../03_code/diffusion_policy_ur7e_v1/src/dp_ur7e/cli.py) | `inspect`、`camera-bridge`、`capture`、`shadow` | 原只读入口；不含实机执行子命令 |
| [runner.py](../../../03_code/diffusion_policy_ur7e_v1/src/dp_ur7e/runner.py) | 采集和影子推理 | `executed=false` 表示这里没有控制下发 |
| [config.py](../../../03_code/diffusion_policy_ur7e_v1/src/dp_ur7e/config.py) | YAML 读取、路径和契约校验 | 相对路径以工程根目录解析，而非终端当前目录 |
| [camera_bridge.py](../../../03_code/diffusion_policy_ur7e_v1/src/dp_ur7e/camera_bridge.py) | ROS `Image` 订阅和写帧 | 时间、frame、颜色与重复帧检查 |
| [images.py](../../../03_code/diffusion_policy_ur7e_v1/src/dp_ur7e/images.py) | 解码、裁剪、缩放、张量排布 | `uint8 HWC` 到 `float32 CHW` |
| [frame_store.py](../../../03_code/diffusion_policy_ur7e_v1/src/dp_ur7e/frame_store.py) | `CameraFrame`、`FrameStore` | 临时文件完成后原子替换，避免读到半帧 |
| [robot.py](../../../03_code/diffusion_policy_ur7e_v1/src/dp_ur7e/robot.py) | `ReceiveOnlyRobot` | 只读 TCP/关节/模式，转换报告 TCP |
| [geometry.py](../../../03_code/diffusion_policy_ur7e_v1/src/dp_ur7e/geometry.py) | UR 位姿变换、`PlanarMapping` | 米、旋转向量、仿真动作坐标各自的意义 |
| [session.py](../../../03_code/diffusion_policy_ur7e_v1/src/dp_ur7e/session.py) | `SensorSession` | 两个采集线程、队列、会话锚点、错误传播 |
| [observations.py](../../../03_code/diffusion_policy_ur7e_v1/src/dp_ur7e/observations.py) | `RobotSample`、`ObservationHistory` | 配对两帧与其各自的状态，形成输入字典 |
| [model.py](../../../03_code/diffusion_policy_ur7e_v1/src/dp_ur7e/model.py) | 校验文件、加载原策略与 EMA 参数 | strict 加载、保留 normalizer、输出形状验证 |
| [motion_safety.py](../../../03_code/diffusion_policy_ur7e_v1/src/dp_ur7e/motion_safety.py) | `MotionLimits`、`ActionGuard` | 纯数值过滤，不建立硬件连接 |
| [motion_robot.py](../../../03_code/diffusion_policy_ur7e_v1/src/dp_ur7e/motion_robot.py) | `GuardedRobot`、反馈与控制边界 | ready、TCP、IK、安全检查、发送和停止 |
| [guarded_backend.py](../../../03_code/diffusion_policy_ur7e_v1/src/dp_ur7e/guarded_backend.py) | 加载私有原生控制扩展 | 路径、源码/二进制哈希及能力检查，无原库回退 |
| [recording.py](../../../03_code/diffusion_policy_ur7e_v1/src/dp_ur7e/recording.py) | `RunWriter`、版本与预览 | 元数据、观察 NPZ、逐行事件日志 |
| [__main__.py](../../../03_code/diffusion_policy_ur7e_v1/src/dp_ur7e/__main__.py) | `python -m dp_ur7e` 入口 | 转交 `cli.main` |
| [__init__.py](../../../03_code/diffusion_policy_ur7e_v1/src/dp_ur7e/__init__.py) | 包标识 | 不在导入时启动设备或模型 |

`with SensorSession(...)` 表示会话结束时尝试关闭自己持有的采集资源；`try/finally` 表示无论正常结束还是报错，都进入清理逻辑。这些结构会影响实机行为，不能只关注神经网络那一行。

## 5. 还新增了哪些工程内容

- `configs/platform.yaml`：平台、时序、图像和映射配置。实机限幅当前写在 `MotionLimits.visible()`，不在该 YAML 中。
- `models/`：原 checkpoint、官方 sidecar 配置、来源/大小/SHA256 清单。没有训练新权重。
- `environment.inference.yml` 与 `scripts/`：隔离环境准备、依赖检查、下载及文件验证。
- `tests/`：几何、图像、时间、契约、退出和执行异常回归；测试通过不等于任务成功。
- `artifacts/`：环境、文件清单、测试结果与私有后端补丁/构建清单。
- `references/`：technical report、服务器参考代码快照和第三方原始归档。参考别人的 Agent/LLM 工作不等于本系统依赖它们运行。
- `runs/`：运行证据；`runtime/`：当前帧、锁文件和本机私有扩展；`.cache/`：下载和构建缓存。
- 工程外的 [preparation_tools](../../../03_code/ur7e_deployment_reference/preparation_tools)：已有 SSH/SFTP、服务器试验和构建辅助工具。这是当前组织上的技术债，规整方案见第 5 章。

## 6. 第三方控制库到底改了什么

原始 `ur_rtde==1.6.5` 的部分异常分支会自动重连、重新上传控制程序或重发旧命令，其默认等待也较长。本次希望发生异常后退出，而不是在 Python 限幅与新鲜度检查之外恢复旧指令，因此使用私有副本。

| 私有副本中修改的文件 | 修改目的 |
|---|---|
| `include/ur_rtde/rtde.h` | 断开默认不发 pause 握手；发送函数增加即时发送选项 |
| `include/ur_rtde/rtde_control_interface.h` | 缩短命令阈值、连接故障锁存；暴露已有缓存只读 ready 读取 |
| `src/rtde.cpp` | MOVEL 一次非阻塞完整发送；其他发送 500 ms 期限；接收超时缩短 |
| `src/rtde_control_interface.cpp` | 去掉两处自动恢复路径；失败显式返回/抛错；就绪不满足时不排队 MOVEL |
| `src/rtde_python_bindings.cpp` | 私有模块名、能力标记和 `guarded_ready()` Python 绑定 |

完整差异见 [control_backend.patch](../../../03_code/diffusion_policy_ur7e_v1/artifacts/control_backend.patch)，构建清单见 [control_backend.json](../../../03_code/diffusion_policy_ur7e_v1/artifacts/control_backend.json)。系统中的原 `ur_rtde` 没有被替换；原 Receive 扩展仍用于只读状态。

这些修改属于设备通信与失效行为的工程约束，不是扩散网络创新，也不构成安全认证。初始化连接阶段仍保留上游部分握手流程；普通 Linux 调度和物理急停响应不能由这几个超时参数完整保证。

## 7. 按什么顺序阅读代码

第一次：`execution.run_execution` → `session.observation` → `model.load_policy` → 上游 `predict_action` → `prepare_candidate` → `ActionGuard` → `GuardedRobot.move` → `RunWriter`。

第二次再细读桥接、图像、几何、时间窗与私有后端。不要一开始从 3000 行 C++ 控制库读起；也不要直接运行上游 `eval_real_robot.py`，它使用的设备假设、坐标和执行路径不等于当前系统。

### 回顾题

1. 为什么模型权重能加载，不代表机器人已经适配？
2. 哪些文件属于论文算法，哪些属于新增适配，哪些属于第三方库私有修改？
3. 为什么相机桥接和模型推理使用两个 Python 环境？
