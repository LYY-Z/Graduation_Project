# 03 推理与动作输出

本章从已经构造好的 `observation` 开始，沿真实调用顺序解释模型加载、去噪和输出。算法流程来自未修改的上游代码，不是适配层新设计的一种扩散算法。

## 1. 当前到底加载了哪个模型

| 项目 | 实际值 |
|---|---|
| 来源 | Chi 等人公开的仿真 Push-T 图像实验 |
| 策略类 | `DiffusionTransformerHybridImagePolicy` |
| checkpoint 文件 | `models/pusht_image_transformer.ckpt`，412,727,949 字节 |
| 参数分支 | `ema_model` |
| 观察／预测／输出动作段长度 | 2／10／8 |
| 去噪调度器 | `DDPMScheduler`，100 次推理迭代 |
| 日程／预测类型／方差类型 | `squaredcos_cap_v2`／`epsilon`／`fixed_small` |
| 当前是否训练 | 否 |

来源、URL 和文件哈希在 [checkpoint_manifest.json](../../../03_code/diffusion_policy_ur7e_v1/models/checkpoint_manifest.json)。文件名中的 `test_mean_score=0.748` 是原实验的仿真测试分数，不能解释成 UR7e 的成功率。

当前没有改成 DDIM、没有把去噪步数减到 10，也没有使用 CNN 权重。论文讲过的可选方案不等于这个 checkpoint 的实际配置。

## 2. `load_policy` 在做什么

按实际代码顺序：

1. 检查 checkpoint 字节数与 SHA256，避免误用文件或不完整下载。
2. 把固定的 `upstream/` 加入导入路径，从文件读取保存的配置和参数。
3. 校验只包含 `image` 和 `agent_pos`，动作维度为 2，策略类在允许列表中。
4. 按 checkpoint 内的配置构造原策略对象，不构造训练 workspace 或优化器。
5. 使用 `load_state_dict(..., strict=True)` 加载 EMA 参数，包含视觉编码器、去噪网络及 normalizer。
6. 移至选定 GPU，调用 `eval()`；返回模型及用于记录的实际配置。

`strict=True` 的意义是参数名称和维度必须匹配，不能用 `strict=False` 让架构错误悄悄通过。`eval()` 切换评估行为，但它本身不负责关闭梯度；真正预测时还使用 `torch.inference_mode()`。

`models/transformer_config.yaml` 是便于审阅的官方 sidecar；实际构造主要使用 checkpoint 内的配置。两者应核对，不能只改 sidecar 就认为模型参数结构会随之改变。

## 3. 图像怎样影响动作

调用链如下：

```text
predict(policy, observation)
  → NumPy 转 PyTorch，保持形状并移到 GPU
  → policy.predict_action(tensors)
      → normalizer.normalize(obs)
      → 两帧分别经过既有视觉/观察编码器
      → cond，形状 [B, To, Do]
      → 条件去噪生成动作轨迹
      → 反归一化动作
      → 返回 action_pred 与 action
```

`Do` 是编码器输出的特征维度，不必把它等同于物体类别数。上游按 robomimic 的图像编码设置构造视觉网络；图像特征与二维低维位置共同形成观察表示。本次仍使用 checkpoint 已训练的特征，不新增杯子检测器或类别标签。

当前构造路径使用 robomimic 的 `VisualCore`、`ResNet18Conv` 和 `SpatialSoftmax`：

| 模块 | 对数字做什么 | 不应误解为 |
|---|---|---|
| ResNet-18 视觉骨干 | 把像素逐层转成空间特征图；参数来自已有 checkpoint | 给每个物体自动附上中文类别名 |
| Spatial Softmax | 将空间响应变成紧凑的、保留位置信息的表示，再形成特征向量 | 相机到机械臂的几何标定 |
| 特征拼接 | 把图像特征向量和 `agent_pos` 的数值沿特征维接在一起 | 把图片与坐标逐项相加 |
| Transformer 条件输入 | 用两帧特征为动作 token 的去噪提供条件 | 当前同时运行了 CNN+FiLM 版本 |

这些结构解释了图像如何进入预测，但不保证新视角下提取到的线索仍然正确。部署阶段也不会因为动作执行了就自动“学会”识别新物体。

一个容易漏掉的细节：桥接先输出 **96×96**，checkpoint 内部还配置了 **84×84** 裁剪；`eval_fixed_crop=true` 使用上游固定评估裁剪实现，在评估时取中心区域。不能把外部裁到 84×84 后仍声称输入契约为 96×96。

`obs_encoder_group_norm=true` 等结构选项已保存在原策略配置中。本次没有重新训练视觉编码器，也没有通过机械臂动作反向更新 ResNet。原论文训练阶段的端到端学习与本次纯推理阶段必须区分。

图像提供动作生成的条件。网络在新腕部视角下是否仍能提取正确任务线索，需要独立实验，不能仅从输出有限数就断言它正确识别了目标。

## 4. 100 次去噪具体在哪里

实现位于上游 [conditional_sample / predict_action](../../../03_code/diffusion_policy_ur7e_v1/upstream/diffusion_policy/policy/diffusion_transformer_hybrid_image_policy.py)。在 `obs_as_cond=true`、`pred_action_steps_only=false` 的当前分支中：

```text
cond = 对同一观察窗口编码得到的特征
trajectory = randn([1,10,2])
scheduler.set_timesteps(100)

对 scheduler.timesteps 中的每个扩散级：
    model_output = Transformer(trajectory, 扩散级, cond)
    trajectory = scheduler.step(model_output, 扩散级, trajectory).prev_sample
```

初始随机张量中有 10 个二维动作向量。它们是**归一化动作空间中的随机候选轨迹**，不是已经可以下发给机械臂的随机关节角。

`eval()` 和 `inference_mode()` 不会消除扩散采样的随机性。运行开始设置种子 42，但随机数状态会随采样前进，不是每轮重新生成同一份噪声；固定种子也不能代替对跨设备、版本和输入变化的复现记录。

Transformer 输出当前噪声估计；调度器按 DDPM 系数计算下一级样本。同一次推理里 `cond` 保持不变，图像并不每个扩散级重新从相机读取；下一轮推理才使用新的观察窗口。现在没有 warm-start 或历史动作复用：上游还明确不支持传入 `past_action`。

本模型预测噪声的 DDPM 均值可以用学习过的式子理解：

$$\mu_\theta(A^k,O,k)=\frac{1}{\sqrt{\alpha_k}}
\left(A^k-\frac{\beta_k}{\sqrt{1-\bar\alpha_k}}
\epsilon_\theta(A^k,O,k)\right).$$

实际系数和随机项由 `diffusers==0.11.1` 调度器处理。适配层没有再手写一套系数，也不把论文中的 Langevin 风格简写直接替换到这里。`clip_sample=true` 是调度器中的归一化样本裁剪，**不等于实体工作空间限幅**。

## 5. normalizer 与反归一化分别是什么

图像除以 255 只是外部像素尺度处理。进入策略后仍按保存的 normalizer 转换观察；动作也是先在归一化尺度生成，再用 `normalizer['action'].unnormalize(...)` 还原。

因此，上游返回的动作已经是原任务动作单位，本项目用 `px` 标明其仿真坐标尺度。不要再反归一化一次，也不要用刚采到的两帧重新拟合 normalizer。否则同一个数值会被错误解释，且不再对应训练时的数据分布。

## 6. 为什么返回 10 步和 8 步两份结果

```python
output = {
    "action_pred": ...,  # [1,10,2]：完整生成序列
    "action": ...,       # [1,8,2]：按观察偏移选择的可执行动作段
}
```

当前上游切片是：

```python
start = n_obs_steps - 1  # 1
end = start + n_action_steps  # 9
action = action_pred[:, 1:9]
```

Python 从 0 编号，`1:9` 包含索引 1 到 8。因此本次选择的 `action[0,0]` 对应 `action_pred[0,1]`，不是完整序列索引 0 的那一项。

原模型返回 8 步，不代表当前短测会全部执行。当前执行器只取动作段第一项，完成一条小目标后重新采集并推理，最多三次。这是平台初次受限验收策略，区别于按论文滚动时域执行整个动作块的完整任务控制。

## 7. 用真实记录走一遍数值转换

成功短测第一轮记录：

| 阶段 | 数值／意义 |
|---|---|
| 模型动作段第一项 | `[277.403442, 214.829193]`，仿真动作坐标 |
| 逆工程映射 | 约 `[0.274339, 0.381804, 0.697228] m` |
| 当时实际 TCP | 约 `[0.252929, 0.422986, 0.697230] m` |
| 二维原始目标距离 | 约 46.4 mm，尚未过滤 |
| 有界方向 | 向量范数先压到 1 mm 以内 |
| 首次平滑 | 系数 0.5、历史增量为零，平面目标约 0.5 mm |
| 最终六维 TCP 目标 | 约 `[0.253160, 0.422543, z₀, rx₀, ry₀, rz₀]` |
| 实测第一条起止位移 | 约 0.495 mm |

目标在预测完成时生成，真正发送前又读取实际状态并重新验证，因此最后一条命令距离会包含读回抖动和固定高度带来的微小差异。这也解释了日志中首条三维命令距离约 0.5004 mm，而非数学示例中恰好 0.5000 mm。

关键事实是：**没有把 46.4 mm 的原始工程目标直接发送给机器人**。第 4 章解释完整过滤、检查和反馈链。

## 8. 推理没有做哪些事

- 没有奖励计算、Q 网络、策略梯度或在线探索；这是已有行为克隆策略的部署。
- 没有损失反传、优化器 step、EMA 更新或视觉微调。
- 没有把图像生成出来再控制机器人；被扩散的是动作序列。
- 没有证明预测已适合真实 Push-T 场景；正确形状、有限输出与正确任务行为是不同层次。

### 回顾题

1. 为什么初始高斯动作张量不能直接发给机械臂？
2. 96×96 外部输入和 84×84 内部裁剪分别在哪一步？
3. `action[0,0]` 对应完整序列哪一项？为什么？
4. 为什么 `clip_sample=true` 不能代替实体运动限幅？
