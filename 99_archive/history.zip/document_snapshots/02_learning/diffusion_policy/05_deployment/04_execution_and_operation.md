# 04 受限执行与操作手册

本章先解释模型输出怎样作用于六轴机器人，再给出当前服务器的手动运行步骤。下面命令是供操作者以后执行的说明；编写本章时没有运行它们，没有连接或移动机械臂。

## 1. 为什么不是直接下发模型的二维坐标

模型输出的是仿真任务坐标，不是关节角，也不是天然准确的真实桌面目标。当前先逆工程映射为 UR base 中的候选位置，再只利用其平面方向生成小目标。

设当前 TCP 平面位置为 $p_{xy}$，映射目标为 $p^*_{xy}$，当前限制 $L=0.001\text{ m}$。向量限幅定义为：

$$C(v,L)=\begin{cases}v,&\|v\|\le L,\\Lv/\|v\|,&\|v\|>L.\end{cases}$$

实际顺序是：

$$d=C(p^*_{xy}-p_{xy},L),\qquad
\bar d=0.5d+0.5d_{prev},$$
$$d_{final}=C\bigl(\bar d,\min(L,0.003-\ell)\bigr).$$

`d_prev` 初值为零，$ℓ$ 是本次运行已经承诺发送的三维目标距离之和；`commit` 后才更新历史增量与预算。因此首次平面位移通常约为 0.5 mm。沿对角线也按欧氏范数限幅，不是 X、Y 各放行 1 mm。

目标组装为 `[当前x+d_x, 当前y+d_y, 初始z, 初始rx, 初始ry, 初始rz]`。最后重新用完整六维位姿检查单步、累计距离、初始包络及高度/姿态锁定；预测后和实际发送前的测量差异也要计入检查。

当前有效限制：

| 项目 | 数值 |
|---|---:|
| 单步三维目标距离 | ≤1 mm |
| 本次累计命令路径 | ≤3 mm |
| 初始 TCP 周围位置包络 | 半径 3 mm |
| 命令平移速度／加速度 | 2 mm/s／5 mm/s² |
| 平滑系数／目标条数 | 0.5／最多 3 条 |
| 小于此位移时保持 | 0.01 mm |
| 原始观察到发送的最大年龄 | 1.5 s |
| 单条运动监控超时 | 3 s |

这些值来自实际调用的 `MotionLimits.visible()`；`MotionLimits()` 本身还有更保守的默认值。修改 YAML 中同名猜测字段不会改变这些硬编码限制。曾讨论的更大档位已取消，当前不生效。

## 2. 六个关节在哪里参与

`GuardedRobot.move` 先调用控制器 IK，使用当前关节角作为近邻参考，检查目标解是否出现大跳变。通过后发送的是 `moveL(六维TCP目标, 速度, 加速度, True)`，不是把二维模型输出当作关节角。

控制器负责让六轴机构协调实现笛卡尔运动；每个目标不要求六个关节都有相同或明显的角度变化。记录中“三条位移”表示三个时间上先后的动作，不是机器人只有三个自由度。

执行检查包括：

| 检查对象 | 当前行为 |
|---|---|
| 模式 | 正常 safety mode=1、robot mode=7；创建控制前还查正常、空闲、远程模式 |
| TCP | 逐条核对激活偏移与 `[0,0,0.244,0,0,0]` 一致，不自动修改 TCP |
| 目标可达性 | 控制器位姿/关节安全检查，IK 相对当前每轴 ≤0.01 rad、相对初始每轴 ≤1° |
| 控制 ready | 原查询清除后，缓存 ready 连续稳定 20 ms；总等待 ≤300 ms，之后再做最终新鲜度检查 |
| 当前状态 | 发送前静止；读回 host 年龄 ≤0.1 s，控制柜时间不能倒退或停更超过 0.15 s |
| 实测运动 | 初始包络、Z 偏差 ≤0.15 mm、旋转偏差 ≤0.002 rad、每轴总关节变化 ≤1° |
| 实测速度 | 当前 visible 档位线速度监控阈值 3 mm/s；角速度 ≤0.01 rad/s |
| 力／力矩 | 力范数 ≤50 N、相对初始力变化 ≤5 N、力矩变化 ≤0.5 N·m |
| 路径跟踪 | 实测位置到本条起止线段的距离 ≤0.15 mm |

这些是当前工程阈值，不是由本次三条运动标定出来的传感器精度，也不是碰撞规划或经过认证的安全功能。TCP 限幅不能单独证明所有连杆、相机、夹爪及线缆无碰撞。

## 3. “发送成功”和“到位成功”不是同一件事

一条目标经历以下状态：

```text
filtered_prediction：原始输出和候选目标已记录
  → motion_dispatch_intent：下发意图已落盘
  → 再读状态、再检查静止/限幅/原始输入年龄
  → motion_command_acknowledged：moveL 返回确认
  → motion_feedback：采集运动期间的实际 TCP、q、速度、力
  → motion completed=true：异步完成状态变化 + 低速度 + 连续三次到位
```

到位阈值是 `min(0.05 mm, 0.4×本条目标距离)`，不能用大于首条位移的容差把“未移动”判成成功。运动反馈先存于内存，到位或停止后再落盘，避免慢磁盘挡住正在运行的监控；下发意图落盘后还要再检查新鲜度。

`filtered_prediction` 内的 `executed=false` 只说明那条“预测事件”本身没有证明执行；不能忽略后面的 motion 事件就断言整轮没有运动。反过来，仅有 intent 或 ACK 也不足以断言到位。

异常会尝试 `stopL`，随后清理自己创建的控制脚本/连接，不自动解锁保护停止、不重发旧目标、不自动回起点。失败记录可能包含已经开始但未完成的运动，应检查实际反馈，不能把 `motion_count=0` 自动解释成绝对没有任何位移。网络中断时也不能宣称软件已经确认物理停止。

## 4. 手动运行前的范围

以下步骤适用于已准备好的服务器，不重新安装依赖或编译后端。前提是现场看护、急停可用、机械臂/相机/线缆的相应运动范围无障碍，示教器为 Remote Control，当前 TCP 确认正确，且没有其他程序占用机械臂控制。原报告的初始关节角不是本次必须自动到达的姿态；本程序不会先运行大幅回零动作。

先登录服务器：

```bash
ssh robotic_arm@10.108.1.251
```

使用自己的凭据输入密码，不把密码保存到文档、代码或命令行。准备三个服务器终端：A 驱动、B 桥接、C 模型。

### 4.1 先生成独立手动配置

仅在完成现场 TCP 核对后执行。写的是运行配置副本，不改主配置或机器人设置：

```bash
export DP_ROOT=/home/robotic_arm/lyy_ws/diffusion_policy_ur7e
cd "$DP_ROOT"

"$DP_ROOT/.envs/inference/bin/python" - <<'PY'
import os
from pathlib import Path
import yaml
root = Path(os.environ['DP_ROOT'])
folder = root / 'runtime/manual'
folder.mkdir(parents=True, exist_ok=True)
cfg = yaml.safe_load((root / 'configs/platform.yaml').read_text())
cfg['project_root'] = str(root)
cfg['paths']['frame_store'] = 'runtime/manual/wrist_rgb.npz'
cfg['paths']['runs'] = 'runs/manual'
cfg['robot']['active_tcp_offset_verified_on_pendant'] = True
(folder / 'platform.yaml').write_text(yaml.safe_dump(cfg, sort_keys=False))
print(folder / 'platform.yaml')
PY
```

`execution.enabled=false`、`implementation=absent` 仍应保留。它们是旧只读配置校验的一部分；独立执行入口通过 `--execute --site-ready` 加现场核验开启控制。当前存在这种命名不一致，未来应规整，而不是现在把该字段改成 true 绕过校验。

### 4.2 终端 A：相机驱动

使用干净 ROS 终端，不激活模型 conda。已有驱动发布同一话题时跳过启动，不启动第二份驱动。

```bash
source /opt/ros/humble/setup.bash
ros2 topic info /wrist_camera/color/image_raw
```

没有驱动时，使用本次验证过的单相机启动配置：

```bash
ros2 launch orbbec_camera gemini_330_series.launch.py \
  camera_name:=wrist_camera serial_number:=CP285630005V device_num:=1 \
  enable_color:=true color_width:=640 color_height:=480 \
  color_fps:=30 color_format:=MJPG \
  enable_depth:=false enable_left_ir:=false enable_right_ir:=false \
  enable_point_cloud:=false enable_colored_point_cloud:=false \
  enable_accel:=false enable_gyro:=false \
  publish_tf:=false enumerate_net_device:=false
```

保持此终端运行。这里明确关闭深度和点云，不应改写为已经使用 RGB-D 融合。

### 4.3 终端 B：图像桥接

```bash
DP_ROOT=/home/robotic_arm/lyy_ws/diffusion_policy_ur7e
source /opt/ros/humble/setup.bash
export PYTHONNOUSERSITE=1
export PYTHONPATH="$DP_ROOT/src${PYTHONPATH:+:$PYTHONPATH}"
cd "$DP_ROOT"
/usr/bin/python3 -m dp_ur7e camera-bridge \
  --config "$DP_ROOT/runtime/manual/platform.yaml"
```

桥接持续更新本次指定的帧文件。不要把旧试验的 `runs/.../trial.yaml` 直接当作新配置，否则可能向历史试验的帧目录写入新内容。

### 4.4 终端 C：先预演

本终端不 source ROS，显式使用独立模型 Python：

```bash
DP_ROOT=/home/robotic_arm/lyy_ws/diffusion_policy_ur7e
cd "$DP_ROOT"
unset PYTHONPATH PYTHONHOME LD_LIBRARY_PATH
export PYTHONNOUSERSITE=1
export OMP_NUM_THREADS=4
export MKL_NUM_THREADS=4
export XDG_CACHE_HOME="$DP_ROOT/.cache/xdg"
export TORCH_HOME="$DP_ROOT/.cache/torch"
export HF_HOME="$DP_ROOT/.cache/huggingface"
nvidia-smi
```

选择空闲 GPU。下面 0 是示例，应根据当时占用情况选择，不终止他人的 GPU 作业。

```bash
export CUDA_VISIBLE_DEVICES=0
"$DP_ROOT/.envs/inference/bin/python" -m dp_ur7e.execution \
  --config "$DP_ROOT/runtime/manual/platform.yaml"
```

这会读取真实输入、推理、构造过滤目标，但不建立控制客户端。正常出现三条 `FILTERED ... live= False completed_moves= 0`，随后退出；首个预热预测被丢弃，不用于动作。

### 4.5 预演正常后再运行实体短测

在终端 C 运行：

```bash
"$DP_ROOT/.envs/inference/bin/python" -m dp_ur7e.execution \
  --config "$DP_ROOT/runtime/manual/platform.yaml" \
  --execute --site-ready
```

**这条命令会发送真实运动目标。** 它重新采集与推理，不回放预演动作。正常打印 `completed_moves=1`、`2`、`3` 后退出；如果输出低于死区或被拒绝，不能只凭循环计数认定执行了三次。

最多三条、不会自动返回起点。连续重新启动会重新建立会话锚点，运行间累计位移可能继续增加，因此不要用无限 shell 循环把每次小范围限制变成长期无人看护运动。

### 4.6 正常停止与日志

执行完成后再在 B、A 按 Ctrl+C。运行中出现异常优先使用现场急停；Ctrl+C 会触发软件清理，但不能替代物理急停。

每次运行会打印自己的目录，位于 `runs/manual/<UTC时间_随机ID>/`：

| 文件 | 用途 |
|---|---|
| `metadata.json` | 配置、模型与环境版本、实际限幅、初始 TCP/q/力和映射原点 |
| `observations/000000.npz` 等 | 实际送入模型的两个数组，支持事后检查输入 |
| `events.jsonl` | 预测、发送意图、ACK、反馈、完成或失败 |

保存完整目录。当前手动入口不会自动保存与此前服务器试验编排器相同的 `trial_result.json`；不能在新目录找不到它就认定失败。成功试验的编排器与逐条执行日志属于两层记录。

## 5. 报错时先定位在哪一级

| 现象 | 优先检查，不放宽参数掩盖错误 |
|---|---|
| 没有帧或序号不前进 | A/B 是否运行、话题/frame、是否使用同一帧路径 |
| 提示 stale、skew、历史不足 | 图像与状态时序、主机负载、GPU占用、是否误用旧帧 |
| checkpoint/私有后端 hash 不符 | 文件是否被改动、二进制是否对应记录源码 |
| Local/运行中/非正常模式 | 示教器和已有程序状态；不要禁用检查强行连接 |
| TCP 不符 | 现场安装和激活 TCP；不要在代码中硬加长度补偿 |
| IK 或关节变化超限 | 当前姿态与目标的近邻解；不是通过增大步长解决 |
| ready/ACK/timeout | 保留原异常和反馈，确认是否开始运动；不自动重复旧目标 |
| 输出很差但数组正常 | 当前是仿真权重加未标定工程映射，应进入任务适配研究 |

### 回顾题

1. 为什么要先向量限幅，再平滑，最后还要再限幅和验证？
2. 为什么 ACK、实际到位和任务成功必须分别判断？
3. 当前为什么保持夹爪不动？
4. 三个终端各自使用哪个环境，谁真正创建控制接口？
