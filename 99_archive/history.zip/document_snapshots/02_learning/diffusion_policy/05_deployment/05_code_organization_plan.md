# 05 公共仓库规划：模块结构与项目文档规范

**后续实施状态：已在独立副本完成重构。** 实际交付见 [新工程 README](../../../03_code/diffusion_policy_ur7e/README.md) 与 [新学习文档](../06_refactored_code/README.md)。本章保留设计阶段的记录；原工程未修改，新工程尚待目标环境及实机复验。

**2026-10-26 收敛方案。本文为目标结构，尚未移动、删除、合并或修改现有生产代码，也未更改服务器。**

本章取代先前的平铺方案。目标是一个面向项目贡献者、复现者和使用者的公共代码仓库。源码按 hardware、inference、control 三个子包分组，公共配置、几何、记录和流程放在包根目录，不继续增加嵌套层级。当前实现仍为 18 个平铺 Python 文件；下面描述待实施目标，不表示这些新路径已经存在。

## 0. 公共发布定位

- 仓库定位为 UR7e 与单腕部相机的 Diffusion Policy 接入及受限执行平台，明确复用的上游算法、权重与新增适配工作。
- README、docstring 和项目文档采用客观项目语言，说明能力、依赖、接口、操作、设计依据、验证结果和限制；不以某位学习者为叙述对象，不复制个人对话或实施流水账。
- 个人学习问答保留在仓库外的 02_learning。问答产生的有效技术结论改写为架构说明、接口约束、设计理由和可复现验证，不丢失结论，也不把整段教学对话搬进仓库。
- 代码标识符、命令及文件名统一英文；公共函数和类的说明明确参数、单位、返回值、异常和副作用。文档语言随项目约定统一，不把英文或文件数量作为专业性的替代。
- 公共配置为 config.example.yaml，实际 config.yaml 和凭据不提交。设备地址、相机标识、主机路径经参数/配置传入，不硬编码某台机器。
- 软件许可证由项目维护者选择，确认后提交真实 LICENSE，不自行假定许可。保留第三方原有许可、来源、固定版本及修改补丁。原论文引用和第三方归属在 README/文档中明确。
- 大权重、完整原始运行数据、环境、缓存和编译产物不进入普通源码提交。权重通过来源和校验清单获取；关键验证结果在报告中记录，并可提供适当的示例或发布附件。
- 公共 CI 运行无硬件、无权重依赖的测试；ROS、GPU、原生后端及实机验证显式区分。安装、导入、默认测试和帮助命令不产生机器人运动。
- 本规划不是已完成的发布审计。本次不上传公共仓库，不改服务器，不改变已验证运动参数。

## 1. 完整目标结构

列出全部拟维护的项目文件。第三方完整源码由来源清单逐文件登记，权重是下载产物，运行数据按运行编号生成；这些不应误认为需要手写的新增模块。

```text
diffusion_policy_ur7e/
├── .gitignore
├── README.md
├── LICENSE                    [维护者确定项目许可后写入]
├── pyproject.toml
├── environment.yml
├── config.example.yaml
│
├── .github/workflows/
│   └── tests.yml
│
├── src/dp_ur7e/
│   ├── __init__.py
│   ├── __main__.py
│   ├── cli.py
│   ├── config.py
│   ├── pipeline.py
│   ├── geometry.py
│   ├── recording.py
│   ├── hardware/
│   │   ├── __init__.py
│   │   ├── camera_bridge.py
│   │   ├── camera.py
│   │   ├── robot_state.py
│   │   └── observations.py
│   ├── inference/
│   │   ├── __init__.py
│   │   └── policy.py
│   └── control/
│       ├── __init__.py
│       ├── safety.py
│       └── robot.py
│
├── third_party/
│   ├── sources.json
│   ├── diffusion_policy/       [完整保留固定版本的上游文件]
│   └── ur_rtde_guarded/
│       ├── source/             [完整保留已验证的补丁后 SDK 源码]
│       ├── guarded.patch
│       └── build.json
│
├── models/
│   ├── checkpoint_manifest.json
│   ├── transformer_config.yaml
│   └── pusht_image_transformer.ckpt [下载产物，不提交 Git]
│
├── scripts/
│   ├── prepare_environment.sh
│   ├── prepare_environment_cache.py
│   ├── check_environment.py
│   ├── fetch_checkpoint.py
│   ├── build_backend.py
│   ├── deploy.py
│   ├── verify_bundle.py
│   └── summarize_run.py
│
├── tests/
│   ├── test_additional_boundaries.py
│   ├── test_camera_bridge_shutdown.py
│   ├── test_contracts_and_robot.py
│   ├── test_execution_contract.py
│   ├── test_geometry_and_mapping.py
│   ├── test_guarded_backend.py
│   ├── test_images_and_store.py
│   ├── test_motion_robot.py
│   ├── test_motion_safety.py
│   ├── test_observations.py
│   ├── test_recording.py
│   └── native/
│       └── test_guarded_transport.cpp
│
├── docs/
│   ├── guide.md
│   └── technical_report.md
│
└── runs/                       [按需生成；完整原始数据不默认提交 Git]
```

## 2. 自有源码逐文件职责

| 文件 | 职责 |
|---|---|
| 各 __init__.py | 包标识与必要的轻量导出；不连接硬件、不加载模型 |
| __main__.py | 支持 python -m dp_ur7e，调用 cli.main |
| cli.py | 统一解析 inspect/camera-bridge/capture/shadow/preview/execute；按需导入相应模块 |
| config.py | 配置加载、路径解析、单位和参数检查；形成可记录的有效配置 |
| pipeline.py | 统一编排采集、预测、预览和执行模式；共享数据步骤，保持只读与控制副作用边界 |
| hardware/camera_bridge.py | ROS 图像桥接，运行于 ROS 环境；负责节点和退出生命周期 |
| hardware/camera.py | 图像编码/stride、颜色、裁剪、缩放、帧数据结构与原子交换；不依赖 ROS 初始化 |
| hardware/robot_state.py | 只读机器人接口；TCP、关节、模式与状态时间等 |
| hardware/observations.py | 采集线程与资源生命周期、RobotSample/ObservationHistory、因果配对和时间有效性检查 |
| geometry.py | TCP 几何及真实空间与模型平面空间的转换；明确未标定映射的边界 |
| inference/policy.py | checkpoint 校验、原版模型实例化、strict EMA 加载、输入输出契约与预测包装 |
| control/safety.py | 纯数值平滑、限幅、累计预算及目标检查，不发送指令 |
| control/robot.py | 私有后端来源/哈希/能力校验、受限运动连接、状态/IK 检查、指令发送、反馈确认与停止 |
| recording.py | 原始输入、预测、过滤目标、执行事件及实际反馈的结构化记录 |

核心业务文件为 12 个，另有包标识和入口文件。pipeline.py 只编排流程，不承载图像处理、去噪算法或 RTDE 底层实现；只读模式不创建控制连接。跨环境相机桥接和隔离推理继续采用独立进程。数据结构放在所属模块中，公共格式通过导入复用，避免用未说明的 dict 字段传递隐含单位。以上为目标职责，统一命令与共享接口尚未实现。

## 3. 根目录、工具和文档

- README.md 包含项目定位、架构概览、支持/已验证配置、安装与快速开始、运行模式、验证范围/限制、原论文引用和文档链接。说明当前已验证硬件输入到策略推理再到受限 TCP 执行；不把链路成功写成 Push-T 实机任务成功，不声称现有权重已适配腕部视角。
- pyproject.toml 管理适配包、命令、必需依赖、可选开发/部署依赖及测试配置。
- environment.yml 记录模型环境的兼容固定版本；ROS 继续使用其系统环境。实际解析后的 Conda/Pip 清单存入本次环境验证记录。
- config.example.yaml 提供字段、单位及可理解的配置示例；运行者复制为不提交的 config.yaml。模型事实由 checkpoint/模型清单提供，不重复手填；参数冲突直接拒绝。强约束仍由控制模块校验。示例配置不随附生产凭据或本机目录。
- .gitignore 排除环境、缓存、编译产物、大权重及默认不提交的大型运行数据；重要实验必须另有备份。
- scripts 下前四个已有同名工具；后四个中 verify_bundle.py 已有，build_backend.py/deploy.py/summarize_run.py 是待整合入口，不声称现已存在。
- build_backend.py 整合私有 SDK 准备/构建，使用 source + patch，在私有构建目录产生产物。
- deploy.py 仅负责显式文件部署与完整性核对，不附带启动推理或机器人动作。SSH 依赖作为可选部署依赖，凭据不写入代码。
- summarize_run.py 根据事件和反馈汇总证据，保留失败状态；不把模型输出当作实际运动。
- guide.md 是面向项目的技术指南，按“架构与接口 → 设备/坐标/时间契约 → 模型输入输出 → 执行流程 → 部署和操作 → 验证与故障处理”组织。提供实际命令、预期输出和设计依据，不保留对话式教学、个人称呼或未实现功能的执行示例。
- technical_report.md 保留与 Technical Report 一致的英文技术写法，记录平台配置、实现、验证方法、量化结果和局限；严格区分算法复用、工程映射与实测结果。
- .github/workflows/tests.yml 只执行无设备依赖的自动检查；真实模型、ROS、原生后端及实机验证分别记录所需条件。部署到公共 Git 服务时再启用对应工作流，本次未创建工作流。
- 现有测试全部保留并随接口迁移更新；新的纯 CLI/共享流程检查并入对应测试文件。默认测试不连接真实机器人，ROS/原生/实机相关检查显式区分。

## 4. 第三方与模型文件

third_party/diffusion_policy 完整保留固定上游版本（当前为 5ba07ac6661db573af695b419a7947ecb704690f），包括原有许可证。当前原版副本共有 369 个文件。

实施时为保留已验证源码的逐字节一致性，third_party/ur_rtde_guarded/source 保留已应用受限补丁的 SDK 源码，guarded.patch 保存相对原始 SDK 的修改依据，build.json 明确 source_state=guarded_patch_already_applied。构建不重复应用补丁，使用私有构建副本；源文件/补丁/模块继续校验，不能因目录整理改变当前控制语义。

sources.json 登记来源、版本、许可证位置、补丁与逐文件校验信息。checkpoint_manifest.json 则登记实际使用权重的来源、大小、哈希和模型标识；transformer_config.yaml 是对应官方配置的可读副本。当前未启用 CNN 权重，其配置与下载过程记录进入历史归档，不增加当前运行分支。

## 5. 运行目录与可重建产物

历史成功和失败运行保持原始证据，不直接把旧文件改成新格式。新记录的目标模板为：

```text
runs/<run_id>/
├── metadata.json       代码、模型、环境、时间和有效配置
├── events.jsonl        采集/推理/发送/确认/到位/异常事件
├── observations.npz    实际模型观察输入
├── predictions.npz     原始预测、处理后目标与映射信息
├── feedback.npz        机器人实际状态反馈
└── result.json         结果与统计
```

以上是新记录的目标格式，并非声称已有运行均采用这些文件名。环境/构建/静态验证记录可放 runs/validation/<run_id>/，保留原始日志和来源清单。

.envs/inference/ 为项目隔离环境，.cache/ 为可重建下载/构建缓存，.runtime/ 为图像交换、锁及本机控制扩展。它们按需生成，不作为手写源码或实验数据集。环境隔离需要的 Conda 配置可由准备脚本生成在运行目录，隔离规则必须保留。

## 6. 现有材料如何归并

| 现有位置 | 目标处理 |
|---|---|
| src/dp_ur7e 的 18 个 Python 文件 | 按三子包及公共模块重组；图像/帧交换、采样/观察、后端/运动分别归并；runner/execution 的共享流程归入 pipeline |
| upstream/ | 迁移为 third_party/diffusion_policy/，内容保持可校验 |
| vendor/ur_rtde_guarded + artifacts/control_backend.patch/json | 形成 SDK 原始来源、补丁和构建配置，不直接丢弃现有已验证产物 |
| configs/platform.yaml、环境规格及隔离设置 | 分别整理为公共 config.example.yaml、非提交的实际 config.yaml、environment.yml 与脚本生成的隔离配置 |
| requirements-adapter.txt | 核对后与 pyproject 的包依赖合并，避免重复维护 |
| 现有 docs 与 02_learning/diffusion_policy/05_deployment | 个人问答继续保留在学习目录；提炼与项目相关的技术结论进入专业 guide 与英文报告，不公开个人学习过程 |
| 现有 models | 保留当前 Transformer 权重、对应配置和清单，其余材料归档 |
| 现有 tests | 全部保留，不因精简目录删除必要验证 |
| 现有 artifacts、references、旧运维工具 | 有用工具纳入 scripts；原始验证资料保留为带来源的历史记录；论文原件归入统一论文目录 |
| 现有 runs | 原始成功/失败证据保留，不覆盖，不为统一外观而重写 |

## 7. 实施顺序

先冻结当前已跑通版本及证据，再统一入口和配置、提取公共流程、整合工具与文档，最后迁移第三方目录。每步验证输入/输出契约、只读模式无控制副作用、限幅和停止语义保持不变。目录整理不顺带修改运动幅度、算法、训练或硬件功能。

当前结构的实际完整文件名见 [current_file_inventory.txt](current_file_inventory.txt)。该清单与目标结构分开，排除 Git 内部文件、缓存和 Python 环境。本次没有执行上述重构。

