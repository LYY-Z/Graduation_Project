# DDPM与Diffusion Policy学习手册

本主题保留原有DDPM、Diffusion Policy论文、官方源码及UR7e部署教材，并按用途组织。2026-11-02统一移入本目录；基础正文不因目录调整而删减。

## 1. 按目标选择路线

| 学习目标 | 从哪里开始 |
|---|---|
| 第一次完整学习 | [学习地图](00_learning_map.md) |
| 机器学习、深度学习、行为克隆 | [基础01](01_foundations/01_ml_dl_and_imitation.md) |
| 高斯噪声、贝叶斯反向、DDPM、DDIM | [DDPM教材](01_foundations/02_ddpm_from_intuition_to_formula.md) |
| 按论文顺序读 | [中文阅读](02_paper_study/00_paper_chinese_reading.md)、[问题与全流程](02_paper_study/01_problem_and_full_pipeline.md) |
| 条件动作扩散、KL、score | [方法与公式](02_paper_study/02_action_diffusion_and_formulas.md) |
| 视觉、FiLM、Transformer、EMA、滚动控制 | [网络与控制设计](02_paper_study/03_control_network_and_design.md) |
| 实验、消融与局限 | [实验与附录](02_paper_study/04_experiments_appendix_limits.md) |
| 官方代码逐节学习 | [13节代码教材](03_code_and_practice/code_study/README.md) |
| UR7e硬件、输入、权重、推理、受限执行 | [部署与重构代码教材](06_refactored_code/README.md) |
| 找回当时的疑问 | [疑问索引](04_review/02_faq_and_question_index.md) |
| 公式速查、自测与汇报 | [符号公式卡](04_review/01_symbols_and_formula_cards.md)、[自测](04_review/03_paper_recap_and_self_test.md) |

## 2. 目录职责

```text
diffusion_policy/
├── 01_foundations/        机器学习、DDPM、控制与RL背景
├── 02_paper_study/        论文精读，完整机制解释
├── 03_code_and_practice/  官方仓库阅读与实践，含13节教材
├── 04_review/            公式、问题定位、自测
├── 05_deployment/        重构前部署记录与当时的证据
└── 06_refactored_code/   后续模块化代码的六章学习说明
```

05与06记录不同阶段，保留是为了追溯代码和验证依据，不表示需要同时启动两套部署系统。

## 3. 当前代码与原始记录的边界

- 当前模块化项目：[diffusion_policy_ur7e](../../03_code/diffusion_policy_ur7e/README.CN.md)。
- 保留的早期版本：[diffusion_policy_ur7e_v1](../../03_code/diffusion_policy_ur7e_v1/README.md)。
- 原论文代码：[diffusion_policy](../../03_code/diffusion_policy/README.md)。

六章教材形成于重构阶段；其中实验数值与验收范围按原记录解释，后续操作应以当前项目README与guide为准。本次整理没有运行模型或控制机械臂，也没有新增实机验收。

原有材料中被重命名项目的链接同步到当前路径。归档的JSON、验证证据和原始文件备份保留其原始来源信息，不因目录重排而伪造新验证日期。

## 4. 与LocoFormer学习的衔接

两者共用张量、网络和自动求导基础，但本文主角是行为克隆；LocoFormer主角是奖励驱动的PPO。不要把噪声MSE、动作扩散步与强化学习优势、优化轮次相混。

继续：[LocoFormer学习手册](../locoformer/README.md) · [总学习入口](../README.md) · [汇报资料](../04_review/README.md)。
