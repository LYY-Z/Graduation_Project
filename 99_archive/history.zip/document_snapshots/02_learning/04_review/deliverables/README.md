# 汇报交付文件

按主题保存当前版本。`CN` 为中文版，`EN` 为英文版。

| 主题 | 汇报材料 | 配套材料 |
|---|---|---|
| 适应与扰动恢复文献调研 | [中文 PPT](motion_control/motion_control_review.CN.pptx) · [英文 PPT](motion_control/motion_control_review.EN.v3.pptx)，7 页正文与 6 页附录 | [中文讲稿](motion_control/speech.CN.md) · [英文讲稿](motion_control/speech.EN.md) |
| FLAIR 与 Go2-W | [中文 PPT](flair/FLAIR_Paper_Review_and_Go2W_Research.CN.pptx) · [英文 PPT](flair/FLAIR_Paper_Review_and_Go2W_Research.EN.pptx) | [中文讲稿](flair/FLAIR_Presenter_Notes.CN.md) · [代码学习与论文计划](../../flair/README.md) |
| LocoFormer | [中文 PPT](locoformer/report.CN.pptx) · [English PPT](locoformer/report.EN.pptx) | [中文讲稿](locoformer/speech.CN.md) · [English script](locoformer/speech.EN.md) |
| Diffusion Policy | [论文汇报 PPT](diffusion_policy/report.CN.pptx) | [演讲稿](diffusion_policy/speech.CN.docx) · [逐页知识回顾](diffusion_policy/knowledge_review.CN.docx) |
| UR7e 部署 | [部署进展汇报](ur7e/deployment_brief.CN.md) | — |

LocoFormer 中英文版逐页对应，均包含 12 页主讲和 2 页隐藏补充；每页备注中附有对应语言的演讲稿，来源信息置于备注末尾。

整理前备份见 [归档压缩包](../../../99_archive/review_cleanup/2026-11-02/deliverables_before_cleanup.zip)。
