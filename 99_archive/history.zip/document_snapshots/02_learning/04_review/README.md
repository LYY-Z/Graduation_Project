# 汇报资料

当前交付文件按主题集中保存于 [`deliverables`](deliverables/README.md)。

| 主题 | 汇报材料 | 学习资料 |
|---|---|---|
| FLAIR 与 Go2-W | [中文 PPT](deliverables/flair/FLAIR_Paper_Review_and_Go2W_Research.CN.pptx) · [英文 PPT](deliverables/flair/FLAIR_Paper_Review_and_Go2W_Research.EN.pptx) · [中文讲稿](deliverables/flair/FLAIR_Presenter_Notes.CN.md) | [复现源码导读](../flair/README.md) |
| LocoFormer | [中文 PPT](deliverables/locoformer/report.CN.pptx) · [英文 PPT](deliverables/locoformer/report.EN.pptx) · [中文讲稿](deliverables/locoformer/speech.CN.md) · [英文讲稿](deliverables/locoformer/speech.EN.md) | [学习手册](../locoformer/README.md) |
| Diffusion Policy | [论文汇报 PPT](deliverables/diffusion_policy/report.CN.pptx) | [论文与代码教材](../diffusion_policy/README.md) |
| UR7e 部署 | [部署进展汇报](deliverables/ur7e/deployment_brief.CN.md) | [部署代码学习](../diffusion_policy/06_refactored_code/README.md) |

LocoFormer 为 12 页正文与 2 页隐藏补充。补充 A 解释 PPO 裁剪，补充 B 说明第三方参考代码的采集与更新时序。中英文版页序一致，演讲稿已写入对应备注。
