# 总学习地图

## 1. 两条研究路线如何衔接

```text
共同基础：数组/张量、网络层、参数、前向、损失、梯度、优化器
       ├─ Diffusion Policy：演示数据 → 噪声预测 → 条件动作采样 → 滚动执行
       └─ LocoFormer：环境交互 → 奖励与优势 → PPO更新 → 历史条件控制
```

共同使用神经网络和自动求导，不代表训练信号、输入时间组织与采样机制相同。

| 需要区分的对象 | Diffusion Policy | LocoFormer |
|---|---|---|
| 真实交互时间 | t | t |
| 单次生成内部迭代 | 扩散步k | 不以扩散去噪为主线 |
| 历史组织 | 观察窗口、条件特征 | segment、缓存、Episode边界 |
| 训练数据 | 专家演示中的观测与动作 | 策略交互产生的动作、奖励等 |
| 主要优化信号 | 已知加噪噪声的预测误差 | 优势驱动的策略目标与价值目标 |
| 运行随机量 | 扩散采样的初始噪声等 | 动作分布采样等 |

## 2. 按问题定位

| 问题 | 推荐阅读 |
|---|---|
| 网络是代码还是库？参数放在哪里？ | [LocoFormer网络基础](locoformer/02_network_and_memory.md#tensors) |
| 前向、反向、参数更新有什么区别？ | [PPO自动求导](locoformer/03_reinforcement_learning_and_ppo.md#autograd) |
| DDPM为什么加高斯噪声、为什么有平方根？ | [DDPM完整推导](diffusion_policy/01_foundations/02_ddpm_from_intuition_to_formula.md) |
| 动作扩散、score、DDIM怎样连接？ | [条件动作扩散](diffusion_policy/02_paper_study/02_action_diffusion_and_formulas.md) |
| 视觉编码器、FiLM、EMA是什么意思？ | [Diffusion网络与控制](diffusion_policy/02_paper_study/03_control_network_and_design.md) |
| QKV为什么乘矩阵、点积为什么能匹配？ | [QKV数值计算](locoformer/02_network_and_memory.md#qkv) |
| Trial、Episode、segment、batch怎么区分？ | [时间尺度](locoformer/01_paper_and_full_pipeline.md#concepts) |
| 奖励、回报、价值、优势有什么区别？ | [强化学习基本量](locoformer/03_reinforcement_learning_and_ppo.md#return) |
| 为什么重新前向、旧概率为什么不变？ | [PPO重算与比例](locoformer/03_reinforcement_learning_and_ppo.md#recompute) |
| 本地项目怎样对照论文？ | [Diffusion官方代码教材](diffusion_policy/03_code_and_practice/code_study/README.md)、[LocoFormer参考代码](locoformer/04_code_and_reproduction.md) |
| 相机、状态、checkpoint与UR7e如何连起来？ | [部署代码教材](diffusion_policy/06_refactored_code/README.md) |
| 六足仿真怎样从航点一路运行到论文统计？ | [FLAIR 复现代码导读](flair/README.md) |

## 3. 避免再次卡住的固定读法

每次出现一个公式或代码片段，先写出四项：

1. **阶段**：交互采集、训练求梯度，还是部署推理？
2. **数据**：实际数组是什么形状，来自环境还是网络？
3. **版本**：当前参数、旧参数，还是历史缓存？
4. **用途**：结果交给损失、下一层、缓存，还是实际执行器？

理解后用一个小数值例子重算，再回到整个流程。不要因一个系数忘记，就从论文第一页重新开始。

## 4. 快速复习入口

- LocoFormer：[十分钟恢复路线](locoformer/05_questions_and_review.md#7-十分钟快速恢复路线)。
- Diffusion Policy：[原有完整学习地图](diffusion_policy/00_learning_map.md)。
- FLAIR 与 Go2-W：[源码导读、复现结果与论文计划](flair/README.md)。
- 论文汇报：[交付文件入口](04_review/README.md)。
