# 机器人学习资料

资料按研究主题组织，正文使用中文，文件与目录使用英文命名。论文原文位于`01_papers`，项目源码位于`03_code`；本目录负责理解、复习与知识衔接。

## 选择当前学习主题

跨窗口继续研究时，先读[研究交接与长期要求](00_research_handoff.CN.md)，其中区分已有证据、历史方案、当前文献候选，以及论文调研、学习和汇报规范。

| 主题 | 入口 | 内容 |
|---|---|---|
| LocoFormer | [学习与复习手册](locoformer/README.md) | 论文全流程、长记忆、QKV、segment、强化学习、PPO、源码与疑问索引 |
| DDPM与Diffusion Policy | [学习路线](diffusion_policy/README.md) | 零基础、扩散推导、论文精读、官方代码、UR7e部署与重构代码 |
| 跨主题快速定位 | [总学习地图](00_learning_map.md) | 忘记概念时选择哪份文档，怎样避免训练和部署混淆 |
| 汇报材料 | [汇报入口](04_review/README.md) | 当前PPT、讲稿和相关交付文件 |

## 目录结构

```text
02_learning/
├── README.md
├── 00_learning_map.md
├── locoformer/
│   ├── README.md
│   ├── 01_paper_and_full_pipeline.md
│   ├── 02_network_and_memory.md
│   ├── 03_reinforcement_learning_and_ppo.md
│   ├── 04_code_and_reproduction.md
│   └── 05_questions_and_review.md
├── diffusion_policy/
│   ├── README.md
│   ├── 00_learning_map.md
│   ├── 01_foundations/
│   ├── 02_paper_study/
│   ├── 03_code_and_practice/
│   ├── 04_review/
│   ├── 05_deployment/
│   └── 06_refactored_code/
└── 04_review/
    ├── README.md
    └── deliverables/
```

`diffusion_policy/04_review`放公式卡、疑问索引与自测；根目录`04_review`集中管理汇报交付物。已交付PPT保持原路径，避免已有引用失效。较早汇报版本与构建目录保留，不作为学习路线入口。

## LocoFormer忘记以后从哪里重新开始

先读[全局流程](locoformer/01_paper_and_full_pipeline.md#overview)，再按阻塞点进入：

- 任务、Trial、Episode、segment混淆：[概念与时间尺度](locoformer/01_paper_and_full_pipeline.md#concepts)。
- 不理解历史与整段训练：[网络与记忆](locoformer/02_network_and_memory.md#segment)。
- 奖励怎样修改权重：[强化学习与PPO](locoformer/03_reinforcement_learning_and_ppo.md)。
- 要快速找回当时的疑问：[90项疑问归纳](locoformer/05_questions_and_review.md)。

## 资料维护规则

主线教材负责完整解释，疑问索引负责定位，汇报文件负责表达。新增问题优先补充对应章节与索引，不再新建同主题的重复“最终版”。

学习解释、论文明确事实、第三方实现和本次实际验证范围分别标明。旧部署证据与后来重构状态按各自记录解释，不将不同版本的结果混为一谈。

2026-11-02整理：原Diffusion教材内容保留并归入主题目录，原文件及迁移记录备份于`99_archive/documentation_updates`。
