# 参考项目与实施选型

更新日期为 2026-11-08。参考项目按本项目需要承担的功能选择。源码静态审查、安装成功、训练有效和实机运行分别记录。下列“可参考”表示存在对应代码，具体复用范围通过运行验证确定。

## 1. 核心学习项目

| 项目 | 原项目用途与对象 | 可参考部分 | 本项目采用方式 |
| --- | --- | --- | --- |
| 本地 locoformer | lucidrains 第三方通用库，含 Microduck 和 Gymnasium 示例 | TXL、KV/段间缓存、Actor/Critic、GAE/PPO、经历采集与多次经历组合 | **主要算法候选，优先验证直接接入** |
| BabyLocoFormer | 非官方简化复现，多种体型四足 | 参数化生成、USD 导入、Isaac Lab 任务与 TXL 训练接线 | 身体生成与平台接入参考 |
| GenBot1K 所属项目 | 多形态资产、专家训练及共享策略蒸馏 | 生成器、URDF/USD、关节描述、初始姿态与控制元数据 | 筛选资产子集，接入本项目任务 |
| MetaMorph | Unimal 模块机器人，多形态策略 | 按肢体补齐、存在/填充掩码、动作过滤与有效概率处理 | 统一接口的首选工程参考 |
| URMA | 多种足式机器人，含 Go2 等 | 逐关节状态和身体描述的共享编码/解码 | 身体元数据与结构感知对照 |
| GenLoco | 程序化四足共享控制 | 形态随机化、关节命名和未见四足评测 | 多形态训练与对照设计 |
| BodyTransformer | 将身体表示成传感器/执行器图 | 结构注意力和局部信息汇聚 | 后续结构感知对照 |

本地保留现有 locoformer 和六份源码阅读快照；框架、SDK、网格、权重与完整数据在服务器准备。[学习源码索引](../../../03_code/references/README.md) · [来源与提交](../../../03_code/references/sources.json)

### 本地 locoformer 的价值与缺口

已实现输入编码、历史网络、动作分布、PPO、随机化接口和经历重组。RemappedReplayDataset 支持把指定经历沿时间组合；采集器和跨次注意力配置为历史适应提供基础。

待接入 Go2-W 及生成身体环境，补齐语义映射、物理动作解码、同任务分组、适应预算与评测。环境对象相同不保证隐藏动力学相同，缓存保留必须以任务身份为依据。默认 Microduck 路径不等同于完整多 Trial 训练。

库包含 Beta 动作、HLGauss 价值损失、逐维 PPO 裁剪及附加模型等选择，采用时逐项记录。依赖要求 torch>=2.8，与已选仿真安装脚本的 2.7 存在待验证冲突，先做兼容性检查。[核心源码](../../../03_code/locoformer/locoformer/locoformer.py) · [训练示例](../../../03_code/locoformer/train_microduck.py)

### Baby 与 GenBot 的复用边界

Baby 主要变化四足机身长、宽与腿长，网络也作了修改。其固定 RSL-RL 子模块中 reset() 为空，序列生成器只返回一批；任务边界和多轮训练需进一步审查。它提供实现参考，公开结果尚不能证明达到原文性能。[BabyLocoFormer](https://github.com/linden713/BabyLocoFormer)

已查 GenBot 包含 1,012 份 URDF，覆盖四足、双足、六足，部分带额外膝关节。先按槽位表达能力、关节轴与可加载性筛选，完整留出测试身体。上游旧 API、绝对路径和资产依赖需转换；只复用资产不要求采用其蒸馏训练。[GenBot 项目](https://github.com/BoAi01/embodiment-scaling-laws)

## 2. 服务器运行与部署参考

| 项目 | 提供什么 | 本项目用途 |
| --- | --- | --- |
| Isaac Sim / Isaac Lab | 物理仿真、并行机器人学习框架 | 主仿真与环境组织 |
| Robot Lab | Go2-W 等任务、观测动作和奖励配置 | 普通 PPO 与轮足基线 |
| 配套 RSL-RL | PPO 采集与更新、存档、分布式基础 | 基线及训练接口参考 |
| rl_sar | 策略加载、仿真和部署，含 Go2-W 权重配置 | 参考策略闭环与动作解码 |
| Unitree MuJoCo / ROS 模型 | Go2、Go2-W MJCF/URDF | 身体、关节与参数检查 |
| Unitree SDK2 / Python | 官方状态和关节命令接口 | 实机适配 |
| Unitree RL Lab / RL Mjlab | 官方训练和部署配置 | 双向索引、控制周期及执行流程 |

以上在服务器阶段按实际需要获取，软件版本与硬件要求集中在[复现条件](04_reproduction_resources.md)。扩展对照还可查 Walk These Ways、LocoWheeledLegged、DreamWaQ_Go2W、RoboGauge 与 go2_rl_lab，当前不增加主线依赖。

## 3. 最终选择与原因

| 功能 | 选择 | 原因 |
| --- | --- | --- |
| 历史网络与 PPO | 优先本地 locoformer | 已包含较完整算法，先减少重复开发 |
| 单本体平台 | Isaac Lab + Robot Lab Go2-W | 已有明确任务和腿轮动作定义 |
| 统一输入输出 | 项目语义槽位与存在掩码，参考 MetaMorph | 接近论文统一关节空间，映射可审查 |
| 多本体资产 | 小规模参数化四足 → 筛选 GenBot → 轮足变体 | 逐步扩大覆盖，控制调试成本 |
| 实机控制 | SDK2 + 项目动作适配器 | 物理量与硬件通道可追溯 |
| 评测 | 历史配对、0/5 秒适应、整机留出 | 分别检验记忆、交互预算与泛化 |

统一空间候选为四腿七槽共 28 维，122 维观测为项目草案，字段在首次接口验收时冻结。代码准确性通过逐项映射和单位检查建立，作者最终逐项顺序与轮槽解码仍未确认。

## 4. 原论文证据与复现边界

论文的主要贡献是大规模程序化身体与强随机化训练，以及跨 Trial 的长历史适应。方法属于跨本体、基于历史的强化学习运动控制，采用 Transformer-XL 与 PPO。

| 原文条件 | 已核对信息 | 当前限制 |
| --- | --- | --- |
| 身体分布 | 四足、轮足四足、双足、轮足双足 | 原生成器与完整采样配置未确认 |
| 统一接口 | 正文描述关节超集；源文件注释提四腿七槽、补零和存在掩码 | 注释与最终权重对应关系、逐项配置待确认 |
| 训练规模 | 补充报告 128 GPU，每卡 2,048 环境 | 原设备、完整超参数和权重未齐备 |
| 历史示例 | 6 层、段长 128、50 Hz；直接缓存最多 255 步 | 项目网络先按小规模验证 |
| Benchmark | 10 种未见机器人，各 1,000 环境，few-shot 预交互 5 s | 精确评测与位移归一化实现待补 |
| Baseline | GRU、64 步历史且有运动学条件的 Conditioning、目标本体 Expert | 相关工作不等于论文已实测对照 |
| 平均得分 | zero-shot 0.96，few-shot 0.98，GRU 0.37，Conditioning 0.78，Expert 0.99 | 原协议下的归一化位移，非成功率 |

截至已查入口，未确认作者完整代码和权重。XHugWBC、H-Zero、Multi-Loco、MetaLoco、SGMA 等保留为论文资料，当前未确认可直接下载的实现不纳入执行依赖。缺失资料记录为结果对齐限制，现阶段按公开描述独立复现。[LocoFormer 项目页](https://generalist-locomotion.github.io/) · [论文](../../../01_papers/LocoFormer.pdf) · [源包](https://arxiv.org/src/2509.23745v1) · [补充材料](<../../../03_code/50_LocoFormer_Generalist_Locom_Supplementary Material/LocoFormer_Appendix.pdf>)

## 5. 阅读入口

优先顺序为本地 locoformer → MetaMorph 的观测/动作封装 → Robot Lab Go2-W 配置 → Baby 生成器 → GenBot 子集。URMA、GenLoco 和 BodyTransformer 用于针对性对照。

术语对应如下。Observation 为观测，Action 为动作，Checkpoint 为训练存档，Trial 为一次身体尝试，Episode 为保持同一隐藏任务的一组经历，Segment 为网络计算分段，Baseline 为对照方法，Benchmark 为评测协议。算法实现和实验安排见[工作计划](03_reproduction_plan.md)。
