# Go2-W 实机验证平台

更新日期为 2026-11-08。本项目实机平台为 Unitree Go2-W。下表区分厂商规格、模型声明和当前设备验证状态；实机固件、装配与控制权限尚待现场登记。

## 1. 整机与主动自由度

| 项目 | 公开条件 | 当前设备状态 |
| --- | --- | --- |
| 机型 | Unitree Go2-W 轮足四足 | 已确认 |
| 主动关节 | 12 个腿关节＋4 个轮关节，共 16 路 | 逐路方向与零位待核 |
| 每腿结构 | 髋外展、髋俯仰、膝俯仰、轮转动 | 官方模型与 SDK 已核对 |
| 浮动基座 | 机身空间 6 自由度，由腿轮接触间接控制 | 模型定义 |
| 固定/随动部分 | 外壳与传感器固定连接；所查模型未见额外随动腿关节 | 按实物复核 |
| 站立尺寸 | 约 0.70 × 0.43 × 0.50 m | 厂商规格 |
| 含电池质量 | 约 18 kg | 加装后质量待测 |
| 载荷 | 约 8 kg，最大约 12 kg | 实验载荷另定 |
| 速度、爬坡 | 0–2.5 m/s，最大坡度 35° | 产品能力，非首测设置 |
| 轮胎 | 7 英寸充气轮胎 | 胎压、有效滚动半径待登记 |
| 供电与续航 | 33.6 V、15,000 mAh，标称 1.5–3 h | 电池状态待登记 |
| 计算模块 | 标称 8 核 CPU，可选 Orin NX 等扩展 | 实际 CPU、内存和扩展模块待清点 |

MuJoCo 模型控制维数为 16，位置坐标为 23，速度坐标为 22。额外状态来自浮动基座及四元数表示。[厂商规格](https://www.unitree.com/go2-w/) · [官方 Go2-W 模型](https://github.com/unitreerobotics/unitree_mujoco/tree/1eb6642e3f3fdfb7fb13a9794fd6a2dd93ea0e7d/unitree_robots/go2w)

## 2. 电机编号与动作含义

以下编号来自 Go2-W 官方 SDK 示例。hip、thigh、calf 依次对应髋外展、大腿俯仰和膝关节。编号为零起始。

| 部位 | SDK/参考基线编号 | URDF 关节名 |
| --- | --- | --- |
| 右前腿 | 0、1、2 | FR_hip_joint、FR_thigh_joint、FR_calf_joint |
| 左前腿 | 3、4、5 | FL_hip_joint、FL_thigh_joint、FL_calf_joint |
| 右后腿 | 6、7、8 | RR_hip_joint、RR_thigh_joint、RR_calf_joint |
| 左后腿 | 9、10、11 | RL_hip_joint、RL_thigh_joint、RL_calf_joint |
| 右前轮 | 12 | FR_foot_joint |
| 左前轮 | 13 | FL_foot_joint |
| 右后轮 | 14 | RR_foot_joint |
| 左后轮 | 15 | RL_foot_joint |

官方 MJCF 的轮关节后缀为 wheel_joint，URDF/Robot Lab 使用 foot_joint。所查 Robot Lab 基线采用腿关节位置目标和轮关节速度目标。硬件编号、策略动作顺序和统一语义槽分别建立映射。[SDK 编号](https://github.com/unitreerobotics/unitree_sdk2_python/blob/814556d15970dd2ecf1c9984e845ca02ab07e206/example/go2w/low_level/unitree_legged_const.py) · [Go2-W 动作配置](https://github.com/fan-ziqi/robot_lab/blob/v2.3.2/source/robot_lab/robot_lab/tasks/manager_based/locomotion/velocity/config/wheeled/unitree_go2w/rough_env_cfg.py)

## 3. 位置、速度与力矩参数

### 3.1 官方 URDF 声明

| 关节组 | 位置范围 rad | 约合角度 | 速度上限 rad/s | effort N·m |
| --- | --- | --- | --- | --- |
| 四腿 hip | [−1.0472, 1.0472] | [−60°, 60°] | 30.1 | 23.7 |
| 前腿 thigh | [−1.5708, 3.4907] | [−90°, 200°] | 30.1 | 23.7 |
| 后腿 thigh | [−0.5236, 4.5379] | [−30°, 260°] | 30.1 | 23.7 |
| 四腿 calf | [−2.7227, −0.83776] | [−156°, −48°] | 20.07 | 35.55 |
| 四轮 foot | continuous，无有限位置端点 | 连续旋转 | 30.1 | 23.7 |

这些为模型字段；当前实机机械范围、固件限制和运行允许值待核验。[官方 URDF](https://github.com/unitreerobotics/unitree_ros/blob/master/robots/go2w_description/urdf/go2w_description.urdf)

### 3.2 来源差异

| 来源 | hip/thigh 力矩范围 | calf 力矩范围 | 轮力矩范围 |
| --- | --- | --- | --- |
| 官方 URDF effort | ±23.7 | ±35.55 | ±23.7 |
| 官方 MJCF motor ctrlrange | ±23.7 | ±45.43 | ±15 |
| Robot Lab v2.3.2 | ±23.5 | ±23.5 | ±23.5 |
| 当前实机 | 待核验 | 待核验 | 待核验 |

单位均为 N·m，MJCF 按所查直接驱动设置解释。Robot Lab 配置的速度限制为 30 rad/s。厂商标称约 45 N·m 指最大电机，并非每个关节均具有该能力。部署采用经核验的设备限值和任务范围。[MJCF](https://github.com/unitreerobotics/unitree_mujoco/blob/1eb6642e3f3fdfb7fb13a9794fd6a2dd93ea0e7d/unitree_robots/go2w/go2w.xml) · [Robot Lab 电机配置](https://github.com/fan-ziqi/robot_lab/blob/v2.3.2/source/robot_lab/robot_lab/assets/unitree.py)

## 4. 传感器与可获得状态

| 部件 | 分布 | 状态或数据 | 需实机确认 |
| --- | --- | --- | --- |
| 电机反馈 | 16 路电机 | q、dq、力矩估计、温度等 | 编号、方向、零位、有效频率 |
| IMU | 机身内部 | 四元数、角速度、加速度、RPY 等 | 轴向、顺序、单位、偏置和外参 |
| 3D LiDAR | 产品标配，机身前部 | 点云 | 型号、话题、时间戳、外参 |
| 广角相机 | 产品标配，机身前部 | 图像/视频 | 分辨率、帧率、获取接口 |
| 足端力/接触 | 消息结构含四路字段 | foot_force、foot_force_est | 当前轮足装配与字段有效性 |
| 电池管理 | 电池模块 | 电量、温度和诊断 | 实际字段及阈值 |
| 扩展相机/计算模块 | 按装配位置登记 | 深度、RGB、额外计算能力 | 是否安装、型号和标定 |

模型 IMU site 相对机身的位置为 (−0.02557, 0, 0.04232) m，实机外参需独立确认。模型的基座位置和速度可由仿真直接给出；实机对应量须注明估计来源。初期策略以本体感知与速度命令为主，相机和雷达是否进入网络由任务定义决定。[SDK 消息定义](https://github.com/unitreerobotics/unitree_sdk2/tree/main/include/unitree/idl/go2) · [模型传感器](https://github.com/unitreerobotics/unitree_mujoco/blob/1eb6642e3f3fdfb7fb13a9794fd6a2dd93ea0e7d/unitree_robots/go2w/go2w.xml)

## 5. 实机软件与控制接口

| 条件 | 用途 | 当前状态 |
| --- | --- | --- |
| 支持二次开发的固件与权限 | 获取低层状态、接管关节控制 | 待核验 |
| Unitree SDK2 / SDK2 Python | DDS 状态与命令通信 | 官方 Go2-W 示例已定位 |
| rt/lowstate | 接收 IMU 与电机反馈 | 实机订阅待验 |
| rt/lowcmd | 发送 q、dq、kp、kd、tau | 控制模式与实际执行待验 |
| SportClient | 调用厂商整机运动能力 | 可作接口了解及设备检查 |
| 推理运行环境 | 加载策略与缓存，生成控制目标 | 部署计算设备及依赖待选 |
| 机器人设备网络 | 专用网口及 DDS 传输 | 网卡、地址、延迟与掉包待测 |

SDK 消息容量与实际关节数量分别处理。服务器 SSH 穿透用于远程管理，机器人控制需单独验证设备网络与实时性。[SDK2 Python](https://github.com/unitreerobotics/unitree_sdk2_python) · [Go2-W 开发指南](https://support.unitree.com/home/en/Go2-W_developer/Quick_Start)

## 6. 仿真到实机的对齐与验收

| 对齐项目 | 要求 |
| --- | --- |
| 观测 | 字段、顺序、单位、坐标、缩放与训练一致 |
| 动作 | 腿/轮控制类型、参考姿态、增益和通道对应 |
| 时间 | 采样与控制频率、延迟、上一动作更新时间一致 |
| 记忆 | 同任务 Trial 保留与任务切换清空有明确规则 |
| 执行 | 限位、限速、力矩、变化率、超时和停止行为经验证 |

参考基线物理步长为 0.005 s，降采样 4，策略周期 0.02 s（50 Hz）。rl_sar 配套策略为 57 维观测、16 维动作；该规格属于平台基线。策略输入维度以实际训练配置为准。[Go2-W 基线配置](https://github.com/fan-ziqi/rl_sar/tree/376d42c9b128f963ab08579762d5a216a976ce39/policy/go2w)

首轮交付为实物配置登记、16 路映射、静止状态日志和有效频率记录。随后完成离线推理、时延测量，再进入低速实机闭环。平台当前已确认机型与公开接口，尚缺设备级验证证据。
