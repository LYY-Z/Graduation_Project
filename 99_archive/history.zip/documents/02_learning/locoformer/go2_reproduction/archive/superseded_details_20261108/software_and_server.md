# 软件栈与服务器资源

## 1. 运行栈分层

| 层 | 组件与版本 | 职责 | 本项目状态 |
|---|---|---|---|
| 物理仿真 | Isaac Sim 5.1 | 刚体、关节、接触、地面与传感器仿真 | 尚未部署到完整运行状态 |
| 机器人学习框架 | Isaac Lab 2.3.2 | 并行环境、任务接口和 RL 工作流 | 计划与 Isaac Sim 配套安装 |
| 任务和资产 | Robot Lab 2.3.2 | Go2-W 资产、动作定义、观测和奖励基线 | Go2-W 配置已整理 |
| 策略算法 | PyTorch + LocoFormer 参考实现 | Transformer-XL、Actor/Critic、PPO 和记忆状态 | 源码可用于学习和接线，属于第三方实现 |
| 实机通信 | Unitree SDK2 | 读取硬件状态、发送低层命令 | 用于后续实机适配 |
| 交叉核对 | Unitree MuJoCo | 检查关节和轮子模型、控制约定 | 辅助模型核对，不作为主训练器 |

## 2. 版本兼容关系

目标版本基于项目当前规划：Isaac Sim 5.1、Isaac Lab 2.3.2、Robot Lab 2.3.2。Isaac Lab 是运行在 Isaac Sim 上的机器人学习框架，Robot Lab 依赖 Isaac Lab 的 API 和资产约定。因此不能把三者视作可随意混装的独立 Python 包：安装顺序、分支版本和运行方式需要保持兼容。

Robot Lab v2.3.2 的 Go2-W 资产可以作为仿真起点，但需要核对其 URDF 的轮关节 continuous 声明、PD 参数、执行器限值和项目动作语义。MuJoCo 使用 MJCF 模型描述物理系统，不等同于 Isaac Sim 的 USD/URDF 导入和执行器配置。

## 3. 服务器资源

最近一次只读核查时间为 2026-11-06。

| 项目 | 服务器条件 | 复现影响 |
|---|---|---|
| 系统 | Ubuntu 22.04.5 LTS | 满足 Isaac Sim 5.1 的受支持 Linux 基线 |
| GPU | RTX PRO 5000 Blackwell × 2，每卡约 48 GiB | 可按实际显存和吞吐量逐步增加环境并行数 |
| CPU | 96 个逻辑处理器 | 用于仿真调度和数据处理 |
| 内存 | 约 251 GiB RAM | 高并行仿真的系统内存余量较充足 |
| 存储 | 约 445 GiB 可用空间 | 需留意仿真安装包、环境缓存、检查点和日志增长 |
| NVIDIA 驱动 | 580.178.04 | GPU 运行支持 |
| Python | 独立 Conda 环境，Python 3.11 | 依赖隔离基础已经建立 |

Isaac Sim 5.1 官方 Linux 基线要求 Ubuntu 22.04 或 24.04、至少 16 GB GPU 显存、32 GB RAM 和 50 GB SSD。服务器达到该文档列出的基础门槛。两张卡的显存不能合并成单张 96 GiB 显存，环境并行数和训练批量仍需实测调整。

来源：[Isaac Sim 5.1 系统要求](https://docs.isaacsim.omniverse.nvidia.com/5.1.0/installation/requirements.html)。

## 4. 训练规模的解释

论文补充材料报告 128 张 GPU、每张 GPU 并行 2,048 个环境。当前两张 GPU 适合完成软件链路、Go2-W 基线、机制消融和小规模多本体实验，但训练规模与论文报告不同。后续汇报应分别说明“复现的机制和评测协议”与“可用计算规模”，不以环境并行数较小掩盖差异。

## 5. 现有准备与下一阶段

已具备：Ubuntu 服务器、GPU 驱动、独立 Conda Python 3.11 环境、Go2-W 公开模型与 SDK 资料、代表性参考项目和接口规划。

下一阶段：按指定版本部署 Isaac Sim/Lab/Robot Lab，先以小规模并行启动 Go2-W 场景，检查模型加载、物理步进、关节状态、轮速命令、奖励信号和日志；基线可复现后再接入长历史策略。

## 6. 软件组件来源

- [Isaac Sim 5.1 要求](https://docs.isaacsim.omniverse.nvidia.com/5.1.0/installation/requirements.html)
- [Isaac Lab v2.3.2](https://github.com/isaac-sim/IsaacLab/releases/tag/v2.3.2)
- [Robot Lab v2.3.2](https://github.com/fan-ziqi/robot_lab/tree/v2.3.2)
- [Unitree SDK2](https://github.com/unitreerobotics/unitree_sdk2_python)
- [Unitree MuJoCo](https://github.com/unitreerobotics/unitree_mujoco)
