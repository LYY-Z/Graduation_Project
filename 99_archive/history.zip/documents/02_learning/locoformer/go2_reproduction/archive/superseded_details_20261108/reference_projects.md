# 参考项目与资料目录

本项目不会把所有公开仓库合并成一个运行栈。每个项目只承担它最擅长的部分；论文原文决定研究方法，代码和模型负责提供实现线索。

## 1. 论文和作者资料

| 资料 | 原始用途 | 本项目使用方式 | 限制 |
|---|---|---|---|
| LocoFormer 论文 | 提出多本体大规模强化学习和长上下文适应方法 | 确定目标机制、基准、实验协议和论文结论 | 论文没有给出完整、可直接迁移的作者训练仓库和全部部署工程 |
| 补充材料 | 提供额外实验和训练规模等信息 | 核对并行环境、训练流程和实机案例 | 不能代替完整源码与逐项配置 |
| LocoFormer 作者项目页 | 介绍论文与展示视频 | 汇报时展示实机案例 | 展示材料不能用于推断没有公开的配置细节 |

链接：[论文 PDF](https://openreview.net/pdf?id=VqmAvBkFhw) · [补充材料](https://openreview.net/attachment?id=VqmAvBkFhw&name=supplementary_material) · [项目页](https://generalist-locomotion.github.io/)。

## 2. 仿真与机器人任务

### Robot Lab v2.3.2

Robot Lab 是基于 Isaac Lab 的机器人学习扩展项目，提供机器人模型、任务配置、奖励和训练入口。仓库包含 Go2-W 资产与速度控制任务，是本项目优先使用的 Go2-W 仿真基线。

可借鉴：
- Go2-W URDF/资产、初始关节姿态和轮关节定义；
- Isaac Lab 任务如何组织观测、动作、奖励和随机化；
- 现有 actuator 配置如何区分腿部与轮子。

不宜直接照搬：机器人资产与 Reward 只是一种仿真任务设置，不等同 LocoFormer 的程序化形态生成或跨 Trial 训练。版本固定为 [Robot Lab v2.3.2](https://github.com/fan-ziqi/robot_lab/tree/v2.3.2)。

### Isaac Lab 2.3.2 与 Isaac Sim 5.1

Isaac Sim 提供物理引擎和仿真场景；Isaac Lab 在其上提供机器人学习工作流、并行环境和任务接口。二者是底层引擎与学习框架的关系。Robot Lab 再基于 Isaac Lab 提供 Go2-W 任务。

链接：[Isaac Sim 5.1 要求](https://docs.isaacsim.omniverse.nvidia.com/5.1.0/installation/requirements.html) · [Isaac Lab v2.3.2 发布](https://github.com/isaac-sim/IsaacLab/releases/tag/v2.3.2)。

## 3. 算法实现代码

### 本地 `locoformer`

当前本地仓库来源于 lucidrains / Phil Wang 的第三方 PyTorch 实现。可用于理解和复用 Transformer-XL、segment 缓存、Actor/Critic、PPO rollout 与优化器更新的代码结构。它不是 LocoFormer 作者的训练仓库，配置默认值也不应写成论文设置。

链接：[第三方实现仓库](https://github.com/lucidrains/locoformer)。

### BabyLocoFormer

这是非官方复现线索，重点是把类似算法接入 Isaac Lab、构造机器人身体并验证训练管线。适合研究任务组装和环境接线，不应作为作者原始实现或论文实验配置的依据。

链接：[BabyLocoFormer](https://github.com/linden713/BabyLocoFormer)。

## 4. 实机接口和模型

### Unitree SDK2

SDK2 是读取 Go2-W 状态和发送低层控制命令的官方通信接口。项目主要借鉴消息类型、Low-level 电机编号和命令发送方式。SDK 不负责定义 LocoFormer 的观测空间或跨本体网络。

链接：[Unitree SDK2 Python](https://github.com/unitreerobotics/unitree_sdk2_python) · [Go2-W 电机常量](https://github.com/unitreerobotics/unitree_sdk2_python/blob/814556d15970dd2ecf1c9984e845ca02ab07e206/example/go2w/low_level/unitree_legged_const.py)。

### Unitree MuJoCo

官方模型和示例可帮助核对轮关节是否连续、关节方向、名字、控制模式和观测量。它适合作为模型/接口交叉检查；本项目主训练栈仍选 Isaac Sim/Lab/Robot Lab，以复用现成 Go2-W 任务。

链接：[Unitree MuJoCo](https://github.com/unitreerobotics/unitree_mujoco)。

## 5. 跨本体表示方法

| 项目 | 原问题与设计重点 | 对本项目的参考 | 与本项目初版方案的关系 |
|---|---|---|---|
| MetaMorph | 用身体结构描述和模块化策略处理不同机器人 | 统一结构描述、身体条件和策略输入输出 | 可作为“固定槽位 + 有效位”之外的形态条件化方案对照 |
| URMA | 用逐关节表示与注意力处理不同关节数量 | 每关节描述、关节集合处理和动作生成 | 有助比较逐关节编码与固定维度槽位的扩展性 |
| GenBot1K | 收集或生成多样机器人模型资产并研究 embodiment scaling | 选择和筛选多本体 URDF，建立测试身体库 | 资产并不自动包含接触正确的仿真环境、控制器和策略 |

链接：[MetaMorph](https://arxiv.org/abs/2203.11931) · [URMA](https://arxiv.org/abs/2409.06366) · [GenBot1K / embodiment scaling](https://github.com/BoAi01/embodiment-scaling-laws)。

## 6. 选型结论

- **主仿真**：Isaac Sim 5.1 + Isaac Lab 2.3.2 + Robot Lab 2.3.2。
- **算法入口**：第三方 `locoformer` 作为阅读与改造起点，逐项对照论文定义。
- **实机接口**：Unitree SDK2。
- **模型检查**：Unitree MuJoCo 与官方 URDF。
- **形态设计参考**：MetaMorph、URMA、BabyLocoFormer、GenBot1K 各取对应部分，不把它们误认为完整复现环境。

优先目标是建立单本体基线、统一接口和跨 Trial 记忆实验，再扩展程序生成与整机留出评测。
