# 05｜仿真软件栈与服务器计算条件

## 1. 软件栈的职责边界

```mermaid
flowchart LR
  A[Isaac Sim：仿真引擎与资产运行] --> B[Isaac Lab：RL 环境/并行采样]
  B --> C[Robot Lab：Go2-W 资产与任务配置]
  C --> D[LocoFormer 策略：MLP + TXL + Actor/Critic + PPO]
  D --> E[训练模型与评测日志]
  E --> F[Unitree SDK2 适配层]
  F --> G[Go2-W 实机]
```

| 组件 | 作用 | 在本项目中的位置 | 不能替代什么 |
|---|---|---|---|
| NVIDIA Isaac Sim | 物理仿真、场景、碰撞与资产运行 | 仿真底层 | 不定义 LocoFormer 方法或机器人任务指标 |
| Isaac Lab 2.3.2 | Isaac Sim 上的机器人学习框架，提供环境和 RL 工作流 | 训练任务底座 | 不等同于单独可用的物理引擎 |
| Robot Lab 2.3.2 | Isaac Lab 的机器人资产和任务扩展，包含 Go2-W 相关配置 | Go2-W 单体基线 | 不包含论文的完整 TXL 跨 Trial 训练算法 |
| LocoFormer 算法 | 输入观测与历史，输出动作；训练时通过 PPO 更新 | 需要接入仿真任务 | 不能替代仿真资产和硬件通信 |
| Unitree SDK2 | 与真机交换状态/命令 | 实机通信 | 不替代策略输入输出适配和安全逻辑 |
| Unitree MuJoCo | MuJoCo 格式下的模型/控制参考 | 辅助核对 | 不等于 Isaac Sim 主训练路线 |

## 2. 版本路线与注意事项

当前项目拟定的可复现基线为：**Isaac Sim 5.1 + Isaac Lab 2.3.2 + Robot Lab 2.3.2，Python 3.11**。版本需整体锁定，安装后在记录中保存 git commit、依赖版本、CUDA/驱动、模型版本。不能只固定其中一个 tag，再混用其它仓库 main 分支。

NVIDIA Isaac Lab 2.3.2 安装说明给出的 5.x 依赖 Python 3.11，并建议使用 Isaac Sim 5.1。当前 Isaac Sim 5.1 官方文档已标为 unsupported release（该版本不再接收新功能和修复）；因此此选择是基于与所选 Isaac Lab/Robot Lab 版本的配套和研究复现稳定性，不代表是 NVIDIA 当前支持的最新产品组合。

若 5.1 兼容性或驱动在服务器上出现不可解决问题，再单独评估更新版本。Isaac Sim 6.x/Isaac Lab 3.x 涉及 Python、API 和架构变化，不能仅升级 Isaac Sim 后继续沿用 2.x 代码。

## 3. 服务器资源与实际意义

最后一次只读核查：2026-11-06。

| 资源 | 当前服务器 | Isaac Sim 5.1 官方基础要求/说明 | 判断 |
|---|---|---|---|
| 操作系统 | Ubuntu 22.04.5 LTS | Ubuntu 22.04/24.04 | 满足操作系统基线 |
| GPU | RTX PRO 5000 Blackwell ×2，每卡约 48 GiB | Minimum 表列 16 GB VRAM；高级训练建议更多 | 单卡显存足够；两张卡是两块设备，不能当成一块 96 GiB 显存 |
| NVIDIA 驱动 | 580.178.04 | 5.1 文档测试版本 580.65.06 及以后建议分支 | 版本号达到文档门槛，实际需运行兼容性检查 |
| CPU | 96 逻辑处理器 | 建议 8–16 核等级 | 仿真调度资源充足，仍需按负载测试 |
| RAM | 约 251 GiB | 基线 32 GB，建议 64 GB | 容量充足 |
| 磁盘 | 约 445 GiB 可用 | Minimum 50 GB、Good 500 GB、Ideal 1 TB | 能做初步环境；大量资产、checkpoint、视频日志会消耗空间 |
| Python 环境 | 已有隔离 Conda Python 3.11 | Isaac Sim 5.x / Isaac Lab 2.3.2 要求 3.11 | Python 基础版本匹配，Isaac 栈尚未完成部署 |

以上资源数来自一次服务器检查，不是对长时间训练吞吐的保证。GPU 名称也不能直接换算成环境并行数；需要用实际 Go2-W task 做小规模 benchmark 并逐步增加 `num_envs`，同时监测显存、RAM、仿真步频和 PPO 采样速度。

## 4. 能不能复现论文规模

可以在当前服务器上复现研究机制和开展规模适中的实验；不能据此承诺复现论文的大规模训练速度或统计效果。

论文补充材料展示 32、64 与 128 GPU 的训练规模对照，并指出更大计算量能带来更好的最终模型，同时存在计算量与效果的折中。公开材料不应被简化成未经核实的“每 GPU 固定 2,048 个环境”；更准确的汇报应引用论文图表中的 GPU 数和训练迭代数，并在项目实测中报告自己的环境并行数。本服务器两张 GPU 与论文最大训练规模差距很大。该差距影响可生成/训练的总步数、身体数、重复种子和实验时长；是否能以较少算力复现定性机制，要通过训练收敛、不同 seed 的方差、历史消融和留出身体评估验证。报告应分别写明方法复现程度和资源差异。

合理目标分层：

1. 先跑通一台 Go2-W 的小并行环境和 PPO baseline。
2. 验证跨 Trial TXL cache 的数值/边界正确性。
3. 选少量身体做机制实验和 mask/representation 消融。
4. 若 GPU/时间允许，再增加身体数量和并行环境，按完整本体留出。
5. 不把较小样本上的单次曲线与论文大规模均值直接当作同等复现结果。

## 5. MuJoCo / MJCF 与 Isaac Sim / URDF/USD 的关系

MJCF 是 MuJoCo 用于描述 world、body、joint、actuator、contact 等模型的 XML 格式；URDF 是机器人描述格式，常用于链接/关节/惯量和可视化/ROS 生态。二者都能描述机器人结构，但不是同一种文件，也不是一份配置在两种仿真器里自动具有同一物理意义。

当前主训练计划选择 Isaac Sim + Isaac Lab + Robot Lab；MuJoCo 用于交叉检查关节语义、轮连续性和控制约定。若后续用 MuJoCo 做仿真对照，需要另外校准碰撞几何、接触摩擦、执行器模型、PD 参数、积分步长和传感器噪声，不能把“模型文件转换成功”当成物理行为相同。

## 6. 环境部署后应保留的记录

- 操作系统、内核、NVIDIA 驱动、GPU 型号/显存、CUDA runtime。
- Conda 环境 Python 版本和锁定依赖清单。
- Isaac Sim / Isaac Lab / Robot Lab tags 与 Git commit。
- Go2-W 资产来源、模型文件 hash、执行器配置、任务配置。
- 启动命令、日志目录、配置覆盖项和随机种子。
- 单环境启动结果、扩展到多环境的吞吐/显存曲线。

## 来源

- [Isaac Sim 5.1 requirements](https://docs.isaacsim.omniverse.nvidia.com/5.1.0/installation/requirements.html)
- [Isaac Lab 2.3.2 installation guide](https://isaac-sim.github.io/IsaacLab/v2.3.2/source/setup/installation/index.html)
- [Isaac Lab 2.3.2 release](https://github.com/isaac-sim/IsaacLab/releases/tag/v2.3.2)
- [Robot Lab 2.3.2 release](https://github.com/fan-ziqi/robot_lab/releases)
- [Robot Lab Go2-W assets/configuration](https://github.com/fan-ziqi/robot_lab/tree/v2.3.2)
- [Unitree MuJoCo](https://github.com/unitreerobotics/unitree_mujoco)
