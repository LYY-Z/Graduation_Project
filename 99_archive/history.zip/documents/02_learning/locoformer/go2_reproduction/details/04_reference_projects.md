# 04｜参考项目、用途与本项目选型

参考项目不是一套可以直接拼装的“完整复现包”。它们分别解决形态表示、训练环境、算法组件、机器人资产或实机通信中的某一部分。使用前要先说明：原项目解决什么问题、我们借用什么、与 LocoFormer 的差异是什么。

## 1. 研究与表示方法

### LocoFormer 论文及作者项目页（首要研究依据）

- **原本用途**：训练一个跨身体运动策略，通过程序化身体训练、动力学随机化和 TXL 跨 Trial 长历史适应未见身体。
- **本项目借鉴**：研究问题、机制、统一关节空间、PPO + 记忆机制、论文评测基线和报告边界。
- **边界**：公开论文说明了统一 joint superset，但没有给出 Go2-W 每个 canonical slot 的完整工程表。论文网页/展示视频不是作者训练代码和配置文件。
- **优先级**：所有架构实现和实验结论都对照论文，参考仓库不能覆盖论文定义。

来源：[CoRL 2025 论文 PDF](https://openreview.net/pdf?id=VqmAvBkFhw) · [作者项目页](https://generalist-locomotion.github.io/) · [补充材料](https://openreview.net/attachment?id=VqmAvBkFhw&name=supplementary_material)。

### URMA：可变关节数的逐关节表示

- **原本用途**：构建适用于不同形态腿式机器人的通用控制器，通过形态无关 encoder/decoder 在机器人间共享策略。
- **核心可借鉴**：按关节形成 token/表示，再以共享注意力传递跨关节信息，输出对应关节动作；适合关节数量和拓扑变化大时使用。
- **与 LocoFormer 差异**：不是同一套输入合同或方法。LocoFormer 正文强调统一的 superset joint space 和长历史适应；URMA 以形态表示结构支持多本体控制，其训练和结构需要分别复现。
- **适合本项目的用途**：作为跨四足/人形/六足时的架构比较，不作为第一阶段强制替换方案。

来源：[URMA PMLR 正式页面](https://proceedings.mlr.press/v270/bohlinger25a.html)。

### MetaMorph：形态条件化的通用控制思路

- **原本用途**：研究模块化机器人形态上的 Transformer 通用控制，并把形态作为策略条件。
- **可借鉴**：形态结构/模块信息如何作为输入，策略怎样在同一模型中处理组合变化。
- **限制**：它不是 Go2-W 专用运动策略，也不提供 LocoFormer 的跨 Trial PPO/TXL 复现。引用它说明“形态可被模型显式表示”即可，不要称为可直接迁移的轮足控制器。

来源：[MetaMorph 项目页](https://metamorph-iclr.github.io/site/) · [ICLR 2022 论文](https://openreview.net/forum?id=Opmqtk_GvYL)。

## 2. 机器人资产与多身体训练

### GenBot-1K / embodiment-scaling-laws

- **原本用途**：程序生成约 1,000 个 humanoid、quadruped 和 hexapod 机器人描述，研究训练身体数量与未见身体泛化的关系。
- **能借什么**：形态资产生成、URDF/USD 转换线索、身体库组织、训练/测试身体划分、整机留出实验。
- **不能直接假定**：URDF 集合不是已经验证的 RL 环境集合。要为每个身体检查质量/惯量、碰撞、关节轴和限位、执行器模型、站立初态、稳定控制和仿真数值；否则“增加身体数”只是增加坏模型。
- **路线建议**：先验证 Go2-W 单体环境和算法接口，再挑少量资产加入；建立模型审核和可训练性筛选后，才扩大到整套数据。GenBot-1K 论文采用了自己的 URMA 系列策略/蒸馏设置，不能将其结果归因于 LocoFormer。

来源：[项目页](https://embodiment-scaling-laws.github.io/) · [CoRL 论文](https://openreview.net/pdf?id=9LMG2hQ3jq) · [仓库](https://github.com/BoAi01/embodiment-scaling-laws)。

### BabyLocoFormer（最接近的非官方机制实现参考）

- **仓库自述包含**：基于 Isaac Lab 的非官方 LocoFormer“学习版”；Transformer-XL 变体、多形态四足生成、有限域随机化、训练与评估入口。
- **可借什么**：从 Isaac Lab 环境接入 TXL、把生成机器人转成仿真资产、组织 rollout 和训练/评测脚本的工程样例。
- **边界**：作者明确称其为 unofficial baby version；TXL 实现与原始形式不同，并加入 Flash Attention、RoPE、SwiLU；形态覆盖以四足为主，域随机化有限。README 自述主要用于学习且结果较弱、单 RTX 5090 训练。它适合作为代码阅读和管线验证，不是论文性能对齐证据。

来源：[BabyLocoFormer README](https://github.com/linden713/BabyLocoFormer)。

## 3. 本地第三方策略代码

### `G:\毕设\03_code\locoformer`（lucidrains / Phil Wang）

- **仓库定位**：通用 PyTorch LocoFormer 灵感实现，包含 TXL、PPO、Actor/Critic、回放等程序组件；README 示例支持多个输入状态维数和动作 selector。
- **代码中怎么处理输入差异**：`StateEmbedder` 为 `dim_state` 列表中的每种状态宽度创建一个 MLP，每个 MLP 投影到统一 `dim`；调用者传 `state_id` 决定使用哪一个。它不会仅凭输入自动识别身体。动作侧由 `selector_index` 选择动作输出配置/子集。
- **本项目能借什么**：读懂 embedding → TXL → Actor/Critic、segment/cache、PPO rollout 与更新；做最小策略接口样例。
- **不能借此宣称**：这是论文作者仓库；其多输入模式就是任意未见本体通用策略；具备 Go2-W 输入/输出和实机部署。

来源：[本地仓库 README 对应上游](https://github.com/lucidrains/locoformer)，本地需以当前文件版本为准。

## 4. 仿真资产和 Go2-W 任务

### Isaac Sim + Isaac Lab + Robot Lab 2.3.2

- Isaac Sim：物理仿真、场景与资产运行底座。
- Isaac Lab：在 Isaac Sim 上组织 RL 环境、并行采样和训练流程。
- Robot Lab：基于 Isaac Lab 的机器人/任务扩展；可作为 Go2-W 资产与速度任务起点。
- **本项目借什么**：先得到可启动的 Go2-W 任务、状态通路、动作通路和单体 PPO baseline。
- **边界**：这条现成任务不是 LocoFormer。需要查锁定版本中 Go2-W 实际 asset、关节/轮 actuator、观测和动作定义；不能只看到 `UNITREE_GO2W_CFG` 就认为训练配置与硬件已完全对齐。

来源：[Robot Lab v2.3.2](https://github.com/fan-ziqi/robot_lab/tree/v2.3.2) · [发行记录](https://github.com/fan-ziqi/robot_lab/releases) · [Isaac Lab 2.3.2](https://github.com/isaac-sim/IsaacLab/releases/tag/v2.3.2)。

### Unitree RL Lab

- **原本用途**：Unitree 自有机器人在 Isaac Lab 上的强化学习和部署工程。
- **可借什么**：观测项顺序、动作 scaling、PD 配置、策略部署接口和真实硬件软件结构。
- **限制**：它的任务、Actor 和训练目标不是 LocoFormer；Go2 普通四足示例通常 12 关节，不能直接当作 Go2-W 16 执行器的正确设置。
- **选型**：与 Robot Lab 并列作映射/部署参考，但第一阶段以版本锁定、资料和实际仿真配置最容易复核的一条路线为主，不把两套 task config 混用。

来源：[Unitree RL Lab](https://github.com/unitreerobotics/unitree_rl_lab)。

### Unitree MuJoCo 与官方模型

- **用途**：交叉核对关节名称、连续轮、轴向、初始姿态和控制字段；适合后期做 sim-to-sim 检查。
- **边界**：MJCF 是 MuJoCo 的模型格式，Isaac Sim 主路线使用 USD/URDF 等资产；两边的接触/执行器/控制设置不自动等价。不是当前主训练器。

来源：[Unitree MuJoCo](https://github.com/unitreerobotics/unitree_mujoco) · [Unitree ROS/URDF](https://github.com/unitreerobotics/unitree_ros)。

## 5. 实机通信

### Unitree SDK2

- **用途**：与 Go2-W 状态和低层控制消息通信，核对 16 路电机的通道常量与 command 字段。
- **不可替代**：它不定义策略的 canonical 关节槽位、不训练策略，也不会把任意策略动作自动变成安全电机命令。
- **本项目适配器**：读取 SDK 状态 → 组装策略观测；策略动作 → 顺序/单位/方向/类型转换 → SDK 命令；同时保留输入输出和反馈日志。

来源：[Unitree SDK2 Python](https://github.com/unitreerobotics/unitree_sdk2_python)。

## 6. 选型矩阵

| 工作包 | 主工具/资料 | 辅助参考 | 选择理由 |
|---|---|---|---|
| 研究定义与指标 | LocoFormer 原文/补充材料 | 作者项目页 | 唯一对论文结论负责的依据 |
| Go2-W 单体仿真 | Robot Lab 2.3.2 | Unitree RL Lab | 从真实 Go2-W 资产/任务起步，先验证控制链路 |
| TXL/跨 Trial 管线 | 本地 lucidrains 代码 + 逐段对照论文 | BabyLocoFormer | 前者便于读核心代码，后者提供 Isaac Lab 接线样例 |
| 多本体资产 | GenBot-1K 挑选/生成少量机器人 | Robot Lab 其它模型 | 逐个检验物理资产，再扩大分布 |
| 可变关节数架构对照 | URMA | MetaMorph | 对照 joint-token 与结构条件化，不混称为 LocoFormer |
| 真机 I/O | Unitree SDK2 + 官方 URDF | Unitree RL Lab deployment | 形成独立可复核的硬件适配层 |

## 7. 在本地与服务器上的使用原则

本地参考仓库用于阅读、检索和比较；需要运行的仿真依赖、训练代码及大型模型资源放服务器，避免在个人电脑上搭建未计划的 GPU 环境。多个上游项目可以保留网页/版本引用，不要求全部 clone；只将进入当前工作包的仓库固定 commit 并放在项目受控目录。此原则避免参考资料清单膨胀成多个互相冲突的运行栈。
