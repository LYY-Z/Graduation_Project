# FLAIR 六足仿真复现计划

**复现对象**　Allard 等，*Getting Robots Back on Track by Reconstituting Control in Unexpected Situations with Online Learning*，*Nature Communications*，2026。首轮复现论文补充材料中的六足 Chicane 弯道实验。

**目标**　用公开数据复核原结果，再用作者代码独立生成四组实验结果。随后从源代码和日志中明确 FLAIR 的指令、反馈、模型更新与重置接口，作为 Go2-W 迁移的输入。

**当前状态**　已核对正式代码版本、下载清单、笔记本和实验入口。环境安装、原始数据分析与仿真运行列入下方执行步骤。

## 1. 实验要验证什么

六足机器人沿预设航点行驶。路径跟踪器给出期望前进速度和偏航率，底层控制器据此选择一组六足动作。FLAIR 开启时，上层会根据已下发指令和实测车体运动更新响应模型，再选出更接近期望运动的补偿指令。场景变化检测触发时，原方法会重置在线数据与模型。

~~~text
航点与位姿 → 路径跟踪器 → 期望车体运动 → FLAIR → 下发车体指令 → 六足控制器库 → Brax
                                           ↑                               │
                                           └────── 车体运动与时间戳 ────────┘
~~~

四组共用路线、控制器库和默认运行设置。默认损伤分支从仿真初始化时启用，发布版的损伤配置把 leg_3_1_2 和 leg_3_2_3 的执行器强度从 60 降至 20，body_leg_3 保持 60。README 将其称为中右腿减力。损伤组主表的 Scaling_Value 可以是 1.0，因为损伤施加在仿真模型中，应以 Damage_Type 和模型配置识别。Go2-W 的行驶中突变实验将在下一阶段单独设计。

| 组别 | 六足状态 | FLAIR | 作用 |
| --- | --- | --- | --- |
| healthy_driver | 健康 | 关闭 | 建立健康时的路径跟踪水平 |
| healthy_flair | 健康 | 开启 | 检查健康状态下启用补偿后的表现 |
| weakened_driver | 中右腿减力 | 关闭 | 测量减力造成的性能变化 |
| weakened_flair | 中右腿减力 | 开启 | 测量开启补偿后的恢复程度 |

原论文还包含 GVR-Bot 履带车实机实验，其独立复现需要原平台与传感器。六足主线结束后，可用公开数据复核对应实机图表。

## 2. 准备工作空间与材料

在 Linux 服务器的个人工作目录中执行。六足示例按作者提供的 CPU 路径运行，使用独立 Conda 环境。默认仿真无须启动 ROS 2、连接实体机器人或打开 VNC。生成的轨迹和可选 HTML 回放可传回后查看。

~~~text
flair_reproduction/
├── upstream/FLAIR/       固定版本的作者源码与六足控制器库
├── data/author/          作者 notebook 与原始 CSV
├── analysis/             执行后的 notebook、统计表与图
└── runs/                 本次生成的日志、轨迹、配置与依赖记录
~~~

### 2.1 固定源码与底层控制器

源码放在工作空间的 upstream/FLAIR 目录，固定为作者发布的 v1.0.0。记录 Git 提交或归档校验值，作为后续运行的版本依据。

对应提交为 9e1fa31a8f39b912c5edb61bd65ba15289241276。使用 GitHub 上的固定版本或 Zenodo 官方代码归档。使用 ZIP 归档时，校验 MD5 为 fc9fb0356fb81b5995360891fedc1bf0，并记录归档来源。源码目录包含 README.md 和 fast_adaptation。

运行前确认 fast_adaptation/example/map_elites_map/config.csv 和同目录下 repertoire_MAP-Elites_180813 中的 centroids.npy、descriptors.npy、fitnesses.npy、genotypes.npy 均存在。它们共同组成作者已生成的 MAP-Elites 六足控制器库。示例按车体指令从库中选取控制器，首轮可直接使用。

### 2.2 下载公开实验数据

四组主实验需要以下文件。CSV 合计约 143 MB，Zenodo 记录提供每个文件的 MD5。

| 文件 | 实验条件 | MD5 |
| --- | --- | --- |
| FLAIR_plots_simplified_Hexapod.ipynb | 分析与绘图笔记本 | f4625a2bcdb3ac84b28aaa198392530c |
| hexapod_main_no_flair_no_perturb.csv | 健康，关闭 FLAIR | 7e96eb7574acd7791e2f667ffdcc3e29 |
| hexapod_main_flair_no_perturb.csv | 健康，开启 FLAIR | 2855ecc0a03f66624a67eead9180ea31 |
| hexapod_main_no_flair.csv | 中右腿减力，关闭 FLAIR | dec32648076694b89c1e72b7d2bfc6af |
| hexapod_main_flair.csv | 中右腿减力，开启 FLAIR | 4d86df193d6d3825fc02e89a6ab8a2cc |

将笔记本和四份 CSV 保存在同一目录，按上表校验文件。

完整笔记本还会读 hexapod_remove_no_flair.csv、hexapod_remove_flair.csv、hexapod_front_leg_no_flair.csv 和 hexapod_front_leg_flair.csv。只做主四组时，在笔记本副本中保留四组读取和对应汇总，把 all_sections 限定为 Chicane Broken Middle Leg，从 all_final_errors 和 all_final_times 的对应键生成四组图表。保留原计算函数和单位转换，按需跳过后面的扩展工况与轨迹单元。运行完整作者分析时，补齐八份 CSV，后续轨迹细节单元也按文件与试次依赖核对。

## 3. 建立 CPU 环境

使用 Python 3.11，保留作者的 QDax 0.3.0、GPJax 0.5.0、Optax 0.1.7、Brax 0.10.2 和 SciPy 1.12.0。作者依赖清单使用 JAX 的 CUDA extra。本计划将六足示例改用 PyPI 提供的 CPU 版 JAX 与 jaxlib 0.4.22，并限制 NumPy 低于 2。Flax、Chex 和 Orbax 的版本是初始兼容候选，以解析结果和冒烟验证为准。

~~~bash
conda create -n lyy_flair_v100_cpu python=3.11 pip -y
conda activate lyy_flair_v100_cpu

export JAX_PLATFORMS=cpu
export MPLBACKEND=Agg

sed -e '/^--find-links /d' \
    -e '/^jax\[/c\jax==0.4.22' \
    -e '/^triton$/d' \
    "$FLAIR_SRC/singularity/requirements.txt" > "$FLAIR_WORK/requirements-cpu.txt"

cat >> "$FLAIR_WORK/requirements-cpu.txt" <<'EOF'

jaxlib==0.4.22
numpy<2
flax==0.7.5
chex==0.1.85
orbax-checkpoint==0.4.4
scikit-learn==1.4.2
ipykernel
nbconvert
EOF

python -m pip install -r "$FLAIR_WORK/requirements-cpu.txt"
python -m pip check
python -m pip freeze > "$FLAIR_WORK/runs/requirements-resolved.txt"
~~~

检查解释器、JAX 设备、主要包和示例入口。JAX 应报告 CPU 设备，示例应能输出参数帮助。默认运行会加载 GP 分支，因此单独导入包和执行 --help 都只是环境检查，完整性还需通过实际仿真运行验证。示例的相对导入和控制器库路径基于当前工作目录。

~~~bash
python -c "import sys, jax, jaxlib, brax.v1, qdax, gpjax, sklearn; print(sys.executable); print(jax.__version__, jaxlib.__version__, jax.devices()); print(jax.jit(lambda x: x + 1)(1).block_until_ready())"
cd "$FLAIR_SRC/fast_adaptation/example"
python flair_example.py --help
~~~

如果服务器不能访问包索引，优先使用可访问的镜像，或在相同架构的 Linux 和 Python 3.11 环境中准备完整依赖再传入。首轮按错误来源检查缺包、版本、路径或模型资产，保留初始和成功时的依赖记录。若 Conda 路径持续遇到旧依赖冲突，可评估仓库提供的 Apptainer 容器构建方案，并记录所用 Python 和依赖版本。

## 4. 用作者数据复核指标与图表

1. 在同一数据目录复制一份笔记本，保留原文件。先运行导入、函数定义和主四组读取及其后续汇总单元。以官方文件从 0 开始计数，主四组读取在第 20、23、26、29 个单元，分别执行后面紧邻的汇总单元。修改 all_sections 后，运行主图函数及其调用，或直接从四组统计字典导出表格。笔记本按相对路径读 CSV。将执行后的笔记本、主要图和每组汇总表存到 analysis。
2. 记录每组有效回合数、每回合指令跟踪误差及完成时间。作者笔记本的原有输出对中右腿减力主实验四组分别显示 20 回合。本次复画应同时核对实际读到的回合数和有效样本量。
3. 保留作者的对齐、滤波、边界剔除和每回合聚合规则。**作者指标中的 Tracking Error 是车体速度指令跟踪误差**。它使用对齐后的前进速度和偏航率两项差值，每回合取逐样本误差的中位数。完成时间依据回合内数据时间戳和航点计时统计。轨迹图单独展示空间路径。
4. **指标使用前核对偏航率单位、符号和采样率。** 作者 notebook 对其 CSV 的 wz 使用负号和度到弧度转换。新仿真示例直接记录 Brax 的车体系角速度，需要先从代码和样例波形核对转换。笔记本的延时窗口以样本数给出，新仿真日志的默认传感器时间戳按 50 Hz 生成。分析新日志时按对应的物理时间重新核对窗口，或依据明确的时间匹配规则对齐，并在结果中说明差异。
5. 核对正文的 **138.8%**。作者 notebook 衡量的是相对健康无补偿基线的**额外误差被消除的比例**。其计算是“减力无补偿误差减去减力有补偿误差”，再除以“减力无补偿误差减去健康无补偿误差”，三项均用对应组的回合中位数。若补偿组的中位误差低于健康无补偿组，结果可以超过 100%。汇报同时给出原始误差和对应分母。

## 5. 复现交付与 Go2-W 迁移准备

| 交付项 | 内容 |
| --- | --- |
| 复现报告 | 四组条件、官方数据图表、独立运行统计、偏差分析和可复查的源数据位置 |
| 实验记录 | 源码提交或归档校验值、CPU 依赖、命令、重复次数、种子来源、配置和失败记录 |
| 最小证据 | 四组典型轨迹、跟踪误差与完成时间分布、一次有代表性的补偿指令及车体响应 |
| Go2-W 接口记录 | 期望前进速度与偏航率、实际下发值、实测车体运动、坐标系、时间戳、更新和重置事件，以及代码对应位置 |

阅读源码可沿 follow_path → get_command → 低层控制器查询 → get_sensor → add_datapoint → train_model 追踪一条指令。迁移前确认反馈中 vx 和 wz 的坐标系与单位，确定采样时序、指令边界和状态特征，再为 Go2-W 替换仿真执行端。原版 FLAIR 复现结果用于建立迁移基线。

**工期估计**　环境与原始材料可用时，前 2–4 个有效工作日用于依赖检查、作者数据复画、四组单回合和首批统计。正式批次总耗时根据小批次结果更新，旧依赖排障另计。第一项可验收结果是四组单回合各自完成路线，并能从日志确认扰动和 FLAIR 开关。
