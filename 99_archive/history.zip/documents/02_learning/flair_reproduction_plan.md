# FLAIR 六足仿真复现执行计划

**复现对象**　Allard 等，*Getting Robots Back on Track by Reconstituting Control in Unexpected Situations with Online Learning*，*Nature Communications*，2026。首轮复现论文补充材料中的六足 Chicane 弯道实验。 [正式论文](https://doi.org/10.1038/s41467-026-70256-y) · [论文补充材料入口](https://pmc.ncbi.nlm.nih.gov/articles/PMC13102915/)

**目标**　用公开数据复核原结果，再用作者代码独立生成四组实验结果。随后从源代码和日志中明确 FLAIR 的指令、反馈、模型更新与重置接口，作为 Go2-W 迁移的输入。

**执行记录**　服务器上的环境、验证结果和批次状态见文末。

## 0. 服务器执行顺序

| 步骤 | 操作 | 进入下一步的依据 |
| --- | --- | --- |
| 1. 服务器盘点 | 登录 robotic_dog，读取 CPU、可用存储、Conda 环境列表与现有 FLAIR 工作目录。 | 确认个人工作路径、可用 Conda 程序及候选环境前缀。 |
| 2. 选择隔离环境 | 用 `conda env list` 查看已有环境，只复用专用于 FLAIR 且通过 Python 版本、依赖、CPU 后端和导入检查的环境。若缺失或不兼容，在个人工作目录下创建新前缀。 | 所用解释器位于核实过的项目独立环境中，运行记录可定位该前缀。 |
| 3. 准备材料 | 校验固定版本源码、控制器库和作者数据。先尝试服务器直接下载，网络受限时传输经过校验的官方归档及数据。 | 源码版本和数据校验值与第 2 节一致。 |
| 4. 复核作者数据 | 按作者笔记本计算四组跟踪误差和完成时间，保存统计与图表。 | 四组均有可追溯统计，每组试次数和指标口径已核对。 |
| 5. 独立运行仿真 | 先分别验证四组单回合。再按单回合实测耗时安排正式批次，每组计划 20 回合。 | 每回合检查末航点、控制台、记录完整性，并登记失败或超时。 |
| 6. 整理结果 | 汇总作者数据、独立批次、软件版本与运行偏差。 | 交付数据统计、图表、运行日志及后续迁移接口记录。 |

盘点可使用 `hostname`、`lscpu`、`df -h "$HOME"`、`conda info --base` 与 `conda env list`。若 SSH 的非交互会话未加载 Conda，先定位已有安装，再加载其 `etc/profile.d/conda.sh`，或直接调用安装目录中的 `bin/conda`。检查候选环境时使用 `conda run -p <环境绝对路径> python -V` 和 `python -m pip check`，并执行第 3 节的导入及 CPU 检查。依赖安装前确认 `sys.prefix` 指向选定环境。

新环境建议使用 `"$FLAIR_WORK/.conda/lyy_flair_v100_cpu_py310"`，通过 `conda create -p` 创建。需要重建时使用新的项目内前缀。所有依赖安装、实验脚本和输出均落在个人工作目录或选定的 FLAIR 专用环境。记录实际采用的环境与命令，便于重跑。

## 1. 实验要验证什么

六足机器人沿预设航点行驶。路径跟踪器给出期望前进速度和偏航率，底层控制器据此选择一组六足动作。FLAIR 开启时，上层会根据已下发指令和实测车体运动更新响应模型，再选出更接近期望运动的补偿指令。场景变化检测触发时，原方法会重置在线数据与模型。 [FLAIR 方法](https://doi.org/10.1038/s41467-026-70256-y) · [六足示例](https://raw.githubusercontent.com/adaptive-intelligent-robotics/FLAIR/v1.0.0/README.md)

~~~text
航点与位姿 → 路径跟踪器 → 期望车体运动 → FLAIR → 下发车体指令 → 六足控制器库 → Brax
                                           ↑                               │
                                           └────── 车体运动与时间戳 ────────┘
~~~

四组共用路线、控制器库和默认运行设置。默认损伤分支从仿真初始化时启用，发布版的损伤配置把 leg_3_1_2 和 leg_3_2_3 的执行器强度从 60 降至 20，body_leg_3 保持 60。README 将其称为中右腿减力。损伤组主表的 Scaling_Value 可以是 1.0，因为损伤施加在仿真模型中，应以 Damage_Type 和模型配置识别。Go2-W 的行驶中突变实验将在下一阶段单独设计。 [损伤模型源码](https://github.com/adaptive-intelligent-robotics/FLAIR/blob/9e1fa31a8f39b912c5edb61bd65ba15289241276/fast_adaptation/example/brax_environments/hexapod.py) · [实验入口](https://github.com/adaptive-intelligent-robotics/FLAIR/blob/9e1fa31a8f39b912c5edb61bd65ba15289241276/fast_adaptation/example/flair_example.py#L1474)

| 组别 | 六足状态 | FLAIR | 作用 |
| --- | --- | --- | --- |
| healthy_driver | 健康 | 关闭 | 建立健康时的路径跟踪水平 |
| healthy_flair | 健康 | 开启 | 检查健康状态下启用补偿后的表现 |
| weakened_driver | 中右腿减力 | 关闭 | 测量减力造成的性能变化 |
| weakened_flair | 中右腿减力 | 开启 | 测量开启补偿后的恢复程度 |

原论文还包含 GVR-Bot 履带车实机实验，其独立复现需要原平台与传感器。六足主线结束后，可用公开数据复核对应实机图表。 [官方仓库](https://github.com/adaptive-intelligent-robotics/FLAIR/tree/v1.0.0) · [公开数据](https://zenodo.org/records/14546657)

## 2. 准备工作空间与材料

在 Linux 服务器的个人工作目录中执行。六足示例按作者提供的 CPU 路径运行，使用独立 Conda 环境。默认仿真无须启动 ROS 2、连接实体机器人或打开 VNC。生成的轨迹和可选 HTML 回放可传回后查看。 [作者运行说明](https://raw.githubusercontent.com/adaptive-intelligent-robotics/FLAIR/v1.0.0/README.md)

~~~text
flair_reproduction/
├── upstream/             经过校验的代码归档与作者源码
├── data/author/          作者 notebook 与原始 CSV
├── analysis/             统计表与图
├── scripts/              复核、运行与统计脚本
└── runs/                 本次生成的日志、轨迹、配置与依赖记录
~~~

### 2.1 固定源码与底层控制器

~~~bash
export FLAIR_WORK="$HOME/lyy_ws/flair_reproduction"
mkdir -p "$FLAIR_WORK"/{upstream,data/author,analysis,runs}

git clone --branch v1.0.0 --single-branch \
  https://github.com/adaptive-intelligent-robotics/FLAIR.git \
  "$FLAIR_WORK/upstream/FLAIR"

export FLAIR_SRC="$FLAIR_WORK/upstream/FLAIR"
git -C "$FLAIR_SRC" rev-parse HEAD | tee "$FLAIR_WORK/runs/source_revision.txt"
~~~

Git 标签 v1.0.0 对应提交 9e1fa31a8f39b912c5edb61bd65ba15289241276。服务器无法连接 GitHub 时，可取得 [Zenodo v1.0.0 代码归档](https://zenodo.org/records/18336476)，校验 ZIP 的 MD5 为 fc9fb0356fb81b5995360891fedc1bf0，传到服务器后解压，并将 FLAIR_SRC 指向包含 README.md 和 fast_adaptation 的目录。归档方式在 source_revision.txt 中记录来源和校验值。

运行前确认 fast_adaptation/example/map_elites_map/config.csv 和同目录下 repertoire_MAP-Elites_180813 中的 centroids.npy、descriptors.npy、fitnesses.npy、genotypes.npy 均存在。它们共同组成作者已生成的 MAP-Elites 六足控制器库。示例按车体指令从库中选取控制器，首轮可直接使用。 [控制器库目录](https://github.com/adaptive-intelligent-robotics/FLAIR/tree/9e1fa31a8f39b912c5edb61bd65ba15289241276/fast_adaptation/example/map_elites_map)

### 2.2 下载公开实验数据

四组主实验需要以下文件。CSV 合计约 143 MB，Zenodo 记录提供每个文件的 MD5。 [作者数据归档](https://zenodo.org/records/14546657)

| 文件 | 实验条件 | MD5 |
| --- | --- | --- |
| FLAIR_plots_simplified_Hexapod.ipynb | 分析与绘图笔记本 | f4625a2bcdb3ac84b28aaa198392530c |
| hexapod_main_no_flair_no_perturb.csv | 健康，关闭 FLAIR | 7e96eb7574acd7791e2f667ffdcc3e29 |
| hexapod_main_flair_no_perturb.csv | 健康，开启 FLAIR | 2855ecc0a03f66624a67eead9180ea31 |
| hexapod_main_no_flair.csv | 中右腿减力，关闭 FLAIR | dec32648076694b89c1e72b7d2bfc6af |
| hexapod_main_flair.csv | 中右腿减力，开启 FLAIR | 4d86df193d6d3825fc02e89a6ab8a2cc |

~~~bash
cd "$FLAIR_WORK/data/author"
for file in FLAIR_plots_simplified_Hexapod.ipynb \
  hexapod_main_no_flair_no_perturb.csv hexapod_main_flair_no_perturb.csv \
  hexapod_main_no_flair.csv hexapod_main_flair.csv; do
  curl -fL --retry 3 \
    "https://zenodo.org/records/14546657/files/$file?download=1" \
    -o "$file" || break
done
md5sum FLAIR_plots_simplified_Hexapod.ipynb hexapod_main*.csv
~~~

完整笔记本还会读 hexapod_remove_no_flair.csv、hexapod_remove_flair.csv、hexapod_front_leg_no_flair.csv 和 hexapod_front_leg_flair.csv。只做主四组时，在笔记本副本中保留四组读取和对应汇总，把 all_sections 限定为 Chicane Broken Middle Leg，从 all_final_errors 和 all_final_times 的对应键生成四组图表。保留原计算函数和单位转换，按需跳过后面的扩展工况与轨迹单元。运行完整作者分析时，补齐八份 CSV，后续轨迹细节单元也按文件与试次依赖核对。 [笔记本预览与下载](https://zenodo.org/records/14546657)

## 3. 建立 CPU 环境

服务器使用已有的 Conda 程序 `/opt/miniconda3/bin/conda`。已登记的环境用于 LocoFormer，本实验使用 `lyy_ws/flair_reproduction/.conda/lyy_flair_v100_cpu_py310`。包缓存与 Python 依赖均放在项目目录中。服务器上的 `requirements-cpu.txt` 记录直接依赖，`runs/requirements-resolved.txt` 记录实际安装版本，`runs/conda-explicit.txt` 记录 Conda 底包。

发布包根目录指定 GPJax 0.6.0，容器清单指定 0.5.0。实测后者缺少六足示例使用的模块。首轮 Python 3.11 环境也暴露了旧版 GPJax 的 dataclass 兼容问题，使用项目内独立的 Python 3.10 前缀、GPJax 0.6.0 和 CPU 版 JAX/jaxlib 0.4.22。 [发布包根目录依赖](https://github.com/adaptive-intelligent-robotics/FLAIR/blob/v1.0.0/requirements.txt) · [作者容器依赖](https://github.com/adaptive-intelligent-robotics/FLAIR/blob/v1.0.0/singularity/requirements.txt)

~~~bash
export FLAIR_WORK="$HOME/lyy_ws/flair_reproduction"
export FLAIR_ENV="$FLAIR_WORK/.conda/lyy_flair_v100_cpu_py310"
export CONDA_PKGS_DIRS="$FLAIR_WORK/.conda/pkgs"
export CONDA_ENVS_PATH="$FLAIR_WORK/.conda"
export PIP_CACHE_DIR="$FLAIR_WORK/.cache/pip"
export PYTHONNOUSERSITE=1 JAX_PLATFORMS=cpu MPLBACKEND=Agg

# 仅在重建专用环境时运行
/opt/miniconda3/bin/conda create -y -p "$FLAIR_ENV" python=3.10 pip
"$FLAIR_ENV/bin/python" -m pip install -r "$FLAIR_WORK/requirements-cpu.txt"
"$FLAIR_ENV/bin/python" -m pip check

# 日常运行使用已经核对过的解释器和源码路径
source /opt/miniconda3/etc/profile.d/conda.sh
conda activate "$FLAIR_ENV"
export FLAIR_SRC="$(cat "$FLAIR_WORK/runs/source_path.txt")"
~~~
检查解释器、JAX 设备、主要包和示例入口。JAX 应报告 CPU 设备，示例应能输出参数帮助。默认运行会加载 GP 分支，因此单独导入包和执行 --help 都只是环境检查，完整性还要通过第 5 节验证。示例的相对导入和控制器库路径基于当前工作目录。 [示例源码](https://github.com/adaptive-intelligent-robotics/FLAIR/blob/9e1fa31a8f39b912c5edb61bd65ba15289241276/fast_adaptation/example/flair_example.py)

~~~bash
python -c "import sys, jax, jaxlib, brax.v1, qdax, gpjax, sklearn; print(sys.executable); print(jax.__version__, jaxlib.__version__, jax.devices()); print(jax.jit(lambda x: x + 1)(1).block_until_ready())"
cd "$FLAIR_SRC/fast_adaptation/example"
python flair_example.py --help
~~~

如果服务器不能访问包索引，优先使用可访问的镜像，或在相同架构的 Linux 和 Python 3.10 环境中准备完整依赖再传入。首轮按错误来源检查缺包、版本、路径或模型资产，保留初始和成功时的依赖记录。 [作者容器说明](https://github.com/adaptive-intelligent-robotics/FLAIR/tree/v1.0.0/singularity)

## 4. 用作者数据复核指标与图表

1. 在同一数据目录复制一份笔记本，保留原文件。先运行导入、函数定义和主四组读取及其后续汇总单元。以官方文件从 0 开始计数，主四组读取在第 20、23、26、29 个单元，分别执行后面紧邻的汇总单元。修改 all_sections 后，运行主图函数及其调用，或直接从四组统计字典导出表格。笔记本按相对路径读 CSV。将执行后的笔记本、主要图和每组汇总表存到 analysis。
2. 记录每组有效回合数、每回合指令跟踪误差及完成时间。作者笔记本的原有输出对中右腿减力主实验四组分别显示 20 回合。本次复画应同时核对实际读到的回合数和有效样本量。 [作者 notebook](https://zenodo.org/records/14546657)
3. 保留作者的对齐、滤波、边界剔除和每回合聚合规则。**作者指标中的 Tracking Error 是车体速度指令跟踪误差**。它使用对齐后的前进速度和偏航率两项差值，每回合取逐样本误差的中位数。完成时间依据回合内数据时间戳和航点计时统计。轨迹图单独展示空间路径。
4. **指标使用前核对偏航率单位、符号和采样率。** 作者 notebook 对其 CSV 的 wz 使用负号和度到弧度转换。新仿真示例直接记录 Brax 的车体系角速度，需要先从代码和样例波形核对转换。笔记本的延时窗口以样本数给出，新仿真日志的默认传感器时间戳按 50 Hz 生成。分析新日志时按对应的物理时间重新核对窗口，或依据明确的时间匹配规则对齐，并在结果中说明差异。 [作者笔记本](https://zenodo.org/records/14546657) · [仿真日志实现](https://github.com/adaptive-intelligent-robotics/FLAIR/blob/9e1fa31a8f39b912c5edb61bd65ba15289241276/fast_adaptation/example/flair_example.py)
5. 核对正文的 **138.8%**。作者 notebook 衡量的是相对健康无补偿基线的**额外误差被消除的比例**。其计算是“减力无补偿误差减去减力有补偿误差”，再除以“减力无补偿误差减去健康无补偿误差”，三项均用对应组的回合中位数。若补偿组的中位误差低于健康无补偿组，结果可以超过 100%。汇报同时给出原始误差和对应分母。 [论文表 1 与六足结果](https://doi.org/10.1038/s41467-026-70256-y) · [作者笔记本](https://zenodo.org/records/14546657)

## 5. 独立重跑四组仿真

### 5.1 先跑四个单回合

在激活后的同一个 Bash 会话中，从示例目录执行。每批使用独立的结果目录，避免作者脚本以同名文件覆盖上一批数据。

~~~bash
cd "$FLAIR_SRC/fast_adaptation/example"
set -o pipefail

export RUN_ROOT="$FLAIR_WORK/runs/$(date -u +%Y%m%dT%H%M%SZ)_smoke"
mkdir -p "$RUN_ROOT"

run_case() {
  local case_name="$1"
  local reps="$2"
  shift 2
  local case_dir="$RUN_ROOT/$case_name"
  mkdir "$case_dir" || return 1

  python -u flair_example.py \
    --circuit chicane_broken_leg \
    --num-reps "$reps" \
    --results "$case_dir" \
    "$@" 2>&1 | tee "$case_dir/console.log"
}

run_case healthy_driver 1 --perturbation-off --adaptation-off
run_case healthy_flair 1 --perturbation-off
run_case weakened_driver 1 --adaptation-off
run_case weakened_flair 1 --save-html
~~~

--save-html 用于查看一条代表性回合，批量阶段按需启用。首轮记录首个回合的总运行耗时和后续回合耗时。JAX 首次编译可能使首回合更慢。脚本终端输出的墙钟耗时和根据仿真日志统计的赛道完成时间应分别记录。 [脚本参数与运行循环](https://github.com/adaptive-intelligent-robotics/FLAIR/blob/9e1fa31a8f39b912c5edb61bd65ba15289241276/fast_adaptation/example/flair_example.py#L1474)

### 5.2 每组怎样判定完成

| 检查项 | 通过依据 |
| --- | --- |
| 开关与损伤 | 控制台和 vicon_configuration.csv 对应预设开关。CSV 中健康组的 Damage_Type 为 none，减力组为 broken_leg。 |
| 路径完成 | 每个预定回合有到达最后航点的记录，控制台出现 Driver is done.，轨迹和终点相符。 |
| 数据完整 | 每组的主 CSV、逐回合 CSV、轨迹与速度图可读。按 Sections_index 统计独立回合，检查时间递增、航点进度和有效数据行。 |
| FLAIR 行为 | 开启组可见模型更新尝试，结合 adaptation CSV 对比实际补偿指令和期望指令。若日志有模型训练尝试但没有有效补偿，检查对齐、过滤、数据量和模型更新状态。 |

作者脚本会捕获部分回合异常并继续写出指标，仿真状态异常也可能提前终止循环。验收需结合末航点、控制台和 CSV，重点排查 Failed rep、Traceback 与 Robot exploded。失败或超时回合保留原始记录，并计入失败率。完成时间的统计注明使用了多少成功回合。 [运行结束及异常处理源码](https://github.com/adaptive-intelligent-robotics/FLAIR/blob/9e1fa31a8f39b912c5edb61bd65ba15289241276/fast_adaptation/example/flair_example.py#L1783)

### 5.3 扩展到正式批次

- 先用每组 3–5 回合做小批次，检查离散程度和单回合耗时。正式批次以每组 20 回合为计划，与公开主组规模对齐。通过设置新的 RUN_ROOT 并将 run_case 的次数换成 20，沿用相同的四组开关。
- 发布版的环境种子来自系统时钟，且 CLI 没有 --seed。先保留一批原版运行结果。若要做可复查的配对比较，再在实验副本增加一个可选种子入口，把种子传入 EnvironmentManager，并写入回合记录。四组用相同种子序列和回合编号，记录补丁与基础提交。只有确认初始条件可比，才按配对试验计算差值。 [随机初始化源码](https://github.com/adaptive-intelligent-robotics/FLAIR/blob/9e1fa31a8f39b912c5edb61bd65ba15289241276/fast_adaptation/example/flair_example.py#L519)
- 固定路线、控制器库、频率和噪声设置。按小批次耗时预先确定正式批次的资源预算与超时口径。需要逐回合强制超时时，使用独立运行目录逐回合启动，给每次进程设置同一时限，并保留超时日志与试次编号。若缩小批次，报告实际完成数量。比较四组的回合中位数、离散程度和失败情况。重点判断减力时开启 FLAIR 后，指令跟踪误差与完成时间是否向原文报告的方向变化。
- 作者数据复画与本次重跑各自保留图表和统计结果。若结果偏离，按“输入版本与控制器库 → 损伤与路线 → 运行完整性 → 时间与单位 → 回合统计”排查，并记录仍存在的差异。

## 6. 复现交付与 Go2-W 迁移准备

| 交付项 | 内容 |
| --- | --- |
| 复现报告 | 四组条件、官方数据图表、独立运行统计、偏差分析和可复查的源数据位置 |
| 实验记录 | 源码提交或归档校验值、CPU 依赖、命令、重复次数、种子来源、配置和失败记录 |
| 最小证据 | 四组典型轨迹、跟踪误差与完成时间分布、一次有代表性的补偿指令及车体响应 |
| Go2-W 接口记录 | 期望前进速度与偏航率、实际下发值、实测车体运动、坐标系、时间戳、更新和重置事件，以及代码对应位置 |

阅读源码可沿 follow_path → get_command → 低层控制器查询 → get_sensor → add_datapoint → train_model 追踪一条指令。迁移前确认反馈中 vx 和 wz 的坐标系与单位，确定采样时序、指令边界和状态特征，再为 Go2-W 替换仿真执行端。原版 FLAIR 复现结果用于建立迁移基线。 [FLAIR 示例源码](https://github.com/adaptive-intelligent-robotics/FLAIR/blob/9e1fa31a8f39b912c5edb61bd65ba15289241276/fast_adaptation/example/flair_example.py) · [Go2-W 后续工作计划](./go2w_adaptive_control_workplan.md)

**工期估计**　环境与原始材料可用时，前 2–4 个有效工作日用于依赖检查、作者数据复画、四组单回合和首批统计。正式批次总耗时根据小批次结果更新，旧依赖排障另计。第一项可验收结果是四组单回合各自完成路线，并能从日志确认扰动和 FLAIR 开关。

## 7. 服务器执行记录

工作目录为 `/home/robotic_dog/lyy_ws/flair_reproduction`。原 FLAIR 通过校验后的 Zenodo ZIP 解压，源码位置保存在 `runs/source_path.txt`。服务器访问 Zenodo 返回 403，公开数据经本地下载和 MD5 校验后传输至服务器。四份 CSV 及笔记本的服务器端校验值均与发布记录相符。

### 7.1 作者数据复核

`scripts/review_author.py` 读取官方笔记本主四组单元，输出 `analysis/author_trials.csv`、`analysis/author_summary.csv` 和 `analysis/author_four_groups.png`。每组均有 20 个回合。减力无补偿组指令跟踪误差中位数为 0.050322，减力有补偿组为 0.044313，健康无补偿组为 0.045992。按作者口径得到额外误差恢复比例 138.773%。

### 7.2 原版与 CPU 加速版

原版首批运行中，两组关闭 FLAIR 的回合抵达末航点，两组开启 FLAIR 的回合在持续更新时超出 660 秒墙钟限时。延长限时后，原版四组各完成一个回合，全部通过末航点与 CSV 核验。原版开启 FLAIR 的两个回合分别用时约 36 和 41 分钟（墙钟）。输出位于 `runs/smoke-v100-long`，本地保存[原版四组单回合记录](./flair_results/smoke-v100-long_trials.csv)。性能分析显示原版状态网格含 125,000 个单元，整网格更新是当前 CPU 配置的主要耗时。

单独的 `scripts/fast_cpu_example.py` 在运行时替换网格加样与筛选操作。仅更新受当前批次影响的单元及对已有样本的单元计算筛选，超出快速路径条件时调用原实现。六组受控输入下四个网格数组均逐元素一致，其中热运行的加样和筛选合计约 0.33–0.36 秒，原实现约 10–12 秒。官方源码目录保留原网格实现。在同种子 40391 的减力仿真中，原版与加速版完成了 110 个控制步的对照。551 行主日志和 110 行指令日志的全部数值列一致。该对照覆盖启动和多次在线更新，完整回合的一致性仍需进一步核验。

加速版四组单回合均已到达航点 31，控制台无运行异常，逐回合 CSV 通过终点检查。输出位于 `runs/smoke-v100-fast`，统计及轨迹图位于 `analysis`。独立仿真统计采用同一行指令和车体反馈计算误差，作者数据统计沿用其 notebook 的时延对齐、偏航率转换和边界剔除，两套误差口径分别报告。

### 7.3 在服务器上的常用命令

~~~bash
cd "$HOME/lyy_ws/flair_reproduction"
python_flair="$PWD/.conda/lyy_flair_v100_cpu_py310/bin/python"

MPLBACKEND=Agg "$python_flair" scripts/review_author.py "$PWD"
bash scripts/run_four_groups.sh 1 upstream_check
FLAIR_ENTRYPOINT="$PWD/scripts/fast_cpu_example.py" bash scripts/run_four_groups.sh 1 cpu_check
MPLBACKEND=Agg "$python_flair" scripts/summarize_rerun.py runs/cpu_check
~~~

首次正式批次由 `bash scripts/run_formal.sh` 启动，分成 4 个分片，每片四组各 5 回合。分片环境种子为 40260–40263，每片组间使用相同种子。输出名称为 `runs/formal-v100-s0` 至 `runs/formal-v100-s3`，相同批次名用于保护已有结果。正式批次使用加速版。运行结束后用下列命令汇总。对照指标脚本分别输出同一行误差、时间对齐后保留 Brax 偏航率的误差，以及原样应用作者笔记本得到的误差。

~~~bash
bash scripts/analyze_formal.sh
~~~

### 7.4 正式批次结果

四组各运行 20 回合，共 80 回合。16 个分组进程均以状态 0 退出，日志中均有末航点完成记录，有效回合数为 80。终点验收使用原路径跟踪器 0.3 m 容差及最后一个指令周期内的反馈，因为原脚本在判定到达后仍记录 5 个仿真传感步。

| 实验条件 | 作者数据跟踪误差 | 独立重跑跟踪误差 | 作者数据完成时间（s） | 独立重跑完成时间（s） |
| --- | ---: | ---: | ---: | ---: |
| 健康，关闭 FLAIR | 0.045992 | 0.045961 | 180.75 | 180.25 |
| 健康，开启 FLAIR | 0.043697 | 0.043713 | 151.65 | 151.60 |
| 减力，关闭 FLAIR | 0.050322 | 0.050362 | 196.95 | 197.05 |
| 减力，开启 FLAIR | 0.044313 | 0.043791 | 170.95 | 170.60 |

上表两侧均使用作者笔记本口径，包含其时延匹配与偏航率转换。保留 Brax 偏航率并重新对齐的敏感性分析也显示减力条件下的误差下降，从 0.052797 降至 0.046424。减力时开启 FLAIR 后，作者口径的跟踪误差中位数下降约 13.0%，完成时间中位数缩短 26.45 秒。按健康无补偿误差作为参考的额外误差恢复比例为 149.3%，其分母与直接误差下降比例不同。

本地结果包括[作者与重跑指标对照](./flair_results/comparison_metrics.csv)、[80 回合记录](./flair_results/formal_trials.csv)、[正式批次统计图](./flair_results/formal_four_groups.png)和[四组代表轨迹](./flair_results/smoke-v100-fast_trajectories.png)。服务器保留逐回合原始 CSV、配置、依赖锁定、性能分析和单回合 HTML 回放。正式批次的轨迹与性能结论限定在六足仿真，Go2-W 迁移另行验证。

### 7.5 交给 Go2-W 迁移阶段的接口

| 模块 | 六足代码中的入口 | 迁移时要核对的量 |
| --- | --- | --- |
| 路径跟踪 | Driver.follow_path | 根据位置和朝向给出前进速度与偏航率目标。 |
| 指令补偿 | FLAIR.get_command | 输入目标车体速度和当前状态，输出补偿后的命令。关闭时转发原指令。 |
| 执行与感知 | EnvironmentManager.step、get_sensor | 六足执行侧查询控制器库，同时提供车体系的速度和姿态。Go2-W 执行侧需提供等价量，并确认单位与符号。 |
| 指令与响应配对 | FLAIR.add_datapoint、DataCollection | 保存期望、补偿指令和实际反馈，明确其各自的采样时刻。如果执行端有额外限幅，记录实际下发值。 |
| 更新与重置 | FLAIR.train_model、AdaptiveGP.auto_reset | 维护在线样本，判断是否触发重置，再更新模型供下一次指令选择。 |

六足示例的默认配置给出 50 Hz 传感时间戳、10 Hz 指令频率和 1 Hz 模型训练参数。Go2-W 应基于实际数据频率与端到端时延确定对应设置。优先验证上层补偿接入前后的原始指令、命令和响应日志能否逐项对应。 [发布版示例源码](https://github.com/adaptive-intelligent-robotics/FLAIR/blob/9e1fa31a8f39b912c5edb61bd65ba15289241276/fast_adaptation/example/flair_example.py)
