import sys, pathlib, json
sys.stdout.reconfigure(encoding='utf-8')
import pypdfium2 as pdfium
from PIL import Image

ROOT=pathlib.Path(r'G:/毕设/02_learning/04_review/.build_locoformer_report_20261101')
OUT=ROOT/'assets'
OUT.mkdir(exist_ok=True)
doc=pdfium.PdfDocument(r'G:/毕设/01_papers/LocoFormer.pdf')
def crop(page, bbox, name, scale=4):
    x0,y0,x1,y1=bbox
    p=doc[page-1]
    im=p.render(scale=scale,crop=(x0,p.get_height()-y1,p.get_width()-x1,y0)).to_pil()
    im.save(OUT/name)
    return im

crop(1,(108,181.95,504.01,447.24),'figure1.png')
crop(6,(126.56,72,304.76,205.65),'figure4a.png',5)
crop(6,(309.74,72,487.94,205.65),'figure4b.png',5)
crop(7,(108,72,504,312.44),'figure5.png')
crop(14,(111.74,72,507.74,200.54),'figure6a.png')

# Render the paper's original equations. This preserves mathematical layout
# and avoids retyping subscripts, superscripts or stop-gradient notation.
crop(4,(204,108,406,157),'objective.png',7)
crop(5,(234,277,359,296),'memory.png',8)
crop(5,(180,295,405,313),'qkv.png',7)

manifest={p.name:list(Image.open(p).size) for p in OUT.glob('*.png')}
(ROOT/'assets_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(manifest,ensure_ascii=False))
