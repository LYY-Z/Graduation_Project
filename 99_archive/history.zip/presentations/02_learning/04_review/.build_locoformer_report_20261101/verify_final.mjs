import fs from 'node:fs/promises';
import path from 'node:path';
import {PresentationFile,FileBlob} from '@oai/artifact-tool';
const b='G:/毕设/02_learning/04_review/.build_locoformer_report_20261101';
const f='G:/毕设/02_learning/04_review/deliverables/locoformer_paper_report.pptx';
const p=await PresentationFile.importPptx(await FileBlob.load(f));
await fs.mkdir(path.join(b,'final-preview'),{recursive:true});
for(let i=0;i<p.slides.items.length;i++){
 const blob=await p.export({slide:p.slides.items[i],format:'png',scale:1});
 await fs.writeFile(path.join(b,'final-preview',`slide-${String(i+1).padStart(2,'0')}.png`),new Uint8Array(await blob.arrayBuffer()));
}
const result=await p.inspect({select:'$.slides[*]',include:['index','title','elements.text']});
await fs.writeFile(path.join(b,'final-content.ndjson'),result.ndjson);
console.log(JSON.stringify({finalFile:f,slides:p.slides.items.length,rendered:p.slides.items.length}));
