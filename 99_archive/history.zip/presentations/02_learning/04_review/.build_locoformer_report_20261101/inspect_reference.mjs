import fs from 'node:fs/promises';
import path from 'node:path';
import {PresentationFile, FileBlob} from '@oai/artifact-tool';
const dir='G:/毕设/02_learning/04_review/.build_locoformer_report_20261101';
await fs.mkdir(path.join(dir,'reference'),{recursive:true});
const src='G:/毕设/02_learning/04_review/deliverables/diffusion_policy_report-LYY.pptx';
const p=await PresentationFile.importPptx(await FileBlob.load(src));
console.log('slides',p.slides.items.length,'masters',p.masters.items.length,'layouts',p.layouts.items.length);
const info=await p.inspect({select:'$.slides[*]',include:['id','index','title','elements.id','elements.kind','elements.name','elements.text','elements.position']});
await fs.writeFile(path.join(dir,'reference','inspect.ndjson'),info.ndjson);
console.log(p.help('*',{search:'delete|remove',include:['index','examples','notes'],maxChars:9000}).ndjson);
for(let i=0;i<p.slides.items.length;i++){
 const b=await p.export({slide:p.slides.items[i],format:'png',scale:1});
 await fs.writeFile(path.join(dir,'reference',`slide-${String(i+1).padStart(2,'0')}.png`),new Uint8Array(await b.arrayBuffer()));
 console.log('rendered',i+1);
}
