import fs from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
import {PresentationFile,FileBlob} from '@oai/artifact-tool';

const WORK='G:/毕设';
const BUILD=path.join(WORK,'02_learning/04_review/.build_locoformer_report_20261101');
const REF=path.join(WORK,'02_learning/04_review/deliverables/diffusion_policy_report-LYY.pptx');
const SKILL='C:/Users/laiyo/.codex/plugins/cache/openai-primary-runtime/presentations/26.1026.10807/skills/presentations';
const PY='C:/Users/laiyo/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe';
const FINAL=path.join(WORK,'02_learning/04_review/deliverables/locoformer_paper_report.pptx');
process.env.RUNTIME_NODE_MODULES='C:/Users/laiyo/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules';
const {applyPresentationChartFont,finalizePresentation}=await import(pathToFileURL(path.join(SKILL,'container_tools/artifact_tool_utils.mjs')).href);
const C={bg:'#F5F3F0',ink:'#252A31',body:'#434950',muted:'#646A70',wine:'#78394C',wineSoft:'#EFE7E9',gold:'#B58A4A',goldSoft:'#F3EEE3',green:'#78827B',greenSoft:'#E7EBE6',rule:'#D5D0C9',white:'#FFFFFF'};
const FONT='微软雅黑';
const assets=JSON.parse(await fs.readFile(path.join(BUILD,'assets_manifest.json'),'utf8'));
const images={};
for(const k of Object.keys(assets))if(!k.startsWith('paper-page'))images[k]=new Uint8Array(await fs.readFile(path.join(BUILD,'assets',k)));
const p=await PresentationFile.importPptx(await FileBlob.load(REF));
const inspect=await p.inspect({select:'$.slides[*]',include:['id','index','elements.id','elements.kind','elements.text','elements.position']});
const records=inspect.records;

function text(s,value,x,y,w,h,size=21,color=C.body,bold=false,opts={}){
 const sh=s.shapes.add({geometry:'textbox',name:opts.name??value.slice(0,50),position:{left:x,top:y,width:w,height:h},fill:'none',line:{fill:'none',width:0}});
 sh.text=value;
 sh.text.style={typeface:opts.font??FONT,fontSize:size,color,bold,alignment:opts.align??'left',verticalAlignment:opts.valign??'middle',wrap:'square',autoFit:'none',insets:0};
 return sh;
}
function rect(s,x,y,w,h,fill=C.white,stroke=C.rule,lw=1){return s.shapes.add({geometry:'rect',name:'diagram block',position:{left:x,top:y,width:w,height:h},fill,line:{fill:stroke,width:lw,style:'solid'}});}
function rule(s,x,y,w,color=C.rule,h=1){return rect(s,x,y,w,h,color,'none',0);}
function line(s,x1,y1,x2,y2,color=C.gold,arrow=false,dashed=false){
 const x=Math.min(x1,x2),y=Math.min(y1,y2),w=Math.abs(x2-x1),h=Math.abs(y2-y1);
 return s.shapes.add({geometry:'connector',name:arrow?'flow arrow':'flow line',kind:'straight',position:{left:x,top:y,width:w,height:h,horizontalFlip:x2<x1,verticalFlip:y2<y1},line:{fill:color,width:1.8,style:dashed?'dashed':'solid'},tail:arrow?{type:'triangle',width:'sm',length:'sm'}:{type:'none'}});
}
function connect(s,a,b,from='right',to='left',color=C.gold,dashed=false){return s.shapes.connect(a,b,{kind:from==='right'&&to==='left'?'straight':'elbow',fromSide:from,toSide:to,line:{fill:color,width:1.8,style:dashed?'dashed':'solid'},tail:{type:'triangle',width:'sm',length:'sm'}});}
function image(s,file,x,y,w,h){
 const [iw,ih]=assets[file],scale=Math.min(w/iw,h/ih),dw=iw*scale,dh=ih*scale;
 return s.images.add({name:file,blob:images[file],contentType:'image/png',alt:`LocoFormer 原文 ${file}`,position:{left:x+(w-dw)/2,top:y+(h-dh)/2,width:dw,height:dh},fit:'contain'});
}
function takeaway(s,value,y=602,size=22){rect(s,66,y,6,43,C.wine,'none',0);text(s,value,88,y-2,1112,48,size,C.ink,true);}
function footer(s,value){text(s,value,66,682,1040,17,12,C.muted);}
function subtitle(s,value){text(s,value,66,136,1146,42,22,C.wine,true);}
function block(s,label,detail,x,y,w,h,fill=C.white){
 const sh=rect(s,x,y,w,h,fill);
 text(s,label,x+17,y+13,w-34,37,23,C.ink,true);
 if(detail)text(s,detail,x+17,y+56,w-34,h-67,18,C.muted,false,{valign:'top'});
 return sh;
}
function notes(s,value){s.speakerNotes.text=value;s.speakerNotes.setVisible(false);}
function base(i,title,source){
 const s=p.slides.items[i],rec=records[i];
 const keep=new Set();
 for(const e of rec.elements??[]){
  const a=e.position??{};
  if(e.kind==='textbox'&&a.top<100){keep.add(e.id);const sh=p.resolve(e.id);sh.text=title;sh.text.style={typeface:FONT,fontSize:38,bold:true,color:C.ink,insets:0,wrap:'square',autoFit:'none'};}
  else if(e.kind==='shape'&&Math.abs(a.top-113)<1&&a.height<4)keep.add(e.id);
  else if(e.kind==='textbox'&&/^\d\d \/ 10$/.test(e.text??'')){keep.add(e.id);const sh=p.resolve(e.id);sh.text=`${String(i+1).padStart(2,'0')} / 10`;sh.position={left:1155,top:679,width:61,height:22};}
 }
 const ids=(rec.elements??[]).filter(e=>!keep.has(e.id)).map(e=>e.id);
 if(ids.length)p.delete(ids);
 s.speakerNotes.clear();
 rule(s,64,668,1152);
 footer(s,source);
 return s;
}

// 01. Reuse the reference cover's exact typography and furniture.
{
 const s=p.slides.items[0];
 for(const e of records[0].elements??[]){
  if(e.text==='Diffusion Policy')p.resolve(e.id).text='LocoFormer';
  else if(e.text?.startsWith('Visuomotor'))p.resolve(e.id).text='Generalist Locomotion via Long-context Adaptation';
  else if(e.text?.startsWith('面向视觉'))p.resolve(e.id).text='长上下文适应驱动的跨本体运动控制';
  else if(e.text?.startsWith('汇报人'))p.resolve(e.id).text='汇报人：赖咏怡\n2026年11月';
 }
 text(s,'Min Liu, Deepak Pathak, Ananye Agarwal',108,512,680,30,20,C.muted);
 text(s,'Skild AI    CoRL 2025    arXiv:2509.23745',108,550,680,28,18,C.muted);
 notes(s,'来源：LocoFormer: Generalist Locomotion via Long-context Adaptation, Min Liu, Deepak Pathak, Ananye Agarwal, CoRL 2025. 本地论文为 arXiv:2509.23745v1，2025-09-28。汇报按约10分钟、10页组织。');
}

// 02. Problem: interaction history is needed to distinguish control conditions.
{
 const s=base(1,'身体变化使短历史难以支持统一控制','来源：LocoFormer §1，Figure 1');
 subtitle(s,'同一控制指令在不同身体上产生不同响应，策略需要从交互中辨别当前条件。');
 const rows=[
  ['01','身体结构不同','双足、四足与轮足具有不同的关节布局、支撑方式和运动能力。'],
  ['02','动力学与驱动条件变化','质量、惯量、控制增益或关节失效，都会改变动作的实际效果。'],
  ['03','短历史限制条件辨别','少量瞬时状态难以区分暂态偏差与持续异常，长交互提供更多响应证据。'],
 ];
 for(let j=0;j<rows.length;j++){
  const y=201+j*126;
  text(s,rows[j][0],72,y,44,29,18,C.gold);
  text(s,rows[j][1],124,y-1,430,34,24,C.ink,true);
  text(s,rows[j][2],124,y+42,430,65,20,C.muted,false,{valign:'top'});
  if(j<2)rule(s,124,y+112,405);
 }
 image(s,'figure1.png',650,191,550,368);
 text(s,'同一策略部署到不同实机，训练数据来自程序化生成的机器人。',650,567,550,43,17,C.muted);
 takeaway(s,'研究目标：学习依赖交互历史的通用策略，并在部署中适应身体变化。',615,21);
 notes(s,'来源：论文 §1 与 Figure 1，pp.1–2。作者的两个核心选择是大规模程序化机器人训练与长上下文。此页将任务概括为根据交互响应调整控制，不声称策略显式恢复准确物理参数。训练未使用测试市场机器人的精确参数。');
}

// 03. Training distribution, episode construction and PPO optimization.
{
 const s=base(2,'多样身体与跨 Trial 经历共同构成训练任务','来源：LocoFormer §2.1，Eq. (1)，Appendix A');
 subtitle(s,'在同一任务内保留交互历史，使策略通过经历改善控制，并优化整组经历的累计回报。');
 text(s,'程序化任务分布',70,194,300,35,24,C.wine,true);
 text(s,'双足、四足及其轮足变体\n随机化关节结构、质量与惯量\n扩展控制增益和关节限位范围',70,242,345,115,21,C.body,false,{valign:'top'});
 rule(s,439,198,1,C.rule,216);
 text(s,'同一任务中的多个 Trial 共享历史',477,194,720,35,24,C.wine,true);
 text(s,'适应窗口 u ~ Uniform(0, U)',477,233,610,28,20,C.muted);
 text(s,'训练目标：整组经历的累计回报',70,375,345,35,21,C.wine,true);
 const trials=[block(s,'Trial 1','运行、积累经历',477,282,183,91,C.white),block(s,'Trial 2 …','重置身体，保留历史',679,282,215,91,C.wineSoft),block(s,'最终 Trial','继续利用此前经历',925,282,269,91,C.greenSoft)];
 connect(s,trials[0],trials[1]);connect(s,trials[1],trials[2]);
 rule(s,477,268,417,C.wine,2);
 text(s,'次数由适应预算和 Trial 持续时间共同决定',477,385,710,27,18,C.muted);
 rule(s,70,430,1125);
 const steps=[['交互采集','观测、动作、奖励'],['回报与优势估计','结合 Critic 预测'],['策略与价值损失','评价动作与回报预测'],['反向传播更新参数','共享主干与两个分支']];
 const bs=[];
 for(let j=0;j<4;j++)bs.push(block(s,steps[j][0],steps[j][1],70+j*287,460,258,102,j===3?C.wineSoft:C.white));
 for(let j=0;j<3;j++)connect(s,bs[j],bs[j+1]);
 text(s,'奖励兼顾指令跟踪、存活及力矩等惩罚。训练先采用短 Trial 与小 U，再延长运行与适应时间。',70,589,1130,59,20,C.body);
 notes(s,'来源：论文 §2.1、Eq.(1)、Appendix A.2。原始形式采样Trial数k并累计整个Episode的折扣回报；实际训练改采样u~Uniform(0,U)，预算内允许若干Trial，之后运行最终Trial。不能据此声称仅最后Trial参与训练损失，时间预算版本未披露完整奖励掩码。PPO概念流程为原理概括，本文未公开完整损失系数、GAE及优化调度。程序化任务配置不是网络学习参数。');
}

// 04. Forward pass and physical closed loop, actor and critic separated.
{
 const s=base(3,'共享历史主干分别支持动作输出与价值估计','来源：LocoFormer §2.1–2.2，Figure 3');
 subtitle(s,'观测经 MLP 与 Transformer-XL 形成特征，Actor 输出目标关节位置，Critic 支持训练。');
 const obs=block(s,'统一观测 oₜ','按统一关节表示\n组织机器人观测',70,219,190,125);
 const mlp=block(s,'输入 MLP','观测转换为\n当前特征 xₜ',300,219,180,125);
 const txl=block(s,'Transformer-XL','结合当前特征\n与交互历史',520,219,230,125,C.wineSoft);
 const actor=block(s,'Actor MLP','产生动作',792,219,175,125,C.white);
 const target=block(s,'关节目标','提取当前机器人\n对应的关节输出',1006,219,206,125,C.greenSoft);
 for(const [a,b]of [[obs,mlp],[mlp,txl],[txl,actor],[actor,target]])connect(s,a,b);
 const cache=block(s,'各层历史缓存','读取并更新内部历史',520,400,230,99,C.goldSoft);
 const critic=block(s,'Critic MLP','估计未来回报',792,400,175,99,C.white);
 const env=block(s,'控制器与身体','目标驱动运动\n返回实际响应',1006,400,206,99,C.white);
 connect(s,cache,txl,'top','bottom',C.wine);
 connect(s,txl,critic,'bottom','top',C.green);
 connect(s,target,env,'bottom','top',C.gold);
 line(s,1109,499,1109,536,C.gold);line(s,165,536,1109,536,C.gold);line(s,165,536,165,344,C.gold,true);
 text(s,'实际响应形成下一时刻观测',262,501,310,31,18,C.muted);
 rule(s,70,572,1142);
 text(s,'目标关节位置通过底层控制作用于身体，实际运动由身体动力学与接触共同决定。',70,586,1130,32,20,C.body);
 text(s,'训练损失可沿当前计算图更新输入编码器和 Transformer，部署时通常固定参数。',70,624,1130,28,20,C.wine,true);
 notes(s,'来源：论文 §2.1 Unified Observation, Action and Reward Space、§2.2 首段。原文确认观察MLP、TXL、独立Actor/Critic MLP以及统一关节空间的目标位置输出。未完整给出观测字段、关节槽位、padding、mask、动作尺度及全部硬件映射，因此本页不把常见输入清单冒充实现配置。图中底层控制与身体响应是控制闭环概括，Critic不直接给机器人下指令。');
}

// 05. Exact source equations and the representation path across segments.
{
 const s=base(4,'段间缓存传递历史，SG 限制反向传播范围','来源：LocoFormer §2.2，Eqs. (2)–(4)，Figure 3');
 subtitle(s,'旧段表示供当前段读取，同一层跨时间共享参数，较深表示可携带更早历史。');
 rect(s,70,190,1142,112,C.white);
 text(s,'段间拼接',91,205,190,30,21,C.wine,true);
 image(s,'memory.png',310,207,590,74);
 text(s,'Eq. (2)',1064,223,120,28,18,C.muted,false,{align:'right'});
 text(s,'当前段生成 Q，旧段与当前段的扩展材料生成 K、V',76,320,1100,30,22,C.ink,true);
 image(s,'qkv.png',76,362,650,58);
 text(s,'Eq. (3)',745,374,100,28,18,C.muted);
 text(s,'Q 决定当前查询，K 用于匹配，V 提供组合内容。',76,433,1118,31,20,C.muted);
 const aa=block(s,'更早的 A 段','其交互影响 B 段表示',76,488,291,91,C.white);
 const bb=block(s,'B 段已处理的表示','缓存中可能携带 A 段信息',446,488,322,91,C.goldSoft);
 const cc=block(s,'C 段当前计算','读取 B 段表示获得历史影响',846,488,360,91,C.wineSoft);
 connect(s,aa,bb);connect(s,bb,cc);
 takeaway(s,'SG 固定旧段表示，不冻结当前计算路径中的共享网络参数。',607,22);
 notes(s,'来源：论文 Eqs.(2)–(4)，§2.2。公式图像直接从原论文渲染以保留上下标。h的上标是网络层，下标是segment。拼接沿时间维，SG只阻断通过旧表示生成过程的梯度。读取旧表示所用的Wk/Wv仍可参与训练。图中A到B到C表示层间历史传播示意，不能据此宣称无限精确记忆。当前与旧段内只读取允许的因果位置，不同Episode必须隔离。');
}

// 06. Deployment adaptation, cache efficiency and the two context notions.
{
 const s=base(5,'部署时固定参数，交互历史持续改变动作','来源：LocoFormer §2.1–2.2，Inference Acceleration');
 subtitle(s,'适应来自输入与内部表示的变化，KV-cache 复用已计算结果，支持逐时刻控制。');
 text(s,'逐时刻运行',70,193,600,35,24,C.wine,true);
 const b1=block(s,'新观测','计算当前 Q、K、V',70,247,195,108);
 const b2=block(s,'读取历史','当前 Q 匹配已有 KV',291,247,213,108,C.wineSoft);
 const b3=block(s,'输出并追加','执行动作，保留新 KV',530,247,225,108,C.greenSoft);
 connect(s,b1,b2);connect(s,b2,b3);
 text(s,'历史 K、V 供后续读取，不必反复重新生成。\nsegment 尚未收满时，也能使用已有位置输出动作。',70,377,690,69,20,C.body);
 rule(s,70,466,685);
 text(s,'Trial 重新开始：可保留失败经历。\nEpisode 切换：隔离此前任务的历史。',70,485,685,67,21,C.body);
 text(s,'Zero-shot：无额外预评估交互。\nFew-shot：先允许短暂交互，仿真评估采用 5 秒。',70,574,685,69,20,C.muted);
 rule(s,790,199,1,C.rule,438);
 text(s,'论文示例：6 层，L = 128，50 Hz',831,196,378,48,21,C.ink,true);
 text(s,'约 18 秒',831,265,378,65,44,C.wine,true);
 text(s,'最大可能的历史影响范围\n896 个时间步，包含层间间接传递',831,336,378,64,19,C.muted);
 rule(s,831,421,378);
 text(s,'255 个时间步',831,444,378,53,34,C.gold,true);
 text(s,'部署 KV-cache 保留最近 2L−1 步\n50 Hz 下约 5.1 秒直接读取范围',831,514,378,65,19,C.muted);
 text(s,'直接缓存范围与间接历史影响范围需区分。',831,604,378,44,18,C.wine,true);
 notes(s,'来源：论文 §2.1 Deployment、§2.2 Inference Acceleration。零样本运行仍在当前Trial内积累历史；few-shot预评估交互与之后的评估Trial需区分。6层L128是原文示例，最大可能896步约18秒，不是所有实验统一配置或精确记忆保证。实时KV-cache保存最近2L-1=255步约5.1秒。历史表示缓存与KV缓存位于计算链不同阶段，不代表部署必须长期保存两份完全重复历史。');
}

// 07. Editable chart with literal values from Table 1.
{
 const s=base(6,'未见机器人上接近目标平台专用策略的表现','来源：LocoFormer §3.1，Table 1；图示为各方法平均值');
 subtitle(s,'10 种未见机器人，每种 1,000 个随机化环境，包含粗糙地形与广泛参数变化。');
 text(s,'归一化朝目标位移（均值）',74,190,705,35,23,C.ink,true);
 const chart=s.charts.add('bar',{
  position:{left:65,top:235,width:700,height:345},
  categories:['LocoFormer zero-shot','LocoFormer few-shot','GRU','Conditioning','Expert'],
  series:[{name:'平均归一化位移',values:[0.96,0.98,0.37,0.78,0.99],fill:C.wine,points:[{idx:0,fill:C.wine},{idx:1,fill:C.wine},{idx:2,fill:'#A9ADA9'},{idx:3,fill:'#A9ADA9'},{idx:4,fill:C.gold}]}],
  hasLegend:false,
  barOptions:{direction:'bar',grouping:'clustered',gapWidth:86},
  dataLabels:{showValue:true,position:'outEnd',numberFormatCode:'0.00',textStyle:{fontSize:20,fill:C.ink,typeface:FONT}},
  xAxis:{textStyle:{fontSize:18,fill:C.body,typeface:FONT},line:{fill:'none',width:0},majorTickMark:'none',minorTickMark:'none'},
  yAxis:{min:0,max:1.08,majorUnit:0.2,numberFormatCode:'0.0',textStyle:{fontSize:15,fill:C.muted,typeface:FONT},majorGridlines:{fill:C.rule,width:1},line:{fill:'none',width:0}},
  chartFill:C.bg,chartLine:{fill:'none',width:0},plotAreaFill:C.bg,plotAreaLine:{fill:'none',width:0}
 });
 applyPresentationChartFont(chart,{fontFamily:FONT});
 rule(s,799,201,1,C.rule,377);
 text(s,'比较对象分别回答什么问题',835,195,366,38,23,C.wine,true);
 const rows=[['GRU','相同训练设置，比较记忆架构。'],['Conditioning','提供运动学信息，但上下文仅 64 步。'],['Expert','直接在目标机器人上训练的参考策略。']];
 for(let j=0;j<3;j++){
  const y=258+j*103;
  text(s,rows[j][0],835,y,366,30,22,C.ink,true);
  text(s,rows[j][1],835,y+38,366,52,19,C.muted,false,{valign:'top'});
 }
 takeaway(s,'额外 5 秒交互后平均值由 0.96 提升至 0.98，接近 Expert 的 0.99。',606,21);
 notes(s,'来源：Table 1。平均值依次0.96±0.19、0.98±0.13、0.37±0.41、0.78±0.37、0.99±0.07。本页只显示均值，不解释原文未在此处定义的±统计含义。指标是随机目标方向位移归一化至[0,1]，不是成功率或米数。测试5双足、3四足、2轮足；每平台1000随机化环境。Few-shot预评估5秒；并非所有平台均提高，例如GR1均值0.95至0.94。Conditioning同时改变特权输入与上下文长度，不能作为单因素因果消融。');
}

// 08. Keep the original plots because underlying time-series data are not provided.
{
 const s=base(7,'短暂交互改善稳定性，内部表示逐渐区分身体','来源：LocoFormer §3.1，Figure 4；两图直接取自原文');
 subtitle(s,'行为改善与内部表示变化提供互补证据，分别检验适应收益和历史信息的使用。');
 text(s,'适应时间与平均存活时间',78,194,535,35,24,C.wine,true);
 text(s,'不同身体的表示随交互分化',680,194,530,35,24,C.wine,true);
 rect(s,70,244,546,302,C.white);
 rect(s,664,244,546,302,C.white);
 image(s,'figure4a.png',85,249,516,292);
 image(s,'figure4b.png',679,249,516,292);
 text(s,'随机化强度加倍，评估运行最长 6 秒。\n每个适应预算评估 50,000 个 Episode。',78,558,535,57,19,C.body);
 text(s,'4 种人形变体，4,096 次 zero-shot 运行。\n第 2 层平均输出在约 5 秒时形成不同簇。',680,558,530,57,19,C.body);
 text(s,'整体收益趋于饱和，曲线存在波动。',78,625,535,28,18,C.muted);
 text(s,'表示分化支持身体相关表征，未直接证明精确物理辨识。',680,622,530,36,18,C.muted);
 notes(s,'来源：Figure 4(a)(b)及§3.1 Adaptation Performance/Representation Dynamics。4(a)四类程序化机器人，2倍随机化，适应预算0至6秒，之后6秒rollout记录倒下时间，每设置50KEpisodes；曲线总体改善但并非每个点单调。4(b)4096次zero-shot、四人形变体、第2层平均输出随时间，约5秒分簇。原文未说明本图可视化投影方法，不补写PCA/t-SNE。图不证明质量、惯量等参数被准确恢复。正文误引用Fig.6c/d，实际为Figure4。');
}

// 09. Representative real-world evidence, all from the same model.
{
 const s=base(8,'同一模型在真实身体变化中调整运动方式','来源：LocoFormer §3.2，Figure 5；同一模型的实机演示');
 subtitle(s,'G1、H1、Go2 与 Go2-W，包含后腿双足模式，部署前不针对目标平台微调或重训。');
 image(s,'figure5.png',70,192,685,416);
 text(s,'A、E  关节或腿锁定',793,199,418,33,23,C.wine,true);
 text(s,'可用支撑改变，调整负载分配与步态。',793,241,418,52,20,C.body);
 rule(s,793,307,418);
 text(s,'B  跨 Trial 保留失败经历',793,325,418,33,23,C.wine,true);
 text(s,'不稳定双足配置中，后续尝试利用缓存，\n演示在第 3 次 Trial 稳定行走。',793,368,418,65,20,C.body);
 rule(s,793,447,418);
 text(s,'C、D、F  驱动与结构变化',793,465,418,33,23,C.wine,true);
 text(s,'轮部驱动改变、附加负载、加长或截短腿部，\n均展示了相应的运动调整。',793,508,418,76,20,C.body);
 takeaway(s,'实机结果展示固定参数下的适应行为，恢复时延与成功范围仍需系统统计。',616,20);
 notes(s,'来源：§3.2、Figure5。A膝关节固定PD目标，正文报告2–3秒后恢复三足行走。B不稳定无踝双足配置保留失败缓存，演示第三Trial稳定。C原文称锁轮并描述将增益置零；增益置零不等于机械刹车锁死，故本页使用轮部驱动改变，不补写机械锁实现。D高跷改变腿长和动力学。F截短下腿，正文7–8秒而图注数十秒，故本页不列统一恢复时间。案例演示不能解释成系统成功率或任意故障保证。图像来源论文Figure5，CC BY4.0。');
}

// 10. Conclusions, evidential limits and a concrete research question.
{
 const s=base(9,'贡献、证据边界与后续研究问题','来源：LocoFormer §5–6，Appendix A、C；研究问题为汇报分析');
 text(s,'方法与实验支持的结论',70,157,523,40,26,C.wine,true);
 text(s,'规模与多样性提供适应训练条件',70,221,520,34,23,C.ink,true);
 text(s,'程序化身体与广泛随机化共同构成\n统一策略的训练任务空间。',70,265,520,65,21,C.body);
 text(s,'长上下文把经历转为控制依据',70,357,520,34,23,C.ink,true);
 text(s,'固定参数的策略利用跨段与跨 Trial 历史，\n在测试中呈现相应的行为调整。',70,401,520,68,21,C.body);
 rule(s,628,158,1,C.rule,349);
 text(s,'需要保留的边界',678,157,523,40,26,C.green,true);
 text(s,'训练成本与任务生成仍受约束',678,221,520,34,23,C.ink,true);
 text(s,'训练计算需求高，手工设计的生成空间\n仍难以覆盖所有机器人。',678,265,520,65,21,C.body);
 text(s,'现有证据尚不能解释全部增益来源',678,357,520,34,23,C.ink,true);
 text(s,'训练规模、随机化与记忆共同变化。\n实机验证以案例演示为主。',678,401,520,68,21,C.body);
 rule(s,70,526,1140,C.wine,1.5);
 text(s,'后续研究问题',70,550,1130,35,24,C.wine,true);
 text(s,'在匹配训练数据与计算预算后，长记忆和跨 Trial 保留各自带来多少收益？',70,597,1134,43,23,C.ink,true);
 notes(s,'来源：Conclusion、Limitations、AppendixA/C。正文强调训练成本高及手工设计任务生成空间。AppendixA说明生成空间不穷尽；AppendixC提及100k机器人和约500倍单平台训练计算，但本页不把不同资源口径的天数直接等同。最后的匹配预算与跨Trial消融是汇报者提出的研究问题，不冒充论文已完成实验。复现还需核对输入/动作映射、奖励权重、随机化范围、PPO设置、缓存与重置边界；论文未完整披露这些配置。');
}

await fs.mkdir(path.join(BUILD,'preview'),{recursive:true});
for(let i=0;i<p.slides.items.length;i++){
 const png=await p.export({slide:p.slides.items[i],format:'png',scale:1});
 await fs.writeFile(path.join(BUILD,'preview',`slide-${String(i+1).padStart(2,'0')}.png`),new Uint8Array(await png.arrayBuffer()));
 const layout=await p.slides.items[i].export({format:'layout'});
 await fs.writeFile(path.join(BUILD,'preview',`slide-${String(i+1).padStart(2,'0')}.json`),new Uint8Array(await layout.arrayBuffer()));
 console.log('rendered',i+1);
}
const candidate=path.join(BUILD,'candidate.pptx');
await (await PresentationFile.exportPptx(p)).save(candidate);
const content=await p.inspect({select:'$.slides[*]',include:['index','title','elements.kind','elements.text','notes.text']});
await fs.writeFile(path.join(BUILD,'content.ndjson'),content.ndjson);
console.log('DRAFT',candidate);
if(process.argv.includes('--finalize')){
 const sha=createHash('sha256').update(await fs.readFile(REF)).digest('hex');
 const result=await finalizePresentation({
  workspaceDir:WORK,candidatePath:candidate,finalPath:FINAL,
  pythonExecutable:PY,
  integrityValidatorPath:path.join(SKILL,'container_tools/inspect_presentation_package_integrity.py'),
  layoutValidatorPath:path.join(SKILL,'container_tools/inspect_presentation_layout_geometry.py'),
  explicitTotalSlideCount:10,
  requiredNativeChartOwnerSlides:[7],requiredNativeTableOwnerSlides:[],
  materializeLiteralChartWorkbooks:true,
  layoutArgs:['--expected-slide-size-emu','12192000,6858000','--validate-bullet-geometry','--validate-heading-fit'],
  fontPolicy:{basis:'reference',families:[FONT,'Cambria Math'],referencePath:REF,referenceSha256:sha},
  verifyArtifactToolImport:true,
  receiptPath:path.join(BUILD,'final.validation.json'),
 });
 console.log('FINAL',JSON.stringify(result));
}
