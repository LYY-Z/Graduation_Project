from pathlib import Path
from zipfile import ZipFile
from hashlib import sha256
from urllib.parse import unquote,urlsplit
from io import BytesIO
import json,re,sys
from lxml import etree as E
from PIL import Image,ImageChops
sys.stdout.reconfigure(encoding='utf-8')
ROOT=Path('G:/毕设');L=ROOT/'02_learning';D=L/'04_review/deliverables';B=L/'04_review/.build_locoformer_bilingual_20261102'
NS={'p':'http://schemas.openxmlformats.org/presentationml/2006/main','a':'http://schemas.openxmlformats.org/drawingml/2006/main','c':'http://schemas.openxmlformats.org/drawingml/2006/chart','s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
digest=lambda p:sha256(p.read_bytes()).hexdigest()
sections=lambda p:[s.split('\n',1)[1].strip().removesuffix('---').strip() for s in re.split(r'^## ',p.read_text(encoding='utf-8-sig'),flags=re.M)[1:]]
get_text=lambda root:'\n'.join(''.join(p.xpath('.//a:t/text()',namespaces=NS)) for p in root.findall('a:p',NS))
checks=[]
with ZipFile(B/'source.pptx') as original:
    original_chart=[n for n in original.namelist() if n.endswith('/chart1.xml')][0]
    numeric=E.fromstring(original.read(original_chart)).xpath('//c:numCache/c:pt/c:v/text()',namespaces=NS)
    assert numeric==['0.96','0.98','0.37','0.78','0.99']
    for lang in ['CN','EN']:
        ppt=D/f'locoformer/report.{lang}.pptx'
        assert digest(ppt)==digest(B/f'validated/report.{lang}.pptx')
        speeches=sections(D/f'locoformer/speech.{lang}.md');assert len(speeches)==14
        with ZipFile(ppt) as z:
            assert z.testzip() is None
            assert len([n for n in z.namelist() if re.fullmatch(r'ppt/slides/slide\d+\.xml',n)])==14
            hidden=[]
            for i in range(1,15):
                slide=E.fromstring(z.read(f'ppt/slides/slide{i}.xml'))
                if slide.get('show')=='0':hidden.append(i)
                text=''.join(slide.xpath('//a:t/text()',namespaces=NS))
                assert '来源：' not in text
                if lang=='EN':assert not re.search(r'[\u4e00-\u9fff]',text)
                note=E.fromstring(z.read(f'ppt/notesSlides/notesSlide{i}.xml'))
                body=note.xpath('//p:sp[p:nvSpPr/p:nvPr/p:ph[@type="body"]]/p:txBody',namespaces=NS)[0]
                note_text=get_text(body)
                assert note_text.startswith(speeches[i-1]),(lang,i)
                assert len(note_text)>len(speeches[i-1])+30
                if lang=='CN':
                    expected=E.fromstring(original.read(f'ppt/slides/slide{i}.xml'))
                    for shape in expected.findall('p:cSld/p:spTree/p:sp',NS):
                        t=shape.find('p:txBody',NS)
                        if t is not None and get_text(t).startswith('来源：'):shape.getparent().remove(shape)
                    assert E.tostring(expected,method='c14n')==E.tostring(slide,method='c14n'),i
                    assert original.read(f'ppt/notesSlides/notesSlide{i}.xml')==z.read(f'ppt/notesSlides/notesSlide{i}.xml')
                assert all(original.read(n)==z.read(n) for n in original.namelist() if '/media/' in n)
            assert hidden==[13,14]
            assert E.fromstring(z.read(original_chart)).xpath('//c:numCache/c:pt/c:v/text()',namespaces=NS)==numeric
            wb=[n for n in z.namelist() if n.endswith('.xlsx')][0]
            with ZipFile(BytesIO(z.read(wb))) as w:
                sheet=E.fromstring(w.read('xl/worksheets/sheet1.xml'))
                assert sheet.xpath('//s:c/s:v/text()',namespaces=NS)==numeric
        checks.append({'language':lang,'slides':14,'notesMatch':14,'hiddenSlides':hidden,'chartValuesUnchanged':True,'mediaUnchanged':True,'sha256':digest(ppt)})

pixel_checks=[]
for i in range(1,15):
    before=Image.open(L/f'04_review/.build_locoformer_notes_20261102/final-preview/slide-{i:02d}.png').convert('RGB')
    after=Image.open(B/f'preview.CN/slide-{i:02d}.png').convert('RGB')
    bbox=ImageChops.difference(before,after).getbbox()
    assert bbox is None if i==1 else bbox is not None and bbox[1]>=675 and bbox[2]<1130,(i,bbox)
    pixel_checks.append({'slide':i,'changedRegion':bbox})

mds=[D/'README.md',D/'locoformer/speech.CN.md',D/'locoformer/speech.EN.md',D/'ur7e/deployment_brief.CN.md',L/'04_review/README.md',L/'locoformer/README.md']
links=[]
for md in mds:
    for raw in re.findall(r'\]\(([^)]+)\)',md.read_text(encoding='utf-8-sig')):
        if raw.startswith(('https://','http://','#','mailto:')):continue
        target=unquote(raw.split('#')[0].strip('<>'))
        p=Path(target) if re.match(r'^[A-Za-z]:',target) else md.parent/target
        assert p.exists(),(str(md),raw)
        links.append({'file':str(md),'target':raw})
result={'decks':checks,'chinesePixelChangesOnlyInSourceFooters':pixel_checks,'localLinksChecked':len(links)}
(B/'delivery-verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'verifiedDecks':2,'verifiedNotes':28,'chineseChanges':'source footers only','localLinks':len(links)},ensure_ascii=False))
