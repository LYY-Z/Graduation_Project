import fs from 'node:fs/promises';
import path from 'node:path';
import {PresentationFile,FileBlob} from '@oai/artifact-tool';
const B='G:/毕设/02_learning/04_review/.build_locoformer_bilingual_20261102';
const lang=process.argv[2]??'EN';
const input=process.argv[3]??`preserved.${lang}.pptx`;
const p=await PresentationFile.importPptx(await FileBlob.load(path.join(B,input)));
const out=path.join(B,`preview.${lang}`);await fs.mkdir(out,{recursive:true});
for(let i=0;i<p.slides.items.length;i++){
 const s=p.slides.items[i];
 const png=await p.export({slide:s,format:'png',scale:1});
 await fs.writeFile(path.join(out,`slide-${String(i+1).padStart(2,'0')}.png`),new Uint8Array(await png.arrayBuffer()));
 const layout=await s.export({format:'layout'});
 await fs.writeFile(path.join(out,`slide-${String(i+1).padStart(2,'0')}.json`),new Uint8Array(await layout.arrayBuffer()));
}
const content=await p.inspect({select:'$.slides[*]',include:['index','title','elements.id','elements.kind','elements.text','elements.position','notes.text']});
await fs.writeFile(path.join(B,`final-content.${lang}.ndjson`),content.ndjson);
console.log(JSON.stringify({language:lang,rendered:p.slides.items.length,input}));
