import fs from 'node:fs/promises';
import path from 'node:path';
import {PresentationFile, FileBlob} from '@oai/artifact-tool';
const B='G:/毕设/02_learning/04_review/.build_locoformer_bilingual_20261102';
const dictionary=JSON.parse(await fs.readFile(path.join(B,'translations.json'),'utf8'));
const inventory=JSON.parse(await fs.readFile(path.join(B,'source-inventory.json'),'utf8'));
const p=await PresentationFile.importPptx(await FileBlob.load(path.join(B,'source.pptx')));
const records=(await p.inspect({select:'$.slides[*]',include:['id','index','title','elements.id','elements.kind','elements.text','elements.position']})).records;
await fs.writeFile(path.join(B,'source-inspection.ndjson'),(await p.inspect({select:'$.slides[*]',include:['id','index','title','elements.id','elements.kind','elements.text','elements.position']})).ndjson);
const changes=[];
for(let i=0;i<14;i++){
  for(const e of records[i].elements.filter(e=>e.kind==='textbox'&&e.text?.startsWith('来源：'))){
    p.resolve(e.id).text='';
    changes.push({slide:i+1,id:e.id,source:e.text,action:'remove visible source footer'});
  }
}
await(await PresentationFile.exportPptx(p)).save(path.join(B,'candidate.CN.pptx'));

const md=await fs.readFile(path.join(B,'speech.EN.md'),'utf8');
const sections=md.split(/^## /m).slice(1).map((s,i)=>({slide:i+1,heading:s.slice(0,s.indexOf('\n')).trim(),body:s.slice(s.indexOf('\n')+1).trim().replace(/\n+---\s*$/,'').trim()}));
if(sections.length!==14)throw new Error('Expected 14 English speeches');
const refs=JSON.parse(await fs.readFile(path.join(B,'references.EN.json'),'utf8'));
const untranslated=[];
for(let i=0;i<14;i++){
  for(const e of records[i].elements.filter(e=>e.kind==='textbox')){
    if(e.text?.startsWith('来源：'))continue;
    if(dictionary[e.text]){
      const shape=p.resolve(e.id);shape.text=dictionary[e.text];
      // Preserve the template; adjust only local typography needed by English text.
      if(i===0&&e.text.startsWith('汇报人'))shape.text.fontSize=24;
      if(i===2&&e.position.top>=255&&e.position.height<=57)shape.text.fontSize=e.position.height===35?21:17;
      if(i===3&&e.text==='按规则生成双足、四足与轮足\n改变关节结构、质量与惯量\n随机化控制增益和关节限位')shape.text.fontSize=19;
      if(i===3&&e.text==='任务 M：身体及其控制条件')shape.text.fontSize=22;
      if(i===4&&e.text==='控制器与身体')shape.text.fontSize=18;
      if(i===5&&['保留数值，停止反传','读取历史，生成当前输出'].includes(e.text))shape.text.fontSize=17;
      if(i===6&&e.text==='优势决定调整方向\n裁剪限制过大的变化')shape.text.fontSize=17;
      if(i===5&&['采集时：逐步获得观测','段间记忆与停止梯度（SG）','训练时：已保存观测整段输入'].includes(e.text))shape.text.fontSize=22;
      if(i===8&&e.text==='归一化朝目标位移')shape.text.fontSize=21;
      if(i===9&&['更多交互总体提高存活时间','网络特征逐渐区分不同身体'].includes(e.text))shape.text.fontSize=22;
      if(i===10&&e.text==='C、D、F  驱动与结构变化')shape.text.fontSize=21;
      if(i===11&&['控制训练规模，比较记忆长度','检验保留失败经历的作用'].includes(e.text))shape.text.fontSize=21;
      if(i>=12&&e.text.startsWith('补充 ')&&e.position.left>1100)shape.text.fontSize=12;
      changes.push({slide:i+1,id:e.id,source:e.text,translation:dictionary[e.text]});
    }else if(/[\u4e00-\u9fff]/.test(e.text??''))untranslated.push({slide:i+1,text:e.text});
  }
  for(let t=0;t<inventory[i].tables.length;t++){
    const table=p.slides.items[i].tables.items[t];
    const cells=inventory[i].tables[t];
    for(let r=0;r<cells.length;r++)for(let c=0;c<cells[r].length;c++){
      const value=cells[r][c];
      if(dictionary[value])table.cells.set(r,c,dictionary[value]);
      else if(/[\u4e00-\u9fff]/.test(value))untranslated.push({slide:i+1,table:t,row:r,col:c,text:value});
    }
  }
  p.slides.items[i].speakerNotes.text=sections[i].body+'\n\n—— Source and verification notes (not for reading aloud) ——\n'+refs[i];
  p.slides.items[i].speakerNotes.setVisible(true);
}
if(untranslated.length)throw new Error(JSON.stringify(untranslated));
const chart=p.slides.items[8].charts.items[0];
chart.series.getItemAt(0).name=dictionary['平均归一化位移'];
await(await PresentationFile.exportPptx(p)).save(path.join(B,'candidate.EN.pptx'));
await fs.writeFile(path.join(B,'changes.json'),JSON.stringify(changes,null,2));
await fs.writeFile(path.join(B,'speeches.EN.json'),JSON.stringify(sections,null,2));
console.log(JSON.stringify({slidesPerLanguage:14,removedFooters:changes.filter(x=>x.action).length,translatedShapes:changes.filter(x=>x.translation).length}));
