"""Publish verified decks and organize only the explicitly requested deliverables directory."""
from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile
import json,re,shutil,sys
sys.stdout.reconfigure(encoding='utf-8')
ROOT=Path('G:/毕设')
L=ROOT/'02_learning'
D=L/'04_review/deliverables'
B=L/'04_review/.build_locoformer_bilingual_20261102'
A=ROOT/'99_archive/review_cleanup/2026-11-02'
digest=lambda p:sha256(p.read_bytes()).hexdigest()
old_manifest=json.loads((A/'manifest.json').read_text(encoding='utf-8'))
with ZipFile(A/'deliverables_before_cleanup.zip') as archive:
    assert archive.testzip() is None
    for record in old_manifest:
        assert sha256(archive.read(record['name'])).hexdigest()==record['sha256']

copies={
    B/'validated/report.CN.pptx':D/'locoformer/report.CN.pptx',
    B/'validated/report.EN.pptx':D/'locoformer/report.EN.pptx',
    D/'diffusion_policy_report-LYY.pptx':D/'diffusion_policy/report.CN.pptx',
    D/'diffusion_policy_10min_speech_script.docx':D/'diffusion_policy/speech.CN.docx',
    D/'diffusion_policy_slide_knowledge_review.docx':D/'diffusion_policy/knowledge_review.CN.docx',
}
for source,target in copies.items():
    target.parent.mkdir(parents=True,exist_ok=True)
    if target.exists():assert digest(target)==digest(source),'Do not replace an unrelated file'
    else:shutil.copy2(source,target)
    assert digest(target)==digest(source)

speech_cn=(B/'speech.CN.md').read_text(encoding='utf-8').replace('locoformer_paper_report_presenter.pptx','report.CN.pptx')
(D/'locoformer/speech.CN.md').write_text(speech_cn,encoding='utf-8')
shutil.copy2(B/'speech.EN.md',D/'locoformer/speech.EN.md')
ur=(D/'ur7e_deployment_brief.md').read_text(encoding='utf-8')
ur=ur.replace('../../../03_code/','../../../../03_code/')
ur=re.sub(r'\n{3,}','\n\n',ur)
(D/'ur7e').mkdir(exist_ok=True)
(D/'ur7e/deployment_brief.CN.md').write_text(ur,encoding='utf-8')

(D/'README.md').write_text('''# 汇报交付文件

按主题保存当前版本。`CN` 为中文版，`EN` 为英文版。

| 主题 | 汇报材料 | 配套材料 |
|---|---|---|
| LocoFormer | [中文 PPT](locoformer/report.CN.pptx) · [English PPT](locoformer/report.EN.pptx) | [中文讲稿](locoformer/speech.CN.md) · [English script](locoformer/speech.EN.md) |
| Diffusion Policy | [论文汇报 PPT](diffusion_policy/report.CN.pptx) | [演讲稿](diffusion_policy/speech.CN.docx) · [逐页知识回顾](diffusion_policy/knowledge_review.CN.docx) |
| UR7e 部署 | [部署进展汇报](ur7e/deployment_brief.CN.md) | — |

LocoFormer 中英文版逐页对应，均包含 12 页主讲和 2 页隐藏补充；每页备注中附有对应语言的演讲稿，来源信息置于备注末尾。

整理前备份见 [归档压缩包](../../../99_archive/review_cleanup/2026-11-02/deliverables_before_cleanup.zip)。
''',encoding='utf-8')

(L/'04_review/README.md').write_text('''# 汇报资料

当前交付文件按主题集中保存于 [`deliverables`](deliverables/README.md)。

| 主题 | 汇报材料 | 学习资料 |
|---|---|---|
| LocoFormer | [中文 PPT](deliverables/locoformer/report.CN.pptx) · [英文 PPT](deliverables/locoformer/report.EN.pptx) · [中文讲稿](deliverables/locoformer/speech.CN.md) · [英文讲稿](deliverables/locoformer/speech.EN.md) | [学习手册](../locoformer/README.md) |
| Diffusion Policy | [论文汇报 PPT](deliverables/diffusion_policy/report.CN.pptx) | [论文与代码教材](../diffusion_policy/README.md) |
| UR7e 部署 | [部署进展汇报](deliverables/ur7e/deployment_brief.CN.md) | [部署代码学习](../diffusion_policy/06_refactored_code/README.md) |

LocoFormer 为 12 页正文与 2 页隐藏补充。补充 A 解释 PPO 裁剪，补充 B 说明第三方参考代码的采集与更新时序。中英文版页序一致，演讲稿已写入对应备注。
''',encoding='utf-8')

index=L/'locoformer/README.md'
t=index.read_text(encoding='utf-8-sig')
t=t.replace('../04_review/deliverables/locoformer_paper_report_presenter.pptx','../04_review/deliverables/locoformer/report.CN.pptx')
t=t.replace('../04_review/deliverables/locoformer_paper_report_speech.md','../04_review/deliverables/locoformer/speech.CN.md')
index.write_text(t,encoding='utf-8')

removed=[];pending=[]
for record in old_manifest:
    p=D/record['name']
    assert p.resolve().parent==D.resolve(),'Deletion must remain in the named deliverables directory'
    if not p.exists():continue
    if digest(p)!=record['sha256']:
        pending.append({'file':p.name,'reason':'modified since backup'});continue
    try:p.unlink();removed.append(p.name)
    except PermissionError:pending.append({'file':p.name,'reason':'open in another application'})

result={'published':sorted(str(p.relative_to(D)) for p in D.rglob('*') if p.is_file() and not p.name.startswith('~$')),
        'removedOldFiles':removed,'pending':pending,'backup':str(A/'deliverables_before_cleanup.zip')}
(B/'organization.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False))
