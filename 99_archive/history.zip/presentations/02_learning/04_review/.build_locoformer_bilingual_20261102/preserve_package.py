"""Preserve original media, geometry, chart data and workbook while applying authored edits."""
from copy import copy, deepcopy
from io import BytesIO
from pathlib import Path
from zipfile import ZipFile
import json
from lxml import etree as ET

B=Path('G:/毕设/02_learning/04_review/.build_locoformer_bilingual_20261102')
NS={'p':'http://schemas.openxmlformats.org/presentationml/2006/main',
    'a':'http://schemas.openxmlformats.org/drawingml/2006/main',
    'c':'http://schemas.openxmlformats.org/drawingml/2006/chart',
    's':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}

def xml(data):return ET.fromstring(data)
def serialize(root):return ET.tostring(root,encoding='UTF-8',xml_declaration=True,standalone=True)
def shape_id(shape):return shape.find('p:nvSpPr/p:cNvPr',NS).get('id')
def texts(element):return '\n'.join(''.join(p.xpath('.//a:t/text()',namespaces=NS)) for p in element.findall('a:p',NS))
def replace_body(original,authored):
    old=original.find('p:txBody',NS);new=authored.find('p:txBody',NS)
    if new is not None:
        if old is None:original.append(deepcopy(new))
        else:original.replace(old,deepcopy(new))

results=[]
with ZipFile(B/'source.pptx') as source:
 for lang in ['CN','EN']:
  replacements={}
  with ZipFile(B/f'candidate.{lang}.pptx') as authored:
   for i in range(1,15):
    name=f'ppt/slides/slide{i}.xml';root=xml(source.read(name));edited=xml(authored.read(name))
    new_by_id={shape_id(s):s for s in edited.findall('p:cSld/p:spTree/p:sp',NS)}
    touched=False
    for shape in root.findall('p:cSld/p:spTree/p:sp',NS):
     old_body=shape.find('p:txBody',NS)
     if old_body is None:continue
     old_text=texts(old_body)
     new_shape=new_by_id[shape_id(shape)]
     new_body=new_shape.find('p:txBody',NS)
     if old_text.startswith('来源：'):
      assert not texts(new_body).strip()
      shape.getparent().remove(shape);touched=True
     elif lang=='EN' and old_text!=texts(new_body):
      replace_body(shape,new_shape);touched=True
    if lang=='EN':
     old_tables=root.findall('.//a:tbl',NS);new_tables=edited.findall('.//a:tbl',NS)
     assert len(old_tables)==len(new_tables)
     for old_tab,new_tab in zip(old_tables,new_tables):
      old_cells=old_tab.findall('a:tr/a:tc',NS);new_cells=new_tab.findall('a:tr/a:tc',NS)
      for old_cell,new_cell in zip(old_cells,new_cells):
       old=old_cell.find('a:txBody',NS);new=new_cell.find('a:txBody',NS)
       if texts(old)!=texts(new):old_cell.replace(old,deepcopy(new));touched=True
    if touched:replacements[name]=serialize(root)
    if lang=='EN':
     name=f'ppt/notesSlides/notesSlide{i}.xml'
     old=xml(source.read(name));new=xml(authored.read(name))
     xp='//p:sp[p:nvSpPr/p:nvPr/p:ph[@type="body"]]/p:txBody'
     old_body=old.xpath(xp,namespaces=NS)[0];new_body=new.xpath(xp,namespaces=NS)[0]
     old_body.getparent().replace(old_body,deepcopy(new_body));replacements[name]=serialize(old)
   if lang=='EN':
    chart_path=[n for n in source.namelist() if n.endswith('/chart1.xml')][0]
    authored_chart=[n for n in authored.namelist() if n.endswith('/chart1.xml')][0]
    old=xml(source.read(chart_path));new=xml(authored.read(authored_chart))
    # Read the translated series label from the authored chart; retain its source formula.
    label=new.xpath('//c:ser/c:tx//c:v/text()',namespaces=NS)
    if not label:label=new.xpath('//c:ser/c:tx/c:v/text()',namespaces=NS)
    assert label and label[0]=='Mean normalized displacement',label
    old.xpath('//c:ser/c:tx//c:pt/c:v',namespaces=NS)[0].text=label[0]
    replacements[chart_path]=serialize(old)
    workbook=[n for n in source.namelist() if n.endswith('.xlsx')][0]
    workbook_bytes=BytesIO()
    with ZipFile(BytesIO(source.read(workbook))) as wb,ZipFile(workbook_bytes,'w') as out:
     for item in wb.infolist():
      content=wb.read(item.filename)
      if item.filename=='xl/worksheets/sheet1.xml':
       sheet=xml(content);sheet.xpath('//s:c[@r="B1"]/s:is/s:t',namespaces=NS)[0].text=label[0]
       content=serialize(sheet)
      out.writestr(copy(item),content)
    replacements[workbook]=workbook_bytes.getvalue()
  target=B/f'preserved.{lang}.pptx'
  with ZipFile(target,'w') as output:
   output.comment=source.comment
   for item in source.infolist():output.writestr(copy(item),replacements.get(item.filename,source.read(item.filename)))
  with ZipFile(target) as output:
   assert set(source.namelist())==set(output.namelist())
   changed=[n for n in source.namelist() if source.read(n)!=output.read(n)]
   assert all(source.read(n)==output.read(n) for n in source.namelist() if '/media/' in n)
   for i in range(1,15):
    text=''.join(xml(output.read(f'ppt/slides/slide{i}.xml')).xpath('//a:t/text()',namespaces=NS))
    assert '来源：' not in text
    if lang=='EN':assert not any('\u4e00'<=c<='\u9fff' for c in text),(i,text)
  results.append({'language':lang,'changedParts':changed,'mediaUnchanged':True,'sourceFootersRemoved':13})
(B/'package-preservation.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps([{'language':r['language'],'changedParts':len(r['changedParts'])} for r in results]))
