import fs from 'node:fs/promises';
import path from 'node:path';
import {PresentationFile,FileBlob} from '@oai/artifact-tool';
const B='G:/毕设/02_learning/04_review/.build_locoformer_flow_20261102';
const p=await PresentationFile.importPptx(await FileBlob.load(path.join(B,'source.pptx')));
const records=(await p.inspect({select:'$.slides[*]',include:['id','index','title','elements.id','elements.kind','elements.text','elements.position']})).records;
const edits=[];
function replace(i,old,value,opts={}){
 const hits=records[i].elements.filter(e=>e.kind==='textbox'&&e.text===old);
 if(hits.length!==1)throw new Error(`Slide ${i+1}: expected one match for ${JSON.stringify(old)}, got ${hits.length}`);
 const sh=p.resolve(hits[0].id);sh.text=value;
 if(opts.position)sh.position={...hits[0].position,...opts.position};
 if(opts.size)sh.text.fontSize=opts.size;
 edits.push({slide:i+1,old,new:value});
}
const deck=[
 {title:'LocoFormer',seconds:20},
 {title:'跨机器人控制的难点',seconds:45},
 {title:'方法框架：训练与部署',seconds:50},
 {title:'训练任务：多样身体与多次尝试',seconds:60},
 {title:'控制网络：观测、历史与动作',seconds:50},
 {title:'历史记忆：分段计算与缓存',seconds:65},
 {title:'策略训练：奖励与 PPO 更新',seconds:70},
 {title:'部署过程：固定参数、积累历史',seconds:50},
 {title:'仿真结果：迁移到未见机器人',seconds:50},
 {title:'适应过程：交互带来哪些改善',seconds:50},
 {title:'实机结果：身体变化后的调整',seconds:50},
 {title:'方法总结与后续研究',seconds:40},
 {title:'补充 A：PPO 裁剪与整批损失',seconds:60},
 {title:'补充 B：参考代码的采集与更新时序',seconds:60},
];
for(let i=1;i<12;i++)replace(i,records[i].title,deck[i].title);

// 02 Establish the need for interaction history.
replace(1,'相近观测可能对应不同身体条件，动作后的响应提供进一步判断依据。','不同机器人的身体与驱动条件不同，策略需要结合实际响应调整控制。');
replace(1,'身体与驱动变化','相同指令，身体响应不同');
replace(1,'结构、质量、控制增益或关节状态改变，\n相同目标指令会产生不同身体响应。','身体结构、质量和驱动能力改变后，\n相同关节目标会产生不同的实际运动。');
replace(1,'当前观测提供状态','单次观测提供的信息有限');
replace(1,'关节与身体状态描述“现在怎样”，\n未必足以判断异常来自何种条件。','当前姿态和关节状态，\n未必足以区分短暂扰动与持续变化。');
replace(1,'历史提供交互证据','历史响应帮助判断控制条件');
replace(1,'结合过去的控制与实际响应，\n逐步形成与当前身体相关的内部表示。','结合过去的控制和身体响应，\n为后续动作提供更充分的判断依据。');
replace(1,'程序化身体训练，同一策略迁移至未见实机。','在多种仿真身体上训练，将同一策略迁移到未见实机。',{size:17});
replace(1,'多样化训练提供初始泛化能力，交互历史支持部署中的进一步调整。','核心要求：既能控制不同身体，也能利用交互历史继续调整动作。');

// 03 Position the next four method slides inside one framework.
replace(2,'训练通过奖励更新共享策略，部署通过持续交互更新历史表示。','训练阶段学习如何利用历史，部署阶段用新交互持续调整动作。');
replace(2,'任务采样','生成训练任务');
replace(2,'程序化身体\n动力学与控制条件','多种机器人身体\n随机化动力学与控制条件');
replace(2,'闭环交互','策略与仿真交互');
replace(2,'策略选动作\n仿真返回状态与奖励','策略选择动作\n仿真计算响应与奖励');
replace(2,'保存一批经历','收集交互经历');
replace(2,'PPO 优化','PPO 更新参数');
replace(2,'重算输出与损失\n反向传播更新参数','根据奖励计算损失\n求梯度并更新网络');
replace(2,'当前观测与历史','读取观测与历史');
replace(2,'逐步读取并更新缓存','结合当前状态与过去响应');
replace(2,'当前动作输出','输出当前动作');
replace(2,'新观测与新历史','获得新的身体响应');
replace(2,'响应信息进入下一步','新信息进入下一步计算');
replace(2,'参数学习发生在 PPO 更新中，部署适应发生在固定参数的交互计算中。','方法由训练任务、历史记忆和奖励驱动的参数优化共同构成。');

// 04 Define Trial/Episode before using their training role.
replace(3,'身体重置与历史保留分别控制物理尝试和信息积累。','同一任务允许多次尝试，并保留先前经历，使后续控制能够利用早期反馈。');
replace(3,'任务 M：一种身体与控制条件','任务 M：身体及其控制条件');
replace(3,'程序化生成双足、四足及轮足\n随机化关节结构、质量与惯量\n改变控制增益与关节限位等条件','按规则生成双足、四足与轮足\n改变关节结构、质量与惯量\n随机化控制增益和关节限位');
replace(3,'统一关节空间','统一的关节输入与输出');
replace(3,'策略输出统一关节目标，\n提取当前机器人对应的关节分量。','用统一格式组织关节信息，\n提取当前机器人对应的关节目标。');
replace(3,'同一任务内的一组经历 Episode','同一任务的一组尝试（Episode）');
replace(3,'适应预算 u ~ Uniform(0, U)','适应交互时间 u ~ Uniform(0, U)');
replace(3,'Trial 1','第1次尝试');
replace(3,'实际交互','Trial：一次运行');
replace(3,'Trial 2 …','后续尝试');
replace(3,'最终 Trial','最终尝试');
replace(3,'继续利用\n此前经历','利用此前\n交互经历');
replace(3,'预算内可运行若干 Trial，随后运行最终 Trial。\n切换到另一个 Episode 时，隔离原任务历史。','适应时间内允许若干次尝试，随后运行最终尝试。\n更换任务时，隔离此前任务的历史。');
replace(3,'目标：最大化整组经历的期望折扣回报。','训练目标：提高整组尝试的期望折扣回报。');
replace(3,'先用较短 Trial 和较小适应预算学习适应，再延长运行与交互时间。','先使用较短尝试和较少交互时间，再逐步延长运行时间。');
replace(3,'Trial 是物理尝试，segment 是计算分块，两者边界不要求对齐。','身体可以重新开始一次尝试，先前经历仍可为后续控制提供信息。');

// 05 Make the physical and neural pathways readable before memory details.
replace(4,'共享历史特征支持动作选择和价值估计，实际身体响应闭合控制回路。','网络结合当前观测与历史，选择关节目标；身体响应形成下一步观测。');
replace(4,'统一关节表示','统一格式的状态');
replace(4,'输入 MLP','观测编码 MLP');
replace(4,'观测编码为特征','把观测转换为特征');
replace(4,'读取历史，更新表示','读取历史，计算当前特征');
replace(4,'各层已计算的信息','保留过去计算出的特征');
replace(4,'预测未来折扣回报','预测未来累计回报');
replace(4,'Critic 提供训练评价，动作经底层控制器作用于身体。','Actor 负责选择动作，Critic 为训练提供回报预测。');
replace(4,'目标角度与实际角度的差异来自执行动力学，历史响应因此具有控制价值。','身体响应随时间积累，网络需要保存并读取这些历史信息。');

// 06 Segment is a computational organization with a clear information boundary.
replace(5,'采集逐步获得观测，训练整段并行计算，各位置始终只读取当前与过去。','连续观测按时间段（segment）处理，缓存把可用历史传给下一段。');
replace(5,'采集：当前观测逐步到来','采集时：逐步获得观测');
replace(5,'每一步立即输出动作，缓存持续追加。','每步输出动作，执行后才能获得下一步观测。');
replace(5,'跨段读取','段间记忆与停止梯度（SG）');
replace(5,'旧段表示','上一段特征');
replace(5,'SG 后保留数值','保留数值，停止反传');
replace(5,'当前段计算','当前段计算');
replace(5,'读取历史并生成输出','读取历史，生成当前输出');
replace(5,'截断旧生成链的梯度，保留历史对当前输出的影响。','后段损失不回传到旧段的生成过程，当前段仍可训练。');
replace(5,'训练：保存好的观测整段输入','训练时：已保存观测整段输入');
replace(5,'同一层的多个位置可通过矩阵运算并行。','同一层可并行计算多个位置，掩码限制读取范围。',{size:19});
replace(5,'当前段生成 Q，历史与当前段提供 K、V。\n因果掩码阻止未来观测进入当前动作计算。','Q 用于查询，K 用于匹配，V 提供读取内容。\n因果掩码保证当前动作只使用已出现的信息。',{size:19});

// 07 Reward-to-gradient mechanism, with the equations retained.
replace(6,'保存的经历提供固定参照，当前网络重新前向以计算损失与梯度。','历史信息需要通过奖励训练，才能成为有助于控制的输入。');
replace(6,'从经历构造训练依据','先评价已执行的动作');
replace(6,'δ：一步后的评价差异\nÂ：综合后续信息的优势\nR̂：Critic 的回报训练目标','δ：一步后评价与原预期的差\nÂ：综合后续反馈，评价动作好坏\nR̂：用于训练 Critic 的回报目标');
replace(6,'利用同一批经历优化当前网络','再用这些评价训练当前网络');
replace(6,'重新前向','重新计算网络输出');
replace(6,'新旧概率比与优势\n裁剪过大的有利推动','优势决定调整方向\n裁剪限制过大的变化');
replace(6,'当前价值输出\n与固定回报目标比较','当前价值预测\n与回报目标比较');
replace(6,'损失汇总、反向传播、优化器更新','汇总损失，求梯度并更新参数');
replace(6,'按有效位置平均，同批经历可重复优化','逐段计算梯度，整批完成后更新');
replace(6,'重新前向服务于求梯度，保存的动作只用于评价其当前概率。','奖励通过优势和损失影响参数，使策略学会利用历史选择动作。');

// 08 Fixed weights do not imply fixed behavior.
replace(7,'新交互改变缓存与内部表示，训练获得的策略据此调整动作。','训练结束后固定网络参数，运行中持续更新历史并据此调整动作。');
replace(7,'计算当前 Q、K、V','把当前观测编码为特征');
replace(7,'历史读取','读取相关历史');
replace(7,'当前 Q 匹配已有 K','按相关性读取历史信息');
replace(7,'动作执行，追加新信息','生成动作，保留新特征');
replace(7,'无额外预评估交互，运行中仍会积累历史。','直接开始评估，运行中仍会积累历史。');
replace(7,'先允许短暂交互，仿真评估采用5秒；\n随后Trial可以利用此前经历。','先交互再评估，仿真设置为5秒；\n后续尝试可以利用此前经历。');
replace(7,'6层、L = 128、50 Hz','论文示例：6层，L = 128\n控制频率50 Hz',{size:20,position:{height:56}});
replace(7,'896步的最大可能历史影响\n包含层间间接传递','历史可通过多层间接传递\n最大可能影响896步');
replace(7,'部署KV缓存直接读取范围\n2L−1步，约5.1秒','近期K/V的直接保留范围\n2L−1步，约5.1秒');
replace(7,'部署适应依靠历史更新，直接缓存范围与间接历史影响需区分。','适应效果通过未见机器人表现、交互收益和实机变化三类证据检验。');

// 09 Separate migration performance from evidence of adaptation.
replace(8,'10种未见机器人，每种1,000个随机化环境，比较朝随机目标的归一化位移。','先检验迁移能力：在10种未见机器人上，每种评估1,000个随机化环境。');
replace(8,'如何解释这些比较','与哪些策略比较');
replace(8,'相同训练设置，检验记忆架构差异。','训练设置相同，比较不同的记忆方式。');
replace(8,'有运动学特权信息，但上下文仅64步。','额外提供身体结构信息，\n但只使用64步历史。');
replace(8,'Expert：0.99','专用策略：0.99');
replace(8,'直接在目标机器人上训练的参考策略。','直接在目标机器人上训练，\n作为专用策略参照。');
replace(8,'Zero-shot 0.96，额外5秒交互后0.98，接近目标平台 Expert 的0.99。','平均得分为0.96，额外交互后为0.98，专用策略为0.99。');

// 10 Examine how the adaptation process changes with more interaction.
replace(9,'行为改善和表示分化分别检验适应效果与身体相关信息的形成。','再检验适应过程：增加交互时间，观察存活表现与网络特征怎样变化。');
replace(9,'更多交互总体改善存活','更多交互总体提高存活时间');
replace(9,'不同身体逐渐形成不同表示','网络特征逐渐区分不同身体');
replace(9,'随机化强度加倍，每个设置50,000个Episode。\n适应后评估6秒运行，曲线存在波动与饱和。','随机化强度加倍，每个设置50,000组评估。\n适应后运行6秒，曲线存在波动与饱和。');
replace(9,'4种人形变体，4,096次zero-shot运行。\n第2层表示在约5秒后形成身体相关簇。','4种人形变体，4,096次zero-shot运行。\n约5秒后，不同身体的第2层特征逐渐分开。');
replace(9,'适应窗口与最终Trial的计分时段需区分。','适应交互与最终评估分别计时。');
replace(9,'表示分化不等同于精确恢复质量、惯量等参数。','特征分组不等于准确估计质量、惯量等物理参数。');

// 11 Real-world conditions change the same mechanism's inputs.
replace(10,'G1、H1、Go2与Go2-W，包含后腿双足模式，部署前无目标平台微调。','最后检验实机：同一模型部署于G1、H1、Go2和Go2-W，无目标平台微调。');
replace(10,'B  跨Trial保留失败经历','B  多次尝试保留失败经历');
replace(10,'后续尝试利用已有缓存，\n演示在第3次Trial稳定行走。','保留先前失败经历后，\n该示例在第3次尝试中稳定行走。');
replace(10,'实机案例展示固定参数的适应行为，系统成功率与恢复时延仍需统计。','固定参数下可以调整控制，但故障恢复的成功率与时间仍需系统评估。');

// 12 End with the causal chain and concrete follow-up comparisons.
replace(11,'形成通用策略的条件','论文的三项关键设计');
replace(11,'任务分布','多样化训练任务');
replace(11,'身体结构与动力学多样性，\n提供学习适应的交互条件。','按规则生成多种身体，\n提供不同的动力学与控制条件。');
replace(11,'历史机制','历史信息利用');
replace(11,'跨段与跨Trial缓存保留响应信息，\n固定参数仍可产生不同控制行为。','保留过去的响应与失败经历，\n为当前动作提供判断依据。');
replace(11,'优化机制','奖励驱动的训练');
replace(11,'PPO用长期奖励改善共享策略，\n让利用历史的行为获得训练收益。','PPO根据长期回报调整参数，\n学习利用历史的控制行为。');
replace(11,'仍需区分的增益来源','需要进一步验证的问题');
replace(11,'匹配数据和计算预算','控制训练规模，比较记忆长度');
replace(11,'比较短上下文、长上下文与GRU，\n减少训练规模对架构结论的干扰。','在相同数据和计算预算下，\n比较不同历史长度与GRU策略。');
replace(11,'独立控制历史保留条件','检验保留失败经历的作用');
replace(11,'对比跨Trial保留与清空缓存，\n统计故障后的恢复时间和失败率。','比较尝试间保留或清空历史，\n统计故障后的恢复时间与失败率。');
replace(11,'核心理解','方法主线');
replace(11,'学习过程更新参数，适应过程利用经历；两者通过训练任务与历史架构连接。','多样任务提供训练条件，历史提供判断依据，PPO学习相应控制策略。');

// Supplement pages remain outside the main 10-minute sequence.
replace(12,'取较小训练目标：停止过大的有利推动，同时保留纠正不利变化的梯度。','限制过大的有利变化，同时保留纠正相反方向变化的梯度。');
replace(12,'各位置分别算损失，再按有效位置数N平均。裁剪不是对概率比或关节运动施加硬边界。','各位置分别计算损失，再按有效位置数N平均。PPO裁剪不等同于机器人动作限幅。');
replace(13,'以下为所提供第三方实现的默认入口配置，论文未公开同等完整训练设置。','以下是第三方Microduck示例的默认配置，用于说明流程，不代表论文作者配置。');
replace(13,'16个窗口，每窗12×16位置\n逐窗前向、损失与梯度累积','16个时间段，每段12×16位置\n逐段计算损失并累积梯度');

await fs.mkdir(path.join(B,'preview'),{recursive:true});
for(let i=0;i<p.slides.items.length;i++){
 const blob=await p.export({slide:p.slides.items[i],format:'png',scale:1});
 await fs.writeFile(path.join(B,'preview',`slide-${String(i+1).padStart(2,'0')}.png`),new Uint8Array(await blob.arrayBuffer()));
 const l=await p.slides.items[i].export({format:'layout'});
 await fs.writeFile(path.join(B,'preview',`slide-${String(i+1).padStart(2,'0')}.json`),new Uint8Array(await l.arrayBuffer()));
 console.log('RENDER',i+1);
}
await(await PresentationFile.exportPptx(p)).save(path.join(B,'candidate.pptx'));
await fs.writeFile(path.join(B,'content.ndjson'),(await p.inspect({select:'$.slides[*]',include:['index','title','elements.text','elements.kind','notes.text']})).ndjson);
await fs.writeFile(path.join(B,'edits.json'),JSON.stringify(edits,null,2));
await fs.writeFile(path.join(B,'speech-order.json'),JSON.stringify(deck,null,2));
console.log('Edits',edits.length);
