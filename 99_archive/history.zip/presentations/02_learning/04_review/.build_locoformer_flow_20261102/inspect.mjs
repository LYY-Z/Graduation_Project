import fs from 'node:fs/promises';
import path from 'node:path';
import {PresentationFile,FileBlob} from '@oai/artifact-tool';
const B='G:/毕设/02_learning/04_review/.build_locoformer_flow_20261102';
const p=await PresentationFile.importPptx(await FileBlob.load(path.join(B,'source.pptx')));
await fs.mkdir(path.join(B,'source-preview'),{recursive:true});
const result=await p.inspect({select:'$.slides[*]',include:['id','index','title','layout','elements.id','elements.kind','elements.text','elements.position','notes.text']});
await fs.writeFile(path.join(B,'source-content.ndjson'),result.ndjson);
const layout=await p.inspect({kind:'layout',maxChars:30000});
await fs.writeFile(path.join(B,'source-layout.ndjson'),layout.ndjson??'');
for(let i=0;i<p.slides.items.length;i++){
 const png=await p.export({slide:p.slides.items[i],format:'png',scale:1});
 await fs.writeFile(path.join(B,'source-preview',`slide-${String(i+1).padStart(2,'0')}.png`),new Uint8Array(await png.arrayBuffer()));
}
console.log('Inspected',p.slides.items.length,'slides');
