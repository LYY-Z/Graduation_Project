import fs from 'node:fs/promises';
import path from 'node:path';
import {PresentationFile,FileBlob} from '@oai/artifact-tool';
const B='G:/毕设/02_learning/04_review/.build_locoformer_flow_20261102';
const p=await PresentationFile.importPptx(await FileBlob.load(path.join(B,'validated/locoformer_paper_report.pptx')));
await fs.mkdir(path.join(B,'final-preview'),{recursive:true});
const matches=[];
for(let i=0;i<p.slides.items.length;i++){
 const blob=await p.export({slide:p.slides.items[i],format:'png',scale:1});
 const bytes=Buffer.from(await blob.arrayBuffer());
 const name=`slide-${String(i+1).padStart(2,'0')}.png`;
 await fs.writeFile(path.join(B,'final-preview',name),bytes);
 matches.push({slide:i+1,identical:bytes.equals(await fs.readFile(path.join(B,'preview',name)))});
}
const content=await p.inspect({select:'$.slides[*]',include:['index','title','elements.kind','elements.text','notes.text']});
await fs.writeFile(path.join(B,'final-content.ndjson'),content.ndjson);
const order=JSON.parse(await fs.readFile(path.join(B,'speech-order.json'),'utf8'));
if(content.records.length!==14)throw new Error('Incorrect slide count');
for(let i=0;i<14;i++)if(content.records[i].title!==order[i].title)throw new Error('Slide-title mismatch at '+(i+1));
if(order.slice(0,12).reduce((a,b)=>a+b.seconds,0)!==600)throw new Error('Unexpected planned timing');
await fs.writeFile(path.join(B,'visual-verification.json'),JSON.stringify({matches,mainSeconds:600},null,2));
console.log(JSON.stringify({slides:14,matches,mainSeconds:600}));
