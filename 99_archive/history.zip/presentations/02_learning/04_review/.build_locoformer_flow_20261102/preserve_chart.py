"""Preserve the current source chart and its real embedded workbook after export."""
from pathlib import Path, PurePosixPath
from zipfile import ZipFile, ZIP_DEFLATED
from lxml import etree as E
import posixpath,json,hashlib,io

B=Path(__file__).parent
NS={'c':'http://schemas.openxmlformats.org/drawingml/2006/chart',
    'r':'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}
REL='http://schemas.openxmlformats.org/package/2006/relationships'
CT='http://schemas.openxmlformats.org/package/2006/content-types'

def relpart(part):
    p=PurePosixPath(part)
    return str(p.parent/'_rels'/(p.name+'.rels'))

def resolve(part,target):return posixpath.normpath(posixpath.join(posixpath.dirname(part),target)).lstrip('/')

def owner_chart(z):
    slide='ppt/slides/slide9.xml'
    root=E.fromstring(z.read(slide))
    ids=root.xpath('//c:chart/@r:id',namespaces=NS)
    assert len(ids)==1
    relationships=E.fromstring(z.read(relpart(slide)))
    hits=[r for r in relationships if r.get('Id')==ids[0]]
    assert len(hits)==1
    return resolve(slide,hits[0].get('Target'))

with ZipFile(B/'source.pptx') as src,ZipFile(B/'candidate.pptx') as draft:
    source_chart,target_chart=owner_chart(src),owner_chart(draft)
    a,b=E.fromstring(src.read(source_chart)),E.fromstring(draft.read(target_chart))
    for xpath in ['.//c:cat//c:pt/c:v/text()','.//c:val//c:pt/c:v/text()','.//c:f/text()']:
        assert a.xpath(xpath,namespaces=NS)==b.xpath(xpath,namespaces=NS),xpath
    assert a.find('c:externalData',NS) is not None
    parts={n:draft.read(n) for n in draft.namelist()}
    copied={}

    def copy_graph(old,new):
        if old in copied:return
        copied[old]=new
        if new in parts and old!=source_chart:
            assert parts[new]==src.read(old),f'Unexpected part collision: {new}'
        parts[new]=src.read(old)
        rp=relpart(old)
        if rp not in src.namelist():return
        relationships=E.fromstring(src.read(rp))
        for rel in relationships:
            if rel.get('TargetMode')=='External':continue
            child=resolve(old,rel.get('Target'))
            newchild=target_chart if child==source_chart else child
            copy_graph(child,newchild)
            rel.set('Target',posixpath.relpath(newchild,posixpath.dirname(new)))
        parts[relpart(new)]=E.tostring(relationships,encoding='UTF-8',xml_declaration=True)

    copy_graph(source_chart,target_chart)
    # The current PowerPoint-saved source encoded its literal series name as
    # a formula. Restore the equivalent internal reference to the existing B1
    # cell, after checking both strings, without rebuilding the workbook.
    normalized=E.fromstring(parts[target_chart])
    title_f=normalized.find('.//c:ser/c:tx/c:strRef/c:f',NS)
    formula_repair=None
    if title_f is not None and title_f.text=='平均归一化位移':
        workbook=next(n for n in copied if n.endswith('.xlsx'))
        with ZipFile(io.BytesIO(src.read(workbook))) as w:
            sheet=E.fromstring(w.read('xl/worksheets/sheet1.xml'))
            xns={'x':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
            header=sheet.xpath("string(//x:c[@r='B1']/x:is/x:t)",namespaces=xns)
        assert header==title_f.text
        formula_repair={'old':title_f.text,'new':"'Chart Data'!$B$1",'existing_workbook_cell':header}
        title_f.text=formula_repair['new']
        parts[target_chart]=E.tostring(normalized,encoding='UTF-8',xml_declaration=True)
    ct=E.fromstring(parts['[Content_Types].xml'])
    source_ct=E.fromstring(src.read('[Content_Types].xml'))
    for old,new in copied.items():
        ext=PurePosixPath(old).suffix.lstrip('.')
        for entry in source_ct:
            tag=E.QName(entry).localname
            if tag=='Default' and entry.get('Extension')==ext:
                if not any(E.QName(t).localname=='Default' and t.get('Extension')==ext for t in ct):
                    ct.append(E.fromstring(E.tostring(entry)))
            elif tag=='Override' and entry.get('PartName')=='/'+old:
                if not any(E.QName(t).localname=='Override' and t.get('PartName')=='/'+new for t in ct):
                    clone=E.fromstring(E.tostring(entry));clone.set('PartName','/'+new);ct.append(clone)
    parts['[Content_Types].xml']=E.tostring(ct,encoding='UTF-8',xml_declaration=True)
    out=B/'candidate_repaired.pptx'
    with ZipFile(out,'w',ZIP_DEFLATED) as z:
        for n,data in parts.items():z.writestr(n,data)
    with ZipFile(out) as repaired:
        for old,new in copied.items():
            if old==source_chart and formula_repair:
                check=E.fromstring(repaired.read(new))
                check.find('.//c:ser/c:tx/c:strRef/c:f',NS).text=formula_repair['old']
                assert E.tostring(check,method='c14n')==E.tostring(a,method='c14n')
            else:assert src.read(old)==repaired.read(new)

report={'source_chart':source_chart,'target_chart':target_chart,'preserved_source_graph':copied,'series_formula_repair':formula_repair,'source_workbook_bytes_unchanged':True,'sha256':hashlib.sha256(out.read_bytes()).hexdigest()}
(B/'chart-preservation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=True))
