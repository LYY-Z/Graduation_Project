import path from 'node:path';
import {finalizePresentation} from 'file:///C:/Users/laiyo/.codex/plugins/cache/openai-primary-runtime/presentations/26.1119.11507/skills/presentations/container_tools/artifact_tool_utils.mjs';
const workspaceDir='G:/毕设/02_learning/04_review';
const skillDir='C:/Users/laiyo/.codex/plugins/cache/openai-primary-runtime/presentations/26.1119.11507/skills/presentations';
const result=await finalizePresentation({
 workspaceDir,
 candidatePath:path.join(workspaceDir,'.build_tam/motion_control_review.EN.candidate.pptx'),
 finalPath:path.join(workspaceDir,'deliverables/motion_control/motion_control_review.EN.v3.pptx'),
 pythonExecutable:'C:/Users/laiyo/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe',
 integrityValidatorPath:path.join(skillDir,'container_tools/inspect_presentation_package_integrity.py'),
 layoutValidatorPath:path.join(skillDir,'container_tools/inspect_presentation_layout_geometry.py'),
 explicitTotalSlideCount:13,
 requiredNativeTableOwnerSlides:[6,7,8,9,10,11,12,13],
 layoutArgs:['--expected-slide-size-emu','12192000,6858000','--validate-bullet-geometry','--validate-heading-fit',...[6,7,8,9,10,11,12,13].flatMap(n=>['--require-native-table-slide',String(n)])],
 fontPolicy:{basis:'design',families:['Arial']},
 verifyArtifactToolImport:true,
 receiptPath:path.join(workspaceDir,'.build_tam/motion_control_review.EN.v3.validation.json')
});
console.log(JSON.stringify(result));
