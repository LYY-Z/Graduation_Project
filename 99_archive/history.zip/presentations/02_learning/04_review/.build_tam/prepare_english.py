import json
import re
from pathlib import Path

root = Path(__file__).parent
translations = json.loads((root / 'translation.EN.json').read_text(encoding='utf-8'))
literal = re.compile(r"'((?:\\.|[^'\\])*)'")

def translate_literal(match):
    raw = match.group(1)
    value = raw.replace(r'\n', '\n').replace(r"\'", "'")
    if value not in translations:
        return match.group(0)
    return json.dumps(translations[value], ensure_ascii=False)

for source, target, appendix in [
    ('visual_screening.mjs', 'visual_screening.EN.mjs', False),
    ('appendix_audit.mjs', 'appendix_audit.EN.mjs', True),
]:
    text = (root / source).read_text(encoding='utf-8')
    text = literal.sub(translate_literal, text)
    text = text.replace("'Microsoft YaHei'", "'Arial'")
    text = text.replace('论文原图：', 'Original paper figure: ')
    text = text.replace('path:`${ROOT}/${name}.png`', 'blob:readFileSync(`${ROOT}/${name}.png`),contentType:"image/png"')
    text = text.replace('w-28,35,20,true', 'w-28,35,18,true')
    text = text.replace('y+25,w-28,35,18,true', 'y+18,w-28,58,18,true')
    text = text.replace('[245,285,130,504]', '[245,275,175,469]')
    text = text.replace('1164,63,31,true', '1164,63,29,true')
    text = text.replace('1164,63,30,true', '1164,63,28,true')
    text = text.replace('875,224,337,38,21,true', '875,220,337,62,20,true')
    text = text.replace('875,282,337,119,20', '875,298,337,119,19')
    text = text.replace('691,387,515,86,20', '691,387,515,105,19')
    text = text.replace('889,545,327,70,18', '889,530,327,100,18')
    text = text.replace('60,624,730,25,17', '60,624,1150,25,17')
    text = text.replace('60,654,1120,49,17', '60,654,1120,60,17')
    text = text.replace('60,654,1110,49,17', '60,654,1110,60,17')
    text = text.replace('60,642,1110,55,18', '60,642,1110,65,17')
    text = text.replace('60,657,1120,37,21', '60,657,1120,37,20')
    text = text.replace('60,666,1110,31,19', '60,666,1110,31,18')
    text = text.replace('842,224,370,35,21', '842,224,370,55,20')
    text = text.replace('60,611,740,35,18', '60,611,760,35,17')
    text = text.replace('60,536,735,37,19', '60,536,735,37,18')
    text = text.replace("insets:15,verticalAlignment", "insets:12,verticalAlignment")
    text = text.replace("insets:12,verticalAlignment", "insets:10,verticalAlignment")
    if appendix:
        text = text.replace("insets:10,verticalAlignment", "insets:{top:1,bottom:1,left:10,right:10},verticalAlignment")
        text = text.replace("bold:r===0||c===0,color:", "bold:r===0||c===0,lineSpacing:1.0,color:")
        text = text.replace("t.borders.assign({fill:'#FFFFFF',width:2,style:'solid'});", "t.borders.assign({fill:'#FFFFFF',width:2,style:'solid'});t.cells.block({row:0,column:0,rowCount:v.length,columnCount:widths.length}).assign({margins:{top:1,bottom:1,left:10,right:10}});")
    # Keep slide content in a separate deck; preserve source links in its notes.
    text = 'import {readFileSync} from "node:fs";\nimport {SPEECH} from "./speech.EN.mjs";\nlet noteIndex=0;\n' + text
    text = re.sub(r'function notes\(s,t,links\)\{[^\n]*\}',
        "function notes(s,t,links){s.speakerNotes.text=SPEECH[noteIndex++]+String.fromCharCode(10,10)+'References:'+String.fromCharCode(10)+links.replace(/：/g,': ');}", text)
    if appendix:
        text = text.replace('for(let i=input.start;i<input.end;i++){', 'noteIndex=7+input.start;\nfor(let i=input.start;i<input.end;i++){', 1)
    else:
        text = text.replace('if(input.start===0)p.slides.delete', 'noteIndex=input.start;\n if(input.start===0)p.slides.delete', 1)
    (root / target).write_text(text, encoding='utf-8')
print('Prepared English builders from the source layouts.')
