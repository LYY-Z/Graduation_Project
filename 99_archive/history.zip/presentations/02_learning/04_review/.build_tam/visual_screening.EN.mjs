import {readFileSync} from "node:fs";
import {SPEECH} from "./speech.EN.mjs";
let noteIndex=0;
const ROOT='G:/毕设/02_learning/04_review/.build_tam';
const C={blue:'#195FC0',ink:'#142D50',muted:'#526780',line:'#CCD9E9',pale:'#EDF4FC'};
const S={tam:'https://arxiv.org/html/2606.06218v3',gram:'https://www.merl.com/publications/docs/TR2026-057.pdf',sadl:'https://arxiv.org/html/2505.19574v3'};
function tx(s,t,x,y,w,h,z=20,b=false,c=C.ink){const a=s.shapes.add({geometry:'textbox',position:{left:x,top:y,width:w,height:h},fill:'none',line:{fill:'none',width:0}});a.text=t;a.text.style={fontSize:`${z}pt`,fontFamily:'Arial',bold:b,color:c,insets:0};return a;}
function head(p,n,label,title,sub){const s=p.slides.add({width:1280,height:720});s.background.fill='#FFFFFF';tx(s,label,58,22,1140,25,12,true,C.blue);tx(s,title,58,64,1164,63,29,true);tx(s,sub,60,137,1156,36,18,false,C.muted);s.shapes.add({geometry:'rect',position:{left:58,top:184,width:1164,height:2},fill:C.line,line:{fill:'none',width:0}});tx(s,`${n} / 7`,1154,687,68,22,11,false,C.muted);return s;}
function img(s,name,x,y,w,h){s.images.add({blob:readFileSync(`${ROOT}/${name}.png`),contentType:"image/png",alt:`Original paper figure: ${name}`,fit:'contain',position:{left:x,top:y,width:w,height:h}});}
function notes(s,t,links){s.speakerNotes.text=SPEECH[noteIndex++]+String.fromCharCode(10,10)+'References:'+String.fromCharCode(10)+links.replace(/：/g,': ');}
function flow(s,labels,y,w=252,gap=52,h=88){const nodes=[];labels.forEach((v,i)=>{const x=58+i*(w+gap);const a=s.shapes.add({geometry:'rect',position:{left:x,top:y,width:w,height:h},fill:C.pale,line:{fill:C.line,width:1}});tx(s,v,x+14,y+18,w-28,58,18,true);if(i)s.shapes.connect(nodes[i-1],a,{kind:'straight',fromSide:'right',toSide:'left',line:{fill:C.blue,width:2.5},tail:{type:'triangle',width:'med',length:'med'}});nodes.push(a);});}
function table(s,v,y,widths,heights,font=19){const t=s.tables.add({rows:v.length,columns:widths.length,left:58,top:y,width:1164,height:heights.reduce((a,b)=>a+b,0),columnWidths:widths,values:v});t.borders.assign({fill:'#FFFFFF',width:2,style:'solid'});v.forEach((_,r)=>{t.rows[r].height=heights[r];widths.forEach((_,c)=>{const a=t.getCell(r,c);a.fill=r===0?C.blue:r%2?C.pale:'#F5F7FA';a.text.style={fontSize:`${r===0?18:font}pt`,fontFamily:'Arial',bold:r===0||c===0,color:r===0?'#FFFFFF':C.ink,insets:10,verticalAlignment:'middle'};});});return t;}
export async function build({presentation:p,input}){
 noteIndex=input.start;
 if(input.start===0)p.slides.delete(p.slides.items.map((_,i)=>i));
 for(let i=input.start;i<input.end;i++){
  if(i===0){const s=head(p,1,'TAM  ·  CoRL 2026 Spotlight  ·  KAIST / Ai2 / UW / Toronto',"TAM: Torque-level dynamics adaptation","Problem: Payload and friction changes cause motion to deviate from the policy’s intended response.");
   img(s,'fig1',58,230,770,270);
   tx(s,"History encoding → residual torque",875,220,337,62,20,true,C.blue);
   tx(s,"Transformer encodes history\nMLP torque adaptor\nSupervised training\nin simulation",875,298,337,119,19);
   tx(s,"Reference model defines\nthe intended response",875,440,337,69,19,false,C.muted);
   tx(s,"Input: Joint states, torque history and nominal controller torque\nOutput: Per-joint residual torques",60,550,1150,70,21);
   tx(s,"Contribution: Reuse RL, BC and MPC policies through torque-level adaptation.",60,642,1135,39,22,true,C.blue);
   notes(s,'TAM 将适应放在低层控制器之后。按原图从左向右，上层策略产生动作，控制器将动作转换为原始力矩，TAM 再根据执行历史和参考模型预测残差力矩。它主要通过仿真监督学习训练，历史编码器采用 Transformer，快速适配器采用 MLP。上层策略可以来自强化学习、行为克隆或 MPC，其核心价值是降低适应模块与具体任务的绑定。下面看作者如何验证这种复用。',S.tam+'\nhttps://github.com/Dongwon-Son/TAM');
  }
  if(i===1){const s=head(p,2,"TAM  ·  EXPERIMENTAL EVIDENCE","TAM: Policy reuse and adaptation to sudden changes","Hardware tests policy reuse. Simulation tests cross-robot transfer and sudden dynamics changes.");
   img(s,'fig3',58,228,730,288);img(s,'fig4',834,227,380,237);
   tx(s,"Four Panda tasks: Pushing, flipping, balancing and tracking",60,536,735,37,18,true);
   tx(s,"Pushing success: 47.6% → 76.2%",60,580,730,37,23,true,C.blue);
   tx(s,"Recovery in simulation\nOriginal: 4.6 s; DAgger: 1.7 s",835,493,380,91,20,true,C.blue);
   tx(s,"Hardware baselines: Direct and Online SysID. RMA is evaluated only for pushing.",60,624,1150,25,17);
   tx(s,"Reproduction: Official training, checkpoints and example evaluations. Hardware interfaces require extension.\nLimits: Reference-model dependence, contact coverage and actuator capacity.",60,654,1120,60,17);
   notes(s,'左图来自原文 Figure 3，上排为直接执行，下排为加入 TAM，四列是 RL 推箱、BC 翻块、MPC 球盘平衡和负载跟踪。推箱成功率从 47.6% 提高到 76.2%，Online SysID 为 57.1%。右图是 Figure 4，在二十条仿真轨迹中途切换动力学参数，原版恢复约四点六秒，两个 DAgger 变体约一点七秒；采用原版 TAM 稳态误差作为共同恢复参考，包含轨迹追赶，不能当作通用故障恢复时间。官方代码有仿真训练和评估，机器人侧控制桥接仍需拓展。复杂接触、训练外变化和执行器能力不足仍限制补偿。平台迁移在最后统一比较。',S.tam+'\nhttps://github.com/Dongwon-Son/TAM/blob/main/docs/deployment.md');
  }
  if(i===2){const s=head(p,3,'GRAM  ·  RA-L 2026  ·  MERL / MIT',"GRAM: Adaptation guided by confidence","Problem: History inference may fail out of distribution, while robust control can be conservative.");
   flow(s,["State–action history","Context & uncertainty","Unified policy","Joint position targets"],211);
   img(s,'gram_fig2',58,333,570,323);
   tx(s,"Training",691,338,515,35,22,true,C.blue);
   tx(s,"PPO trains the policy.\nTeacher–student learning estimates context.\nAdversarial training develops robust behavior.",691,387,515,105,19);
   tx(s,"Input and output",691,501,515,35,22,true,C.blue);
   tx(s,"Joint/base states, commands and history\n→ 12 joint position targets for Go2",691,551,515,80,20);
   notes(s,'上方流程是对论文方法的概括，左下是原文 Figure 2。历史网络估计当前条件，Epinet 评估估计分歧；不确定性高时，条件表示偏向训练好的鲁棒表示。这是同一个策略的内部调整，不是根据真实故障标签切换独立控制器。PPO 训练策略，教师—学生学习让历史估计对应仿真已知条件，对抗训练学习困难条件下的行为。部署时网络参数固定。输出是普通 Go2 的十二关节位置目标，随后由 PD 控制器执行。下面用实验检查这种设计的效果。',S.gram+'\nhttps://github.com/merlresearch/gram');
  }
  if(i===3){const s=head(p,4,"GRAM  ·  EXPERIMENTAL EVIDENCE","GRAM: Success under challenging hardware conditions","Simulation tests generalization and ablations. Hardware covers controlled and outdoor scenarios.");
   img(s,'gram_fig6',58,223,730,368);
   tx(s,"Successes in difficult scenarios",842,224,370,55,20,true,C.blue);
   tx(s,'GRAM',843,291,210,37,23,true);tx(s,'15 / 15',1080,291,140,40,25,true,C.blue);
   tx(s,"Robust RL",843,370,210,37,23);tx(s,'12 / 15',1080,370,140,40,25);
   tx(s,"Contextual RL",843,449,222,37,23);tx(s,'2 / 15',1080,449,140,40,25);
   tx(s,"3 scenarios × 5 trials per scenario",843,531,375,35,17,false,C.muted);
   tx(s,"Top to bottom: 9 kg payload, slippery surface, ramp to foam",60,611,760,35,17);
   tx(s,"Reproduction: Official Go2 training, evaluation and baseline code are available.\nLimits: Extreme OOD conditions may still cause failure. Wheeled-legged robots and arms are untested.",60,654,1110,60,17);
   notes(s,'左图为原文 Figure 6，三类困难任务分别是九公斤负载、湿滑表面和坡道进入泡沫。右侧数值来自 Table V，各类任务每种方法五次，因此每种方法共十五次。GRAM 成功十五次，鲁棒 RL 十二次，上下文 RL 两次。论文还测试正常、后髋冻结、上下坡等四类中等难度任务，总计七类受控场景，三方法、每类五次，共一百零五次；此外有户外定性验证。十五次成功不代表任意故障下百分之百保证。原文仍以普通 Go2 为平台，运行中恢复的时间与累计误差还需要更系统的实验。',S.gram+'\nhttps://github.com/merlresearch/gram');
  }
  if(i===4){const s=head(p,5,'SADL  ·  IJRR 2026  ·  Indiana University Bloomington',"SADL: Situation-aware dynamics and planning","Problem: Hidden terrain or dynamics conditions cause different responses to the same command.");
   img(s,'sadl_fig2',58,221,790,382);img(s,'sadl_fig4',900,223,310,195);
   tx(s,"Ground-vehicle navigation\nQuadrotor wind simulation",889,448,327,71,19,true);
   tx(s,"Change detection +\nconditioned dynamics\nMPPI planning",889,530,327,100,18,false,C.muted);
   tx(s,"Input: State transitions and goals. Output: Planned actions. Official QuadX training/evaluation example.\nLimit: Situation library is fixed at test time. Full vehicle reproduction package is not confirmed.",60,642,1110,65,17);
   notes(s,'左图是论文 Figure 2，右图是实际 Jackal 平台 Figure 4。方法从状态转移中识别隐藏工况，将工况表示加入动力学模型，再由 MPPI 规划动作，属于模型驱动适应路线。原文包含地面车辆仿真与实机导航、四旋翼风扰动仿真。最新版第 4.1.1 节明确区分训练和测试：训练阶段发现工况并建立模型；测试阶段工况库固定，通过匹配已有工况进行适应，不再创建新工况。因此不能把它描述为部署时无限学习任意新故障。向 Go2-W 和 UR7e 迁移时，都需要拓展机器人响应模型与控制接口，控制层级还会影响规划开销。',S.sadl+'\nhttps://github.com/AlejandroMllo/situationally_aware_dynamics_learning');
  }
  if(i===5){const s=head(p,6,"ADDITIONAL REFERENCES","Additional references: Venues and research roles","Retain relevant baselines and use other papers to inform alternative approaches.");
   table(s,[["Paper","Venue","Research focus","Role in our study"],['ESCP','AAAI 2022',"Short-history representations\nfor sudden environment changes","Adaptation baseline"],['RMA²','CVPR 2024',"Visual and history-based\nadaptation for manipulation","Manipulation reference"],['UARL','RA-L 2026',"Uncertainty-aware\nresidual learning","Residual-policy reference"],['RecoveryChaining','IROS 2025',"Recovery from failure states\nto task continuation","Task-recovery reference"]],230,[245,205,465,249],[48,85,85,85,85],18);
   tx(s,"Assess venue reputation and relevance to our research separately.",60,657,1120,37,20,true,C.blue);
   notes(s,'其余四篇的作用不同。ESCP 用短历史推断环境，直接研究突变适应，可作为对照。RMA² 处理机械臂操作中的视觉与历史适应。UARL 研究有基础策略时如何更高效学习残差。RecoveryChaining 学习任务失败后的局部恢复，再接回原控制器；它的任务状态恢复并不直接等于未知执行器动力学适应。保留这些文献用于背景、对照和查重，不同时开展全部复现。','ESCP：https://github.com/FanmingL/ESCP\nRMA²：https://www.robots.ox.ac.uk/~vgg/publications/2024/Liang24/\nUARL：https://lakshitadodeja.github.io/uncertainty-aware-residual-rl/\nRecoveryChaining：https://www.merl.com/publications/TR2025-152');
  }
  if(i===6){const s=head(p,7,"SELECTION AND NEXT STEPS","Selection: Reproduction scope and transfer effort","Distinguish reproducing the core simulation method from reproducing every experiment.");
   table(s,[["Method","Public reproduction basis","Go2-W extension","UR7e extension"],['GRAM',"Go2 training,\nadaptation and evaluation","Extend leg–wheel actions\nand retrain","Define manipulation tasks\nand retrain the policy"],['TAM',"Training, checkpoints\nand example evaluations","Extend wheel–leg dynamics\nand training","Robot model and\ntorque interface"],['SADL',"Core models and\nQuadX training/evaluation","Response model\nand planning","Response model\nand planning"]],225,[155,345,332,332],[46,89,89,89],18);
   flow(s,["Reproduce original tasks","Extend to platforms","Evaluate sudden changes"],567,340,72,80);
   tx(s,"Prioritize GRAM validation. Retain TAM and SADL as alternatives at other control levels.",60,666,1110,31,18,true,C.blue);
   notes(s,'选型主要看公开原任务是否能复现，以及输入输出如何拓展到两个平台。GRAM 与轮足运动更接近，优先验证原生 Go2 训练，Go2-W 的迁移相对较轻，UR7e 需要重建任务。TAM 对机械臂迁移较接近，但轮足动力学扩展较大。SADL 的成本取决于建模和规划层级。以上为相对迁移评估，不是已完成实验。后续按原任务复现、平台拓展、突变恢复评估推进，不同时建设三套系统。创新研究需要围绕具体失败机制，而不是直接将平台迁移或已有模块组合认定为贡献。',S.gram+'\n'+S.tam+'\n'+S.sadl);
  }
 }
 return {slides:p.slides.items.length,range:[input.start,input.end]};
}
