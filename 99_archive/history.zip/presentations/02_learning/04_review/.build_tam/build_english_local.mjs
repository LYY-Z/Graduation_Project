import fs from 'node:fs/promises';
import path from 'node:path';
import {Presentation, PresentationFile} from 'file:///C:/Users/laiyo/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/@oai/artifact-tool/dist/artifact_tool.mjs';
import {build} from './visual_screening.EN.mjs';
import {append} from './appendix_audit.EN.mjs';
import {SPEECH} from './speech.EN.mjs';

const root='G:/毕设/02_learning/04_review/.build_tam';
const output='G:/毕设/02_learning/04_review/deliverables/motion_control';
const renders=path.join(root,'english_render');
await fs.mkdir(renders,{recursive:true});
await fs.mkdir(output,{recursive:true});
const presentation=Presentation.create({slideSize:{width:1280,height:720}});
await build({presentation,input:{start:0,end:7}});
await append({presentation,input:{start:0,end:6}});
if(presentation.slides.items.length!==13)throw new Error('Expected 13 slides');
const candidate=path.join(root,'motion_control_review.EN.candidate.pptx');
await (await PresentationFile.exportPptx(presentation)).save(candidate);
await fs.writeFile(path.join(root,'english_model.json'),JSON.stringify(presentation.toProto()));
for(let i=0;i<13;i++){
 const png=await presentation.export({slide:presentation.slides.items[i],format:'png',scale:1});
 await fs.writeFile(path.join(renders,`slide-${i+1}.png`),new Uint8Array(await png.arrayBuffer()));
 console.log(`Rendered ${i+1}/13`);
}
await fs.writeFile(path.join(output,'speech.EN.md'),'# Adaptive Robot Motion Control Literature Review\n\nPresenter notes for seven main slides and six appendices. Bracketed text gives pointing cues and is not read aloud.\n\n'+SPEECH.map((text,i)=>'## '+(i<7?`Slide ${i+1}`:`Appendix A${i-7}`)+'\n\n'+text).join('\n\n')+'\n');
console.log(JSON.stringify({candidate,renders,slides:13}));
