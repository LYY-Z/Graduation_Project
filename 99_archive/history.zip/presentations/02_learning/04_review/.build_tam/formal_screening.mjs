const ROOT='G:/毕设/02_learning/04_review/.build_tam';
const C={blue:'#195FC0',ink:'#142D50',muted:'#526780',line:'#CCD9E9',pale:'#EDF4FC'};
const SOURCES={tam:'https://arxiv.org/html/2606.06218v3',gram:'https://www.merl.com/publications/docs/TR2026-057.pdf',sadl:'https://arxiv.org/html/2505.19574v2'};
function text(s,value,x,y,w,h,size=21,bold=false,color=C.ink){const a=s.shapes.add({geometry:'textbox',position:{left:x,top:y,width:w,height:h},fill:'none',line:{fill:'none',width:0}});a.text=value;a.text.style={fontSize:`${size}pt`,fontFamily:'Microsoft YaHei',bold,color,insets:0};return a;}
function rule(s,y){s.shapes.add({geometry:'rect',position:{left:58,top:y,width:1164,height:2},fill:C.line,line:{fill:'none',width:0}});}
function page(p,i,label,title,sub){const s=p.slides.add({width:1280,height:720});s.background.fill='#FFFFFF';text(s,label,58,28,1130,25,12,true,C.blue);text(s,title,58,75,1164,66,31,true);text(s,sub,60,155,1155,47,19,false,C.muted);rule(s,210);text(s,`${i} / 7`,1152,687,70,22,11,false,C.muted);return s;}
function table(s,values,y,widths,heights,size=20){const t=s.tables.add({rows:values.length,columns:widths.length,left:58,top:y,width:1164,height:heights.reduce((a,b)=>a+b,0),columnWidths:widths,values});t.borders.assign({style:'solid',fill:'#FFFFFF',width:2});for(let r=0;r<values.length;r++){t.rows[r].height=heights[r];for(let c=0;c<widths.length;c++){const a=t.getCell(r,c);a.fill=r===0?C.blue:r%2?C.pale:'#F5F7FA';a.text.style={fontSize:`${r===0?18:size}pt`,fontFamily:'Microsoft YaHei',bold:r===0||c===0,color:r===0?'#FFFFFF':C.ink,insets:15,verticalAlignment:'middle'};}}return t;}
function flow(s,labels,y){const nodes=[];labels.forEach((v,i)=>{const x=58+i*304;const a=s.shapes.add({geometry:'rect',position:{left:x,top:y,width:252,height:110},fill:C.pale,line:{fill:C.line,width:1}});text(s,v[0],x+16,y+18,220,37,21,true);text(s,v[1],x+16,y+65,220,30,17,false,C.muted);if(i)s.shapes.connect(nodes[i-1],a,{kind:'straight',fromSide:'right',toSide:'left',line:{fill:C.blue,width:2.5},tail:{type:'triangle',width:'med',length:'med'}});nodes.push(a);});}
function notes(s,value,links){s.speakerNotes.text=value+'\n\n参考资料：\n'+links;}
export async function build({presentation:p,input}){
 if(input.start===0)p.slides.delete(p.slides.items.map((_,i)=>i));
 for(let i=input.start;i<input.end;i++){
  if(i===0){const s=page(p,1,'TAM  ·  CoRL 2026','TAM：基于力矩补偿的运动迁移','研究问题：动力学变化导致既有策略的运动执行偏差。');
   s.images.add({path:ROOT+'/fig1.png',alt:'TAM 原论文 Figure 1：力矩适配模块的部署位置',fit:'contain',position:{left:58,top:235,width:741,height:259}});
   text(s,'方法',842,240,360,36,23,true,C.blue);
   text(s,'编码关节执行历史，\n预测残差力矩，\n补偿运动响应偏差。',842,294,360,123,21);
   text(s,'Transformer 历史编码\nMLP 残差预测 · 仿真监督训练',842,442,360,65,17,false,C.muted);
   text(s,'输入：关节状态与力矩历史、原控制器力矩\n输出：各关节的残差力矩',60,526,1150,70,21);
   text(s,'贡献：在力矩层适配动力学差异，复用不同上层策略。',60,605,1150,36,22,true,C.blue);
   text(s,'实验：Panda 操作与跟踪，跨机械臂及动力学突变仿真。\n推箱成功率：直接执行 47.6%，TAM 76.2%。',60,653,1100,49,17);
   notes(s,'TAM 针对动力学变化造成的执行偏差，在原控制器之后加入力矩补偿。Transformer 从关节执行历史中提取条件，MLP 预测各关节的残差力矩。训练采用仿真监督学习，上层强化学习、行为克隆或 MPC 策略可以保留。论文在 Panda 上验证推箱、翻块、球盘平衡与跟踪，另有跨机械臂和动力学突变仿真。推箱成功率由直接执行的 47.6% 提高至 76.2%；这是原文结果。',SOURCES.tam+'\nhttps://github.com/Dongwon-Son/TAM');
  }
  if(i===1){const s=page(p,2,'TAM  ·  复现与迁移','TAM：复现基础与平台拓展','官方代码覆盖仿真训练与评估，实机部署需拓展控制接口。');
   table(s,[['平台','迁移工作','相对难度'],['UR7e','拓展机械臂模型与力矩控制接口','中等'],['Go2-W','拓展轮足动力学、腿轮控制与训练任务','较高']],250,[180,760,224],[48,121,121]);
   text(s,'局限',60,580,250,37,23,true,C.blue);
   text(s,'依赖参考模型与力矩接口；复杂接触可能影响补偿效果。\n恢复能力受执行器剩余控制能力限制。',60,634,1150,65,21);
   notes(s,'TAM 提供数据生成、训练、微调和仿真评测代码，但机器人侧实机控制桥接仍需拓展。UR7e 属于机械臂内迁移，主要拓展模型和力矩控制接口。Go2-W 涉及浮动基座、轮地接触与腿轮执行器，需要扩展方法并训练。表中的相对难度是本项目评估，不是作者结论。其局限是依赖参考模型及力矩控制；未知接触与动力学差异可能混淆估计。论文的条件性误差有界分析不等于任意故障下的稳定、安全或任务保证。',SOURCES.tam+'\nhttps://github.com/Dongwon-Son/TAM/blob/main/docs/deployment.md');
  }
  if(i===2){const s=page(p,3,'GRAM  ·  RA-L 2026','GRAM：融合历史适应与鲁棒控制','研究问题：兼顾训练范围内的适应性能与范围外的鲁棒性。');
   flow(s,[['交互历史','观测与动作'],['条件估计','不确定性评估'],['策略调整','适应与鲁棒融合'],['关节目标','PD 控制']],250);
   text(s,'训练方法',60,402,280,36,22,true,C.blue);
   text(s,'PPO 策略训练 · 教师—学生适应学习 · 不确定性估计 · 对抗训练',60,453,1150,55,20);
   text(s,'输入：关节与机身状态、运动指令及近期历史\n输出：12 维关节位置目标',60,537,1150,68,21);
   text(s,'实验：泛化对比与消融；Go2 实机 7 类场景、105 次受控测试。\n困难场景成功次数：GRAM 15/15，鲁棒 RL 12/15，上下文 RL 2/15。',60,640,1110,58,18);
   notes(s,'GRAM 的贡献是通过不确定性估计，在同一个策略中融合适应和鲁棒控制。近期历史用于推断当前条件，估计不确定时更偏向已训练的鲁棒表示。PPO 训练动作策略，教师—学生学习历史适应，对抗训练提供鲁棒行为。部署时网络权重固定。原文使用普通 Go2，输出十二个关节位置目标。实验包括仿真泛化、训练分布与消融，以及七类受控实机场景和户外测试。三种困难场景分别为九公斤负载、湿滑表面和坡道进入泡沫。',SOURCES.gram+'\nhttps://github.com/merlresearch/gram');
  }
  if(i===3){const s=page(p,4,'GRAM  ·  复现与迁移','GRAM：复现基础与平台拓展','官方提供 Go2 环境、策略训练及主要基线评估。');
   table(s,[['平台','迁移工作','相对难度'],['Go2-W','拓展轮足观测、腿轮动作与训练任务','中等'],['UR7e','拓展机械臂环境、控制动作与对抗训练','较高']],250,[180,760,224],[48,121,121]);
   text(s,'局限',60,580,250,37,23,true,C.blue);
   text(s,'鲁棒性仍受训练覆盖限制，不确定性不能直接识别故障。\n原文未验证轮足与机械臂，跨平台恢复能力仍需实验评估。',60,634,1150,65,21);
   notes(s,'GRAM 有原任务训练、评估和多种对照实现，可以作为策略适应路线的候选。Go2-W 主要拓展轮足观测、腿位置与轮速度动作，以及训练任务；UR7e 需要机械臂环境、动作和对抗训练。两个平台分别训练，不直接复用 Go2 权重。原文承认极端分布外条件仍可能失败，不确定性也不等于故障类型识别。论文主要检验泛化表现；面向恢复研究，还需要评价扰动后的累计误差和恢复时间。',SOURCES.gram+'\nhttps://github.com/merlresearch/gram');
  }
  if(i===4){const s=page(p,5,'SADL  ·  IJRR 2026','SADL：基于在线动力学学习的适应控制','研究问题：识别工况变化，降低模型失配对运动规划的影响。');
   flow(s,[['交互数据','状态转移'],['变化检测','工况识别'],['动力学更新','响应预测'],['MPPI 规划','控制动作']],250);
   text(s,'输入：状态转移数据与任务目标；输出：动力学预测与规划动作。',60,404,1150,58,20);
   text(s,'实验与公开实现',60,497,540,36,22,true,C.blue);
   text(s,'地面车辆仿真与实机导航；\n四旋翼风扰动仿真。\n公开模型、训练与示例代码。',60,549,540,109,20);
   text(s,'迁移与局限',668,497,540,36,22,true,C.blue);
   text(s,'拓展机器人模型与规划接口。\n高维规划与接触预测仍需评估；\n公开示例尚未覆盖目标平台。',668,549,540,109,20);
   notes(s,'SADL 将工况变化检测、条件动力学模型与 MPPI 规划连接起来。其技术包括在线概率建模、贝叶斯变化检测和采样式预测规划。论文通过地面车辆导航与四旋翼风扰动评估模型适应，官方提供模型、训练和示例。用于 Go2-W 与 UR7e 时，需要分别拓展机器人模型与规划接口。控制层级影响实现难度：高维关节级规划计算量更大，接触预测也需要验证，因此将其保留为在线模型路线。',SOURCES.sadl+'\nhttps://github.com/AlejandroMllo/situationally_aware_dynamics_learning');
  }
  if(i===5){const s=page(p,6,'补充文献','补充文献：方法参考与基线选择','其余工作分别补充突变适应、操作适应、残差学习与任务恢复。');
   table(s,[['论文','研究内容','本研究定位'],['ESCP','短历史环境表征与突变适应','对照方法'],['RMA²','视觉与历史条件化的操作适应','机械臂适应参考'],['UARL','不确定性引导的残差强化学习','残差策略参考'],['RecoveryChaining','局部恢复策略与原控制器衔接','任务恢复参考']],250,[260,570,334],[48,82,82,82,82],19);
   notes(s,'ESCP 研究短时历史条件化策略应对环境突变，保留为适应对照。RMA² 研究机械臂操作中的历史与视觉适应，作为机械臂背景。UARL 关注不确定性引导的残差强化学习与学习效率，作为残差策略参考。RecoveryChaining 关注任务失败后的局部恢复与原控制流程衔接，作为任务恢复参考。上述定位依据本项目的动力学扰动恢复目标，不代表对论文质量进行简单排序。','ESCP：https://github.com/FanmingL/ESCP\nRMA²：https://www.robots.ox.ac.uk/~vgg/publications/2024/Liang24/\nUARL：https://lakshitadodeja.github.io/uncertainty-aware-residual-rl/\nRecoveryChaining：https://www.merl.com/publications/TR2025-152');
  }
  if(i===6){const s=page(p,7,'调研结论','调研结论与后续安排','优先评估 GRAM 的复现条件，TAM 与 SADL 保留为备选。');
   table(s,[['论文','选择依据','后续工作'],['GRAM','运动适应与鲁棒联合训练','原任务复现与轮足拓展'],['TAM','力矩层适配与上层策略复用','机械臂复现与接口拓展'],['SADL','在线模型适应与工况变化检测','模型与规划方案评估']],250,[180,590,394],[48,92,92,92],20);
   text(s,'实施顺序：原任务复现 → 平台拓展 → 突变恢复评估',60,602,1150,43,23,true,C.blue);
   text(s,'双平台采用统一方法，分别训练与验证。',60,659,1120,37,21);
   notes(s,'综合研究问题、公开实现和迁移工作，建议优先评估 GRAM 的原任务复现条件。TAM 保留为力矩层适配候选，SADL 保留为在线模型候选。后续按原任务复现、平台拓展、突变恢复评估的顺序推进。两个平台采用相同核心机制，分别训练和验证。研究贡献需要建立在现有方法的具体不足上，平台迁移本身不直接作为算法创新。',SOURCES.gram+'\n'+SOURCES.tam+'\n'+SOURCES.sadl);
  }
 }
 return {slides:p.slides.items.length,range:[input.start,input.end]};
}
