const B='#195FC0',I='#142D50',M='#526780',L='#EDF4FC',D='#CCD9E9';
const P='https://arxiv.org/html/2606.06218v3';
function tx(s,t,x,y,w,h,z=20,b=false,c=I){const a=s.shapes.add({geometry:'textbox',position:{left:x,top:y,width:w,height:h},fill:'none',line:{fill:'none',width:0}});a.text=t;a.text.style={fontSize:`${z}pt`,fontFamily:'Microsoft YaHei',bold:b,color:c,insets:0};return a;}
function box(s,x,y,w,h,c){return s.shapes.add({geometry:'rect',position:{left:x,top:y,width:w,height:h},fill:c,line:{fill:'none',width:0}});}
function head(p,title,sub){const s=p.slides.add({width:1280,height:720});s.background.fill='#FFFFFF';tx(s,'候选论文调研  /  TAM',58,29,1150,28,12,true,B);tx(s,title,58,78,1160,72,32,true);tx(s,sub,60,152,1150,35,16,false,M);box(s,58,201,1162,2,D);return s;}
export async function revise({presentation:p}){
 p.slides.delete(p.slides.items.map((_,i)=>i));
 let s=head(p,'TAM：在力矩接口补偿动力学偏差','研究对象：机械臂运动迁移；适配未知负载、摩擦和执行器响应等变化。');
 s.images.add({path:'G:/毕设/02_learning/04_review/.build_tam/fig1.png',alt:'TAM 原论文 Figure 1：策略、控制器、力矩适配模块与机器人',fit:'contain',position:{left:58,top:225,width:735,height:288}});
 tx(s,'保留任务策略，在执行前修正力矩',60,548,735,40,24,true,B);
 tx(s,'输入：标称力矩 + 关节状态与力矩历史\n输出：各关节的修正力矩 Δτ',60,603,735,72,19);
 tx(s,'方法',842,227,356,36,22,true,B);
 tx(s,'历史编码器判断当前响应，\n适配器计算修正量；\n使用理想动力学提供参考。',842,277,365,116,20);
 tx(s,'原文验证',842,422,356,36,22,true,B);
 tx(s,'Panda 上复用 RL、BC 和 MPC。\n推箱成功率：47.6% → 76.2%。',842,473,365,88,20);
 tx(s,'训练与代码',842,584,356,34,20,true,B);
 tx(s,'仿真监督训练，部署时权重固定。\n有官方代码仓库。',842,630,365,63,17,false,M);
 s.speakerNotes.text='TAM 关注的是动力学变化之后，原来的任务策略为什么执行不准。它没有直接修改任务策略，而是放在低层控制器之后，根据关节状态和力矩历史计算修正力矩，让真实机器人的响应接近理想模型。因此，上层可以是强化学习、行为克隆或 MPC。原文在 Panda 上验证了这种复用方式，推箱成功率从直接执行的 47.6% 提高到 76.2%。TAM 主要用仿真标签做监督训练，部署时根据历史推断适应状态。下一页重点看这种接口设计能否迁移到我们的两个平台。\n\n来源：'+P+'，Figure 1、§§2–4、Table 1。\n官方仓库：https://github.com/Dongwon-Son/TAM';
 s=head(p,'TAM 的迁移价值与局限','同一方法可以作为两个平台的研究基础，但目前公开验证仍以机械臂为主。');
 box(s,58,225,1162,47,B);tx(s,'平台',75,235,170,33,18,true,'#FFFFFF');tx(s,'需要对接的内容',278,235,610,33,18,true,'#FFFFFF');tx(s,'迁移判断',943,235,250,33,18,true,'#FFFFFF');
 box(s,58,274,1162,122,L);tx(s,'UR7e',75,304,170,48,25,true);tx(s,'6 关节状态、标称力矩与理想模型；\n核对力矩接口版本、重力补偿和控制周期。',278,295,615,90,20);tx(s,'较接近原设定\n需补实机桥接与验证',943,295,260,90,19);
 box(s,58,407,1162,150,'#F6F8FB');tx(s,'Go2-W',75,438,170,48,25,true);tx(s,'12 个腿关节 + 4 个轮执行器；\n复用健康运动策略，转换为标称力矩；\n扩展浮动基座、接触参考与适配训练。',278,426,615,121,20);tx(s,'接口有基础\n方法扩展工作较多',943,438,260,90,19);
 tx(s,'选择时的关键限制',60,583,340,35,21,true,B);
 tx(s,'需要可用的理想模型；局部运动对齐不等于长时稳定。\n官方未提供机器人侧控制桥接，也未验证 Go2-W 轮地故障。',60,632,1150,68,20);
 s.speakerNotes.text='UR7e 是串联机械臂，与原论文设定接近，但有状态和力矩接口还不够，仍要有能够输出标称力矩的控制器、对应的理想模型和实机桥接。Go2-W 的 SDK 有低层命令基础，已有仿真模型也能复用，但原方法不能仅靠把输入改成 16 维就直接运行。身体耦合和接触既影响反馈，也影响理想模型的参考计算，所以需要扩展和训练。TAM 的价值是把适应层与上层任务策略解耦；限制是它依赖参考模型和力矩控制，且没有长时稳定保证。v3 已有机械臂仿真参数突变恢复实验，但不能据此推断轮锁死、打滑或支撑丢失都已解决。因而它是有研究价值的候选，而不是两平台现成可用的完整基线。\n\n论文：'+P+'，§§2、4.4、5、Appendix D.2.1。\n部署范围：https://github.com/Dongwon-Son/TAM/blob/main/docs/deployment.md\nUR 接口：https://docs.universal-robots.com/Universal_Robots_ROS2_Documentation/rolling/doc/ur_robot_driver/ur_robot_driver/doc/usage/force_torque_control.html\nGo2-W 接口：https://github.com/unitreerobotics/unitree_sdk2/blob/main/example/go2w/go2w_stand_example.cpp';
 return {slides:p.slides.items.length};
}
