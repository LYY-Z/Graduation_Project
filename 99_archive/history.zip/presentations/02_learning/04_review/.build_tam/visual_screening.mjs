const ROOT='G:/毕设/02_learning/04_review/.build_tam';
const C={blue:'#195FC0',ink:'#142D50',muted:'#526780',line:'#CCD9E9',pale:'#EDF4FC'};
const S={tam:'https://arxiv.org/html/2606.06218v3',gram:'https://www.merl.com/publications/docs/TR2026-057.pdf',sadl:'https://arxiv.org/html/2505.19574v3'};
function tx(s,t,x,y,w,h,z=20,b=false,c=C.ink){const a=s.shapes.add({geometry:'textbox',position:{left:x,top:y,width:w,height:h},fill:'none',line:{fill:'none',width:0}});a.text=t;a.text.style={fontSize:`${z}pt`,fontFamily:'Microsoft YaHei',bold:b,color:c,insets:0};return a;}
function head(p,n,label,title,sub){const s=p.slides.add({width:1280,height:720});s.background.fill='#FFFFFF';tx(s,label,58,22,1140,25,12,true,C.blue);tx(s,title,58,64,1164,63,31,true);tx(s,sub,60,137,1156,36,18,false,C.muted);s.shapes.add({geometry:'rect',position:{left:58,top:184,width:1164,height:2},fill:C.line,line:{fill:'none',width:0}});tx(s,`${n} / 7`,1154,687,68,22,11,false,C.muted);return s;}
function img(s,name,x,y,w,h){s.images.add({path:`${ROOT}/${name}.png`,alt:`论文原图：${name}`,fit:'contain',position:{left:x,top:y,width:w,height:h}});}
function notes(s,t,links){s.speakerNotes.text=t+'\n\n参考资料：\n'+links;}
function flow(s,labels,y,w=252,gap=52,h=88){const nodes=[];labels.forEach((v,i)=>{const x=58+i*(w+gap);const a=s.shapes.add({geometry:'rect',position:{left:x,top:y,width:w,height:h},fill:C.pale,line:{fill:C.line,width:1}});tx(s,v,x+14,y+25,w-28,35,20,true);if(i)s.shapes.connect(nodes[i-1],a,{kind:'straight',fromSide:'right',toSide:'left',line:{fill:C.blue,width:2.5},tail:{type:'triangle',width:'med',length:'med'}});nodes.push(a);});}
function table(s,v,y,widths,heights,font=19){const t=s.tables.add({rows:v.length,columns:widths.length,left:58,top:y,width:1164,height:heights.reduce((a,b)=>a+b,0),columnWidths:widths,values:v});t.borders.assign({fill:'#FFFFFF',width:2,style:'solid'});v.forEach((_,r)=>{t.rows[r].height=heights[r];widths.forEach((_,c)=>{const a=t.getCell(r,c);a.fill=r===0?C.blue:r%2?C.pale:'#F5F7FA';a.text.style={fontSize:`${r===0?18:font}pt`,fontFamily:'Microsoft YaHei',bold:r===0||c===0,color:r===0?'#FFFFFF':C.ink,insets:15,verticalAlignment:'middle'};});});return t;}
export async function build({presentation:p,input}){
 if(input.start===0)p.slides.delete(p.slides.items.map((_,i)=>i));
 for(let i=input.start;i<input.end;i++){
  if(i===0){const s=head(p,1,'TAM  ·  CoRL 2026 Spotlight  ·  KAIST / Ai2 / UW / Toronto','TAM：在力矩层补偿动力学差异','研究问题：负载、摩擦等变化使实际运动偏离原策略的预期。');
   img(s,'fig1',58,230,770,270);
   tx(s,'历史编码 → 残差力矩',875,224,337,38,21,true,C.blue);
   tx(s,'Transformer 提取历史\nMLP 预测力矩补偿\n仿真监督训练',875,282,337,119,20);
   tx(s,'参考模型提供\n理想运动响应',875,440,337,69,19,false,C.muted);
   tx(s,'输入：关节状态、力矩历史与原控制器力矩\n输出：各关节残差力矩',60,550,1150,70,21);
   tx(s,'核心贡献：复用 RL、BC、MPC 等上层策略，仅适配执行响应。',60,642,1135,39,22,true,C.blue);
   notes(s,'TAM 将适应放在低层控制器之后。按原图从左向右，上层策略产生动作，控制器将动作转换为原始力矩，TAM 再根据执行历史和参考模型预测残差力矩。它主要通过仿真监督学习训练，历史编码器采用 Transformer，快速适配器采用 MLP。上层策略可以来自强化学习、行为克隆或 MPC，其核心价值是降低适应模块与具体任务的绑定。下面看作者如何验证这种复用。',S.tam+'\nhttps://github.com/Dongwon-Son/TAM');
  }
  if(i===1){const s=head(p,2,'TAM  ·  实验证据','TAM：跨策略复用与动力学突变验证','实机验证任务复用；仿真进一步检验跨机械臂迁移与突变后的适应。');
   img(s,'fig3',58,228,730,288);img(s,'fig4',834,227,380,237);
   tx(s,'Panda：推箱、翻块、托盘平衡与负载跟踪',60,536,735,37,19,true);
   tx(s,'推箱成功率：47.6% → 76.2%',60,580,730,37,23,true,C.blue);
   tx(s,'仿真恢复时间\n原版 4.6 s；DAgger 1.7 s',835,493,380,91,20,true,C.blue);
   tx(s,'实机基线：Direct、Online SysID；RMA 仅用于推箱。',60,624,730,25,17);
   tx(s,'复现：官方训练、公开权重与代表性仿真评估；实机接口需拓展。\n局限：参考模型、接触分布与执行器能力限制。',60,654,1120,49,17);
   notes(s,'左图来自原文 Figure 3，上排为直接执行，下排为加入 TAM，四列是 RL 推箱、BC 翻块、MPC 球盘平衡和负载跟踪。推箱成功率从 47.6% 提高到 76.2%，Online SysID 为 57.1%。右图是 Figure 4，在二十条仿真轨迹中途切换动力学参数，原版恢复约四点六秒，两个 DAgger 变体约一点七秒；采用原版 TAM 稳态误差作为共同恢复参考，包含轨迹追赶，不能当作通用故障恢复时间。官方代码有仿真训练和评估，机器人侧控制桥接仍需拓展。复杂接触、训练外变化和执行器能力不足仍限制补偿。平台迁移在最后统一比较。',S.tam+'\nhttps://github.com/Dongwon-Son/TAM/blob/main/docs/deployment.md');
  }
  if(i===2){const s=head(p,3,'GRAM  ·  RA-L 2026  ·  MERL / MIT','GRAM：按估计可靠程度融合适应与鲁棒控制','研究问题：历史推断在陌生条件下可能失准，纯鲁棒策略又可能过于保守。');
   flow(s,['观测与动作历史','条件与不确定性','统一策略','关节位置目标'],211);
   img(s,'gram_fig2',58,333,570,323);
   tx(s,'训练',691,338,515,35,22,true,C.blue);
   tx(s,'PPO 训练策略，教师—学生学习适应。\n对抗训练提供鲁棒行为。',691,387,515,86,20);
   tx(s,'输入与输出',691,501,515,35,22,true,C.blue);
   tx(s,'关节与机身状态、运动指令及历史\n→ Go2 的 12 维关节位置目标',691,551,515,80,20);
   notes(s,'上方流程是对论文方法的概括，左下是原文 Figure 2。历史网络估计当前条件，Epinet 评估估计分歧；不确定性高时，条件表示偏向训练好的鲁棒表示。这是同一个策略的内部调整，不是根据真实故障标签切换独立控制器。PPO 训练策略，教师—学生学习让历史估计对应仿真已知条件，对抗训练学习困难条件下的行为。部署时网络参数固定。输出是普通 Go2 的十二关节位置目标，随后由 PD 控制器执行。下面用实验检查这种设计的效果。',S.gram+'\nhttps://github.com/merlresearch/gram');
  }
  if(i===3){const s=head(p,4,'GRAM  ·  实验证据','GRAM：在困难实机场景中保持任务成功率','仿真包含泛化比较、训练分布与消融；实机包含受控场景和户外测试。');
   img(s,'gram_fig6',58,223,730,368);
   tx(s,'困难场景成功次数',842,224,370,35,21,true,C.blue);
   tx(s,'GRAM',843,291,210,37,23,true);tx(s,'15 / 15',1080,291,140,40,25,true,C.blue);
   tx(s,'鲁棒 RL',843,370,210,37,23);tx(s,'12 / 15',1080,370,140,40,25);
   tx(s,'上下文 RL',843,449,222,37,23);tx(s,'2 / 15',1080,449,140,40,25);
   tx(s,'3 类场景 × 每类 5 次',843,531,375,35,17,false,C.muted);
   tx(s,'上至下：9 kg 负载、湿滑表面、坡道进入泡沫',60,611,740,35,18);
   tx(s,'复现：官方 Go2 训练、评估与基线已公开。\n局限：训练外极端条件仍可能失效；轮足与机械臂尚未验证。',60,654,1110,49,17);
   notes(s,'左图为原文 Figure 6，三类困难任务分别是九公斤负载、湿滑表面和坡道进入泡沫。右侧数值来自 Table V，各类任务每种方法五次，因此每种方法共十五次。GRAM 成功十五次，鲁棒 RL 十二次，上下文 RL 两次。论文还测试正常、后髋冻结、上下坡等四类中等难度任务，总计七类受控场景，三方法、每类五次，共一百零五次；此外有户外定性验证。十五次成功不代表任意故障下百分之百保证。原文仍以普通 Go2 为平台，运行中恢复的时间与累计误差还需要更系统的实验。',S.gram+'\nhttps://github.com/merlresearch/gram');
  }
  if(i===4){const s=head(p,5,'SADL  ·  IJRR 2026  ·  Indiana University Bloomington','SADL：用工况识别改善动力学预测与规划','研究问题：隐藏地形或动力学条件，使相同指令产生不同运动响应。');
   img(s,'sadl_fig2',58,221,790,382);img(s,'sadl_fig4',900,223,310,195);
   tx(s,'地面车辆实机导航\n四旋翼风扰动仿真',889,448,327,71,19,true);
   tx(s,'变化检测 + 条件动力学\nMPPI 规划控制',889,545,327,70,18,false,C.muted);
   tx(s,'输入：状态转移数据与目标；输出：规划动作。官方提供 QuadX 训练评估示例。\n边界：测试时工况库固定；全部车辆实验的公开工程仍需确认。',60,642,1110,55,18);
   notes(s,'左图是论文 Figure 2，右图是实际 Jackal 平台 Figure 4。方法从状态转移中识别隐藏工况，将工况表示加入动力学模型，再由 MPPI 规划动作，属于模型驱动适应路线。原文包含地面车辆仿真与实机导航、四旋翼风扰动仿真。最新版第 4.1.1 节明确区分训练和测试：训练阶段发现工况并建立模型；测试阶段工况库固定，通过匹配已有工况进行适应，不再创建新工况。因此不能把它描述为部署时无限学习任意新故障。向 Go2-W 和 UR7e 迁移时，都需要拓展机器人响应模型与控制接口，控制层级还会影响规划开销。',S.sadl+'\nhttps://github.com/AlejandroMllo/situationally_aware_dynamics_learning');
  }
  if(i===5){const s=head(p,6,'补充文献','补充文献：发表来源与研究定位','保留与研究问题直接相关的对照，其余方法补充不同技术路线。');
   table(s,[['论文','发表来源','研究内容','研究用途'],['ESCP','AAAI 2022','短历史表征与环境突变','适应对照'],['RMA²','CVPR 2024','视觉与历史驱动的操作适应','机械臂参考'],['UARL','RA-L 2026','不确定性引导的残差学习','残差策略参考'],['RecoveryChaining','IROS 2025','失败状态到可继续执行状态','任务恢复参考']],230,[245,205,465,249],[48,85,85,85,85],18);
   tx(s,'会议与期刊分别评价；发表级别不直接等于本研究适用性。',60,657,1120,37,21,true,C.blue);
   notes(s,'其余四篇的作用不同。ESCP 用短历史推断环境，直接研究突变适应，可作为对照。RMA² 处理机械臂操作中的视觉与历史适应。UARL 研究有基础策略时如何更高效学习残差。RecoveryChaining 学习任务失败后的局部恢复，再接回原控制器；它的任务状态恢复并不直接等于未知执行器动力学适应。保留这些文献用于背景、对照和查重，不同时开展全部复现。','ESCP：https://github.com/FanmingL/ESCP\nRMA²：https://www.robots.ox.ac.uk/~vgg/publications/2024/Liang24/\nUARL：https://lakshitadodeja.github.io/uncertainty-aware-residual-rl/\nRecoveryChaining：https://www.merl.com/publications/TR2025-152');
  }
  if(i===6){const s=head(p,7,'选型与后续工作','选型依据：公开复现范围与平台迁移成本','核心仿真复现与全部论文实验复现，分别确定范围。');
   table(s,[['方法','公开复现基础','Go2-W 拓展','UR7e 拓展'],['GRAM','Go2 训练、适应与评估','腿轮动作与训练','任务与策略训练'],['TAM','训练、权重与代表性评估','轮足动力学与训练','模型与力矩接口'],['SADL','模型与 QuadX 训练评估示例','响应模型与规划','响应模型与规划']],225,[155,345,332,332],[46,89,89,89],18);
   flow(s,['原任务复现','平台拓展','突变恢复评估'],567,340,72,80);
   tx(s,'建议优先验证 GRAM；TAM、SADL 保留为不同控制层级的备选。',60,666,1110,31,19,true,C.blue);
   notes(s,'选型主要看公开原任务是否能复现，以及输入输出如何拓展到两个平台。GRAM 与轮足运动更接近，优先验证原生 Go2 训练，Go2-W 的迁移相对较轻，UR7e 需要重建任务。TAM 对机械臂迁移较接近，但轮足动力学扩展较大。SADL 的成本取决于建模和规划层级。以上为相对迁移评估，不是已完成实验。后续按原任务复现、平台拓展、突变恢复评估推进，不同时建设三套系统。创新研究需要围绕具体失败机制，而不是直接将平台迁移或已有模块组合认定为贡献。',S.gram+'\n'+S.tam+'\n'+S.sadl);
  }
 }
 return {slides:p.slides.items.length,range:[input.start,input.end]};
}
