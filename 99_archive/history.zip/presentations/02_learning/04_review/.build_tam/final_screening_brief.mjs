const R='G:/毕设/02_learning/04_review/.build_tam';
const C={blue:'#195FC0',ink:'#142D50',muted:'#526780',line:'#CCD9E9',light:'#EDF4FC'};
const P={tam:'https://arxiv.org/html/2606.06218v3',gram:'https://www.merl.com/publications/docs/TR2026-057.pdf',sadl:'https://arxiv.org/html/2505.19574v2'};
function tx(s,t,x,y,w,h,z=21,b=false,c=C.ink){const a=s.shapes.add({geometry:'textbox',position:{left:x,top:y,width:w,height:h},fill:'none',line:{fill:'none',width:0}});a.text=t;a.text.style={fontSize:`${z}pt`,fontFamily:'Microsoft YaHei',bold:b,color:c,insets:0};return a;}
function line(s,y){s.shapes.add({geometry:'rect',position:{left:58,top:y,width:1164,height:2},fill:C.line,line:{fill:'none',width:0}});}
function page(p,n,label,title,subtitle){const s=p.slides.add({width:1280,height:720});s.background.fill='#FFFFFF';tx(s,label,58,27,1120,25,12,true,C.blue);tx(s,title,58,75,1164,64,31,true);tx(s,subtitle,60,154,1155,53,19,false,C.muted);line(s,210);tx(s,`${n} / 7`,1154,686,68,22,11,false,C.muted);return s;}
function image(s,name,x,y,w,h){s.images.add({path:`${R}/${name}.png`,alt:`TAM 原论文 ${name}`,fit:'contain',position:{left:x,top:y,width:w,height:h}});}
function table(s,values,y,widths,heights,font=19){const t=s.tables.add({rows:values.length,columns:widths.length,left:58,top:y,width:1164,height:heights.reduce((a,b)=>a+b,0),columnWidths:widths,values});t.borders.assign({fill:'#FFFFFF',style:'solid',width:2});
 for(let r=0;r<values.length;r++){t.rows[r].height=heights[r];for(let c=0;c<widths.length;c++){const a=t.getCell(r,c);a.fill=r===0?C.blue:r%2?C.light:'#F5F7FA';a.text.style={fontSize:`${r===0?18:font}pt`,fontFamily:'Microsoft YaHei',bold:r===0||c===0,color:r===0?'#FFFFFF':C.ink,insets:14,verticalAlignment:'middle'};}}return t;}
function flow(s,items,y,w=252,gap=52){const a=[];for(let i=0;i<items.length;i++){const x=58+i*(w+gap);const q=s.shapes.add({geometry:'rect',position:{left:x,top:y,width:w,height:110},fill:C.light,line:{fill:C.line,width:1}});tx(s,items[i][0],x+16,y+19,w-32,34,21,true);tx(s,items[i][1],x+16,y+64,w-32,32,17,false,C.muted);a.push(q);if(i)s.shapes.connect(a[i-1],q,{kind:'straight',fromSide:'right',toSide:'left',line:{fill:C.blue,width:2.5},tail:{type:'triangle',width:'med',length:'med'}});}return a;}
function note(s,t,links){s.speakerNotes.text=t+'\n\n参考资料：\n'+links;}
export async function build({presentation:p,input}){
 if(input.start===0)p.slides.delete(p.slides.items.map((_,i)=>i));
 for(let i=input.start;i<input.end;i++){
  if(i===0){const s=page(p,1,'TAM  ·  CoRL 2026','TAM：不改原策略，补偿执行偏差','问题：增加负载或摩擦改变后，原来能完成的动作可能执行不准。');
   image(s,'fig1',58,238,741,259);
   tx(s,'怎么做',842,242,360,36,23,true,C.blue);tx(s,'读取关节运动和力矩历史，\n预测需要补多少力矩，\n加到原控制力矩上。',842,296,360,122,21);
   tx(s,'技术：Transformer + MLP\n在仿真中做监督学习',842,443,360,64,17,false,C.muted);
   tx(s,'输入：关节位置、速度、力矩历史 + 本次力矩指令\n输出：各关节补偿力矩',60,527,1150,72,21);
   tx(s,'特点：上层 RL、模仿学习或 MPC 策略可以保留。',60,614,1150,35,22,true,C.blue);
   tx(s,'实验：Panda 推箱、翻块、托盘平衡、跟踪；仿真跨臂与参数突变。推箱成功率 47.6% → 76.2%。',60,664,1100,29,16);
   note(s,'TAM 不直接学习任务怎么完成，而是修正原控制器产生的力矩。它用 Transformer 编码历史，再用 MLP，也就是前馈神经网络，算出各关节的补偿。主要训练方式是仿真监督学习，不是部署时在线运行 PPO。它的价值是同一适配模块可以服务于不同来源的上层策略。原文 Panda 推箱成功率从直接执行的 47.6% 提高到 76.2%，在线系统辨识为 57.1%；其余任务采用各自指标。仿真还评估跨机械臂与动力学突变，不能据此认为任意故障都已解决。',P.tam+'\nhttps://github.com/Dongwon-Son/TAM');
  }
  if(i===1){const s=page(p,2,'TAM  ·  复现与迁移','TAM：UR7e 需补接口，Go2-W 还需扩展模型','有官方训练和仿真评测代码；实机控制桥接需要补充。');
   table(s,[['平台','需要补什么','相对工作量'],['UR7e','6 关节力矩控制与参考模型；\n核对重力补偿、控制频率和关节顺序。','中等\n接近原机械臂设定'],['Go2-W','先有正常运动策略，再接入腿轮力矩；\n扩展浮动基座、地面接触模型与训练。','较大\n超出原机械臂设定']],245,[155,730,279],[46,122,122]);
   tx(s,'主要限制',60,570,300,37,23,true,C.blue);tx(s,'需要可用的参考模型和力矩接口。\n接触可能干扰估计；补偿不能超出电机剩余能力。',60,624,1150,66,21);
   note(s,'官方代码的主要计算栈是 MuJoCo/MJX 和 JAX，包含仿真数据生成、训练与评测，但机器人侧底层控制桥接未提供。表中是本项目的相对迁移判断，不是原文实验。UR7e 需要先算出可用的原控制力矩，核对命令是否包含重力，以及反馈、关节顺序和周期。Go2-W 要保留健康运动策略，接入十六执行器，并扩展浮动基座和轮地接触的参考计算及训练。已有物理仿真可以复用，但不是只改网络维度。原文存在有条件的误差有界分析，不是任意接触、故障下的稳定与安全保证。',P.tam+'\nhttps://github.com/Dongwon-Son/TAM/blob/main/docs/deployment.md\nhttps://docs.universal-robots.com/Universal_Robots_ROS2_Documentation/rolling/doc/ur_robot_driver/ur_robot_driver/doc/usage/force_torque_control.html');
  }
  if(i===2){const s=page(p,3,'GRAM  ·  RA-L 2026','GRAM：判断历史估计是否可靠，再调整控制','问题：陌生条件下可能判断错；一直保守控制，又会损失正常性能。');
   flow(s,[['近期交互历史','关节、机身与动作'],['条件估计','判断估计是否可靠'],['同一控制策略','适应 / 鲁棒控制'],['关节位置目标','交给 PD 控制器']],250);
   tx(s,'训练用什么',60,399,270,35,22,true,C.blue);tx(s,'PPO 学动作；教师—学生学历史适应；不确定性网络辅助判断；对抗训练提高鲁棒性。',60,448,1140,63,20);
   tx(s,'输入：关节状态、机身角速度、重力方向、运动指令与历史\n输出：Go2 的 12 个关节位置目标',60,536,1140,70,21);
   tx(s,'实验：仿真对比与消融；实机 7 种场景、105 次受控测试，另有户外测试。\n三种困难场景：GRAM 15/15，鲁棒 RL 12/15，上下文适应 RL 2/15。',60,636,1120,57,18);
   note(s,'GRAM 的贡献是把适应与鲁棒性放进同一个策略。近期历史用于估计当前条件，Epinet 不确定性网络评估估计分歧。估计较可靠时更多采用针对当前条件的表示，较不可靠时偏向训练好的鲁棒表示，并不是根据一个准确故障标签切换控制器。PPO 用回报训练策略，教师—学生训练让历史网络学习仿真已知条件的表示，对抗训练制造困难以学习鲁棒行为。部署时权重固定。原文平台是普通 Go2，输入为关节状态、角速度、重力方向、运动指令与近期历史，输出十二个关节位置目标。实机共七个受控场景，每方法每场景五次，共三方法一百零五次；困难三类是九公斤负载、湿滑表面、坡道进入泡沫。十五次成功不是通用成功率保证。',P.gram+'\nhttps://github.com/merlresearch/gram');
  }
  if(i===3){const s=page(p,4,'GRAM  ·  复现与迁移','GRAM：Go2-W 需扩展轮控制，UR7e 需新建任务','有官方 Go2 训练、评估和对照方法；旧版仿真依赖需要核对兼容性。');
   table(s,[['平台','需要补什么','相对工作量'],['Go2-W','增加轮状态，输出腿位置与轮速度；\n调整奖励、动作限制和扰动，重新训练。','中等\n需扩展轮足任务'],['UR7e','新建机械臂任务、观测和控制动作；\n重新设计奖励、训练条件与对抗扰动。','较大\n原 Go2 策略不能直接用']],245,[155,730,279],[46,122,122]);
   tx(s,'主要限制',60,570,300,37,23,true,C.blue);tx(s,'陌生条件仍可能超出鲁棒训练的能力。\n不确定性不是故障诊断；轮足和机械臂恢复尚未验证。',60,624,1150,66,21);
   note(s,'原代码依赖 Isaac Lab 1.0、Isaac Sim 4.1 和 rsl_rl 2.0，官方给出了原任务训练、评估和主要基线，但本次没有进行运行验证。Go2-W 与 Go2 的本体感知和腿控制较接近，拟输出十二个腿位置和四个轮速度目标，重新训练轮足任务。UR7e 可以迁移适应机制，但需要新的机械臂任务、状态、奖励、控制动作和对抗训练。两个平台不需要共享同一套权重。论文承认极端分布外条件仍会失败，其实验不是所有故障的覆盖证明。研究恢复时还需补充扰动后累计误差、恢复时间等指标。',P.gram+'\nhttps://github.com/merlresearch/gram');
  }
  if(i===4){const s=page(p,5,'SADL  ·  IJRR 2026','SADL：先更新运动模型，再规划动作','问题：条件变化后，旧模型难以预测机器人接下来的运动。');
   flow(s,[['执行与反馈','记录状态与动作'],['检测条件变化','判断是否进入新工况'],['更新动力学模型','预测运动响应'],['重新规划动作','MPPI 采样规划']],250);
   tx(s,'输入：状态—动作—后继状态数据及控制目标；输出：模型预测，再由规划器选动作。',60,399,1140,61,20);
   tx(s,'原文做了什么',60,490,520,36,22,true,C.blue);tx(s,'车辆仿真与实机导航；\n四旋翼仿真中的风变化。\n有官方模型、训练与示例代码。',60,542,536,114,20);
   tx(s,'迁移与限制',666,490,530,36,22,true,C.blue);tx(s,'两平台都要建立各自的响应模型。\n关节级规划的计算量较大；\n公开示例不是目标平台完整工程。',666,542,540,114,20);
   note(s,'SADL 是 Situationally-Aware Dynamics Learning。它将在线变化检测、工况表示和条件动力学模型连接起来，再通过 MPPI 进行控制。主要技术是在线概率建模、贝叶斯变化检测和采样式预测规划，不是直接用 PPO 输出动作。贡献在于把隐藏条件的变化与模型更新联系起来。作者评估地面车辆导航及四旋翼风变化，并提供官方代码与示例。对我们而言，应先决定建模和控制层级：上层指令模型更容易迁移，关节级模型能描述更多变化，但状态维度和规划成本更大。Go2-W 需要轮足状态与动作模型，UR7e 需要机械臂目标、状态和规划约束。并不能因为接口维度可配置就直接迁移原权重。将其保留为模型适应路线，不与前两篇同时展开复现。',P.sadl+'\nhttps://github.com/AlejandroMllo/situationally_aware_dynamics_learning');
  }
  if(i===5){const s=page(p,6,'其他四篇  ·  参考价值与取舍','其余四篇保留参考，不同时开展复现','它们分别关注突变适应、机械臂操作、残差学习和任务失败恢复。');
   table(s,[['论文','主要研究什么','当前用途'],['ESCP','用短时历史应对环境突变','保留作突变适应对照'],['RMA²','利用深度和历史适应机械臂操作','补充机械臂适应背景'],['UARL','有基础策略时，更快学会修正动作','采用残差 RL 时再深入'],['RecoveryChaining','失败后回到能够继续任务的状态','当前问题不同，暂不复现']],245,[260,560,344],[46,79,79,79,79],19);
   tx(s,'ESCP 与突变适应直接相关；其余三篇暂不作为主方法。',60,645,1140,44,22,true,C.blue);
   note(s,'这里不是说其他论文质量差，而是区分它们与当前问题的关系。ESCP 结合短历史 GRU 上下文编码和 SAC，研究环境突然变化，值得作为对照，但旧依赖和目标平台环境需要维护。RMA² 利用教师—学生适应与深度信息处理机械臂操作，可作为 UR7e 方向背景，当前不优先迁移整套环境。UARL 研究不确定性引导的残差强化学习及随机基础策略，其主要贡献是学习效率；如果最终采用残差策略，再深入比较。RecoveryChaining 用分层强化学习学习失败后的恢复技能并返回原控制器，关注任务状态恢复，并不直接等于未知执行器动力学适应。', 'ESCP：https://github.com/FanmingL/ESCP\nRMA²：https://www.robots.ox.ac.uk/~vgg/publications/2024/Liang24/\nUARL：https://lakshitadodeja.github.io/uncertainty-aware-residual-rl/\nRecoveryChaining：https://www.merl.com/publications/TR2025-152');
  }
  if(i===6){const s=page(p,7,'调研结论','优先验证 GRAM，保留 TAM 与 SADL 两条路线','先验证一条路线，避免同时搭建多套训练系统。');
   table(s,[['候选','适合先做什么','主要代价'],['GRAM','先复现 Go2 原任务，再扩展 Go2-W','轮足重新训练；机械臂另建任务'],['TAM','先复现机械臂仿真，核对 UR7e 接口','直接力矩控制、参考模型、桥接'],['SADL','保留在线模型与规划路线','响应模型、在线学习和规划成本']],245,[180,590,394],[46,89,89,89],19);
   tx(s,'先确认原任务能训练和评估，再决定主要复现项目。',60,588,1140,44,23,true,C.blue);
   tx(s,'两个平台验证同一种方法，不要求直接共用一套权重。',60,649,1140,38,21);
   note(s,'当前建议优先验证 GRAM 的原任务，因为它与轮足运动适应更接近，也提供训练和对照实现。TAM 保留为机械臂执行层适配候选，但需要核对实际力矩接口和参考模型。SADL 是模型与规划方向的备选。三条路线不同时展开训练。接下来先固定一个原任务，验证依赖、训练、评估和主要对照，再决定主复现项目。后续研究要围绕运行中变化后的具体失败机制展开，不能把历史编码、门控或简单迁移直接认定为创新。同一种方法可以在 Go2-W 和 UR7e 上分别训练，再用相同逻辑评价恢复表现。',P.gram+'\n'+P.tam+'\n'+P.sadl);
  }
 }
 return {slides:p.slides.items.length,range:[input.start,input.end]};
}
