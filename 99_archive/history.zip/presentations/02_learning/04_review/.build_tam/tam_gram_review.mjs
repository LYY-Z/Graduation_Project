const ROOT='G:/毕设/02_learning/04_review/.build_tam';
const C={blue:'#195FC0',ink:'#142D50',muted:'#526780',line:'#CCD9E9',pale:'#EDF4FC'};
const TAM='https://arxiv.org/html/2606.06218v3';
const GRAM='https://www.merl.com/publications/docs/TR2026-057.pdf';
function tx(s,t,x,y,w,h,z=20,b=false,c=C.ink){const a=s.shapes.add({geometry:'textbox',position:{left:x,top:y,width:w,height:h},fill:'none',line:{fill:'none',width:0}});a.text=t;a.text.style={fontSize:`${z}pt`,fontFamily:'Microsoft YaHei',bold:b,color:c,insets:0};return a;}
function line(s,x,y,w){s.shapes.add({geometry:'rect',position:{left:x,top:y,width:w,height:2},fill:C.line,line:{fill:'none',width:0}});}
function head(p,paper,title,problem,no){const s=p.slides.add({width:1280,height:720});s.background.fill='#FFFFFF';tx(s,paper,58,28,1164,26,12,true,C.blue);tx(s,title,58,74,1164,68,31,true);tx(s,problem,60,151,1160,54,19,false,C.muted);line(s,58,206,1164);tx(s,String(no).padStart(2,'0'),1173,688,50,22,11,false,C.muted);return s;}
function image(s,file,x,y,w,h){s.images.add({path:`${ROOT}/${file}.png`,alt:`论文原图：${file}`,fit:'contain',position:{left:x,top:y,width:w,height:h}});}
function migration(s,values){const t=s.tables.add({rows:3,columns:3,left:58,top:350,width:1164,height:236,columnWidths:[160,692,312],values:[['平台','需要完成的工作','难度判断'],...values]});
 t.borders.assign({fill:'#FFFFFF',width:2,style:'solid'});
 t.rows[0].height=44;t.rows[1].height=96;t.rows[2].height=96;
 for(let r=0;r<3;r++)for(let c=0;c<3;c++){const a=t.getCell(r,c);a.fill=r===0?C.blue:r===1?C.pale:'#F5F7FA';a.text.style={fontSize:r===0?'18pt':'19pt',fontFamily:'Microsoft YaHei',bold:r===0||c===0,color:r===0?'#FFFFFF':C.ink,insets:13,verticalAlignment:'middle'};}
 return t;
}
export async function revise({presentation:p,input}){
 if(input.start===0)p.slides.delete(p.slides.items.map((_,i)=>i));
 for(let i=input.start;i<input.end;i++){
  if(i===0){const s=head(p,'TAM  |  CoRL 2026','TAM：保留原策略，修正执行偏差','问题：负载、摩擦等变化后，同一条控制指令不再产生预期运动。',1);
   image(s,'fig1',58,225,742,260);
   tx(s,'方法与技术',840,227,365,34,22,true,C.blue);
   tx(s,'Transformer 编码关节历史，\nMLP 预测力矩修正。\n理想模型提供动力学参考。',840,278,365,117,19);
   tx(s,'仿真监督学习；可做 DAgger 微调。\n上层可保留 RL、BC 或 MPC。',840,421,365,74,17,false,C.muted);
   tx(s,'输入：标称力矩 + 关节位置、速度及力矩历史\n输出：逐关节修正力矩 Δτ，叠加后限幅执行',60,506,1150,68,19);
   tx(s,'贡献：把适应放到共同的力矩接口，减少对具体任务策略的依赖。',60,586,1150,36,21,true,C.blue);
   tx(s,'实验：Panda 推箱、翻块、球盘平衡与跟踪；仿真跨机械臂、参数突变及消融。\n实机推箱成功率 47.6% → 76.2%；对照包括直接执行、在线系统辨识和 RMA。',60,637,1150,53,17);
   s.speakerNotes.text='TAM 研究的是动力学差异造成的执行偏差。它放在低层控制器之后，历史 Transformer 从关节状态与过去力矩中提取特征，MLP 再根据当前标称力矩算出修正。MLP 可以理解为普通前馈神经网络。理想动力学模型还用于构造参考和物理残差。TAM 主要通过仿真中的正确力矩标签做监督学习，DAgger 微调则补充 TAM 自身执行后遇到的数据，不是部署时实时做 PPO。上层策略可以来自强化学习、行为克隆或模型预测控制。它的贡献是将适应与任务策略分开。原文在 Panda 上测试了推箱、翻块、球盘平衡和轨迹跟踪，推箱成功率由 Direct 的 47.6% 提高到 76.2%，Online SysID 为 57.1%。RMA 只在适用任务中比较，不应理解成每项任务都有这条基线。仿真还包括跨机械臂、动力学突变和结构消融。\n\n来源：'+TAM+'，Figures 1–4、Table 1、Appendix F。\n代码：https://github.com/Dongwon-Son/TAM';
  }
  if(i===1){const s=head(p,'TAM  |  复现与迁移','TAM：UR7e 更接近原设定，Go2-W 需要扩展','迁移判断针对方法与接口；不代表原权重能直接用于两个目标平台。',2);
   tx(s,'复现条件',60,231,220,34,22,true,C.blue);
   tx(s,'官方提供数据生成、训练、仿真评测与部署服务；机器人侧低层控制桥接未公开。\n原训练栈为 MuJoCo / MJX + JAX；需要目标机器人模型与对应训练数据。',60,277,1150,57,18);
   migration(s,[['UR7e','建立 6 关节标称力矩与理想模型；\n核对力矩接口、重力补偿和控制周期。','中等：同类机械臂迁移\n需微调评估与实机桥接'],['Go2-W','接入 16 执行器及健康运动控制；\n扩展浮动基座、轮地接触参考与训练数据。','较高：涉及方法扩展\n原机械臂权重不能直用']]);
   tx(s,'局限',60,605,180,34,22,true,C.blue);
   tx(s,'依赖可用的理想模型；接触与外力可能混淆估计。\n局部响应对齐不能保证任意故障下稳定恢复，补偿也受剩余力矩能力限制。',60,645,1150,53,18);
   s.speakerNotes.text='TAM 有作者官方代码，包含数据生成、训练、微调、仿真评测和工作站侧部署服务，但官方文档明确指出机器人侧低层控制桥接未提供。需要区分复现原仿真和完成目标平台部署。表中的难度是本项目的相对工程判断，不是作者实验结论。UR7e 与原机械臂设定接近，需要建立六关节标称力矩、理想模型和接口桥接，核对自动重力补偿、顺序、单位及控制周期；之后评价原权重与仿真微调。Go2-W 虽有 SDK 力矩通道，但要保留可用的健康运动控制，再扩展十六执行器、浮动基座和接触的参考与训练。已有物理仿真可以复用，不需要从零推导全部动力学，但只有关节数量对应并不足够。原文存在动力学突变恢复的仿真证据，不能据此认为轮锁死或支撑失效已解决。论文 HTML 附录 G 提供有条件的误差有界分析，并非任意接触或故障下的稳定、安全和任务保证。\n\n论文：'+TAM+'，§§2、4.4、5，Appendices D、G。\n部署：https://github.com/Dongwon-Son/TAM/blob/main/docs/deployment.md\nUR：https://docs.universal-robots.com/Universal_Robots_ROS2_Documentation/rolling/doc/ur_robot_driver/ur_robot_driver/doc/usage/force_torque_control.html\nGo2-W：https://github.com/unitreerobotics/unitree_sdk2/blob/main/example/go2w/go2w_stand_example.cpp';
  }
  if(i===2){const s=head(p,'GRAM  |  RA-L 2026','GRAM：兼顾适应性能与分布外鲁棒性','问题：历史估计在陌生条件下可能失准；只追求鲁棒又容易过于保守。',3);
   image(s,'gram_fig2',58,225,664,272);
   tx(s,'方法与技术',768,227,440,34,22,true,C.blue);
   tx(s,'PPO 训练 MLP 控制策略。\n教师—学生训练历史适应模块。\nEpinet 估计推断的不确定性。\n对抗训练学习鲁棒行为。',768,278,440,137,19);
   tx(s,'估计不确定时，内部表示偏向\n训练好的鲁棒表示；仍是同一策略。',768,439,440,62,17,false,C.muted);
   tx(s,'输入：关节状态、机身角速度、重力方向、运动指令及近期历史\n输出：12 个关节位置目标，再由 PD 控制器执行',60,513,1150,65,19);
   tx(s,'贡献：让一个策略根据估计的可靠程度，兼顾适应与鲁棒控制。',60,587,1150,35,21,true,C.blue);
   tx(s,'实验：Go2 仿真对比、训练范围与消融；实机 7 种场景、105 次受控试验及户外测试。\n困难场景成功率：GRAM 15/15，鲁棒 RL 12/15，上下文适应 RL 2/15。',60,637,1150,54,17);
   s.speakerNotes.text='GRAM 研究的是历史适应何时可信。熟悉条件下，策略利用历史估计来针对当前条件调整动作；条件陌生、估计不确定时，策略更多采用已训练的鲁棒行为。这里不是另外学习一个故障标签，也不是两个独立控制器简单切换，而是调整同一个策略的内部条件表示。涉及四项技术：PPO 用回报训练动作策略；教师—学生训练先利用仿真已知条件，再让学生从历史推断；Epinet 用一组内部估计的分歧衡量不确定性；对抗训练故意制造困难，学习鲁棒行为。部署时权重固定，不实时执行 PPO。输入是本体状态、运动指令与历史，输出是普通 Go2 的十二关节位置目标，由 PD 转为力矩。实验分仿真和实机；仿真包括方法比较、训练分布变化和消融，另分析十秒时加九公斤后的适应权重。实机有七种场景，每场景每方法五次、三种方法，共一百零五次，另有户外定性测试。三种困难场景为九公斤负载、湿滑地面和坡道进入泡沫地面；十五次成功并不是任意故障下的百分之百保证。\n\n来源：'+GRAM+'，Figure 2、§§IV–VIII、Tables III–V。\n代码：https://github.com/merlresearch/gram';
  }
  if(i===3){const s=head(p,'GRAM  |  复现与迁移','GRAM：Go2-W 接口较近，UR7e 需重建任务','可以复用适应框架；两个平台分别建立任务并训练，不要求共享同一套权重。',4);
   tx(s,'复现条件',60,231,220,34,22,true,C.blue);
   tx(s,'官方提供 Go2 训练、评估及基线；原任务复现路径明确。\n依赖 Isaac Lab 1.0、Isaac Sim 4.1 和 rsl_rl 2.0，需检查与服务器的兼容性。',60,277,1150,57,18);
   migration(s,[['Go2-W','增加轮状态，输出腿位置与轮速度目标；\n调整奖励、执行器限制与扰动，重新训练。','中等：轮足任务扩展\n保留原方法，修改任务'],['UR7e','建立机械臂观测、任务与位置 / 速度动作；\n重新设计训练条件、奖励及对抗扰动。','较高：跨任务迁移\n接触与恢复需重新验证']]);
   tx(s,'局限',60,605,180,34,22,true,C.blue);
   tx(s,'鲁棒能力仍受训练覆盖限制；不确定性并不直接说明故障类型。\n原文主要验证普通 Go2，未覆盖轮足与机械臂；恢复时间等过程指标还需补充。',60,645,1150,53,18);
   s.speakerNotes.text='GRAM 的公开代码有较明确的训练和评估路径，还包含域随机化、上下文策略、鲁棒 RL 和消融，有利于做公平比较。但原软件依赖较旧，运行前要验证服务器兼容性，不能把公开代码等同于已在本项目完成训练。Go2-W 与 Go2 同属四足平台，本体感知与腿关节控制比较接近。拟议方案是补充轮状态，输出十二个腿位置目标和四个轮速度目标，并重新训练轮足任务。UR7e 可以沿用历史适应、不确定性和鲁棒联合训练的框架，但机械臂任务、奖励和接触明显不同，需要重新建立环境与训练。两者不必采用 TAM 那样的直接关节力矩边界，也不能直接复用原 Go2 权重。原文明确承认极端分布外条件仍可能失败；从方法看，不确定性不是精确故障诊断。论文主要关注泛化任务表现，我们若研究运行中恢复，还需要增加恢复时间、扰动后累计误差等过程指标。表中的难度与方案为本项目迁移评估，不是原文已经完成的实验。\n\n论文：'+GRAM+'，§§VII–IX。\n官方实现与环境：https://github.com/merlresearch/gram';
  }
 }
 return {slides:p.slides.items.length,range:[input.start,input.end]};
}
