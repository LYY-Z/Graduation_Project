const C={ink:'#142D50',blue:'#195FC0',light:'#EDF4FC',line:'#CCD9E9',muted:'#526780',teal:'#117B82',orange:'#B76A22',white:'#FFFFFF'};
const ROOT='G:/毕设/02_learning/04_review/.build_tam';
const PAPER='https://arxiv.org/html/2606.06218v3';
const REPO='https://github.com/Dongwon-Son/TAM';
function text(s,t,x,y,w,h,size=20,bold=false,color=C.ink,align='left'){
 const a=s.shapes.add({geometry:'textbox',position:{left:x,top:y,width:w,height:h},fill:'none',line:{fill:'none',width:0}});
 a.text=t;a.text.style={fontSize:`${size}pt`,fontFamily:'Microsoft YaHei',bold,color,alignment:align,verticalAlignment:'top',wrap:'word',insets:0};return a;
}
function rect(s,x,y,w,h,fill=C.light,line='none'){return s.shapes.add({geometry:'rect',position:{left:x,top:y,width:w,height:h},fill,line:{fill:line,width:line==='none'?0:1}});}
function node(s,title,body,x,y,w=245,h=122,fill=C.light){const a=rect(s,x,y,w,h,fill);text(s,title,x+18,y+18,w-36,36,21,true);if(body)text(s,body,x+18,y+59,w-36,h-63,17,false,C.muted);return a;}
function arrow(s,a,b,from='right',to='left',color=C.blue){return s.shapes.connect(a,b,{kind:from==='right'&&to==='left'?'straight':'elbow',fromSide:from,toSide:to,line:{fill:color,width:2.5},head:{type:'triangle',width:'med',length:'med'}});}
function img(s,name,x,y,w,h){s.images.add({path:`${ROOT}/${name}.png`,alt:`TAM 原论文 ${name}`,fit:'contain',position:{left:x,top:y,width:w,height:h}});}
function base(p,i,title,kicker){let s;if(i===0){s=p.slides.getItem(0);for(const a of [...s.shapes.items])a.delete();}else s=p.slides.add({width:1280,height:720});s.background.fill=C.white;
 if(i>0){text(s,kicker,58,26,1100,25,12,true,C.blue);text(s,title,58,68,1160,68,31,true);rect(s,58,149,1164,2,C.line);}
 text(s,'TAM · 方法与平台迁移',58,679,900,22,11,false,C.muted);text(s,String(i+1).padStart(2,'0')+' / 13',1112,679,110,22,11,false,C.muted,'right');return s;}
function takeaway(s,t){rect(s,58,603,1164,53,C.light);text(s,t,76,615,1128,34,19,true,C.blue);}
function notes(s,t,refs=PAPER){s.speakerNotes.text=t+'\n\n参考资料：\n'+refs;}
function row(s,ys,cols,values,highlight=false){cols.forEach((c,j)=>{rect(s,c.x,ys,c.w,58,highlight?C.light:(Math.round(ys)%2? '#F6F8FB':C.white));text(s,values[j],c.x+14,ys+15,c.w-28,36,18,highlight,highlight?C.blue:C.ink);});}

export async function build({presentation:p,input}){
 for(let i=input.start;i<input.end;i++){
  if(i===0){const s=base(p,0);text(s,'PAPER STUDY  /  ROBOT MOTION CONTROL',60,38,1150,28,13,true,C.blue);
   text(s,'TAM',58,100,560,110,72,true);text(s,'论文学习与平台迁移分析',62,221,1120,65,34,true);
   text(s,'力矩适配如何工作？\n能否接到 UR7e 与 Go2-W？',64,319,480,126,24,false,C.muted);
   img(s,'fig3',577,315,640,258);
   rect(s,62,563,457,3,C.blue);text(s,'问题 → 方法 → 实验证据 → 迁移判断',64,590,1060,43,21,true,C.blue);
   notes(s,'这次主要围绕两个问题展开。第一，TAM 是如何在不修改上层策略的情况下，修正机器人实际运动的。第二，这种方法能否迁移到我们的 UR7e 和 Go2-W。前半部分介绍论文已经验证的内容，后半部分分析两个平台需要满足什么条件。重点不是看到力矩接口就判断可以直接使用，而是把从策略到机器人反馈的整条链路理清楚。本报告采用 arXiv v3 正文及补充材料，检索日期为 2026 年 11 月 23 日。右图为原文 Figure 3，展示 Panda 实机任务。');
  }
  if(i===1){const s=base(p,i,'研究问题：策略没变，为什么机器人运动变了？','01  问题与贡献');
   const a=node(s,'上层给出同一目标','例如：机械臂移动到同一位置',64,210,339,125);
   const b=node(s,'真实机器人条件不同','负载、摩擦、质量或执行器响应变化',468,210,339,125);
   const c=node(s,'实际动作发生偏差','轨迹与接触时机改变，任务可能失败',872,210,339,125);arrow(s,a,b);arrow(s,b,c);
   text(s,'常见处理',64,389,240,35,21,true);text(s,'策略侧适应',64,446,260,32,21,true);text(s,'让策略根据历史改变动作\n通常需要接入或重新训练策略',64,493,450,78,18,false,C.muted);
   text(s,'TAM 的选择',639,446,400,32,21,true,C.blue);text(s,'在底层力矩处修正响应\n尽量复用已有 RL、BC 或 MPC',639,493,540,78,18,false,C.muted);
   takeaway(s,'贡献：把适应模块放在策略和控制器之后，减少它与具体任务的绑定。');
   notes(s,'TAM 研究的是动力学不一致造成的运动迁移问题。比如原来的策略能把方块推到目标处，但机械臂增加负载后，同一条指令不一定再产生同样的运动，接触时机也可能改变。已有方法可以在策略内部加入适应分支，也可以在线辨识物理参数。TAM 换了一个位置：保留上层任务策略，在底层控制器已经算出力矩之后，再修正发给机器人的力矩。它的主要价值是复用不同来源的策略，而不是重新训练一个能完成所有任务的策略。接下来先看它在控制链中的具体位置。');
  }
  if(i===2){const s=base(p,i,'核心方法：在低层控制器之后修正力矩','02  TAM 放在什么位置');
   img(s,'fig1',64,178,1150,403);
   text(s,'任务策略',76,553,245,33,18,true,C.blue);text(s,'转换成标称力矩',352,553,328,33,18,true,C.blue);text(s,'叠加修正，再执行',802,553,385,33,18,true,C.blue);
   takeaway(s,'任务目标与上层策略保持原样；TAM 输出的是每个关节的修正力矩 Δτ。');
   notes(s,'这是原论文 Figure 1。按从左到右的顺序看，RL、行为克隆或者 MPC 先给出任务动作，它可以是关节位置，也可以是末端目标。低层控制器把这些目标转换成标称力矩，也就是没有 TAM 时本来要发出的力矩。TAM 根据当前标称力矩、近期状态和历史特征，输出一组修正力矩。两者相加并限幅后，才交给真实机器人。机器人执行后的关节位置、速度和已发出的力矩又进入历史。图中的理想机器人是运动响应的参考，不是每一步都要在现场同时控制第二台机器人。论文在 Panda 上采用约 5 Hz 的历史编码和 1 kHz 的力矩适配；这是原平台设置，不能直接当成我们平台已实现的频率。');
  }
  if(i===3){const s=base(p,i,'输入输出：TAM 读的是执行历史，改的是力矩','03  一次控制计算');
   const a=node(s,'历史记录','关节位置 q、速度 q̇\n过去发出的力矩 τᵃ',64,213,318,151);
   const b=node(s,'历史编码器','把一段执行过程\n压缩成特征 z',465,213,318,151);arrow(s,a,b);
   const c=node(s,'力矩适配器','近期状态 + z + 当前 τ⁰\n输出修正 Δτ',868,213,344,151);arrow(s,b,c);
   rect(s,64,411,1148,120,C.light);text(s,'执行命令 = 限幅（标称力矩 τ⁰ + 修正力矩 Δτ）',88,439,1100,54,28,true,C.blue);
   text(s,'上层相机、目标与奖励仍由任务策略使用；TAM 不直接读取这些任务信息。',67,555,1145,34,18,false,C.muted);
   takeaway(s,'N 个受控关节 → N 个标称力矩 → N 个修正力矩；顺序、单位与时间必须对齐。');
   notes(s,'这里把 TAM 的输入和输出单独拆出来。历史不是图片序列，也不是任务指令的文本，而是一段关节位置、关节速度和过去施加的力矩。编码器把这些数据压缩成一个表示当前动力学条件的特征。快速适配器再结合近期状态和本次标称力矩，给每个关节算一个修正值。需要注意，论文历史中的 applied torque 记为限幅后发送的执行器命令，并不意味着部署时需要外部力矩传感器提供精确的净关节力矩。实际平台还要核对电流估计、反馈力矩和命令力矩的含义。相机和任务目标仍可能是上层策略的输入，但不是 TAM 的直接输入。下面解释为什么还有理想模型。');
  }
  if(i===4){const s=base(p,i,'理想模型的作用：给历史反馈提供比较依据','04  为什么只有力矩接口还不够');
   const a=node(s,'记录真实执行','发出了多少力矩？\n关节实际怎样运动？',64,205,340,141);
   const b=node(s,'查询理想模型','要产生这段实测运动，\n理想模型需要多少力矩？',470,205,340,141);arrow(s,a,b);
   const c=node(s,'计算物理残差','已发力矩 − 理想所需力矩\n作为额外历史特征',876,205,336,141);arrow(s,b,c);
   rect(s,64,390,1148,75,C.light);text(s,'eτ = τᵃ − Φ₀(q, q̇, 估计加速度, 0)',88,407,1095,44,27,true,C.blue);
   text(s,'身体耦合与接触改变实测运动，也影响理想模型能否给出有意义的参考。',67,500,1142,70,21,true);
   takeaway(s,'反馈告诉模型“发生了什么”；理想模型帮助判断“与参考相比差了多少”。');
   notes(s,'你之前问，身体运动、关节耦合和接触是不是主要影响执行后的反馈。可以这样理解第一步：它们确实会影响机器人怎样运动，因而改变记录到的关节状态。但是还有第二步，TAM 会把实测运动交给理想逆动力学模型，估计理想情况下产生这段运动需要多少执行器命令，再与已发命令相减。这个差值就是物理残差特征。公式最后的 0 表示这一特征计算不输入未知外部力矩，因此它不等于精确识别出的故障力矩。接触与负载可能混在反馈中，论文也将这种混淆列为局限。理想模型不需要手工逐项推导，可以调用仿真或动力学库，但模型和执行器命令必须对应。对 Go2-W 扩展时还要考虑浮动基座与接触，不能只把机械臂函数的输入长度改成 16。');
  }
  if(i===5){const s=base(p,i,'训练学会如何修正，运行时用历史判断当前条件','05  训练与部署分开理解');
   img(s,'fig2',64,191,682,270);
   text(s,'仿真训练',800,196,380,38,23,true,C.blue);text(s,'随机改变摩擦、负载与执行器参数\n用理想模型和扰动模型生成正确力矩\n训练预测修正量；再做目标机器人微调',800,250,405,176,18,false,C.ink);
   const a=node(s,'多机器人预训练','学习可共享的修正能力',64,488,336,92);const b=node(s,'目标机器人仿真微调','适应该平台的响应范围',470,488,336,92);const c=node(s,'部署：参数固定','历史与特征持续更新',876,488,336,92);arrow(s,a,b);arrow(s,b,c);
   takeaway(s,'TAM 本身主要做监督学习；上层策略可以来自强化学习，但部署时不是每步做 PPO。');
   notes(s,'图中是原论文的数据生成与训练流程。训练先在仿真中随机改变机器人的物理参数，让控制器执行多样的关节运动。仿真知道理想模型和扰动后的模型，因此能计算理想响应对应的正确修正力矩，作为监督标签。TAM 通过预测这个标签进行训练，主要使用 Huber 损失，不是依靠任务奖励训练一个行走策略。论文采用多机器人预训练，再在目标机器人仿真中微调，Panda 实机任务复用微调后的同一套 TAM。部署时网络权重固定，变化的是历史数据与推断出的特征。最新版还增加仿真 DAgger 微调：让 TAM 控制仿真、收集其自身执行后的历史，再用仿真教师补充标签；不是让真实机器人每一步在线反向传播。');
  }
  if(i===6){const s=base(p,i,'实验证据：同一 TAM 接到不同类型的任务策略','06  实机任务与基线');
   img(s,'fig3',64,179,1150,272);
   const cols=[{x:64,w:364},{x:428,w:245},{x:673,w:260},{x:933,w:279}];
   rect(s,64,464,1148,46,C.blue);['Panda 实机任务','Direct','Online SysID','TAM'].forEach((t,j)=>text(s,t,cols[j].x+14,475,cols[j].w-25,30,17,true,C.white));
   row(s,513,cols,['RL 推箱成功率','47.6%','57.1%','76.2%'],true);
   takeaway(s,'另两项结果：BC 翻块 72.0%；MPC 平衡 13.6 ± 2.9 个目标 / 15 s。');
   notes(s,'实验首先回答可复用性：同一套在 Panda 仿真中微调的 TAM，分别接到强化学习推箱、行为克隆翻块、MPC 托盘平衡和负载轨迹跟踪。原图上排是没有 TAM，下排是加入 TAM。推箱的实机成功率从 Direct 的 47.6% 提高到 76.2%，在线系统辨识为 57.1%，对应提升 28.6 和 19.1 个百分点。翻块实验 TAM 为 72.0%，Direct 为 50.0%，Online SysID 为 34.0%；平衡实验是 15 秒到达的目标数量，分别为 13.6、8.8 和 13.1。不同任务采用不同指标，不能把这些数放在同一排名里比较。Direct 表示原控制器直接执行，Online SysID 先在线估计显式参数再计算修正。数据是原文结果，不是我们的复现结果。');
  }
  if(i===7){const s=base(p,i,'运行中突变：最新版已给出恢复实验','07  恢复能力与证据范围');
   img(s,'fig4',64,198,684,355);
   text(s,'仿真中途切换动力学参数',800,201,408,60,23,true);text(s,'原版 TAM：恢复约 4.6 s\nDAgger 两种变体：约 1.7 s',800,287,408,99,22,true,C.blue);
   text(s,'20 条随机轨迹\n观察关节位置 RMSE\n恢复包括切换后的轨迹追赶',800,422,408,119,18,false,C.muted);
   takeaway(s,'它证明了该仿真设置中的恢复能力；尚不能推出轮锁死、失去支撑等故障均可处理。');
   notes(s,'这页是核对最新版论文后补充的重要内容。v3 的第 4.4 节在运行中突然切换仿真动力学参数，并在 20 条随机轨迹上评价关节位置误差。原版 TAM 恢复到其稳态误差水平约需 4.6 秒；只做 DAgger 微调，以及增加 TAM 历史修正力矩输入的 DAgger 变体，都约需 1.7 秒。两个微调变体的稳态误差分别为 1.10 度和 0.64 度，原版约 1.83 度。这里恢复阈值按原版 TAM 的稳态水平定义，而且包含轨迹追赶，并不是所有扰动下的通用恢复时间。这个结果说明 TAM 与我们的恢复方向相关，但轮锁死、打滑、支撑丢失和执行器完全失效仍需要分别设计实验，不能据此直接宣称已覆盖。');
  }
  if(i===8){const s=base(p,i,'不同关节数：共享计算，但不是任意本体即插即用','08  输入输出如何迁移');
   const a=node(s,'6 自由度机械臂','6 组关节历史 + 6 个 τ⁰',64,213,329,126);const b=node(s,'共享编码与适配权重','按关节生成特征与修正量',468,213,329,126);const c=node(s,'6 个修正力矩','按该机器人关节顺序执行',872,213,339,126);arrow(s,a,b);arrow(s,b,c);
   const d=node(s,'7 自由度机械臂','7 组关节历史 + 7 个 τ⁰',64,381,329,126);const e=node(s,'相同计算方式','使用前 7 个关节编号嵌入',468,381,329,126);const f=node(s,'7 个修正力矩','无需另设机器人专用输出头',872,381,339,126);arrow(s,d,e);arrow(s,e,f);
   text(s,'原文以关节索引匹配串联机械臂；目标机器人仍使用自己的理想模型与力矩限值。',66,544,1146,42,18,false,C.muted);
   takeaway(s,'Go2-W 的 16 个执行器不是“补到 16 维”就能使用：编号容量、语义和训练范围都需扩展。');
   notes(s,'原文补充材料 D.2.1 写明，网络不是给每台机器人单独建立一个输出头。每个关节的历史生成 token，共享的编码器与适配器逐关节计算，输出 N 维修正。6 关节使用前 6 个编号嵌入，7 关节使用前 7 个。跨关节联系通过历史 Transformer 和全局汇总进入计算。但这种索引匹配基于串联机械臂大致可比的关节顺序，并不自动建立腿、轮与机械臂之间的语义对应。超过配置允许的最大关节数，还要扩展嵌入表并训练或微调。每台机器人还需要自己的理想模型与执行器限值。因此有共享结构，和原始权重能直接控制 16 执行器 Go2-W，是两回事。');
  }
  if(i===9){const s=base(p,i,'UR7e：更接近原设定，先核对完整力矩链路','09  机械臂迁移方案');
   const a=node(s,'现有任务策略','关节目标 / 末端目标',64,204,245,110);const b=node(s,'UR7e 控制器','结合 q、q̇ 算 6 个 τ⁰',365,204,245,110);const c=node(s,'TAM + 限幅','得到 6 个力矩命令',666,204,245,110);const d=node(s,'UR 力矩接口','执行并返回关节状态',967,204,245,110);arrow(s,a,b);arrow(s,b,c);arrow(s,c,d);
   text(s,'模型与数据',65,374,460,40,22,true,C.blue);text(s,'UR7e 理想动力学与执行器命令定义\n六关节顺序、方向、单位和采样时间\nUR7e 仿真数据与微调效果',65,435,524,135,19,false,C.ink);
   text(s,'控制接口',661,374,530,40,22,true,C.blue);text(s,'直接关节力矩，不是 TCP 运动接口\n核对控制器 / 驱动版本与实际频率\n对齐自动重力补偿与力矩反馈语义',661,435,550,135,19,false,C.ink);
   takeaway(s,'判断：机械臂内迁移较有基础；官方仓库尚未提供完整 UR7e 实机接入。');
   notes(s,'UR7e 与论文机械臂设定比较接近，但我们之前通过 RTDE 发送 TCP 位姿或速度，不等于已经具备 TAM 所需的力矩接入。需要有一个在 UR7e 理想模型上工作的低层控制器，能算出六关节标称力矩，再让 TAM 修正并通过兼容接口执行。官方 UR ROS 2 文档目前说明 forward_effort_controller 需要 PolyScope 5.25.1 或更高，或 PolyScope X 10.12.1 或更高。direct_torque 接口带自动重力补偿，因此不能把包含重力的总力矩未经转换直接重复发送。力矩反馈也要区分真实力矩与旧版本的电流字段。这里是迁移条件分析，未在本次制作过程中核验现场控制器版本。下一页看 Go2-W 为什么更复杂。',PAPER+'\nhttps://docs.universal-robots.com/Universal_Robots_ROS2_Documentation/rolling/doc/ur_robot_driver/ur_robot_driver/doc/usage/force_torque_control.html');
  }
  if(i===10){const s=base(p,i,'Go2-W：有力矩通道，还需可用的标称运动与参考模型','10  轮足平台迁移方案');
   const a=node(s,'健康轮足控制策略','腿关节位置目标\n轮子速度目标',64,210,245,133);const b=node(s,'低层控制器','位置 / 速度误差\n转换成 16 个 τ⁰',365,210,245,133);const c=node(s,'扩展后的 TAM','16 个修正 Δτ\n相加并限幅',666,210,245,133);const d=node(s,'Go2-W 与地面','身体运动、关节耦合\n支撑和轮地接触',967,210,245,133);arrow(s,a,b);arrow(s,b,c);arrow(s,c,d);
   rect(s,65,404,1146,151,C.light);text(s,'身体与接触为什么不能忽略？',87,422,1090,38,24,true,C.blue);
   text(s,'① 它们改变执行后的反馈：同样轮速或力矩，可能产生不同车体运动。\n② 它们改变理想参考：轮足系统不能直接使用固定基座机械臂的动力学计算。',87,479,1090,76,19,false,C.ink);
   takeaway(s,'TAM 负责修正已有运动的动力学响应；健康状态下怎样站稳、行走，仍由原控制系统负责。');
   notes(s,'Go2-W 有 12 个腿部关节和 4 个轮执行器。官方 SDK2 提供 q、dq、kp、kd 和 tau 等低层命令字段，但腿位置加轮速度的命令模式并不自动等于 TAM 已需要的纯力矩边界。我们需要明确原控制器算出的标称力矩是什么，实际执行命令和历史记录又是什么。图中的流程是拟议方案，不是原论文已经完成的部署。可以复用健康状态下的轮足控制策略，让它决定怎么走，TAM 只修正动力学响应。身体和接触一方面改变执行反馈；另一方面，计算理想响应与物理残差时也需要一致的浮动基座和接触处理。不是要求一开始手推全部动力学、自己从零写行走策略，或一定训练单独的打滑分类器。可以依靠已有仿真与控制栈，但要扩展并验证 TAM 的参考计算和训练数据。',PAPER+'\nhttps://github.com/unitreerobotics/unitree_sdk2/blob/main/example/go2w/go2w_stand_example.cpp');
  }
  if(i===11){const s=base(p,i,'已有仿真模型有价值，但它只是迁移的起点','11  从资产到可验证方案');
   text(s,'可以复用的基础',65,197,510,41,24,true,C.blue);text(s,'关节结构、运动关系与执行器定义\n质量惯量、轮地碰撞与接触仿真\n已有健康运动策略及控制器',65,263,535,153,20,false,C.ink);
   text(s,'还要补齐的 TAM 部分',664,197,545,41,24,true,C.blue);text(s,'标称力矩与历史数据的统一接口\n轮足理想响应 / 物理残差计算\n扰动数据、模型扩展与效果验证',664,263,545,153,20,false,C.ink);
   const a=node(s,'先跑通健康运动','验证模型与控制器',64,457,245,101);const b=node(s,'记录力矩与响应','核对输入输出合同',365,457,245,101);const c=node(s,'再训练 / 接入 TAM','先做局部响应对齐',666,457,245,101);const d=node(s,'最后测试扰动恢复','逐项评价恢复边界',967,457,245,101);arrow(s,a,b);arrow(s,b,c);arrow(s,c,d);
   takeaway(s,'有物理仿真模型确实解决了一部分问题；还需要让参考模型、训练标签与实机接口一致。');
   notes(s,'你之前问，有 Go2-W 仿真模型是不是已经解决一部分问题。答案是肯定的。可用的物理模型能够提供关节结构、惯量、执行器和接触模拟；如果还有健康运动策略，可以继续复用。但只有外观网格或者运动学 URDF，还不能保证动力学已经可靠。TAM 这边仍要把关节顺序、力矩、状态和时间戳对齐，定义轮足系统的理想响应与残差，然后生成扰动数据做训练或微调。合理顺序是先确认健康运动，再核对数据与力矩接口，之后评价局部运动响应，最后做中途扰动恢复。这样可以分清失败来自基础控制、接口错误，还是 TAM 本身。这里给的是迁移验证路线，不是当前已完成的实验。');
  }
  if(i===12){const s=base(p,i,'结论：适合参考力矩适配，但两个平台的迁移难度不同','12  复现价值与使用边界');
   const cols=[{x:64,w:256},{x:320,w:443},{x:763,w:449}];rect(s,64,193,1148,46,C.blue);['对象','已有基础','仍需完成'].forEach((t,j)=>text(s,t,cols[j].x+14,204,cols[j].w-28,30,18,true,C.white));
   row(s,242,cols,['官方 TAM','仿真数据生成、训练、评测与服务','实机低层控制桥接未随仓库提供']);
   row(s,301,cols,['UR7e','串联机械臂；状态与力矩接口基础','理想模型、命令语义与专用验证']);
   row(s,360,cols,['Go2-W','物理仿真与 SDK 低层执行器通道','浮动基座 / 接触扩展及适配训练']);
   text(s,'三个边界',67,460,275,40,23,true,C.blue);text(s,'局部运动对齐 ≠ 长时稳定保证\n软件限幅 ≠ 执行器失效后仍有足够控制能力\n机械臂上的证据 ≠ 任意轮足扰动已验证',338,460,856,114,21,true);
   takeaway(s,'选用 TAM 的关键：复用已有任务策略，同时具备可用的标称力矩、参考模型和反馈链路。');
   notes(s,'最后把方法价值与复现边界分开。TAM 已有官方代码，包含仿真数据生成、训练、微调、评测和工作站侧服务，比只有独立实现的论文更有复现基础。但官方部署文档明确说明，机器人侧低层控制桥接没有包含在仓库中，所以开源不等于整套实机系统可以直接启动。UR7e 属于更接近原设定的机械臂迁移；Go2-W 则涉及浮动基座、腿轮执行器和接触，是方法扩展。两者都必须核对标称命令与实际反馈。TAM 只保证训练目标意义上的局部响应对齐，没有形式化长时稳定保证。力矩限幅也不能补回已经完全失效的执行器能力。当前可以把 TAM 作为力矩适配的主要参考，但不能把它当作已验证的通用多扰动恢复器。',PAPER+'\n'+REPO+'\nhttps://github.com/Dongwon-Son/TAM/blob/main/docs/deployment.md');
  }
 }
 return {slides:p.slides.items.length,range:[input.start,input.end],sourceVersion:'arXiv v3, 2026-10-12'};
}
