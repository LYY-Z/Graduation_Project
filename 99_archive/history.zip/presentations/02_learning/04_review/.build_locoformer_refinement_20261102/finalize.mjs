import fs from 'node:fs/promises';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
const B='G:/毕设/02_learning/04_review/.build_locoformer_refinement_20261102';
const SKILL='C:/Users/laiyo/.codex/plugins/cache/openai-primary-runtime/presentations/26.1026.10807/skills/presentations';
process.env.RUNTIME_NODE_MODULES='C:/Users/laiyo/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules';
const {finalizePresentation}=await import(pathToFileURL(path.join(SKILL,'container_tools/artifact_tool_utils.mjs')).href);
const REF=path.join(B,'source.pptx');
const result=await finalizePresentation({
 workspaceDir:'G:/毕设',candidatePath:path.join(B,'candidate_repaired.pptx'),finalPath:path.join(B,'validated/locoformer_paper_report_v3.pptx'),
 pythonExecutable:'C:/Users/laiyo/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe',
 integrityValidatorPath:path.join(SKILL,'container_tools/inspect_presentation_package_integrity.py'),
 layoutValidatorPath:path.join(SKILL,'container_tools/inspect_presentation_layout_geometry.py'),
 explicitTotalSlideCount:14,requiredNativeChartOwnerSlides:[9],requiredNativeTableOwnerSlides:[13,14],
 layoutArgs:['--expected-slide-size-emu','12192000,6858000','--validate-bullet-geometry','--validate-heading-fit','--require-native-table-slide','13','--require-native-table-slide','14'],
 fontPolicy:{basis:'reference',families:['微软雅黑','Cambria Math'],referencePath:REF,referenceSha256:createHash('sha256').update(await fs.readFile(REF)).digest('hex')},
 verifyArtifactToolImport:true,receiptPath:path.join(B,'final.v3.validation.json')
});
console.log(JSON.stringify(result));
