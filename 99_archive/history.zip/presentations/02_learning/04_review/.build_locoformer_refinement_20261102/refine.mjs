import fs from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
import {PresentationFile,FileBlob} from '@oai/artifact-tool';

const WORK='G:/毕设';
const B=path.join(WORK,'02_learning/04_review/.build_locoformer_refinement_20261102');
const OLD=path.join(WORK,'02_learning/04_review/.build_locoformer_report_20261101');
const REF=path.join(B,'source.pptx');
const SKILL='C:/Users/laiyo/.codex/plugins/cache/openai-primary-runtime/presentations/26.1026.10807/skills/presentations';
const PY='C:/Users/laiyo/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe';
process.env.RUNTIME_NODE_MODULES='C:/Users/laiyo/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules';
const {finalizePresentation,applyPresentationChartFont}=await import(pathToFileURL(path.join(SKILL,'container_tools/artifact_tool_utils.mjs')).href);
const C={bg:'#F5F3F0',ink:'#252A31',body:'#434950',muted:'#646A70',wine:'#78394C',wineSoft:'#EFE7E9',gold:'#B58A4A',goldSoft:'#F3EEE3',green:'#78827B',greenSoft:'#E7EBE6',rule:'#D5D0C9',white:'#FFFFFF'};
const FONT='微软雅黑';
const assets=JSON.parse(await fs.readFile(path.join(OLD,'assets_manifest.json'),'utf8'));
const p=await PresentationFile.importPptx(await FileBlob.load(REF));
await fs.writeFile(path.join(B,'source-layout.ndjson'),(await p.inspect({kind:'layout',maxChars:50000})).ndjson??'');
const sourceSlides=[...p.slides.items];
// Reuse imported masters, cover, page furniture and the original editable chart.
const overview=sourceSlides[2].duplicate();
const ppo=sourceSlides[2].duplicate();
const appendixA=sourceSlides[2].duplicate();
const appendixB=sourceSlides[2].duplicate();
const desired=[sourceSlides[0],sourceSlides[1],overview,sourceSlides[2],sourceSlides[3],sourceSlides[4],ppo,sourceSlides[5],sourceSlides[6],sourceSlides[7],sourceSlides[8],sourceSlides[9],appendixA,appendixB];
const idRecords=(await p.inspect({select:'$.slides[*]',include:['id']})).records;
const canonical=new Map(p.slides.items.map((s,i)=>[s,idRecords[i].id]));
p.slides.reorder(desired.map(s=>canonical.get(s)));
const records=(await p.inspect({select:'$.slides[*]',include:['id','index','elements.id','elements.kind','elements.text','elements.position']})).records;

function text(s,value,x,y,w,h,size=21,color=C.body,bold=false,opts={}){
 const sh=s.shapes.add({geometry:'textbox',name:opts.name??value.slice(0,55),position:{left:x,top:y,width:w,height:h},fill:'none',line:{fill:'none',width:0}});
 sh.text=value;
 sh.text.style={typeface:opts.font??FONT,fontSize:size,color,bold,alignment:opts.align??'left',verticalAlignment:opts.valign??'middle',wrap:'square',autoFit:'none',insets:0};
 return sh;
}
function rect(s,x,y,w,h,fill=C.white,stroke=C.rule,lw=1){return s.shapes.add({geometry:'rect',name:'diagram region',position:{left:x,top:y,width:w,height:h},fill,line:{fill:stroke,width:lw,style:'solid'}});}
function rule(s,x,y,w,color=C.rule,h=1){return rect(s,x,y,w,h,color,'none',0);}
function line(s,x1,y1,x2,y2,color=C.gold,arrow=false,dashed=false){return s.shapes.add({geometry:'connector',name:arrow?'direction arrow':'diagram line',kind:'straight',position:{left:Math.min(x1,x2),top:Math.min(y1,y2),width:Math.abs(x2-x1),height:Math.abs(y2-y1),horizontalFlip:x2<x1,verticalFlip:y2<y1},line:{fill:color,width:1.8,style:dashed?'dashed':'solid'},tail:arrow?{type:'triangle',width:'sm',length:'sm'}:{type:'none'}});}
function connect(s,a,b,from='right',to='left',color=C.gold,dashed=false){return s.shapes.connect(a,b,{kind:from==='right'&&to==='left'?'straight':'elbow',fromSide:from,toSide:to,line:{fill:color,width:1.8,style:dashed?'dashed':'solid'},tail:{type:'triangle',width:'sm',length:'sm'}});}
function box(s,label,detail,x,y,w,h,fill=C.white,size=22){const sh=rect(s,x,y,w,h,fill);text(s,label,x+15,y+10,w-30,35,size,C.ink,true);if(detail)text(s,detail,x+15,y+51,w-30,h-59,18,C.muted,false,{valign:'top'});return sh;}
async function img(s,file,x,y,w,h){const [iw,ih]=assets[file],k=Math.min(w/iw,h/ih),dw=iw*k,dh=ih*k;return s.images.add({name:file,blob:new Uint8Array(await fs.readFile(path.join(OLD,'assets',file))),contentType:'image/png',alt:`LocoFormer 原文 ${file}`,position:{left:x+(w-dw)/2,top:y+(h-dh)/2,width:dw,height:dh},fit:'contain'});}
function takeaway(s,value,y=610,size=22){rule(s,66,y,5,C.wine,39);text(s,value,87,y-3,1124,45,size,C.ink,true);}
function subtitle(s,value){text(s,value,66,137,1144,39,22,C.wine,true);}
function notes(s,value){s.speakerNotes.text=value;s.speakerNotes.setVisible(false);}
function formula(s,value,x,y,w,h,size=30,color=C.ink){return text(s,value,x,y,w,h,size,color,false,{font:'Cambria Math'});}
function table(s,values,x,y,widths,h,size=19){
 const t=s.tables.add({rows:values.length,columns:values[0].length,left:x,top:y,width:widths.reduce((a,b)=>a+b,0),height:h,columnWidths:widths,values});
 t.borders.assign({fill:C.rule,width:.7,style:'solid'});
 for(let r=0;r<values.length;r++)for(let c=0;c<values[0].length;c++){
  const cell=t.getCell(r,c);cell.fill=r===0?C.wine:r%2?C.white:C.bg;
  cell.text.style={typeface:FONT,fontSize:size,color:r===0?C.white:C.body,bold:r===0,alignment:c===0?'left':'center',verticalAlignment:'middle',insets:8};
 }
 return t;
}
function base(i,title,source,{keepChart=false,subtitleText}={}){
 const s=p.slides.items[i],rec=records[i];const keep=new Set();
 for(const e of rec.elements??[]){const a=e.position??{};
  if(e.kind==='textbox'&&a.top<100){keep.add(e.id);const q=p.resolve(e.id);q.text=title;q.text.style={typeface:FONT,fontSize:38,bold:true,color:C.ink,insets:0,wrap:'square',autoFit:'none'};}
  else if(e.kind==='shape'&&Math.abs(a.top-113)<1&&a.height<4)keep.add(e.id);
  else if(e.kind==='textbox'&&/^\d\d \/ \d+$/.test(e.text??'')){keep.add(e.id);const q=p.resolve(e.id);q.text=i<12?`${String(i+1).padStart(2,'0')} / 12`:`补充 ${i===12?'A':'B'}`;q.position={left:1140,top:679,width:77,height:22};}
  else if(keepChart&&e.kind==='chart')keep.add(e.id);
 }
 const obsolete=(rec.elements??[]).filter(e=>!keep.has(e.id)).map(e=>e.id);if(obsolete.length)p.delete(obsolete);
 s.speakerNotes.clear();rule(s,64,668,1152);text(s,source,66,682,1058,18,12,C.muted);
 if(subtitleText)subtitle(s,subtitleText);
 return s;
}

// 01 Cover remains in the established report style.
{
 const s=p.slides.items[0];
 notes(s,'LocoFormer: Generalist Locomotion via Long-context Adaptation. Min Liu, Deepak Pathak, Ananye Agarwal. CoRL 2025, arXiv:2509.23745v1. 正文12页约10分钟。补充A/B用于问答，不计入主讲时间。叙事主线：为什么需要历史、如何收集和组织经历、如何训练和部署、实验支持什么结论。');
}

// 02 Problem and the information history provides.
{
 const s=base(1,'跨本体控制中的条件不确定性','来源：论文 §1、Figure 1；机制分析为汇报归纳',{subtitleText:'相近观测可能对应不同身体条件，动作后的响应提供进一步判断依据。'});
 await img(s,'figure1.png',651,197,553,365);
 const rows=[['身体与驱动变化','结构、质量、控制增益或关节状态改变，\n相同目标指令会产生不同身体响应。'],['当前观测提供状态','关节与身体状态描述“现在怎样”，\n未必足以判断异常来自何种条件。'],['历史提供交互证据','结合过去的控制与实际响应，\n逐步形成与当前身体相关的内部表示。']];
 for(let i=0;i<3;i++){const y=199+i*124;text(s,rows[i][0],76,y,520,34,24,C.ink,true);text(s,rows[i][1],76,y+42,520,64,20,C.body,false,{valign:'top'});if(i<2)rule(s,76,y+112,510);}
 text(s,'程序化身体训练，同一策略迁移至未见实机。',651,576,553,31,18,C.muted);
 takeaway(s,'多样化训练提供初始泛化能力，交互历史支持部署中的进一步调整。',615,21);
 notes(s,'来源：论文§1、§2.1、Figure1。问题分析：瞬时观测未必足以区分动力学条件，历史动作响应可提供信息。论文并未要求或验证策略准确显式恢复质量、惯量等物理参数。鲁棒性和适应性是相关但不同的性质，不声称前者只能由后者产生。');
}

// 03 New overview connects the entire report.
{
 const s=base(2,'训练与部署的完整流程','来源：论文 §§2.1–2.2；PPO流程按标准算法解释',{subtitleText:'训练通过奖励更新共享策略，部署通过持续交互更新历史表示。'});
 text(s,'训练阶段',72,195,170,35,25,C.wine,true);
 const top=[box(s,'任务采样','程序化身体\n动力学与控制条件',72,245,239,116),box(s,'闭环交互','策略选动作\n仿真返回状态与奖励',362,245,239,116),box(s,'保存一批经历','观测、动作、奖励\n旧概率与旧价值预测',652,245,239,116),box(s,'PPO 优化','重算输出与损失\n反向传播更新参数',942,245,267,116,C.wineSoft)];
 for(let i=0;i<3;i++)connect(s,top[i],top[i+1]);
 line(s,1075,361,1075,393,C.wine);line(s,481,393,1075,393,C.wine);line(s,481,393,481,361,C.wine,true);
 text(s,'更新后的策略继续采集新经历',516,397,502,25,18,C.wine);
 rule(s,72,428,1138);
 text(s,'部署阶段',72,452,170,35,25,C.green,true);
 const bottom=[box(s,'加载训练参数','固定网络权重 θ',72,501,239,97),box(s,'当前观测与历史','逐步读取并更新缓存',362,501,239,97),box(s,'当前动作输出','关节目标作用于身体',652,501,239,97),box(s,'新观测与新历史','响应信息进入下一步',942,501,267,97,C.greenSoft)];
 for(let i=0;i<3;i++)connect(s,bottom[i],bottom[i+1],'right','left',C.green);
 takeaway(s,'参数学习发生在 PPO 更新中，部署适应发生在固定参数的交互计算中。',618,21);
 notes(s,'来源：论文§2.1大规模PPO训练、Deployment，§2.2架构和推理加速。上半图是采集与优化交替，训练前向不会再执行保存的动作。下半图是固定权重的in-context adaptation，缓存数值随输入变化。未将第三方参考实现的12×256或4epochs冒充论文训练配置。建议主讲50秒，此页作为后续各机制的位置索引。');
}

// 04 Task, Trial, Episode, adaptation budget and curriculum.
{
 const s=base(3,'任务分布与跨 Trial 训练组织','来源：论文 §2.1、Eq. (1)、Appendix A',{subtitleText:'身体重置与历史保留分别控制物理尝试和信息积累。'});
 text(s,'任务 M：一种身体与控制条件',72,197,366,35,23,C.wine,true);
 text(s,'程序化生成双足、四足及轮足\n随机化关节结构、质量与惯量\n改变控制增益与关节限位等条件',72,249,366,107,21,C.body,false,{valign:'top'});
 text(s,'统一关节空间',72,392,366,34,23,C.ink,true);
 text(s,'策略输出统一关节目标，\n提取当前机器人对应的关节分量。',72,440,366,66,20,C.body);
 rule(s,466,200,1,C.rule,350);
 text(s,'同一任务内的一组经历 Episode',504,197,700,35,23,C.wine,true);
 text(s,'适应预算 u ~ Uniform(0, U)',504,244,700,31,21,C.muted);
 const a=box(s,'Trial 1','实际交互',504,300,183,109);
 const b=box(s,'Trial 2 …','重置身体\n保留历史',713,300,221,109,C.goldSoft);
 const c=box(s,'最终 Trial','继续利用\n此前经历',960,300,247,109,C.greenSoft);
 connect(s,a,b);connect(s,b,c);
 text(s,'预算内可运行若干 Trial，随后运行最终 Trial。\n切换到另一个 Episode 时，隔离原任务历史。',504,436,700,71,20,C.body);
 text(s,'目标：最大化整组经历的期望折扣回报。',504,514,700,31,20,C.wine,true);
 rule(s,72,550,1136);
 text(s,'训练先短后长',72,568,210,32,23,C.wine,true);
 text(s,'先用较短 Trial 和较小适应预算学习适应，再延长运行与交互时间。',298,568,908,36,21,C.body);
 takeaway(s,'Trial 是物理尝试，segment 是计算分块，两者边界不要求对齐。',619,21);
 notes(s,'来源：论文§2.1及AppendixA。形式目标先抽取k~Uniform(1,...,K)并累计整组Trial回报。实际训练改为抽取u~Uniform(0,U)，预算内任意若干Trial后最终Trial。时间预算版本完整奖励掩码未披露，不声称仅最终Trial参与训练。统一关节空间的最大槽位和完整映射未披露。任务参数与策略参数θ不同。');
}

// 05 One control step, with separate actor and critic uses.
{
 const s=base(4,'单步控制与 Actor–Critic 网络','来源：论文 §§2.1–2.2、Figure 3',{subtitleText:'共享历史特征支持动作选择和价值估计，实际身体响应闭合控制回路。'});
 const o=box(s,'当前观测 oₜ','统一关节表示',72,226,180,112);
 const m=box(s,'输入 MLP','观测编码为特征',289,226,180,112);
 const h=box(s,'Transformer-XL','读取历史，更新表示',506,226,246,112,C.wineSoft);
 const a=box(s,'Actor','动作分布\n抽取当前动作',789,226,184,112);
 const j=box(s,'关节目标','选取对应关节分量',1010,226,197,112,C.greenSoft);
 for(const [u,v]of[[o,m],[m,h],[h,a],[a,j]])connect(s,u,v);
 const mem=box(s,'历史缓存','各层已计算的信息',506,413,246,103,C.goldSoft);
 const v=box(s,'Critic','预测未来折扣回报',789,413,184,103);
 const e=box(s,'控制器与身体','执行并产生实际响应',1010,413,197,103);
 connect(s,mem,h,'top','bottom',C.wine);connect(s,h,v,'bottom','top',C.green);connect(s,j,e,'bottom','top');
 line(s,1108,516,1108,555,C.gold);line(s,162,555,1108,555,C.gold);line(s,162,555,162,338,C.gold,true);
 text(s,'身体响应成为下一步观测',284,522,405,28,18,C.muted);
 text(s,'Critic 提供训练评价，动作经底层控制器作用于身体。',72,581,1124,32,21,C.body);
 takeaway(s,'目标角度与实际角度的差异来自执行动力学，历史响应因此具有控制价值。',619,21);
 notes(s,'来源：论文§2.1统一空间、§2.2首段和Figure3。论文确认MLP编码、TXL共享主干、Actor/Critic MLP及目标关节位置输出。图将PPO策略动作分布与采样标为标准训练机制，未声称作者使用了第三方入口的Beta参数化。关节目标并非直接写入实际角度，执行器、负载、接触均影响响应。Critic不直接下控制指令。');
}

// 06 Segment: online sequential interaction, offline parallel causal processing, SG.
{
 const s=base(5,'分段记忆与因果计算','来源：论文 §2.2、Eqs. (2)–(4)；右侧为4步计算示意',{subtitleText:'采集逐步获得观测，训练整段并行计算，各位置始终只读取当前与过去。'});
 text(s,'采集：当前观测逐步到来',72,196,544,34,24,C.wine,true);
 text(s,'o₁',88,258,65,43,30,C.ink,false,{font:'Cambria Math'});text(s,'a₁',238,258,65,43,30,C.ink,false,{font:'Cambria Math'});text(s,'o₂',388,258,65,43,30,C.ink,false,{font:'Cambria Math'});
 line(s,159,279,224,279,C.gold,true);line(s,309,279,374,279,C.gold,true);
 text(s,'网络计算',153,304,100,29,17,C.muted);text(s,'环境执行',302,304,100,29,17,C.muted);
 text(s,'每一步立即输出动作，缓存持续追加。',72,354,544,31,21,C.body);
 rule(s,72,407,544);
 text(s,'跨段读取',72,428,544,34,24,C.wine,true);
 const b1=box(s,'旧段表示','SG 后保留数值',72,482,235,92,C.goldSoft);
 const b2=box(s,'当前段计算','读取历史并生成输出',345,482,271,92,C.wineSoft);
 connect(s,b1,b2);
 text(s,'截断旧生成链的梯度，保留历史对当前输出的影响。',72,585,544,49,19,C.body);
 rule(s,651,199,1,C.rule,437);
 text(s,'训练：保存好的观测整段输入',690,196,516,34,24,C.wine,true);
 text(s,'同一层的多个位置可通过矩阵运算并行。',690,245,516,31,20,C.body);
 const ox=825,oy=310,cell=49;
 text(s,'可读取的时间位置',813,278,342,26,17,C.muted);
 for(let c=0;c<4;c++)text(s,String(c+1),ox+c*cell,oy-6,cell,28,19,C.ink,true,{align:'center'});
 for(let r=0;r<4;r++){
  text(s,`输出${r+1}`,700,oy+32+r*cell,110,cell,19,C.body);
  for(let c=0;c<4;c++){rect(s,ox+c*cell,oy+32+r*cell,cell-3,cell-3,c<=r?C.wineSoft:C.white,C.rule,.7);text(s,c<=r?'可读':'屏蔽',ox+c*cell,oy+32+r*cell,cell-3,cell-3,15,c<=r?C.wine:C.muted,false,{align:'center'});}
 }
 text(s,'当前段生成 Q，历史与当前段提供 K、V。\n因果掩码阻止未来观测进入当前动作计算。',690,562,516,70,20,C.body);
 notes(s,'来源：论文§2.2 Eqs2–4与Inference Acceleration。4×4为教学示意，未声称段长为4。训练观测已收集，因果掩码允许并行处理时间位置；采集未来观测尚不存在，必须先动作再获得响应。PPO目标可使用后续奖励，但动作前向不能读取未来观测。SG只截断旧表示生成图，当前读取模块仍可训练。注意论文缓存hidden states，第三方参考实现缓存组织有所扩展，不能把具体KV结构等同Eq2。');
}

// 07 New PPO pipeline: rewards become targets, then current computations yield gradients.
{
 const s=base(6,'PPO：把交互结果转为参数更新','来源：论文 §2.1；GAE与裁剪目标为标准PPO训练机制解释',{subtitleText:'保存的经历提供固定参照，当前网络重新前向以计算损失与梯度。'});
 text(s,'从经历构造训练依据',72,196,470,34,24,C.wine,true);
 text(s,'奖励 r、旧价值预测 V̄、旧动作概率',72,243,504,34,21,C.body);
 formula(s,'δₜ = rₜ + γ V̄ₜ₊₁ − V̄ₜ',72,296,514,46,30);
 formula(s,'Âₜ = δₜ + γλ Âₜ₊₁',72,355,514,46,30);
 formula(s,'R̂ₜ = V̄ₜ + Âₜ',72,414,514,46,30);
 text(s,'δ：一步后的评价差异\nÂ：综合后续信息的优势\nR̂：Critic 的回报训练目标',72,490,514,99,20,C.body,false,{valign:'top'});
 rule(s,616,198,1,C.rule,390);
 text(s,'利用同一批经历优化当前网络',656,196,549,34,24,C.wine,true);
 const f=box(s,'重新前向','当前动作分布、当前价值输出',656,251,551,86,C.white,22);
 const al=box(s,'Actor 损失','新旧概率比与优势\n裁剪过大的有利推动',656,372,261,111,C.wineSoft,22);
 const vl=box(s,'Critic 损失','当前价值输出\n与固定回报目标比较',946,372,261,111,C.greenSoft,22);
 connect(s,f,al,'bottom','top');connect(s,f,vl,'bottom','top',C.green);
 const up=box(s,'损失汇总、反向传播、优化器更新','按有效位置平均，同批经历可重复优化',656,520,551,86,C.white,22);
 connect(s,al,up,'bottom','top');connect(s,vl,up,'bottom','top',C.green);
 takeaway(s,'重新前向服务于求梯度，保存的动作只用于评价其当前概率。',620,21);
 notes(s,'来源：论文§2.1仅说明以PPO优化，未完整披露GAE、损失系数、epochs和Critic损失实现。本页为标准PPO机制解释，V̄表示采集时保存的价值预测，Â在R̂构造时为未标准化版本。公式针对有效非终止位置，边界需掩码与bootstrap。训练采集通常no_grad，优化时重新前向构建求梯度所需计算图；初轮概率可相同但梯度非零。补充A展示min的方向选择，补充B单独标注第三方实现。建议主讲65秒，不逐项推导全部公式。');
}

// 08 Deployment adaptation versus optimizer learning, zero/few and cache lengths.
{
 const s=base(7,'固定参数下的在线适应','来源：论文 §2.1 Deployment、§2.2 Inference Acceleration',{subtitleText:'新交互改变缓存与内部表示，训练获得的策略据此调整动作。'});
 const a=box(s,'当前观测','计算当前 Q、K、V',72,218,212,107);
 const b=box(s,'历史读取','当前 Q 匹配已有 K',316,218,228,107,C.wineSoft);
 const c=box(s,'输出并更新缓存','动作执行，追加新信息',576,218,240,107,C.greenSoft);
 connect(s,a,b);connect(s,b,c);
 text(s,'权重 θ 固定，缓存与动作持续变化。',72,357,740,34,23,C.ink,true);
 rule(s,72,411,744);
 text(s,'Zero-shot',72,435,180,34,23,C.wine,true);
 text(s,'无额外预评估交互，运行中仍会积累历史。',266,435,550,58,20,C.body);
 text(s,'Few-shot',72,521,180,34,23,C.wine,true);
 text(s,'先允许短暂交互，仿真评估采用5秒；\n随后Trial可以利用此前经历。',266,514,550,76,20,C.body);
 rule(s,851,199,1,C.rule,399);
 text(s,'6层、L = 128、50 Hz',885,199,322,45,22,C.ink,true);
 text(s,'约18秒',885,268,322,58,42,C.wine,true);
 text(s,'896步的最大可能历史影响\n包含层间间接传递',885,338,322,63,19,C.body);
 rule(s,885,423,322);
 text(s,'255步',885,449,322,48,34,C.gold,true);
 text(s,'部署KV缓存直接读取范围\n2L−1步，约5.1秒',885,513,322,70,19,C.body);
 takeaway(s,'部署适应依靠历史更新，直接缓存范围与间接历史影响需区分。',621,21);
 notes(s,'来源：§2.1Deployment、§2.2。6层L128是论文例子，最大可能896步≈18秒，实时KV最近255步≈5.1秒。不是每个输入都具有18秒精确记忆保证。Zero-shot无额外预评估预算，仍可在当前Trial内积累历史。Few-shot可利用前Trial经历，论文仿真为5秒。固定权重是本文部署机制，不把缓存更新称为参数微调。');
}

// 09 Preserve the original native chart and its workbook.
{
 const s=base(8,'未见机器人上的跨本体泛化','来源：论文 §3.1、Table 1；图示为各方法均值',{keepChart:true,subtitleText:'10种未见机器人，每种1,000个随机化环境，比较朝随机目标的归一化位移。'});
 const chart=s.charts.items[0];chart.position={left:65,top:233,width:700,height:345};applyPresentationChartFont(chart,{fontFamily:FONT});
 text(s,'归一化朝目标位移',74,191,705,35,23,C.ink,true);
 rule(s,799,200,1,C.rule,382);
 text(s,'如何解释这些比较',835,194,367,38,24,C.wine,true);
 const rows=[['GRU：0.37','相同训练设置，检验记忆架构差异。'],['Conditioning：0.78','有运动学特权信息，但上下文仅64步。'],['Expert：0.99','直接在目标机器人上训练的参考策略。']];
 for(let i=0;i<3;i++){const y=259+i*105;text(s,rows[i][0],835,y,367,31,22,C.ink,true);text(s,rows[i][1],835,y+42,367,53,19,C.body,false,{valign:'top'});}
 takeaway(s,'Zero-shot 0.96，额外5秒交互后0.98，接近目标平台 Expert 的0.99。',611,21);
 notes(s,'来源：Table1与§3.1。原生图表沿用源文件及内嵌工作簿，不重建或替换数据。五均值依次0.96、0.98、0.37、0.78、0.99。指标不是成功率。Few-shot并非所有单平台严格提高，Spot均值保持1.00；均值提高不保证每次运行都改善。Conditioning同时改变特权输入与上下文长度，不能当单因素上下文消融。');
}

// 10 Mechanistic evidence, preserve original plots and distinguish claims.
{
 const s=base(9,'交互收益与内部表示的变化','来源：论文 §3.1、Figure 4；两幅图直接取自原文',{subtitleText:'行为改善和表示分化分别检验适应效果与身体相关信息的形成。'});
 text(s,'更多交互总体改善存活',77,196,538,35,24,C.wine,true);text(s,'不同身体逐渐形成不同表示',677,196,535,35,24,C.wine,true);
 rect(s,70,246,547,300,C.white);rect(s,664,246,547,300,C.white);
 await img(s,'figure4a.png',85,250,517,292);await img(s,'figure4b.png',679,250,517,292);
 text(s,'随机化强度加倍，每个设置50,000个Episode。\n适应后评估6秒运行，曲线存在波动与饱和。',77,558,538,65,19,C.body);
 text(s,'4种人形变体，4,096次zero-shot运行。\n第2层表示在约5秒后形成身体相关簇。',677,558,535,65,19,C.body);
 text(s,'适应窗口与最终Trial的计分时段需区分。',77,630,538,27,18,C.muted);
 text(s,'表示分化不等同于精确恢复质量、惯量等参数。',677,630,535,27,18,C.muted);
 notes(s,'来源：Figure4(a)(b)。左图程序化四类机器人、2倍随机化、适应预算0..6秒、之后最长6秒运行记录倒下时间、50K Episodes/设置。右图第2层均值输出、4096次zero-shot四人形变体，投影方式原文未明确，不补写PCA。在线表征变化并非梯度更新，也不证明显式准确系统辨识。');
}

// 11 Real-world examples.
{
 const s=base(10,'实机中的故障与结构变化适应','来源：论文 §3.2、Figure 5；同一模型的实机演示',{subtitleText:'G1、H1、Go2与Go2-W，包含后腿双足模式，部署前无目标平台微调。'});
 await img(s,'figure5.png',70,192,685,416);
 const rows=[['A、E  关节或腿锁定','支撑条件改变后，调整负载分配与步态。'],['B  跨Trial保留失败经历','后续尝试利用已有缓存，\n演示在第3次Trial稳定行走。'],['C、D、F  驱动与结构变化','轮部驱动改变、附加负载、\n加长或截短腿部。']];
 for(let i=0;i<3;i++){const y=201+i*142;text(s,rows[i][0],793,y,418,34,23,C.wine,true);text(s,rows[i][1],793,y+46,418,72,20,C.body,false,{valign:'top'});if(i<2)rule(s,793,y+127,418);}
 takeaway(s,'实机案例展示固定参数的适应行为，系统成功率与恢复时延仍需统计。',619,20);
 notes(s,'来源：§3.2和Figure5。A固定膝关节PD目标，B保留失败缓存在第3次Trial稳定。C原文将增益置零称锁轮，此处不把它改写成机械刹车锁死。D高跷，F截短下腿；正文和图注恢复时间口径不一致，因此不列统一秒数。不将案例演示表述为任意故障保障。');
}

// 12 Synthesis as concrete mechanism and testable questions.
{
 const s=base(11,'方法贡献与可检验的研究问题','来源：论文 §§5–6、Appendix A/C；研究问题为汇报分析');
 text(s,'形成通用策略的条件',72,160,520,40,26,C.wine,true);
 const left=[['任务分布','身体结构与动力学多样性，\n提供学习适应的交互条件。'],['历史机制','跨段与跨Trial缓存保留响应信息，\n固定参数仍可产生不同控制行为。'],['优化机制','PPO用长期奖励改善共享策略，\n让利用历史的行为获得训练收益。']];
 for(let i=0;i<3;i++){let y=222+i*116;text(s,left[i][0],72,y,510,31,23,C.ink,true);text(s,left[i][1],72,y+40,510,66,20,C.body,false,{valign:'top'});}
 rule(s,628,163,1,C.rule,384);
 text(s,'仍需区分的增益来源',678,160,522,40,26,C.green,true);
 text(s,'匹配数据和计算预算',678,228,522,33,23,C.ink,true);text(s,'比较短上下文、长上下文与GRU，\n减少训练规模对架构结论的干扰。',678,273,522,67,20,C.body);
 text(s,'独立控制历史保留条件',678,379,522,33,23,C.ink,true);text(s,'对比跨Trial保留与清空缓存，\n统计故障后的恢复时间和失败率。',678,424,522,67,20,C.body);
 rule(s,72,575,1138,C.wine,1.3);
 text(s,'核心理解',72,596,170,37,23,C.wine,true);
 text(s,'学习过程更新参数，适应过程利用经历；两者通过训练任务与历史架构连接。',253,592,949,57,22,C.ink,true);
 notes(s,'来源：Limitations和AppendixA/C指出高计算需求、手工任务生成空间覆盖有限。右侧匹配预算、历史保留消融与恢复统计是汇报分析提出的后续研究设计，非论文既有完整结果。总结将任务分布、记忆结构和奖励驱动训练三者连接。本文未公开完整作者训练代码与超参数；复现需明确输入动作映射、奖励、任务采样和记忆重置规则。');
}

// 13 Appendix A: why min, and how multiple position losses combine.
{
 const s=base(12,'补充 A：PPO 裁剪与整批损失','来源：标准PPO教学计算；非论文实测数值');
 text(s,'概率比 ρ = 当前动作概率密度 / 采集时保存的旧概率密度',72,153,1138,40,23,C.body);
 formula(s,'ℓπ = −min[ρÂ, clip(ρ, 1−ε, 1+ε)Â]',72,207,1138,55,34);
 text(s,'取较小训练目标：停止过大的有利推动，同时保留纠正不利变化的梯度。',72,278,1138,36,21,C.wine,true);
 table(s,[['优势 Â','概率比 ρ','原目标 ρÂ','裁剪目标','最终损失 ℓπ'],['+1','1.4','1.4','1.2','−1.2'],['+1','0.6','0.6','0.8','−0.6'],['−1','0.6','−0.6','−0.8','+0.8'],['−1','1.4','−1.4','−1.2','+1.4']],72,335,[170,220,240,240,268],213,20);
 formula(s,'L = (1/N) Σᵢ [ℓπ,ᵢ + cᵥ ℓV,ᵢ − cₕ Hᵢ]',72,578,1138,48,29);
 text(s,'各位置分别算损失，再按有效位置数N平均。裁剪不是对概率比或关节运动施加硬边界。',72,631,1138,27,18,C.muted);
 s.hidden=true;
 notes(s,'来源：Schulman et al., Proximal Policy Optimization Algorithms, arXiv:1707.06347（标准clipped surrogate），教学表取ε=.2、Â=±1。min作用于待最大化的目标，负号将其转换成最小化损失；等价于两项负目标中取更大损失。只使用clip会在错误方向也失去纠正梯度。表中四组说明正优势过度增加、正优势错误减少、负优势过度减少、负优势错误增加。末式仅列核心PPO+价值+熵项，具体实现可能有扩展；每个位置不是一个全新环境动作。补充页默认隐藏，可在问答时打开。');
}

// 14 Appendix B: exact supplied third-party entry point, clearly scoped.
{
 const s=base(13,'补充 B：参考代码的采集与更新时序','来源：第三方 lucidrains/locoformer，train_microduck.py 与 locoformer.py');
 text(s,'以下为所提供第三方实现的默认入口配置，论文未公开同等完整训练设置。',72,151,1138,39,22,C.wine,true);
 const a=box(s,'采集一批 D','12环境 × 每环境256步\n共3072条时间位置记录',72,224,329,120);
 const b=box(s,'一轮优化','16个窗口，每窗12×16位置\n逐窗前向、损失与梯度累积',460,224,363,120,C.wineSoft);
 const c=box(s,'更新一次参数','所有窗口完成后Adam.step()\n同一批D重复优化4轮',882,224,325,120,C.greenSoft);
 connect(s,a,b);connect(s,b,c);
 table(s,[['阶段','当前参数','旧概率来自','是否执行环境动作'],['采集D','θ₀','θ₀','是'],['优化第1轮','θ₀ → θ₁','θ₀','否'],['优化第2～4轮','θ₁ → θ₄','θ₀','否'],['采集下一批','θ₄','θ₄','是']],72,388,[250,250,250,388],209,19);
 text(s,'Beta连续动作，默认逐维裁剪。Critic采用HLGaussLoss。有效位置掩码决定实际损失条数。',72,617,1138,40,19,C.body);
 s.hidden=true;
 notes(s,'精确来源：G:/毕设/03_code/locoformer/train_microduck.py:593–605,645–666,692–762；locoformer/locoformer.py:1931–1947,1977–1983,2020–2029,2042–2075,2125–2154。12env×256steps、window16、epochs4、gamma.99、lambda.95、clip.2。每次ppo调用cache=None，窗口内detach_cache=True，全部窗口后一次optimizerstep。默认per_action_dim=True先逐维裁剪再平均，Critic输出32bins的HLGaussLoss。done及padding掩码排除无效位置。当前Microduck ep_id在环境done后递增且默认不跨ep注意力，未完整实现论文同任务多Trial Episode采样协议，不能视为作者训练配置。采集no_grad，训练重新前向为了梯度。每批采集创建新stateful_fwd。补充页默认隐藏。');
}

await fs.mkdir(path.join(B,'preview'),{recursive:true});
for(let i=0;i<p.slides.items.length;i++){
 const blob=await p.export({slide:p.slides.items[i],format:'png',scale:1});
 await fs.writeFile(path.join(B,'preview',`slide-${String(i+1).padStart(2,'0')}.png`),new Uint8Array(await blob.arrayBuffer()));
 const layout=await p.slides.items[i].export({format:'layout'});
 await fs.writeFile(path.join(B,'preview',`slide-${String(i+1).padStart(2,'0')}.json`),new Uint8Array(await layout.arrayBuffer()));
 console.log('RENDER',i+1);
}
const candidate=path.join(B,'candidate.pptx');
await(await PresentationFile.exportPptx(p)).save(candidate);
await fs.writeFile(path.join(B,'content.ndjson'),(await p.inspect({select:'$.slides[*]',include:['index','title','elements.kind','elements.text','notes.text']})).ndjson);
console.log('DRAFT',candidate);
if(process.argv.includes('--finalize')){
 const final=path.join(B,'validated/locoformer_paper_report.pptx');
 await fs.mkdir(path.dirname(final),{recursive:true});
 const result=await finalizePresentation({workspaceDir:WORK,candidatePath:candidate,finalPath:final,pythonExecutable:PY,integrityValidatorPath:path.join(SKILL,'container_tools/inspect_presentation_package_integrity.py'),layoutValidatorPath:path.join(SKILL,'container_tools/inspect_presentation_layout_geometry.py'),explicitTotalSlideCount:14,requiredNativeChartOwnerSlides:[9],requiredNativeTableOwnerSlides:[13,14],layoutArgs:['--expected-slide-size-emu','12192000,6858000','--validate-bullet-geometry','--validate-heading-fit','--require-native-table-slide','13','--require-native-table-slide','14'],fontPolicy:{basis:'reference',families:[FONT,'Cambria Math'],referencePath:REF,referenceSha256:createHash('sha256').update(await fs.readFile(REF)).digest('hex')},verifyArtifactToolImport:true,receiptPath:path.join(B,'final.validation.json')});
 console.log('FINAL',JSON.stringify(result));
}
