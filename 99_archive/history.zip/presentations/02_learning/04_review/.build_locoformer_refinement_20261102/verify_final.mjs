import fs from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {PresentationFile,FileBlob} from '@oai/artifact-tool';
const B='G:/毕设/02_learning/04_review/.build_locoformer_refinement_20261102';
const f=path.join(B,'validated/locoformer_paper_report_v3.pptx');
const p=await PresentationFile.importPptx(await FileBlob.load(f));
await fs.mkdir(path.join(B,'final-preview'),{recursive:true});
const checks=[];
for(let i=0;i<p.slides.items.length;i++){
 const blob=await p.export({slide:p.slides.items[i],format:'png',scale:1});
 const bytes=new Uint8Array(await blob.arrayBuffer());
 const name=`slide-${String(i+1).padStart(2,'0')}.png`;
 await fs.writeFile(path.join(B,'final-preview',name),bytes);
 const before=await fs.readFile(path.join(B,'preview',name));
 checks.push({slide:i+1,identicalToReviewedPreview:Buffer.from(bytes).equals(before)});
}
const content=await p.inspect({select:'$.slides[*]',include:['index','title','elements.kind','elements.text','notes.text']});
await fs.writeFile(path.join(B,'final-content.ndjson'),content.ndjson);
const report={slides:p.slides.items.length,checks,sha256:createHash('sha256').update(await fs.readFile(f)).digest('hex')};
await fs.writeFile(path.join(B,'final-visual-comparison.json'),JSON.stringify(report,null,2));
console.log(JSON.stringify(report));
if(checks.some(x=>!x.identicalToReviewedPreview))process.exitCode=2;
