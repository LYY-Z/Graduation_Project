"""Restore the source chart/workbook parts lost by the import/export round trip.

No chart values, formulas, formatting or workbook contents are regenerated.
"""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
from lxml import etree as ET
import hashlib
import json

BASE = Path(__file__).parent
CHART = 'ppt/slides/charts/chart1.xml'
RELS = 'ppt/slides/charts/_rels/chart1.xml.rels'
BOOK = 'ppt/embeddings/chart-data-snapshot-001.xlsx'
NS = {'c': 'http://schemas.openxmlformats.org/drawingml/2006/chart'}

with ZipFile(BASE / 'source.pptx') as source, ZipFile(BASE / 'candidate.pptx') as draft:
    old = ET.fromstring(source.read(CHART))
    new = ET.fromstring(draft.read(CHART))
    for xpath in ['.//c:cat//c:pt/c:v/text()', './/c:val//c:pt/c:v/text()', './/c:f/text()']:
        assert old.xpath(xpath, namespaces=NS) == new.xpath(xpath, namespaces=NS), xpath
    assert old.find('c:externalData', NS) is not None
    assert new.find('c:externalData', NS) is None

    parts = {name: draft.read(name) for name in draft.namelist()}
    for name in [CHART, RELS, BOOK]:
        parts[name] = source.read(name)

    ct_ns = 'http://schemas.openxmlformats.org/package/2006/content-types'
    types = ET.fromstring(parts['[Content_Types].xml'])
    source_types = ET.fromstring(source.read('[Content_Types].xml'))
    for child in source_types:
        if child.tag == f'{{{ct_ns}}}Default' and child.get('Extension') == 'xlsx':
            if not any(c.tag == child.tag and c.get('Extension') == 'xlsx' for c in types):
                types.append(ET.fromstring(ET.tostring(child)))
    parts['[Content_Types].xml'] = ET.tostring(types, encoding='UTF-8', xml_declaration=True)
    out = BASE / 'candidate_repaired.pptx'
    with ZipFile(out, 'w', ZIP_DEFLATED) as z:
        for name, data in parts.items():
            z.writestr(name, data)

with ZipFile(BASE / 'source.pptx') as source, ZipFile(out) as repaired:
    for name in [CHART, RELS, BOOK]:
        assert source.read(name) == repaired.read(name), name
receipt = {'source_parts_preserved_byte_for_byte': [CHART, RELS, BOOK],
           'source_formulas_and_cached_values_match_draft': True,
           'output': str(out), 'sha256': hashlib.sha256(out.read_bytes()).hexdigest()}
(BASE / 'chart-preservation.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(receipt, ensure_ascii=True))
