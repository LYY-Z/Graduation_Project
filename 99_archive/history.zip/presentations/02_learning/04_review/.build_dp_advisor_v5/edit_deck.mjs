import fs from "node:fs/promises";
import { FileBlob, PresentationFile } from "@oai/artifact-tool";

const sourcePath = "G:/毕设/02_learning/04_review/deliverables/diffusion_policy_advisor_report_10min_refined_v4.pptx";
const draftPath = "G:/毕设/02_learning/04_review/.build_dp_advisor_v5/candidate.pptx";
const previewPath = "G:/毕设/02_learning/04_review/.build_dp_advisor_v5/slide6.png";
const presentation = await PresentationFile.importPptx(await FileBlob.load(sourcePath));
const slide = presentation.slides.items[5];

const snapshot = await presentation.inspect({
  kind: "slide,textbox,shape,image,table,chart",
  maxChars: 50000,
});
const slideRecords = snapshot.records.filter((record) => record.slideIndex === 5);
const titleRecord = slideRecords.find((record) => record.text === "反向采样：从噪声预测到下一步动作");
const subtitleRecord = slideRecords.find((record) => record.text === "生成时用噪声预测替代未知的干净动作。");
if (!titleRecord || !subtitleRecord) throw new Error("Could not identify the target slide's title and subtitle.");

presentation.resolve(titleRecord.id).text = "标准 DDPM 与本文的采样公式";
presentation.resolve(subtitleRecord.id).text = "上一版的后验均值式是标准 DDPM 背景；本论文 Eq. (4) 使用条件 Langevin 更新。";

const preservedNames = new Set(["矩形 1", "矩形 2", "矩形 3", "矩形 5"]);
const preservedIds = new Set([
  titleRecord.id,
  subtitleRecord.id,
  ...slideRecords.filter((record) => record.id?.startsWith("sh/") && preservedNames.has(record.name)).map((record) => record.id),
]);
const removeIds = slideRecords
  .filter((record) => record.id?.startsWith("sh/") && !preservedIds.has(record.id))
  .map((record) => record.id);
presentation.delete(removeIds);

const burgundy = "#78394C";
const ink = "#252A31";
const grey = "#646A70";
const border = "#DED9D2";
const blush = "#F0E8EA";
const cream = "#F4EFE5";
const font = "微软雅黑";
const math = "Cambria Math";

function box(name, position, fill, stroke = border) {
  return slide.shapes.add({
    geometry: "rect",
    name,
    position,
    fill,
    line: { style: "solid", fill: stroke, width: 1 },
  });
}

function text(name, value, position, options = {}) {
  return slide.shapes.add({
    geometry: "textbox",
    name,
    position,
    text: {
      text: value,
      style: {
        fontSize: options.size ?? 17,
        typeface: options.font ?? font,
        color: options.color ?? ink,
        bold: options.bold ?? false,
        alignment: options.align ?? "left",
        verticalAlignment: options.valign ?? "middle",
        autoFit: "shrinkText",
        wrap: true,
        insets: 0,
      },
    },
  });
}

// Keep the deck's existing typography and palette, with the paper's update as the focus.
box("ddpm-context-band", { left: 66, top: 184, width: 1148, height: 166 }, "#FFFFFF");
text("ddpm-context-heading", "经典 DDPM（背景）", { left: 88, top: 194, width: 1104, height: 28 }, { size: 17, color: burgundy, bold: true });
text("ddpm-context-equation", "xₖ₋₁ = 1/√αₖ [ xₖ − βₖ εθ(xₖ,k) / √(1−ᾱₖ) ] + σ̃ₖ z", { left: 88, top: 230, width: 1104, height: 48 }, { size: 22, font: math, align: "center" });
text("ddpm-context-explanation", "噪声预测给出反向均值；σ̃ₖ² = β̃ₖ 是常见固定方差设置下的反向采样方差。", { left: 88, top: 289, width: 1104, height: 40 }, { size: 15.5, color: grey, align: "center" });

box("paper-eq4-band", { left: 66, top: 364, width: 1148, height: 218 }, blush, "#D8C8CC");
text("paper-eq4-heading", "本文 Diffusion Policy（Eq. 4）", { left: 88, top: 376, width: 1104, height: 28 }, { size: 18, color: burgundy, bold: true });
text("paper-eq4-equation", "Aₜᵏ⁻¹ = αₖ [ Aₜᵏ − γₖ εθ(Oₜ,Aₜᵏ,k) + σₖ zₖ ]", { left: 88, top: 416, width: 1104, height: 54 }, { size: 24, font: math, align: "center" });
text("paper-eq4-explanation", "zₖ ~ N(0,I)。这是把原文的随机项 N(0,σₖ²I) 写成等价抽样形式。推理从 Aₜᴷ ~ N(0,I) 开始，Oₜ作条件，模型只对动作块 Aₜ去噪。", { left: 88, top: 478, width: 1104, height: 62 }, { size: 15.5, color: grey, align: "center" });

box("equation-distinction-band", { left: 66, top: 595, width: 1148, height: 42 }, cream, border);
text("equation-distinction", "共同点：都用噪声预测逐步修正动作。区别：论文采用 Langevin 的 αₖ、γₖ、σₖ 日程，不能与标准 DDPM 的 βₖ、ᾱₖ、σ̃ₖ 系数互换。", { left: 82, top: 598, width: 1116, height: 36 }, { size: 14.5, color: ink, align: "center" });
text("paper-citation", "Chi et al., IJRR 2025, §§2.1, 2.3.2, Eqs. (1), (4), p.1686; §3.3, p.1688.", { left: 72, top: 641, width: 1120, height: 19 }, { size: 12.5, color: grey, align: "right" });

// Preserve the previous request: no speaker notes anywhere in the deck.
for (const item of presentation.slides.items) item.speakerNotes.clear();

const preview = await slide.export({ format: "png", scale: 1.5 });
await fs.writeFile(previewPath, new Uint8Array(await preview.arrayBuffer()));
await (await PresentationFile.exportPptx(presentation)).save(draftPath);
console.log(JSON.stringify({
  slideCount: presentation.slides.items.length,
  removedSlideObjects: removeIds.length,
  notesRemaining: presentation.slides.items.filter((item) => item.speakerNotes.text?.trim()).length,
  draftPath,
  previewPath,
}, null, 2));
