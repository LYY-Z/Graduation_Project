import fs from "node:fs/promises";
import path from "node:path";
import { Presentation, PresentationFile, FileBlob } from "@oai/artifact-tool";
import { pathToFileURL } from "node:url";

const workspaceDir = "G:/毕设";
const outputDir = path.join(workspaceDir, "02_learning/04_review");
const buildDir = path.join(outputDir, ".build_dp_report_rework_20261023");
const finalPath = path.join(outputDir, "diffusion_policy_advisor_report_reworked_v2.pptx");
const W = 1280;
const H = 720;

const C = {
  bg: "#FBFCFA",
  ink: "#18263A",
  body: "#344256",
  muted: "#6C7A8B",
  blue: "#315E94",
  blueSoft: "#EEF3F8",
  green: "#47816D",
  greenSoft: "#EAF2EE",
  red: "#B25752",
  rule: "#D8E0E7",
  white: "#FFFFFF",
};

const FONT = "Microsoft YaHei";
const MATH = "Cambria Math";

function text(slide, value, x, y, w, h, opts = {}) {
  const shape = slide.shapes.add({
    geometry: "textbox",
    name: opts.name ?? value.slice(0, 28),
    position: { left: x, top: y, width: w, height: h },
    fill: "none",
    line: { style: "solid", fill: "none", width: 0 },
  });
  shape.text = value;
  shape.text.style = {
    typeface: opts.font ?? FONT,
    fontSize: opts.size ?? 20,
    color: opts.color ?? C.body,
    bold: opts.bold ?? false,
    alignment: opts.align ?? "left",
    verticalAlignment: opts.valign ?? "middle",
    wrap: "square",
    autoFit: "shrinkText",
    insets: opts.insets ?? 0,
  };
  return shape;
}

function rule(slide, x, y, w, color = C.rule, h = 1.5) {
  return slide.shapes.add({
    geometry: "rect",
    name: "separator",
    position: { left: x, top: y, width: w, height: h },
    fill: color,
    line: { style: "solid", fill: "none", width: 0 },
  });
}

function box(slide, x, y, w, h, fill = C.white, stroke = C.rule, lineWidth = 1) {
  return slide.shapes.add({
    geometry: "rect",
    name: "diagram element",
    position: { left: x, top: y, width: w, height: h },
    fill,
    line: { style: "solid", fill: stroke, width: lineWidth },
  });
}

function slideBase(presentation, section, titleText, page, sourceText) {
  const slide = presentation.slides.add();
  slide.background.fill = C.bg;
  text(slide, section, 70, 32, 350, 25, { size: 15, color: C.blue, bold: true });
  text(slide, titleText, 70, 63, 1140, 58, { size: 38, color: C.ink, bold: true });
  rule(slide, 70, 130, 1140, C.rule, 1.5);
  text(slide, sourceText, 70, 681, 1060, 20, { size: 13, color: C.muted });
  text(slide, `${String(page).padStart(2, "0")} / 08`, 1144, 681, 66, 20, {
    size: 13,
    color: C.muted,
    align: "right",
  });
  return slide;
}

function addPaperImage(slide, source, x, y, w, h, alt) {
  const img = source;
  return slide.images.add({
    blob: img.bytes,
    contentType: img.contentType || "image/png",
    alt,
    fit: "contain",
    position: { left: x, top: y, width: w, height: h },
    ...(img.crop ? { crop: img.crop } : {}),
  });
}

const references = [
  {
    time: "0:30",
    speech:
      "各位老师好，我汇报的论文是《Diffusion Policy: Visuomotor Policy Learning via Action Diffusion》。工作最初发表于 RSS 2023，今天读的是 IJRR 2025 扩展期刊版。本文研究的是：机器人能否从示范中学到一个在观测条件下生成动作序列的策略，并把它稳定地用于真实闭环控制。汇报按问题、建模、训练推理和实验展开。",
    source: "来源：论文首页；IJRR 2025, 44(10–11), pp. 1684–1704。",
  },
  {
    time: "1:15",
    speech:
      "行为克隆把专家示范当作监督数据，输入观察，学习对应动作。困难在于，同一观察下可能有多种正确选择。以 Push-T 为例，末端可以从 T 形块两侧接近，最后都能把它推到目标。若用普通均方误差只回归一个确定动作，模型容易把不同路线折中成平均动作，而平均位置可能落在障碍物上。动作还具有时间关联，如果每个时刻各自选模式，轨迹可能左右切换。因此本文要解决的不是单个动作点的误差，而是如何表示条件动作分布，并保持整段轨迹连贯。",
    source: "来源：论文 Figure 3, p. 1688；§§1, 4.1, 4.3。",
  },
  {
    time: "1:20",
    speech:
      "论文把策略表示分成三类。显式策略直接从观察回归动作，推理快，但很难自然表示多个解。隐式能量策略给观察和动作打分，表达能力强，却要处理归一化常数和负样本，实际训练可能不稳定。Diffusion Policy 选择第三条路：从随机动作计划开始，学习预测其中的噪声，再迭代修正计划。这个修正方向隐含地指向演示动作分布中更合理的区域，不需要显式求出整个概率密度或能量模型的归一化常数。这里的主实验仍是行为克隆，监督来自专家示范，不是靠奖励在线试错。",
    source: "来源：论文 Figure 1, p. 1685；§§1–2.3, 4.4。",
  },
  {
    time: "1:30",
    speech:
      "先把模型里的两个对象分开。条件是 O_t，包含最近几帧的相机图像和机器人本体状态；生成对象是 A_t，它表示未来连续 T_p 步的动作向量。图像和状态提供任务上下文，只有动作序列逐步加噪、再逐步去噪。不同相机和历史帧先提取特征，再与状态特征融合，不是把原始像素简单相加。视觉编码器用 ResNet-18 和 Spatial Softmax 提取空间特征；这并不意味着网络预先知道哪个像素是杯子，而是它从图像与专家动作的对应关系里学习任务相关表示。动作去噪网络主要采用带 FiLM 条件化的 1D CNN/U-Net；高频动作变化明显时，论文也提出 Transformer 版本，但它更依赖超参数。",
    source: "来源：论文 Figure 2, pp. 1686–1687；§§2.3, 3.1–3.2。",
  },
  {
    time: "1:35",
    speech:
      "训练阶段有专家答案，所以监督信号可以直接构造。先取一段示范动作 A_t 的零级干净版本，随机选择扩散级 k，再采一份标准高斯噪声 ε。按噪声日程混合两者，得到带噪动作 A_t 的 k 级样本。网络看到观察 O_t、带噪动作和级别 k，输出噪声预测 ε̂。训练损失是注入噪声与预测噪声之间的均方误差。这里的 MSE 比较的是噪声张量，不是直接比较动作；KL 散度出现在扩散模型的理论推导中，论文实际使用的简化训练目标不是额外再叠一个 KL 项。噪声日程决定各级信号和噪声的比例，作者在控制任务中采用 iDDPM 的 Square Cosine Schedule。",
    source: "来源：论文 Eqs. (3), (5), pp. 1686, 1688；§§2.2, 3.3。",
  },
  {
    time: "1:45",
    speech:
      "推理时没有专家动作作为起点，先从高斯随机动作计划 A_t 的 K 级开始。每一轮网络估计当前动作计划里的噪声，再按论文的 Langevin 风格更新式从 k 走向 k 减一。α_k 和 γ_k 控制缩放与修正幅度，σ_k 控制随机扰动大小，z 是本轮新采的标准高斯噪声。要注意，这里展示的是 Diffusion Policy 论文的更新式，不应和标准 DDPM 后验均值公式混成一条。去噪得到完整动作块后，机器人只执行前 T_a 步，再读取新观察并重新规划；k 是一次规划内部的扩散级别，t 才是机器人控制时刻。多数任务中作者发现 T_a=8 较合适，真实 Push-T 的配置则是 6。DDIM 用于减少推理迭代，正文举例是 100 个训练步、10 个推理步，RTX 3080 上约 0.1 秒；附录的个别实机配置列为 16 步，所以具体数字应按任务配置理解。",
    source: "来源：论文 Eqs. (1), (4), pp. 1686, 1688；§§2.1, 2.3, 3.4, 5.3.4–5.3.5；Appendix A.4。",
  },
  {
    time: "1:30",
    speech:
      "实验覆盖四个基准、十五项任务，包含仿真和真实机器人。作者报告相对于每项任务最佳基线的平均相对成功率提升为 46.9%，这是相对比例的平均值，不是成功率提高 46.9 个百分点。以真实 UR5 Push-T 为例，二十次评测中 Diffusion Policy 成功率为 95%，LSTM-GMM 为 20%，IBC 为 0%；平均 IoU 为 0.80，演示均值是 0.84。消融结果还显示，多数任务执行八步较合适，模拟延迟最多四步仍能保持峰值表现，位置控制比速度控制更不易受延迟影响。期刊扩展版进一步报告三项双臂任务，成功率分别为 55%、75% 和 75%，说明验证范围扩大了，但不能据此消除示范质量和具体控制设置的影响。",
    source: "来源：论文 Tables 1–4, 6; Figures 6–7; §§5–7; Appendix B.2, pp. 1689–1694, 1702。",
  },
  {
    time: "0:35",
    speech:
      "归纳来看，这篇论文的贡献不是单独换了一个生成模型，而是把多解动作表示、整段动作预测、视觉条件复用和滚动时域控制组合起来，并在真实任务中验证。它仍然依赖示范覆盖，迭代去噪也比单次回归耗时，而且生成策略不等于安全保证。后续复现时，先核对数据与坐标归一化、动作时域和控制接口，再讨论更换网络结构，才更容易判断性能差异来自哪里。我的汇报到这里，谢谢老师。",
    source: "来源：论文 §§9–10, p. 1698。",
  },
];

const presentation = Presentation.create({ slideSize: { width: W, height: H } });
const sourceDeck = await PresentationFile.importPptx(
  await FileBlob.load("H:/Download/Diffusion Policy 论文组会汇报.pptx"),
);
const figures = {
  multimodal: sourceDeck.resolve("im/6xgry54n"),
  representations: sourceDeck.resolve("im/q1sbal07"),
  architecture: sourceDeck.resolve("im/y18zu1g7"),
  ablations: sourceDeck.resolve("im/m1sb6pgf"),
};

// 1. Cover
{
  const slide = presentation.slides.add();
  slide.background.fill = C.bg;
  rule(slide, 72, 154, 7, C.blue, 420);
  text(slide, "机器人模仿学习 · 论文汇报", 112, 145, 720, 32, { size: 18, color: C.blue, bold: true });
  text(slide, "Diffusion Policy", 108, 210, 1040, 90, { size: 66, color: C.ink, bold: true });
  text(slide, "Visuomotor Policy Learning via Action Diffusion", 112, 312, 1060, 48, {
    size: 28,
    color: C.body,
    font: MATH,
  });
  text(slide, "面向视觉运动控制的动作扩散策略", 112, 371, 920, 44, { size: 27, color: C.blue, bold: true });
  rule(slide, 112, 448, 560, C.green, 3);
  text(slide, "给定观测，生成未来动作块；执行部分动作后重新观测与规划。", 112, 475, 980, 55, {
    size: 23,
    color: C.body,
  });
  text(slide, "Cheng Chi et al.  ·  RSS 2023  ·  IJRR 2025 扩展期刊版", 112, 590, 880, 30, {
    size: 18,
    color: C.muted,
  });
  text(slide, "组会汇报  |  约 10 分钟", 112, 630, 580, 26, { size: 16, color: C.muted });
  slide.speakerNotes.text = `${references[0].time}｜${references[0].speech}\n\n${references[0].source}`;
  slide.speakerNotes.setVisible(true);
}

// 2. Motivation: multimodal actions
{
  const slide = slideBase(
    presentation,
    "问题定义",
    "同一观测下，多个动作方案都可能正确",
    2,
    "Chi et al., IJRR 2025, Figure 3, p. 1688; §§1, 4.1, 4.3",
  );
  text(slide, "行为克隆从专家示范学习观测到动作的映射。", 72, 158, 470, 52, {
    size: 22,
    color: C.ink,
    bold: true,
  });
  text(slide, "Push-T 中，末端可以从 T 形块两侧接近；两种路线都可能成功。", 72, 224, 470, 82, {
    size: 20,
  });
  text(slide, "若用 MSE 只回归一个确定动作，模型可能输出两条路线的平均值。平均位置未必可行。", 72, 326, 470, 112, {
    size: 20,
    color: C.red,
  });
  text(slide, "动作还要前后连贯：逐时刻独立选模式，可能导致轨迹在两种走法之间切换。", 72, 458, 470, 95, {
    size: 20,
  });
  addPaperImage(slide, figures.multimodal, 590, 170, 620, 200, "论文 Figure 3：Push-T 多模态策略轨迹对比");
  text(slide, "不同随机采样可选中不同路线；选中后，整段动作应保持一致。", 590, 374, 620, 48, {
    size: 16,
    color: C.muted,
  });
  rule(slide, 72, 588, 1138, C.rule, 1.5);
  text(slide, "建模目标：在观察条件下表示多种合理的未来动作序列，而非只预测一个动作点。", 72, 605, 1138, 42, {
    size: 22,
    color: C.blue,
    bold: true,
  });
  slide.speakerNotes.text = `${references[1].time}｜${references[1].speech}\n\n${references[1].source}`;
  slide.speakerNotes.setVisible(true);
}

// 3. Policy representations
{
  const slide = slideBase(
    presentation,
    "策略表示",
    "扩散策略以条件去噪表示动作分布",
    3,
    "Chi et al., IJRR 2025, Figure 1, p. 1685; §§1–2.3, 4.4",
  );
  addPaperImage(slide, figures.representations, 90, 150, 1100, 256, "论文 Figure 1：显式、隐式与扩散策略表示对比");
  const cols = [
    {
      x: 82,
      title: "显式策略",
      color: C.blue,
      body: "直接从观测回归动作。推理快，但多个动作模式需要额外表示。",
    },
    {
      x: 454,
      title: "隐式能量策略",
      color: C.body,
      body: "为观测与动作打分。训练和采样要处理负样本及归一化难题。",
    },
    {
      x: 826,
      title: "Diffusion Policy",
      color: C.green,
      body: "从随机动作块开始反复去噪，用已知噪声监督学习修正方向。",
    },
  ];
  for (const col of cols) {
    text(slide, col.title, col.x, 435, 330, 34, { size: 22, color: col.color, bold: true });
    text(slide, col.body, col.x, 475, 330, 83, { size: 18, color: C.body });
  }
  rule(slide, 82, 575, 1110, C.rule, 1.5);
  text(slide, "本文以行为克隆为主：学习信号来自示范动作，不依赖在线奖励。", 82, 592, 1110, 38, {
    size: 19,
    color: C.ink,
    bold: true,
  });
  slide.speakerNotes.text = `${references[2].time}｜${references[2].speech}\n\n${references[2].source}`;
  slide.speakerNotes.setVisible(true);
}

// 4. Conditional formulation and architecture
{
  const slide = slideBase(
    presentation,
    "条件与生成对象",
    "观察提供条件，动作块是去噪对象",
    4,
    "Chi et al., IJRR 2025, Figure 2, pp. 1686–1687; §§2.3, 3.1–3.2",
  );
  addPaperImage(slide, figures.architecture, 100, 150, 1080, 244, "论文 Figure 2：Diffusion Policy 总体结构与网络选项");
  rule(slide, 72, 411, 1138, C.rule, 1.5);
  text(slide, "条件 Oₜ", 82, 428, 150, 34, { size: 21, color: C.blue, bold: true });
  text(slide, "最近多视角图像与机器人状态；图像先提特征，再与状态特征融合。", 232, 428, 960, 38, {
    size: 18,
  });
  text(slide, "动作 Aₜ", 82, 475, 150, 34, { size: 21, color: C.green, bold: true });
  text(slide, "未来 Tₚ 步动作向量；仅动作序列加噪，观察作为条件复用。", 232, 475, 960, 38, {
    size: 18,
  });
  text(slide, "网络选择", 82, 522, 150, 34, { size: 21, color: C.ink, bold: true });
  text(slide, "ResNet-18 + Spatial Softmax 提取视觉特征；去噪端常用 1D CNN/U-Net + FiLM，高频变化任务可用 Transformer。", 232, 522, 960, 58, {
    size: 18,
  });
  text(slide, "GroupNorm 不保存 BatchNorm 式的批次运行统计，便于与 EMA 权重平均配合。", 82, 600, 1110, 30, {
    size: 16,
    color: C.muted,
  });
  slide.speakerNotes.text = `${references[3].time}｜${references[3].speech}\n\n${references[3].source}`;
  slide.speakerNotes.setVisible(true);
}

// 5. Training
{
  const slide = slideBase(
    presentation,
    "训练",
    "已知噪声构成直接监督信号",
    5,
    "Chi et al., IJRR 2025, Eqs. (3), (5), pp. 1686, 1688; §§2.2, 3.3",
  );
  box(slide, 82, 157, 1110, 98, C.blueSoft, C.blueSoft, 0);
  text(slide, "Aₜᵏ = √ᾱₖ · Aₜ⁰ + √(1 − ᾱₖ) · ε", 100, 174, 1074, 58, {
    size: 35,
    font: MATH,
    color: C.ink,
    align: "center",
  });
  text(slide, "专家动作块", 122, 230, 250, 25, { size: 15, color: C.muted, align: "center" });
  text(slide, "已知随机噪声", 848, 230, 250, 25, { size: 15, color: C.muted, align: "center" });
  const stages = [
    ["01", "取示范样本", "(Oₜ, Aₜ⁰)"],
    ["02", "随机选级别", "k ∈ {1,…,K}"],
    ["03", "按日程加噪", "得到 Aₜᵏ"],
    ["04", "预测所加噪声", "ε̂ = εθ(Oₜ,Aₜᵏ,k)"],
  ];
  const xs = [82, 364, 646, 928];
  for (let i = 0; i < stages.length; i++) {
    const [num, label, detail] = stages[i];
    text(slide, num, xs[i], 292, 52, 28, { size: 16, color: C.green, bold: true });
    text(slide, label, xs[i], 327, 245, 34, { size: 20, color: C.ink, bold: true });
    text(slide, detail, xs[i], 368, 250, 42, { size: 17, color: C.body, font: i === 3 ? MATH : FONT });
    if (i < stages.length - 1) {
      rule(slide, xs[i] + 248, 304, 1.5, C.rule, 92);
    }
  }
  rule(slide, 82, 427, 1110, C.rule, 1.5);
  text(slide, "L_noise = E [ || ε − ε̂ ||² ]", 120, 445, 1040, 55, {
    size: 31,
    font: MATH,
    color: C.ink,
    align: "center",
  });
  text(slide, "比较的是注入噪声与预测噪声，不是直接比较动作。KL 是理论推导背景，不是额外叠加的训练损失。", 82, 510, 1110, 50, {
    size: 17,
    color: C.body,
  });
  text(slide, "噪声日程：iDDPM Square Cosine Schedule。它规定不同 k 下信号与噪声的比例。", 82, 573, 1110, 36, {
    size: 17,
    color: C.muted,
  });
  slide.speakerNotes.text = `${references[4].time}｜${references[4].speech}\n\n${references[4].source}`;
  slide.speakerNotes.setVisible(true);
}

// 6. Inference and receding-horizon control
{
  const slide = slideBase(
    presentation,
    "推理与控制",
    "逐步去噪生成计划，再执行一段并重规划",
    6,
    "Chi et al., IJRR 2025, Eqs. (1), (4), pp. 1686, 1688; §§2.1, 2.3, 3.4, 5.3.4–5.3.5; Appendix A.4",
  );
  box(slide, 82, 153, 1110, 92, C.blueSoft, C.blueSoft, 0);
  text(slide, "Aₜᵏ⁻¹ = αₖ [ Aₜᵏ − γₖ εθ(Oₜ, Aₜᵏ, k) + σₖ z ]", 100, 169, 1074, 58, {
    size: 29,
    font: MATH,
    color: C.ink,
    align: "center",
  });
  const meanings = [
    ["εθ", "网络估计当前计划中的噪声", C.blue],
    ["αₖ、γₖ", "控制缩放与去噪修正幅度", C.green],
    ["σₖ z", "按日程加入随机扰动", C.red],
  ];
  const mx = [100, 468, 836];
  for (let i = 0; i < meanings.length; i++) {
    text(slide, meanings[i][0], mx[i], 266, 320, 31, { size: 20, color: meanings[i][2], bold: true, font: MATH });
    text(slide, meanings[i][1], mx[i], 301, 320, 48, { size: 17, color: C.body });
  }
  rule(slide, 82, 370, 1110, C.rule, 1.5);
  const flow = [
    ["01", "读取 Oₜ", "图像与状态"],
    ["02", "随机初始化", "Aₜᴷ ~ N(0,I)"],
    ["03", "反复去噪", "k = K … 1"],
    ["04", "得到动作块", "长度 Tₚ"],
    ["05", "执行前缀", "Tₐ 步后重观测"],
  ];
  const fx = [82, 314, 546, 778, 1010];
  for (let i = 0; i < flow.length; i++) {
    text(slide, flow[i][0], fx[i], 395, 48, 24, { size: 15, color: C.green, bold: true });
    text(slide, flow[i][1], fx[i], 425, 190, 34, { size: 19, color: C.ink, bold: true });
    text(slide, flow[i][2], fx[i], 465, 190, 36, { size: 16, color: C.muted, font: i === 1 || i === 2 ? MATH : FONT });
    if (i < flow.length - 1) {
      text(slide, "›", fx[i] + 195, 426, 34, 34, { size: 30, color: C.blue, align: "center" });
    }
  }
  text(slide, "k 是一次规划内部的扩散级别，t 是机器人控制时刻。多数任务 Tₐ=8；实机 Push-T 配置 Tₐ=6。", 82, 526, 1110, 34, {
    size: 16,
    color: C.body,
  });
  text(slide, "DDIM 加速：主文报告 100 个训练步、10 个推理步约 0.1 s（RTX 3080）；附录具体任务配置存在差异。", 82, 570, 1110, 44, {
    size: 16,
    color: C.muted,
  });
  slide.speakerNotes.text = `${references[5].time}｜${references[5].speech}\n\n${references[5].source}`;
  slide.speakerNotes.setVisible(true);
}

// 7. Results
{
  const slide = slideBase(
    presentation,
    "实验结果",
    "多任务结果与实机评测支持方法设计",
    7,
    "Chi et al., IJRR 2025, Tables 1–4, 6; Figures 6–7; §§5–7; Appendix B.2",
  );
  text(slide, "15", 82, 155, 150, 91, { size: 74, color: C.blue, bold: true, font: MATH });
  text(slide, "项任务", 231, 198, 145, 38, { size: 23, color: C.ink });
  text(slide, "4 个机器人操作基准，包含仿真与真实环境", 82, 248, 420, 50, { size: 18, color: C.body });
  text(slide, "+46.9%", 82, 318, 420, 82, { size: 65, color: C.green, bold: true, font: MATH });
  text(slide, "相对于最佳基线的平均相对成功率提升\n不是增加 46.9 个百分点", 82, 403, 430, 56, { size: 17, color: C.body });
  addPaperImage(slide, figures.ablations, 540, 160, 650, 284, "论文 Figure 6：动作执行时域与延迟消融");
  text(slide, "动作执行长度与延迟消融", 540, 445, 650, 28, { size: 15, color: C.muted });
  rule(slide, 82, 488, 1110, C.rule, 1.5);
  text(slide, "真实 Push-T · UR5 · 20 次评测", 82, 505, 480, 31, { size: 20, color: C.ink, bold: true });
  text(slide, "成功率：Diffusion Policy 95%  |  LSTM-GMM 20%  |  IBC 0%", 82, 542, 620, 34, {
    size: 18,
    color: C.body,
  });
  text(slide, "平均 IoU 0.80，演示均值 0.84", 82, 580, 500, 30, { size: 18, color: C.body });
  text(slide, "多数任务 Tₐ=8 较优；模拟延迟最多 4 步仍保持峰值。\n位置控制比速度控制更不易受延迟影响。", 700, 525, 490, 66, {
    size: 17,
    color: C.body,
  });
  text(slide, "期刊扩展版还评测三项双臂任务：成功率 55%、75%、75%（各 20 次）。", 700, 603, 490, 27, {
    size: 14,
    color: C.muted,
  });
  slide.speakerNotes.text = `${references[6].time}｜${references[6].speech}\n\n${references[6].source}`;
  slide.speakerNotes.setVisible(true);
}

// 8. Conclusion and boundary
{
  const slide = slideBase(
    presentation,
    "结论与边界",
    "动作表示、序列预测与闭环控制共同构成方法",
    8,
    "Chi et al., IJRR 2025, §§9–10, p. 1698",
  );
  text(slide, "方法贡献", 82, 166, 470, 38, { size: 24, color: C.blue, bold: true });
  text(slide, "条件扩散表达多种可行动作块；执行前缀后重观测，使长计划保留反馈能力。", 82, 220, 470, 124, {
    size: 23,
    color: C.ink,
  });
  rule(slide, 620, 166, 2, C.rule, 370);
  text(slide, "适用边界", 680, 166, 450, 38, { size: 24, color: C.green, bold: true });
  text(slide, "行为克隆依赖示范覆盖；\n多步去噪增加推理成本；\n安全约束仍由控制系统负责。", 680, 220, 480, 146, {
    size: 21,
    color: C.body,
  });
  rule(slide, 82, 405, 1110, C.rule, 1.5);
  text(slide, "复现建议", 82, 431, 150, 36, { size: 21, color: C.blue, bold: true });
  text(slide, "先核对数据与坐标归一化、动作时域和控制接口，再判断网络结构是否需要调整。", 232, 431, 930, 68, {
    size: 21,
    color: C.ink,
  });
  text(slide, "核心结论：Diffusion Policy 的效果来自生成式动作表示与机器人闭环执行的协同设计。", 82, 544, 1110, 60, {
    size: 25,
    color: C.green,
    bold: true,
  });
  slide.speakerNotes.text = `${references[7].time}｜${references[7].speech}\n\n${references[7].source}`;
  slide.speakerNotes.setVisible(true);
}

await fs.mkdir(buildDir, { recursive: true });
const previewDir = path.join(buildDir, "final-preview");
await fs.mkdir(previewDir, { recursive: true });
for (let i = 0; i < presentation.slides.items.length; i++) {
  const png = await presentation.export({ slide: presentation.slides.items[i], format: "png", scale: 1 });
  await fs.writeFile(path.join(previewDir, `slide-${String(i + 1).padStart(2, "0")}.png`), new Uint8Array(await png.arrayBuffer()));
}

const stagingDir = path.join(buildDir, "finalizer");
await fs.mkdir(stagingDir, { recursive: true });
const receiptDir = path.join(workspaceDir, ".codex_presentation_validation");
await fs.mkdir(receiptDir, { recursive: true });
const candidatePath = path.join(stagingDir, "candidate.pptx");
await (await PresentationFile.exportPptx(presentation)).save(candidatePath);

const skillDir = "C:/Users/laiyo/.codex/plugins/cache/openai-primary-runtime/presentations/26.1022.11436/skills/Presentations";
const { finalizePresentation } = await import(pathToFileURL(path.join(skillDir, "container_tools/artifact_tool_utils.mjs")).href);
const result = await finalizePresentation({
  workspaceDir,
  candidatePath,
  finalPath,
  pythonExecutable: process.env.RUNTIME_PYTHON,
  integrityValidatorPath: path.join(skillDir, "container_tools/inspect_presentation_package_integrity.py"),
  layoutValidatorPath: path.join(skillDir, "container_tools/inspect_presentation_layout_geometry.py"),
  layoutArgs: ["--expected-slide-size-emu", "12192000,6858000", "--validate-heading-fit"],
  explicitTotalSlideCount: 8,
  fontPolicy: { basis: "design", families: [FONT, MATH] },
  verifyArtifactToolImport: true,
  receiptPath: path.join(receiptDir, "diffusion_policy_advisor_report_reworked_v2.validation.json"),
});
console.log(JSON.stringify({ finalPath, slideCount: presentation.slides.items.length, result }, null, 2));
