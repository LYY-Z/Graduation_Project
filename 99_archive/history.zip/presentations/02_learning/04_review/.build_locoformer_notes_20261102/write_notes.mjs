import fs from 'node:fs/promises';
import path from 'node:path';
import {PresentationFile, FileBlob} from '@oai/artifact-tool';

const B = 'G:/毕设/02_learning/04_review/.build_locoformer_notes_20261102';
const source = path.join(B, 'source.pptx');
const md = await fs.readFile(path.join(B, 'speech_revised.md'), 'utf8');
const sections = md.split(/^## /m).slice(1).map((section, index) => {
  const newline = section.indexOf('\n');
  const heading = section.slice(0, newline).trim();
  const body = section.slice(newline + 1).trim().replace(/\n+---\s*$/, '').trim();
  return {slide: index + 1, heading, body};
});
if (sections.length !== 14) throw new Error('Expected 14 speech sections');
const presentation = await PresentationFile.importPptx(await FileBlob.load(source));
if (presentation.slides.items.length !== 14) throw new Error('Unexpected source slide count');
const sourceInspection = await presentation.inspect({select: '$.slides[*]', include: ['index', 'title', 'notes.text']});
await fs.writeFile(path.join(B, 'source-inspection.ndjson'), sourceInspection.ndjson);
for (let i = 0; i < 14; i++) {
  const slide = presentation.slides.items[i];
  const existing = slide.speakerNotes.text.trim();
  const record = sourceInspection.records[i];
  if (!sections[i].heading.includes(record.title)) throw new Error(`Title mismatch on ${i + 1}: ${record.title}`);
  sections[i].title = record.title;
  sections[i].referenceNotes = existing;
  sections[i].notes = sections[i].body + '\n\n——资料核对（不朗读）——\n' + existing;
  slide.speakerNotes.text = sections[i].notes;
  slide.speakerNotes.setVisible(true);
}
await fs.writeFile(path.join(B, 'notes-authored.json'), JSON.stringify(sections, null, 2));
await (await PresentationFile.exportPptx(presentation)).save(path.join(B, 'candidate.pptx'));
console.log(JSON.stringify({authoredSlides: sections.length, candidate: path.join(B, 'candidate.pptx')}));
