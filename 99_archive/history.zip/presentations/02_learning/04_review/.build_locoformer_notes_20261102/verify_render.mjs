import fs from 'node:fs/promises';
import path from 'node:path';
import {PresentationFile, FileBlob} from '@oai/artifact-tool';
const B = 'G:/毕设/02_learning/04_review/.build_locoformer_notes_20261102';
const BASE = 'G:/毕设/02_learning/04_review/.build_locoformer_flow_20261102/final-preview';
const p = await PresentationFile.importPptx(await FileBlob.load(path.join(B, 'validated/locoformer_paper_report_presenter.pptx')));
const authored = JSON.parse(await fs.readFile(path.join(B, 'notes-authored.json'), 'utf8'));
const inspection = await p.inspect({select: '$.slides[*]', include: ['index', 'title', 'notes.text']});
await fs.writeFile(path.join(B, 'final-inspection.ndjson'), inspection.ndjson);
await fs.mkdir(path.join(B, 'final-preview'), {recursive: true});
const checks = [];
for (let i = 0; i < 14; i++) {
  if (inspection.records[i].title !== authored[i].title) throw new Error(`Title mismatch ${i + 1}`);
  const notes = p.slides.items[i].speakerNotes.text;
  if (notes.trim() !== authored[i].notes.trim()) throw new Error(`Notes mismatch ${i + 1}`);
  const png = await p.export({slide: p.slides.items[i], format: 'png', scale: 1});
  const bytes = Buffer.from(await png.arrayBuffer());
  const name = `slide-${String(i + 1).padStart(2, '0')}.png`;
  await fs.writeFile(path.join(B, 'final-preview', name), bytes);
  const identical = bytes.equals(await fs.readFile(path.join(BASE, name)));
  if (!identical) throw new Error(`Rendered slide changed ${i + 1}`);
  checks.push({slide: i + 1, speechMatches: true, renderedSlideIdentical: identical});
}
await fs.writeFile(path.join(B, 'visual-and-notes-verification.json'), JSON.stringify({checks, slideCount: 14}, null, 2));
console.log(JSON.stringify({slideCount: 14, allSpeechMatches: true, allRenderedSlidesUnchanged: true}));
