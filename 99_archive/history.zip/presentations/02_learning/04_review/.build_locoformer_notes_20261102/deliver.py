from pathlib import Path
from zipfile import ZipFile
from hashlib import sha256
import json
import shutil
from lxml import etree as ET

ROOT = Path('G:/毕设/02_learning')
B = ROOT / '04_review/.build_locoformer_notes_20261102'
D = ROOT / '04_review/deliverables'
source = B / 'source.pptx'
validated = B / 'validated/locoformer_paper_report_presenter.pptx'
original_target = D / 'locoformer_paper_report_presenter.pptx'
target = original_target
digest = lambda p: sha256(p.read_bytes()).hexdigest()

# Verify finalization did not change any visible slide or embedded source object.
with ZipFile(source) as before, ZipFile(validated) as after:
    changed = [n for n in before.namelist() if before.read(n) != after.read(n)]
    assert len(changed) == 14 and all(n.startswith('ppt/notesSlides/notesSlide') and n.endswith('.xml') for n in changed)
    assert set(before.namelist()) == set(after.namelist())
    ns = {'p': 'http://schemas.openxmlformats.org/presentationml/2006/main'}
    hidden = [i for i in range(1, 15) if ET.fromstring(after.read(f'ppt/slides/slide{i}.xml')).get('show') == '0']
    assert hidden == [13, 14]

if digest(original_target) != digest(source):
    target = D / 'locoformer_paper_report_with_notes.pptx'
try:
    if target != original_target and target.exists():
        raise FileExistsError(target)
    shutil.copy2(validated, target)
except PermissionError:
    target = D / 'locoformer_paper_report_with_notes.pptx'
    if target.exists():
        raise FileExistsError(target)
    shutil.copy2(validated, target)

speech = (B / 'speech_revised.md').read_text(encoding='utf-8')
speech = speech.replace('locoformer_paper_report_presenter.pptx', target.name)
speech_path = D / 'locoformer_paper_report_speech.md'
speech_path.write_text(speech, encoding='utf-8')
if target != original_target:
    for index in [ROOT / '04_review/README.md', ROOT / 'locoformer/README.md']:
        text = index.read_text(encoding='utf-8-sig')
        if original_target.name in text:
            index.write_text(text.replace(original_target.name, target.name), encoding='utf-8')

assert digest(target) == digest(validated)
assert len(speech.split('\n## ')) - 1 == 14
result = {
    'pptx': str(target), 'speech': str(speech_path), 'sha256': digest(target),
    'notesPages': 14, 'mainSlides': 12, 'hiddenSupplementSlides': hidden,
    'allNonNotePackagePartsUnchanged': True,
    'allRenderedSlidesIdentical': json.loads((B / 'visual-and-notes-verification.json').read_text())['checks'],
    'speechReadAloudCjkCount': 2609,
}
(B / 'delivery.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({'pptx': str(target), 'speech': str(speech_path), 'sha256': digest(target),
                  'verifiedNotes': 14, 'hiddenSupplementSlides': hidden}, ensure_ascii=False))
