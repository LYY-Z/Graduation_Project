"""Transfer Artifact Tool-authored note bodies without reserializing slide content."""
from copy import deepcopy
from hashlib import sha256
from pathlib import Path
from posixpath import dirname, join, normpath
from zipfile import ZipFile
import json
from lxml import etree as ET

B = Path('G:/毕设/02_learning/04_review/.build_locoformer_notes_20261102')
NS = {'p': 'http://schemas.openxmlformats.org/presentationml/2006/main',
      'a': 'http://schemas.openxmlformats.org/drawingml/2006/main',
      'r': 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}
R = '{http://schemas.openxmlformats.org/package/2006/relationships}'


def target(base, relative):
    return normpath(relative.lstrip('/') if relative.startswith('/') else join(dirname(base), relative))


def ordered_notes(z):
    root = ET.fromstring(z.read('ppt/presentation.xml'))
    rels = ET.fromstring(z.read('ppt/_rels/presentation.xml.rels'))
    by_id = {r.get('Id'): target('ppt/presentation.xml', r.get('Target')) for r in rels}
    paths = []
    for slide in root.findall('p:sldIdLst/p:sldId', NS):
        slide_path = by_id[slide.get('{' + NS['r'] + '}id')]
        rel_path = join(dirname(slide_path), '_rels', slide_path.rsplit('/', 1)[1] + '.rels')
        rel_root = ET.fromstring(z.read(rel_path))
        note = [r for r in rel_root if r.get('Type', '').endswith('/notesSlide')]
        assert len(note) == 1
        paths.append(target(slide_path, note[0].get('Target')))
    return paths


def body(root):
    result = root.xpath('//p:sp[p:nvSpPr/p:nvPr/p:ph[@type="body"]]/p:txBody', namespaces=NS)
    assert len(result) == 1
    return result[0]


def text(node):
    return '\n'.join(''.join(p.itertext()) if False else ''.join(p.xpath('.//a:t/text()', namespaces=NS))
                     for p in node.findall('a:p', NS))


records = json.loads((B / 'notes-authored.json').read_text(encoding='utf-8'))
with ZipFile(B / 'source.pptx') as source, ZipFile(B / 'candidate.pptx') as authored:
    source_paths = ordered_notes(source)
    authored_paths = ordered_notes(authored)
    assert len(source_paths) == len(authored_paths) == len(records) == 14
    replacements = {}
    for index, (original_path, authored_path) in enumerate(zip(source_paths, authored_paths)):
        original_root = ET.fromstring(source.read(original_path))
        authored_body = body(ET.fromstring(authored.read(authored_path)))
        assert text(authored_body).strip() == records[index]['notes'].strip(), index + 1
        original_body = body(original_root)
        original_body.getparent().replace(original_body, deepcopy(authored_body))
        replacements[original_path] = ET.tostring(original_root, encoding='UTF-8', xml_declaration=True, standalone=True)
    output = B / 'candidate_preserved.pptx'
    with ZipFile(output, 'w') as final:
        final.comment = source.comment
        for item in source.infolist():
            final.writestr(item, replacements.get(item.filename, source.read(item.filename)))

with ZipFile(B / 'source.pptx') as source, ZipFile(output) as final:
    assert set(source.namelist()) == set(final.namelist())
    changed = [n for n in source.namelist() if source.read(n) != final.read(n)]
    assert set(changed) == set(source_paths)
    for index, n in enumerate(source_paths):
        assert text(body(ET.fromstring(final.read(n)))).strip() == records[index]['notes'].strip()

(B / 'preservation-verification.json').write_text(json.dumps({
    'sourceSha256': sha256((B / 'source.pptx').read_bytes()).hexdigest(),
    'candidateSha256': sha256(output.read_bytes()).hexdigest(),
    'changedMembers': changed,
    'allOtherMembersByteIdentical': True,
    'speechNotesMatchAll14Sections': True,
}, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({'notesUpdated': len(changed), 'visibleSlidePartsByteIdentical': True}))
