import path from "node:path";
import { pathToFileURL } from "node:url";
import { finalizePresentation } from "file:///C:/Users/laiyo/.codex/plugins/cache/openai-primary-runtime/presentations/26.1022.11436/skills/presentations/container_tools/artifact_tool_utils.mjs";

process.env.RUNTIME_NODE_MODULES = "C:/Users/laiyo/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules";
const workspaceDir = "G:/毕设/02_learning/04_review";
const skillDir = "C:/Users/laiyo/.codex/plugins/cache/openai-primary-runtime/presentations/26.1022.11436/skills/presentations";
const finalPath = "G:/毕设/02_learning/04_review/deliverables/diffusion_policy_advisor_report_10min_refined_v4.pptx";
const sourcePath = "G:/毕设/02_learning/04_review/deliverables/diffusion_policy_advisor_report_10min_refined_v3.pptx";

const result = await finalizePresentation({
  explicitTotalSlideCount: 10,
  workspaceDir,
  candidatePath: "G:/毕设/02_learning/04_review/.build_dp_advisor_v4/candidate.pptx",
  finalPath,
  pythonExecutable: "C:/Users/laiyo/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe",
  integrityValidatorPath: path.join(skillDir, "container_tools/inspect_presentation_package_integrity.py"),
  layoutValidatorPath: path.join(skillDir, "container_tools/inspect_presentation_layout_geometry.py"),
  layoutArgs: [
    "--expected-slide-size-emu", "12192000,6858000",
    "--validate-bullet-geometry",
    "--validate-heading-fit",
  ],
  fontPolicy: {
    basis: "reference",
    families: ["微软雅黑", "Cambria Math"],
    referencePath: sourcePath,
    referenceSha256: "5c361a5c332a6667c135e40a283e37908ffefd775c5634cb027382d3238527ab",
  },
  verifyArtifactToolImport: true,
  receiptPath: "G:/毕设/02_learning/04_review/.build_dp_advisor_v4/diffusion_policy_advisor_report_10min_refined_v4.validation.json",
});
console.log(JSON.stringify(result, null, 2));
