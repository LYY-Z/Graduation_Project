import fs from "node:fs/promises";
import { FileBlob, PresentationFile } from "@oai/artifact-tool";

const sourcePath = "G:/毕设/02_learning/04_review/deliverables/diffusion_policy_advisor_report_10min_refined_v3.pptx";
const draftPath = "G:/毕设/02_learning/04_review/.build_dp_advisor_v4/candidate.pptx";
const previewPath = "G:/毕设/02_learning/04_review/.build_dp_advisor_v4/edited_slide6.png";
const presentation = await PresentationFile.importPptx(await FileBlob.load(sourcePath));
const slide = presentation.slides.items[5];
presentation.resolve("sh/va98j210").text = "反向采样：从噪声预测到下一步动作";

const keep = new Set([
  "sh/va98j210", // title
  "sh/yhg7epsj", // top rule
  "sh/zi98nu94", // accent rule
  "sh/87ipkzal", // footer rule
  "sh/ml07i9sv", // page number
  "sh/7m98ru9g", // subtitle
]);
const snapshot = await presentation.inspect({
  kind: "slide,textbox,shape,image,table,chart",
  target: { id: "sl/x8f69ofe", beforeLines: 0, afterLines: 100 },
  maxChars: 24000,
});
const removeIds = snapshot.records
  .filter((record) => record.slideIndex === 5 && record.id?.startsWith("sh/") && !keep.has(record.id))
  .map((record) => record.id);
presentation.delete(removeIds);

const burgundy = "#78394C";
const ink = "#252A31";
const grey = "#646A70";
const line = "#DED9D2";
const cream = "#F4EFE5";
const blush = "#F0E8EA";
const font = "微软雅黑";
const math = "Cambria Math";

function addText(name, text, position, options = {}) {
  const shape = slide.shapes.add({
    geometry: "textbox",
    name,
    position,
    text: {
      text,
      style: {
        fontSize: options.fontSize ?? 18,
        typeface: options.typeface ?? font,
        color: options.color ?? ink,
        bold: options.bold ?? false,
        alignment: options.alignment ?? "left",
        verticalAlignment: options.verticalAlignment ?? "middle",
        autoFit: "shrinkText",
        wrap: true,
        insets: 0,
      },
    },
  });
  return shape;
}

function addBox(name, position, fill, border = line) {
  return slide.shapes.add({
    geometry: "roundRect",
    name,
    position,
    fill,
    line: { style: "solid", fill: border, width: 1 },
    borderRadius: 8,
  });
}

// A single forward reading path: estimate noise -> calculate the center -> sample.
addBox("reverse-step-1", { left: 66, top: 184, width: 340, height: 92 }, "#FFFFFF");
addText("reverse-step-1-label", "01  预测噪声", { left: 86, top: 194, width: 300, height: 30 }, { fontSize: 20, color: burgundy, bold: true });
addText("reverse-step-1-body", "输入当前动作块 Aₜᵏ、观察 Oₜ 和步数 k\n输出 εθ：估计其中的噪声", { left: 86, top: 226, width: 300, height: 42 }, { fontSize: 15.5, color: grey });

addText("reverse-arrow-1", "→", { left: 411, top: 205, width: 48, height: 44 }, { fontSize: 28, color: "#B58A4A", alignment: "center" });

addBox("reverse-step-2", { left: 468, top: 184, width: 340, height: 92 }, blush, "#D8C8CC");
addText("reverse-step-2-label", "02  计算中心 μθ", { left: 488, top: 194, width: 300, height: 30 }, { fontSize: 20, color: burgundy, bold: true });
addText("reverse-step-2-body", "用噪声预测反推干净动作，再代入后验均值", { left: 488, top: 230, width: 300, height: 38 }, { fontSize: 15.5, color: grey });

addText("reverse-arrow-2", "→", { left: 813, top: 205, width: 48, height: 44 }, { fontSize: 28, color: "#B58A4A", alignment: "center" });

addBox("reverse-step-3", { left: 866, top: 184, width: 348, height: 92 }, "#FFFFFF");
addText("reverse-step-3-label", "03  抽取下一步", { left: 886, top: 194, width: 308, height: 30 }, { fontSize: 20, color: burgundy, bold: true });
addText("reverse-step-3-body", "围绕中心加入按 σₖ 控制的随机波动", { left: 886, top: 230, width: 308, height: 38 }, { fontSize: 15.5, color: grey });

addBox("reverse-mean-panel", { left: 66, top: 294, width: 1148, height: 142 }, "#FFFFFF");
addText("reverse-mean-label", "标准 DDPM 的反向均值（下一步分布的中心）", { left: 88, top: 305, width: 1104, height: 27 }, { fontSize: 16, color: burgundy, bold: true });
addText("reverse-mean-equation", "μθ(Oₜ,Aₜᵏ,k) = 1/√αₖ [ Aₜᵏ − βₖ εθ(Oₜ,Aₜᵏ,k) / √(1−ᾱₖ) ]", { left: 88, top: 336, width: 1104, height: 45 }, { fontSize: 24, typeface: math, alignment: "center" });
addText("reverse-mean-derivation", "它不是另造的规则：用噪声预测反推的干净动作 Âₜ⁰，替代后验均值里未知的真实 Aₜ⁰。", { left: 88, top: 386, width: 1104, height: 34 }, { fontSize: 15.5, color: grey, alignment: "center" });

addBox("reverse-sample-panel", { left: 66, top: 451, width: 1148, height: 86 }, cream, "#DED9D2");
addText("reverse-sample-equation", "Aₜᵏ⁻¹ = μθ + σₖ z", { left: 88, top: 461, width: 420, height: 46 }, { fontSize: 25, typeface: math, color: ink, alignment: "center" });
addText("reverse-sample-explanation", "从反向高斯分布中抽样：μθ 定中心，σₖz 是随机偏移。", { left: 530, top: 463, width: 650, height: 42 }, { fontSize: 17, color: ink });

addBox("reverse-definition-mean", { left: 66, top: 549, width: 354, height: 58 }, "#FFFFFF");
addText("reverse-definition-mean-text", "μθ：下一步分布的中心", { left: 82, top: 559, width: 322, height: 38 }, { fontSize: 16, color: burgundy, bold: true, alignment: "center" });
addBox("reverse-definition-sigma", { left: 430, top: 549, width: 354, height: 58 }, "#FFFFFF");
addText("reverse-definition-sigma-text", "σₖ：标准差；σₖ² = β̃ₖ（方差）", { left: 446, top: 559, width: 322, height: 38 }, { fontSize: 15.5, color: burgundy, bold: true, alignment: "center" });
addBox("reverse-definition-z", { left: 794, top: 549, width: 420, height: 58 }, "#FFFFFF");
addText("reverse-definition-z-text", "z ~ N(0,I)：推理时新抽取的噪声", { left: 810, top: 559, width: 388, height: 38 }, { fontSize: 15.5, color: burgundy, bold: true, alignment: "center" });

addText("reverse-noise-distinction", "训练 ε 是已知监督目标；推理 z 是每步新抽的随机量（最后一步通常取 0）。论文 Eq. (4) 是另一参数化，系数不可与本式混用。", { left: 72, top: 615, width: 1136, height: 38 }, { fontSize: 13.5, color: grey, alignment: "center" });

// The user explicitly requested clearing all speaker notes in the deck.
for (const item of presentation.slides.items) item.speakerNotes.clear();

const preview = await slide.export({ format: "png", scale: 1.5 });
await fs.writeFile(previewPath, new Uint8Array(await preview.arrayBuffer()));
await (await PresentationFile.exportPptx(presentation)).save(draftPath);
console.log(JSON.stringify({
  slides: presentation.slides.items.length,
  deletedObjects: removeIds.length,
  notesRemaining: presentation.slides.items.filter((item) => item.speakerNotes.text?.trim()).length,
  draftPath,
  previewPath,
}, null, 2));
