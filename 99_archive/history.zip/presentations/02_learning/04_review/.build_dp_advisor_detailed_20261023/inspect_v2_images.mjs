import { FileBlob, PresentationFile } from '@oai/artifact-tool';
const input = 'G:/毕设/02_learning/04_review/deliverables/diffusion_policy_advisor_report_10min_refined_v2.pptx';
const p = await PresentationFile.importPptx(await FileBlob.load(input));
for (const [i, slide] of p.slides.items.entries()) {
  const images = slide.images?.items ?? [];
  if (images.length) {
    console.log(JSON.stringify({ slide: i + 1, slideId: slide.id, count: images.length, images: images.map((im) => ({ keys: Object.keys(im), id: im.id, frame: im.frame, crop: im.crop, fit: im.fit, alt: im.alt, src: im.src, path: im.path, blob: im.blob ? String(im.blob).slice(0, 60) : null })) }));
  }
}
const result = await p.inspect({ select: '$.slides[*]', include: ['id', 'index', 'title', 'elements.id', 'elements.kind', 'elements.alt', 'elements.text', 'elements.position'] });
console.log(result.ndjson.split('\n').filter((line) => line.includes('"kind":"image"')).join('\n'));
