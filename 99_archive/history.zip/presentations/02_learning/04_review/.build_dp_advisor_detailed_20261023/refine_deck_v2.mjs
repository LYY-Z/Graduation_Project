import fs from 'node:fs/promises';
import path from 'node:path';
import { FileBlob, PresentationFile } from '@oai/artifact-tool';

const workspaceDir = 'G:/毕设/02_learning/04_review';
const buildDir = path.join(workspaceDir, '.build_dp_advisor_detailed_20261023');
const sourcePath = path.join(workspaceDir, 'deliverables', 'diffusion_policy_advisor_report_10min_refined.pptx');
const draftPath = path.join(buildDir, 'diffusion_policy_advisor_report_10min_refined_v2_draft.pptx');
const C = { bg: '#F5F3F0', ink: '#252A31', muted: '#646A70', plum: '#78394C', ochre: '#B58A4A', line: '#DED9D2', white: '#FFFFFF', palePlum: '#F0E8EA', paleGold: '#F4EFE5', paleGreen: '#E9EDE8' };
const FONT = 'Microsoft YaHei';
const MATH = 'Cambria Math';
const presentation = await PresentationFile.importPptx(await FileBlob.load(sourcePath));

function setText(id, value) {
  const shape = presentation.resolve(id);
  if (!shape?.text) throw new Error(`Text shape not found: ${id}`);
  shape.text = value;
}

function text(slide, name, value, x, y, w, h, options = {}) {
  const shape = slide.shapes.add({
    geometry: 'textbox', name,
    position: { left: x, top: y, width: w, height: h },
    fill: 'none', line: { style: 'solid', fill: 'none', width: 0 },
  });
  shape.text = value;
  shape.text.style = {
    typeface: options.font ?? FONT,
    fontSize: options.size ?? 18,
    color: options.color ?? C.ink,
    bold: options.bold ?? false,
    alignment: options.align ?? 'left',
    verticalAlignment: options.valign ?? 'middle',
    wrap: 'square', autoFit: 'shrinkText', insets: 0,
  };
  return shape;
}

function rect(slide, name, x, y, w, h, fill = C.white, stroke = C.line) {
  return slide.shapes.add({
    geometry: 'rect', name,
    position: { left: x, top: y, width: w, height: h },
    fill, line: { style: 'solid', fill: stroke, width: stroke === 'none' ? 0 : 1 },
  });
}

function rule(slide, name, x, y, w, h = 1.5, color = C.line) {
  return rect(slide, name, x, y, w, h, color, 'none');
}

function header(slide, title, page, citation, subtitle) {
  text(slide, 'slide-title', title, 64, 38, 1135, 62, { size: 38, bold: true });
  rule(slide, 'header-rule', 64, 113, 1152, 1.5, C.line);
  rule(slide, 'header-accent', 64, 113, 72, 3, C.plum);
  text(slide, 'slide-subtitle', subtitle, 66, 132, 1120, 42, { size: 21, color: C.plum, bold: true });
  rule(slide, 'footer-rule', 64, 668, 1152, 1, C.line);
  text(slide, 'slide-citation', citation, 64, 679, 1085, 22, { size: 14, color: C.muted });
  text(slide, 'slide-page', `${String(page).padStart(2, '0')} / 09`, 1155, 679, 61, 22, { size: 14, color: C.muted, align: 'right' });
}

// Preserve the strongest framing from the alternate deck, while keeping claims tied to the paper.
setText('sh/v6l4jq94', '学习动作分布的 score，绕开难估的归一化常数 Z；不同随机起点可生成不同有效模式。');
presentation.resolve('sh/v6l4jq94').text.fontSize = 17;
setText('sh/032tgr6d', 'DDPM 的图像 x₀ 换为未来 Tₚ 步动作块 Aₜ⁰（[Tₚ,Dₐ]）；观察 Oₜ 只作条件，不参与加噪。');
setText('sh/x4r21kru', '02 / 09');
setText('sh/obq90bml', '03 / 09');

// Slide 4: make the encoder data path, task-driven representation learning, and normalization choice visible.
const slide4 = presentation.resolve('sl/jyx0ra1s');
setText('sh/sna103ap', '最近 Tₒ 帧多视角图像与本体状态提供条件；仅动作块被扩散。');
setText('sh/kbm987y5', '最近 Tₒ 帧：多视角图像\n机器人本体状态');
setText('sh/jadsz2xk', '各相机独立 ResNet-18（不预训练）\nSpatial Softmax 保留空间位置\n视觉与本体特征拼接为 Oₜ');
presentation.delete(['sh/tsrqlc7u', 'sh/sri9s7q9']);
text(slide4, 'slide4-learning-heading', '视觉表征由动作监督塑造', 70, 588, 535, 24, { size: 18, color: C.plum, bold: true });
text(slide4, 'slide4-learning-body', '无对象类别标签；ε-MSE 梯度经去噪器回传 ResNet，学习目标位置、接触等动作线索。实机消融支持端到端训练。', 70, 614, 535, 42, { size: 16, color: C.ink });
rule(slide4, 'encoder-note-divider', 640, 590, 1.5, 62, C.line);
text(slide4, 'slide4-gn-ema-heading', 'GroupNorm 与 EMA', 674, 588, 520, 24, { size: 18, color: C.plum, bold: true });
text(slide4, 'slide4-gn-ema-body', 'BatchNorm 运行均值/方差对应在线模型；GroupNorm 不依赖跨批次统计量，减少与 EMA 平滑参数之间的不匹配。', 674, 614, 520, 42, { size: 16, color: C.ink });
setText('sh/ql8jytsj', 'Chi et al., IJRR 2025, Figure 2, §§3.2, 5.4, 6.1.2, pp. 1687, 1692–1693');
setText('sh/doj29oba', '04 / 09');

// Slide 5 heading keeps the training page connected to the original image-DDPM formulation.
setText('sh/l4bupwny', '05 / 09');

// Slide 6: separate reverse sampling mathematics from the robot control loop.
setText('sh/va98j210', '反向采样：噪声预测如何变成下一步动作');
setText('sh/7m98ru9g', '推理从纯高斯动作块 Aₜᴷ 起步；贝叶斯后验给出反向更新中心。');
presentation.resolve('sh/7m98ru9g').position = { left: 66, top: 135, width: 1120, height: 32 };
presentation.resolve('sh/7m98ru9g').text.fontSize = 21;
presentation.delete([
  'sh/oryp8fah', 'sh/pc76hkr2', 'sh/h4bupgn6', 'sh/w32twb6l', 'sh/v2tcn650',
  'sh/u1kbu1ov', 'sh/5svutgni', 'sh/47mt0b6x', 'sh/j6dcr65c', 'sh/i54bylor',
  'sh/twfux0ne', 'sh/svmt4v6t', 'sh/cbe5g3ih', 'sh/dcnm98zm', 'sh/qpwnet0b',
  'sh/bq547yhw', 'sh/0fy5k3id', 'sh/lg76d8zy', 'sh/ydgnit07', 'sh/zep4byhs',
  'sh/gju58ji9', 'sh/1k3mhozu', 'sh/jet8nm1c', 'sh/idk7ehkr', 'sh/50bqpcj2',
  'sh/4f2pgr2h', 'sh/u907axkf', 'sh/hcrqlcj6',
]);
const slide6 = presentation.resolve('sl/x8f69ofe');

rect(slide6, 'ddpm-posterior-card', 66, 184, 556, 267, C.white, C.line);
text(slide6, 'ddpm-card-title', '① 标准 DDPM：后验均值与随机采样', 84, 194, 520, 30, { size: 19, color: C.plum, bold: true });
text(slide6, 'ddpm-posterior', 'q(Aₜᵏ⁻¹ | Aₜᵏ, Aₜ⁰) = N(μ̃ₖ, β̃ₖ I)', 84, 231, 520, 32, { size: 17, font: MATH, align: 'center' });
text(slide6, 'ddpm-mean-equation', 'μθ = 1/√αₖ [ Aₜᵏ − βₖ εθ / √(1−ᾱₖ) ]', 82, 269, 524, 42, { size: 20, font: MATH, align: 'center' });
text(slide6, 'ddpm-sample-equation', 'Aₜᵏ⁻¹ = μθ + σₖ z，z ~ N(0,I)', 84, 315, 520, 35, { size: 21, font: MATH, align: 'center' });
text(slide6, 'ddpm-variance-equation', 'σₖ² = β̃ₖ = βₖ (1−ᾱₖ₋₁) / (1−ᾱₖ)', 84, 352, 520, 32, { size: 17, font: MATH, align: 'center', color: C.muted });
text(slide6, 'ddpm-posterior-explanation', '后验给出中心 μ̃ₖ；生成时用 εθ 估计未知 Aₜ⁰ 得 μθ。σ 是标准差、σ²为方差；最后一步通常令 z=0。', 84, 388, 520, 52, { size: 15.5, color: C.muted });

rect(slide6, 'score-paper-update-card', 646, 184, 568, 267, C.palePlum, C.line);
text(slide6, 'score-card-title', '② 噪声预测的两种读法', 666, 194, 528, 30, { size: 19, color: C.plum, bold: true });
text(slide6, 'score-equation', 'ŝθ ≈ − εθ(Oₜ, Aₜᵏ, k) / √(1−ᾱₖ)', 666, 230, 528, 38, { size: 21, font: MATH, align: 'center' });
text(slide6, 'score-explanation', '近似 score：∇A log p(A|O)，即动作分布的高概率方向。分母是噪声标准差，把噪声预测换算到 score 尺度。', 666, 269, 528, 48, { size: 15.5, color: C.muted });
rule(slide6, 'score-paper-divider', 666, 322, 528, 1, '#D8C8CC');
text(slide6, 'paper-eq4-label', 'Diffusion Policy · Eq. (4) · Langevin 风格更新', 666, 329, 528, 24, { size: 16, color: C.plum, bold: true });
text(slide6, 'paper-eq4', 'Aₜᵏ⁻¹ = αₖ [ Aₜᵏ − γₖ εθ(Oₜ,Aₜᵏ,k) + σₖ z ]', 660, 354, 540, 38, { size: 18, font: MATH, align: 'center' });
text(slide6, 'paper-update-caveat', '论文 Eq. (4) 的 αₖ、γₖ、σₖ不与标准 DDPM 系数互换。训练 ε 是已知监督噪声；推理 z ~ N(0,I) 是每步新抽样的张量。', 666, 393, 528, 50, { size: 14.5, color: C.muted });

rect(slide6, 'ddim-skip-card', 66, 467, 1148, 184, C.white, C.line);
text(slide6, 'ddim-card-title', '③ DDIM：减少推理迭代，可跳过中间扩散级', 86, 477, 1108, 30, { size: 20, color: C.plum, bold: true });
text(slide6, 'ddim-x0-equation', 'Âₜ⁰ = [ Aₜᵏ − √(1−ᾱₖ) ε̂ₖ ] / √ᾱₖ', 86, 510, 1108, 29, { size: 19, font: MATH, align: 'center' });
text(slide6, 'ddim-jump-equation', 'Aₜʲ = √ᾱⱼ Âₜ⁰ + √(1−ᾱⱼ) ε̂ₖ，    j < k', 86, 539, 1108, 32, { size: 20, font: MATH, align: 'center' });
rule(slide6, 'ddim-bottom-divider', 640, 576, 1, 59, C.line);
text(slide6, 'ddim-jump-explanation', '先由噪声估计反推干净动作 Âₜ⁰，再按目标级别 j 重组；因此可以跳级，而非逐步走过所有 k。', 86, 578, 518, 58, { size: 16, color: C.ink });
text(slide6, 'ddim-speed-example', '主文实机示例：100 个训练步、10 个推理步；RTX 3080 上约 0.1 秒。', 668, 578, 520, 58, { size: 16, color: C.ink });
setText('sh/98rqt4r6', 'Chi et al., IJRR 2025, Eqs. (1), (4), §§2.1–2.3, pp. 1686, 1688');
setText('sh/ml07i9sv', '06 / 09');

slide6.speakerNotes.text = [
  '推理开始时没有演示动作块，先抽取 A_t^K ~ N(0,I)。网络输出 εθ 近似当前动作块中的噪声。',
  '标准 DDPM 推导：已知干净动作 A_t^0 时，前向高斯过程的后验 q(A_t^{k−1}|A_t^k,A_t^0) 是高斯，均值 μ̃_k、方差 β̃_k。生成时 A_t^0 不可见，把由 εθ 得到的干净动作估计代入后验均值，整理得到 μθ = 1/√α_k [A_t^k − β_k εθ/√(1−ᾱ_k)]。从反向分布抽样写作 A_t^{k−1}=μθ+σ_k z，常见固定小方差设定 σ_k²=β̃_k=β_k(1−ᾱ_{k−1})/(1−ᾱ_k)。因此 σ_k 是标准差，不能与方差 β̃_k 混淆。',
  'score 视角下，εθ 除以当前加噪标准差 √(1−ᾱ_k)，再取负号，近似条件动作分布的 score ∇_A log p(A|O)，也就是朝动作高概率区域移动的方向。训练里的 ε 是前向加噪时真实已知的监督目标；推理里的 z 是反向采样每一步新抽的标准高斯张量，二者角色不同。',
  'Diffusion Policy 主文 Eq. (4) 采用 Langevin 风格更新 A_t^{k−1}=α_k[A_t^k−γ_k εθ(O_t,A_t^k,k)+σ_k z]。它与标准 DDPM 都利用噪声预测去噪，但参数化不同，α_k、γ_k、σ_k 的定义不能直接互换。',
  'DDIM 允许从级别 k 跳到较小噪声级 j：利用噪声预测反推 Â_t^0，再以 √ᾱ_j Â_t^0+√(1−ᾱ_j)ε̂_k 重组 A_t^j。主文实机示例是 100 个训练扩散步、10 个推理步，RTX 3080 上约 0.1 秒；实机附录的不同模型配置使用 16 个评估步。下一页把采样输出接到闭环控制。',
  '',
  '论文来源：Chi et al., IJRR 2025, Eqs. (1), (4), §§2.1–2.3, pp. 1686, 1688。',
].join('\n');
slide6.speakerNotes.setVisible(true);

// The receding-horizon control page carries the action-chunk and warm-start details from the alternate deck.
const controlSlide = presentation.slides.insert({ after: slide6, background: { fill: C.bg } }).slide;
rect(controlSlide, 'control-slide-background', 0, 0, 1280, 720, C.bg, 'none');
header(
  controlSlide,
  '滚动时域控制：部分执行，持续重规划',
  7,
  'Chi et al., IJRR 2025, §§2.1, 3.4, 5.3.4–5.3.5, pp. 1686, 1690, 1692',
  '生成的是动作块，不是一次性开环轨迹；每执行一段，就用新观测修正后续计划。',
);

const steps = [
  { x: 70, number: '01', title: '读取观察 Oₜ', body: '最近 Tₒ 帧多视角图像\n机器人本体状态', fill: C.white },
  { x: 362, number: '02', title: '生成计划 Aₜ⁰', body: '从噪声动作块开始\n去噪得到未来 Tₚ 步', fill: C.palePlum },
  { x: 654, number: '03', title: '执行前缀 Tₐ', body: '只下发计划最前面的 Tₐ 步\n其余动作暂不执行', fill: C.paleGold },
  { x: 946, number: '04', title: '新观测后重规划', body: '读取新 Oₜ₊ₜₐ\n基于当前状态生成后续动作', fill: C.paleGreen },
];
for (const [index, step] of steps.entries()) {
  rect(controlSlide, `control-step-${index + 1}`, step.x, 193, 244, 190, step.fill, C.line);
  text(controlSlide, `control-step-number-${index + 1}`, step.number, step.x + 18, 207, 52, 28, { size: 18, color: C.ochre, bold: true, font: MATH });
  text(controlSlide, `control-step-title-${index + 1}`, step.title, step.x + 18, 241, 210, 34, { size: 21, bold: true });
  text(controlSlide, `control-step-body-${index + 1}`, step.body, step.x + 18, 287, 210, 74, { size: 17, color: C.muted });
}
text(controlSlide, 'control-arrow-1', '›', 315, 263, 38, 44, { size: 34, color: C.ochre, align: 'center' });
text(controlSlide, 'control-arrow-2', '›', 607, 263, 38, 44, { size: 34, color: C.ochre, align: 'center' });
text(controlSlide, 'control-arrow-3', '›', 899, 263, 38, 44, { size: 34, color: C.ochre, align: 'center' });

text(controlSlide, 'plan-roll-title', '动作计划如何滚动', 70, 407, 300, 30, { size: 19, color: C.plum, bold: true });
text(controlSlide, 'plan-typical-horizons', '常见配置：Tₒ=2、Tₚ=16；多数任务 Tₐ=8（实机 Push-T 为6）', 518, 407, 676, 30, { size: 16, color: C.muted, align: 'right' });
text(controlSlide, 'plan-roll-label-old', '旧计划 Aₜ⁰', 70, 444, 165, 24, { size: 16, color: C.muted, bold: true });
rect(controlSlide, 'executed-prefix', 70, 473, 292, 48, C.palePlum, C.line);
text(controlSlide, 'executed-prefix-text', '已执行前缀  Tₐ', 82, 480, 268, 32, { size: 18, color: C.plum, bold: true, align: 'center' });
rect(controlSlide, 'retained-suffix', 362, 473, 500, 48, C.paleGold, C.line);
text(controlSlide, 'retained-suffix-text', '未执行后缀：可作下一轮 warm-start 初始参考', 376, 480, 472, 32, { size: 17, color: C.ink, align: 'center' });
text(controlSlide, 'replan-arrow', '→', 876, 476, 48, 40, { size: 28, color: C.ochre, align: 'center' });
text(controlSlide, 'replan-label', '新观测到达\n再生成未来计划', 930, 465, 264, 56, { size: 17, color: C.muted, align: 'center' });

rule(controlSlide, 'control-bottom-divider', 70, 545, 1140, 1.5, C.line);
text(controlSlide, 'ta-tradeoff-title', 'Tₐ 决定执行连续性与反馈频率的折中', 70, 557, 565, 30, { size: 19, color: C.plum, bold: true });
text(controlSlide, 'ta-tradeoff-body', '太短：动作连续性下降；太长：对新观测的响应变慢。', 70, 590, 565, 44, { size: 17, color: C.muted });
text(controlSlide, 'ta-eight-highlight', '多数任务中，Tₐ = 8 步表现较好', 680, 560, 520, 32, { size: 22, color: C.ink, bold: true });
text(controlSlide, 'ta-eight-caveat', '这是论文消融中的经验结果，不是所有任务的固定常数。', 680, 596, 520, 38, { size: 16, color: C.muted });
controlSlide.speakerNotes.text = [
  'Diffusion Policy 采用滚动时域控制：时刻 t 读取最近 T_o 步的多视角图像和机器人状态，条件扩散模型生成未来 T_p 步动作块。控制器只执行前 T_a 步，随后获取新观察并重新规划。因此扩散模型输出的是候选计划，闭环控制负责根据执行后的状态不断修正。',
  '旧动作块中已经执行的前缀被丢弃；未执行后缀可以被平移或重用，作为下一轮动作块的 warm-start 初始参考，减少每轮完全从随机动作计划起步带来的变化。它只是初始化参考，不意味着旧动作会不加判断地继续执行。',
  'T_a 存在连续性与响应速度的折中：过短会频繁截断计划，过长会降低对新观察的响应。论文表格中多数图像任务使用 T_o=2、T_p=16；T_a 在多数任务中为8步，实机 Push-T 为6步。论文多数任务的消融也显示 T_a=8 步表现较好；实际系统仍需结合控制频率、任务时长与安全要求选择。',
  '',
  '论文来源：Chi et al., IJRR 2025, §§2.1, 3.4, 5.3.4–5.3.5, pp. 1686, 1690, 1692。',
].join('\n');
controlSlide.speakerNotes.setVisible(true);

// Make the experimental number auditable and carry over the alternate deck's metric caution.
setText('sh/n6x0fqlo', '逐任务计算 (DP−最佳基线)/最佳基线，再对 15 项取平均；非百分点差。');
setText('sh/ozq5szq9', '位置控制更优；Tₐ=8 在多数任务上较好，最多 4 步模拟延迟仍维持峰值表现。');
setText('sh/2x8nqp83', '期刊扩展还验证双臂长时程操作：Egg Beater 成功率 55%，Mat Unrolling 与 Shirt Folding 各 75%。');
presentation.resolve('sh/2x8nqp83').text.fontSize = 18;
setText('sh/kzmdova1', '08 / 09');

// Close with evidence, limits, and implications for a careful reproduction.
setText('sh/sjix0zy1', '论文本身支持的结论');
setText('sh/je9g3ahk', '01  在 15 项任务、4 个基准上优于同协议基线。');
setText('sh/id0fu50z', '02  动作块建模支持多模态选择与时间一致性。');
setText('sh/o7ydoret', '03  视觉条件、位置控制与闭环重规划共同影响落地。');
setText('sh/m5gvmhwn', '结论不能过度外推');
setText('sh/n6pwfmd8', '仍是行为克隆：示范未覆盖的恢复状态不保证可行。');
setText('sh/0jydkreh', '跨相机、光照和物体变化的普适泛化未被系统验证。');
setText('sh/1k7edwv2', '生成结果不等于安全保证；限位、避障与急停\n仍由独立安全控制层负责。');
setText('sh/zipwbmdc', '复现顺序：先对齐动作定义、坐标系与归一化，再核验视觉编码和噪声监督，最后验证反向采样与闭环控制。\n速度结果需连同推理步数与硬件一并报告。');
presentation.resolve('sh/zipwbmdc').text.fontSize = 17.5;
setText('sh/tkby9kzm', '09 / 09');

const existingSlides = await presentation.inspect({ select: '$.slides[*]', include: ['id', 'notes.text'] });
const oldConclusion = existingSlides.records.find((record) => record.id === 'sl/fu1gfa1s');
if (!oldConclusion?.notes?.text) throw new Error('Conclusion notes were not preserved.');

await fs.mkdir(buildDir, { recursive: true });
const exported = await PresentationFile.exportPptx(presentation);
await exported.save(draftPath);
console.log(`Saved draft: ${draftPath}`);
