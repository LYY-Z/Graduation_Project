import path from 'node:path';
import { pathToFileURL } from 'node:url';

const skillDir = 'C:/Users/laiyo/.codex/plugins/cache/openai-primary-runtime/presentations/26.1022.11436/skills/presentations';
const workspaceDir = 'G:/毕设/02_learning/04_review';
const buildDir = path.join(workspaceDir, '.build_dp_advisor_detailed_20261023');
const candidatePath = path.join(buildDir, 'diffusion_policy_advisor_report_10min_refined_v3_draft.pptx');
const finalPath = path.join(workspaceDir, 'deliverables', 'diffusion_policy_advisor_report_10min_refined_v3.pptx');
const receiptPath = path.join(buildDir, 'diffusion_policy_advisor_report_10min_refined_v3.validation.json');
const runtimePython = 'C:/Users/laiyo/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe';
const sourcePath = path.join(workspaceDir, 'diffusion_policy_advisor_report_10min_final.pptx');
const sourceSha256 = 'cf694ab351a490e8a1b87e040593b516950a9c8ce95bbe5893bcfc7069389713';
const expectedSlideSizeEmu = '12192000,6858000';
process.env.RUNTIME_NODE_MODULES = 'C:/Users/laiyo/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules';

const { finalizePresentation } = await import(pathToFileURL(
  path.join(skillDir, 'container_tools/artifact_tool_utils.mjs'),
).href);

const result = await finalizePresentation({
  explicitTotalSlideCount: 10,
  workspaceDir,
  candidatePath,
  finalPath,
  pythonExecutable: runtimePython,
  integrityValidatorPath: path.join(skillDir, 'container_tools/inspect_presentation_package_integrity.py'),
  layoutValidatorPath: path.join(skillDir, 'container_tools/inspect_presentation_layout_geometry.py'),
  layoutArgs: ['--expected-slide-size-emu', expectedSlideSizeEmu, '--validate-bullet-geometry', '--validate-heading-fit'],
  requiredNativeTableOwnerSlides: [],
  requiredNativeChartOwnerSlides: [],
  fontPolicy: {
    basis: 'reference',
    families: ['Microsoft YaHei', 'Cambria Math'],
    referencePath: sourcePath,
    referenceSha256: sourceSha256,
  },
  verifyArtifactToolImport: true,
  receiptPath,
});
console.log(JSON.stringify(result, null, 2));
