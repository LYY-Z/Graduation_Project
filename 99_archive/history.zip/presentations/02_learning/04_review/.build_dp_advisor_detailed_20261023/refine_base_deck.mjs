import fs from 'node:fs/promises';
import path from 'node:path';
import { FileBlob, PresentationFile } from '@oai/artifact-tool';

const workspaceDir = 'G:/毕设/02_learning/04_review';
const buildDir = path.join(workspaceDir, '.build_dp_advisor_detailed_20261023');
const sourcePath = path.join(workspaceDir, 'diffusion_policy_advisor_report_10min_final.pptx');
const draftPath = path.join(buildDir, 'diffusion_policy_advisor_report_10min_refined_draft.pptx');

const presentation = await PresentationFile.importPptx(await FileBlob.load(sourcePath));

function replaceText(id, oldText, newText) {
  const shape = presentation.resolve(id);
  if (!shape?.text) throw new Error(`Text shape not found: ${id}`);
  shape.text.replace(oldText, newText);
}

// Slide 3: make the modeling target explicit and connect it to the multi-solution problem.
replaceText(
  'sh/pcjqtg36',
  '关键变化：从“直接给出一个动作”，转为“逐步生成一段动作计划”。',
  '建模目标：学习专家动作块的条件分布 pθ(Aₜ⁰ | Oₜ)，而非单一动作。',
);
replaceText(
  'sh/v6l4jq94',
  '预测当前噪声并迭代修正，随机初始化可落入不同动作模式。',
  '从随机动作块出发迭代去噪；不同初始噪声可生成不同有效模式。',
);

// Slide 4: explain what the visual stack does and how the policy learns task-relevant features.
replaceText(
  'sh/jadsz2xk',
  'ResNet-18 + Spatial Softmax\n各视角与本体状态融合\nGroupNorm 配合 EMA',
  '每个视角：ResNet-18 编码\nSpatial Softmax 保留位置信息\n与本体状态拼接为 Oₜ',
);
replaceText(
  'sh/sri9s7q9',
  '观察特征提取一次；只有动作块被加噪并反复去噪。',
  '动作噪声损失反向传播至视觉编码器，端到端学习任务相关特征。',
);

// Slide 5: state why the noise is the target, and distinguish diffusion time from robot time.
replaceText(
  'sh/032tgr6d',
  '从专家动作块出发，按噪声日程直接构造任意扩散级的训练样本。',
  '已知实际加入的噪声 ε，因此直接监督网络预测噪声。',
);
replaceText(
  'sh/2h0ni107',
  'k 是扩散级别，t 是机器人控制时刻。论文采用 Square Cosine 噪声日程；训练仍是行为克隆，而非奖励最大化。',
  '平方根是标准差权重；k 为扩散级，t 为机器人控制时刻。Square Cosine 日程决定各级噪声强度。',
);

// Slide 6: retain the paper's Langevin-style update, while explicitly comparing it with canonical DDPM.
const slide6 = presentation.resolve('sl/x8f69ofe');
const ddpmFormula = slide6.shapes.add({
  geometry: 'textbox',
  name: 'canonical-ddpm-reverse-mean',
  position: { left: 70, top: 293, width: 1138, height: 25 },
  fill: 'none',
  line: { style: 'solid', fill: 'none', width: 0 },
});
ddpmFormula.text = '标准 DDPM 反向均值： μθ = 1/√αₖ [Aₖ − βₖ εθ / √(1−ᾱₖ)]';
ddpmFormula.text.style = {
  fontSize: 19,
  typeface: 'Cambria Math',
  color: '#646A70',
  alignment: 'center',
};
const ddpmCaveat = slide6.shapes.add({
  geometry: 'textbox',
  name: 'reverse-formula-distinction',
  position: { left: 70, top: 318, width: 1138, height: 20 },
  fill: 'none',
  line: { style: 'solid', fill: 'none', width: 0 },
});
ddpmCaveat.text = '标准采样还要加 σₖz；论文 Eq. (4) 是 Langevin 风格更新，系数不可直接互换。';
ddpmCaveat.text.style = {
  fontSize: 15,
  typeface: 'Microsoft YaHei',
  color: '#646A70',
  alignment: 'center',
};
replaceText(
  'sh/svmt4v6t',
  'Aₜᴷ ~ N(0,I)\n去噪至 Aₜ⁰，长度 Tₚ',
  'Aₜᴷ ~ N(0,I)\nDDIM 迭代去噪至 Aₜ⁰',
);
replaceText(
  'sh/zep4byhs',
  '读取新观测并重新采样',
  '新观测到达；未执行动作段作初始参考',
);
replaceText(
  'sh/4f2pgr2h',
  '100 个训练步 → 10 个推理步；RTX 3080 上约 0.1 秒。',
  '主文示例：100 个训练步、10 个推理步\nRTX 3080 上约 0.1 秒',
);

// Slide 7: make the real-robot evidence and the relative-improvement unit unambiguous.
replaceText(
  'sh/p8fih03e',
  '真实 Push-T · 20 次评测',
  '真实 UR5 Push-T：136 条演示，20 次评测',
);
presentation.resolve('sh/p8fih03e').text.style = {
  fontSize: 19,
  typeface: 'Microsoft YaHei',
  color: '#252A31',
  bold: true,
  alignment: 'left',
};
replaceText(
  'sh/n6x0fqlo',
  '跨 15 项任务的平均相对成功率提升\n相对于论文比较的最佳基线',
  '15 项任务的平均相对成功率提升\n相对最佳基线，非百分点差',
);

// Slide 8: close by separating what the generative model does from what feedback control does.
replaceText(
  'sh/zipwbmdc',
  'Diffusion Policy 将动作轨迹建模为条件生成分布，并用滚动时域反馈把计划转化为可响应的机器人行为。',
  '动作扩散表示多模态、时间连贯的动作块；滚动时域反馈根据新观测持续修正执行计划。',
);

// Add coherent transitions and retain paper citations in speaker notes.
const notesRecords = await presentation.inspect({
  select: '$.slides[*]',
  include: ['id', 'notes.id', 'notes.text'],
});
const noteIds = new Map(notesRecords.records.map((record) => [record.id, record.notes?.id]));
const noteTextBySlide = new Map([
  ['sl/y90nupkv', `开场定位：这篇工作把条件扩散用于机器人视觉操作中的动作生成。本文汇报沿一条问题链展开：单步回归为何不足，扩散怎样学习动作块分布，视觉条件如何进入去噪器，最后看滚动时域控制与实验结果。文章先发表于 RSS 2023，后扩展发表于 IJRR 2025。\n来源：Chi et al., Diffusion Policy, IJRR 2025, 首页及第 2 页。`],
  ['sl/hwbqtkby', `同一观测下，机械臂可以从 T 形块左侧或右侧接近目标。多模态表示条件动作分布中存在多个高概率区域，不表示机器人任意乱动。若把两类专家动作压成一个确定输出，MSE 回归可能取两种路线的平均值，而平均动作可能穿过障碍物；若每个时刻独立选择模式，轨迹还可能左右切换。因此本文需要同时解决动作多解与整段轨迹的一致性。下一页据此比较几种策略表示。\n来源：论文 §4.1、Figure 3，IJRR 2025, p. 1688。图像来自代码仓库 media/multimodal_sim.png。`],
  ['sl/ofy9wn61', `上一页的问题决定了模型目标：拟合给定观察 O_t 时专家动作块 A_t^0 的条件分布，而非单一动作点。显式策略通常一次前向映射到一个动作，计算快，但普通回归不易表示多个解；能量策略给观察和候选动作评分，训练和采样需要处理负样本或搜索。Diffusion Policy 从随机动作块出发，条件去噪网络逐步把它移向数据支持的动作区域。不同初始噪声可以对应不同可行模式，而一次生成整个动作块有助于保持时序相关。论文主实验采用行为克隆，监督来自专家演示而非在线奖励。下一页说明观察特征如何条件化这个生成过程。\n来源：论文 Figure 1、§§1–2，IJRR 2025, pp. 1685–1686。图像来自代码仓库 media/teaser.png。`],
  ['sl/jyx0ra1s', `观察 O_t 汇集最近 T_o 帧的多视角图像和机器人低维状态。每个相机视角用独立的 ResNet-18 编码，Spatial Softmax 将空间特征压缩为带位置信息的表示；再把不同视角特征与机器人本体状态沿特征维拼接，形成条件向量。网络不会因为看过图片就天然知道“这是杯子”：本文没有要求对象类别标签，去噪损失的梯度会从噪声预测器反向传到视觉编码器，使其逐渐学到对动作有用的线索，例如目标相对位置、接触关系或夹爪状态。特征是否能被人解释并非训练目标。\n论文把 BatchNorm 换为 GroupNorm。BatchNorm 使用批次统计量并保存运行均值和方差，EMA 则平滑历史模型参数；两者可能出现统计量与参数版本不匹配。GroupNorm 不依赖跨批次运行统计量，更容易与 EMA 配合。CNN 版本以 FiLM 调制时序卷积特征，Transformer 版本通过 cross-attention 将观察嵌入注入动作 token。每个观察窗口的特征在一次去噪 rollout 内共享，只有动作块被扩散。下一页进入训练：用已知加噪过程构造监督目标。\n来源：论文 Figure 2、§§2.3、3.1–3.2，IJRR 2025, pp. 1686–1688。`],
  ['sl/i107q5of', `训练样本里的 A_t^0 是专家演示中未来 T_p 步的动作块，可看作形状为 [T_p, 动作维数] 的张量。随机抽扩散级 k 和同形状标准高斯噪声 ε，以闭式前向公式一次性构造 A_t^k。ᾱ_k 是从 1 到 k 的保留系数乘积；√ᾱ_k 和 √(1−ᾱ_k) 是信号、噪声的标准差权重，因而对应方差份额。k 越大，原动作信息越弱、噪声越强。注意 k 是扩散级，t 是机器人控制时刻。\n网络接收 O_t、A_t^k、k，预测实际加入的 ε。MSE 对张量每个元素的误差平方后再平均，所以正负误差不会抵消。DDPM 的完整变分推导可写成 KL 项；论文实际采用常见的噪声预测 MSE 目标，并不是在这条 MSE 旁边再额外加一项 KL。Square Cosine 日程决定各扩散级的噪声比例。这里的监督来自示范动作，因此属于行为克隆。下一页讨论没有干净动作时怎样反向采样并控制机器人。\n来源：论文 Eqs. (3)、(5)，§§2.2–2.3、3.3，IJRR 2025, pp. 1686–1688。`],
  ['sl/x8f69ofe', `推理开始时没有演示动作块，先抽取 A_t^K ~ N(0,I)。网络输出 εθ 近似当前噪声，也隐式给出条件动作分布的 score 方向：ŝ ≈ −εθ/√(1−ᾱ_k)。标准 DDPM 的后验均值可写成 μθ = 1/√α_k [A_t^k − β_k εθ/√(1−ᾱ_k)]，完整采样再加 σ_k z。论文 Eq. (4) 则写成 Langevin 风格的参数化条件更新 A_t^{k−1}=α_k[A_t^k−γ_k εθ+σ_k z]。它们都利用噪声预测推动去噪，但系数与 σ 的定义不应互换。这里 z 是推理时新抽取的标准高斯张量，和训练时已知的目标噪声 ε 不是一回事。\nDDIM 将训练扩散级数与推理迭代次数分开，并可跳过中间级；从 k 跳到 j 时，以预测的干净动作 Â_t^0 与噪声估计重组 A_t^j。主文示例用 100 个训练步、10 个推理步，在 RTX 3080 上约 0.1 秒；实机附录配置会使用不同步数。控制上，系统读取最近 T_o 步观察，生成 T_p 步计划，只执行前 T_a 步，再用新观察重新规划。未执行的旧动作段可用于 warm-start，减少每轮从完全随机计划开始的变化。T_a 太短会损失连续性，太长又降低响应速度；多数任务中 8 步表现较好。下一页用基准和实机数据检验整套设计。\n来源：论文 Eqs. (1)、(4)，§§2.1、2.3、3.4、4.1、5.3.4–5.3.5，IJRR 2025, pp. 1686, 1688, 1692。`],
  ['sl/gnmp4jqx', `评测覆盖 15 项任务和 4 个基准。论文报告相对最佳基线平均成功率提升 46.9%，这是相对提升，不是增加 46.9 个百分点。真实 UR5 Push-T 使用 136 条演示并评测 20 次，Diffusion Policy 成功率为 95%，平均 IoU 为 0.80，演示均值为 0.84；对比的 LSTM-GMM 为 20%，IBC 为 0%。IoU 反映生成的 T 形块与目标形状的重合程度。消融显示动作表示与控制设置同样重要：位置控制对扩散策略更有利，T_a=8 在多数任务中较优，模拟延迟最多 4 步时仍保持峰值表现。结论应限定于论文任务、演示覆盖与硬件设置。最后一页把建模收益与适用边界分开总结。\n来源：论文摘要、§§5–6、Table 6、Figure 6，IJRR 2025, pp. 1684, 1690–1694。`],
  ['sl/fu1gfa1s', `总结逻辑：扩散模型负责表示并采样多模态、时间连贯的动作块；滚动时域控制负责执行其中一段，并用新观测修正后续计划。两者结合，让动作生成进入闭环操作，而不是停留在离线轨迹预测。限制包括：策略质量依赖示范是否覆盖真实状态，迭代去噪比单次回归耗时，碰撞约束、限位和急停仍需独立安全控制层。\n来源：论文 §§9–10，IJRR 2025, p. 1698。`],
]);
for (const [slideId, noteText] of noteTextBySlide) {
  const notesId = noteIds.get(slideId);
  if (!notesId) throw new Error(`Speaker notes anchor not found for ${slideId}`);
  presentation.resolve(notesId).text = noteText;
}

await fs.mkdir(buildDir, { recursive: true });
const exported = await PresentationFile.exportPptx(presentation);
await exported.save(draftPath);
console.log(`Saved draft: ${draftPath}`);
