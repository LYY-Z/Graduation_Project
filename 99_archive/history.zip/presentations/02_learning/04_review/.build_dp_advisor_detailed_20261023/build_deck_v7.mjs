import fs from "node:fs/promises";
import path from "node:path";
import { pathToFileURL } from "node:url";
import { FileBlob, Presentation, PresentationFile } from "@oai/artifact-tool";

const ROOT = "G:/毕设";
const BUILD = path.join(ROOT, "02_learning/04_review/.build_dp_advisor_detailed_20261023");
const OUT = path.join(ROOT, "02_learning/04_review");
const FINAL_PPTX = path.join(OUT, "diffusion_policy_advisor_report_rebuilt_v8.pptx");
const SOURCE_DECK = "H:/Download/Diffusion Policy 论文组会汇报.pptx";
const SKILL_DIR = "C:/Users/laiyo/.codex/plugins/cache/openai-primary-runtime/presentations/26.1022.11436/skills/Presentations";
const PYTHON = "C:/Users/laiyo/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe";
const COLORS = {
  bg: "#F8F8F5",
  ink: "#17283B",
  muted: "#596675",
  teal: "#24766C",
  orange: "#C66B3D",
  line: "#D6DDE2",
  white: "#FFFFFF",
  paleTeal: "#E7F0ED",
  paleBlue: "#EAF0F4",
  paleOrange: "#F6ECE5",
};
const FONT = "Microsoft YaHei";
const MATH = "Cambria Math";
const W = 1280;
const H = 720;

function text(slide, value, x, y, w, h, options = {}) {
  const shape = slide.shapes.add({
    geometry: "textbox",
    name: options.name ?? "editable-text",
    position: { left: x, top: y, width: w, height: h },
    fill: "none",
    line: { style: "solid", fill: "none", width: 0 },
  });
  shape.text = value;
  shape.text.style = {
    typeface: options.font ?? FONT,
    fontSize: options.size ?? 22,
    color: options.color ?? COLORS.ink,
    bold: options.bold ?? false,
    alignment: options.align ?? "left",
    verticalAlignment: options.valign ?? "middle",
    wrap: "square",
    autoFit: "shrinkText",
    insets: 0,
  };
  return shape;
}

function rect(slide, x, y, w, h, fill, line = "none") {
  return slide.shapes.add({
    geometry: "rect",
    position: { left: x, top: y, width: w, height: h },
    fill,
    line: { style: "solid", fill: line, width: line === "none" ? 0 : 1 },
  });
}

function rule(slide, x, y, w, color = COLORS.line, thickness = 1.4) {
  rect(slide, x, y, w, thickness, color);
}

function header(slide, title, page, source) {
  slide.background.fill = COLORS.bg;
  text(slide, title, 68, 30, 1144, 58, { size: 42, bold: true });
  rule(slide, 68, 104, 1144, COLORS.line, 1.5);
  rule(slide, 68, 104, 74, COLORS.teal, 3);
  rule(slide, 68, 668, 1144, COLORS.line, 1);
  text(slide, source, 68, 676, 1050, 22, { size: 14, color: COLORS.muted });
  text(slide, `${String(page).padStart(2, "0")} / 09`, 1135, 676, 77, 22, {
    size: 14, color: COLORS.muted, align: "right",
  });
}

function addImage(slide, sourceDeck, imageId, alt, x, y, w, h) {
  const image = sourceDeck.resolve(imageId);
  const bytes = image.bytes;
  const blob = bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength);
  slide.images.add({
    blob,
    contentType: image.contentType ?? "image/png",
    alt,
    fit: "contain",
    position: { left: x, top: y, width: w, height: h },
  });
}

function notes(slide, speech, source) {
  slide.speakerNotes.text = `${speech}\n\n论文来源：${source}`;
  slide.speakerNotes.setVisible(true);
}

function newSlide(presentation, title, page, source) {
  const slide = presentation.slides.add();
  header(slide, title, page, source);
  return slide;
}

async function writeBlob(filePath, blob) {
  await fs.writeFile(filePath, new Uint8Array(await blob.arrayBuffer()));
}

async function main() {
  await fs.mkdir(BUILD, { recursive: true });
  await fs.mkdir(OUT, { recursive: true });
  const paperDeck = await PresentationFile.importPptx(await FileBlob.load(SOURCE_DECK));
  const presentation = Presentation.create({ slideSize: { width: W, height: H } });

  // 1. Cover
  {
    const s = presentation.slides.add();
    s.background.fill = COLORS.bg;
    rect(s, 0, 0, 18, H, COLORS.teal);
    text(s, "论文组会汇报  /  ROBOT LEARNING", 92, 120, 880, 34, {
      size: 18, color: COLORS.teal, bold: true,
    });
    text(s, "Diffusion Policy", 88, 184, 1080, 92, { size: 74, bold: true });
    text(s, "Visuomotor Policy Learning via Action Diffusion", 94, 286, 1060, 48, {
      size: 29, font: MATH, color: COLORS.muted,
    });
    rule(s, 94, 370, 760, COLORS.line, 1.5);
    text(s, "核心问题", 94, 400, 180, 32, { size: 19, color: COLORS.orange, bold: true });
    text(s, "机器人如何把当前视觉观测，转化为一段连贯且可在线修正的动作计划？", 94, 442, 1035, 72, {
      size: 29, bold: true,
    });
    text(s, "Chi et al.  ·  IJRR 2025（RSS 2023 特刊）", 94, 585, 850, 30, {
      size: 18, color: COLORS.muted,
    });
    text(s, "10 分钟汇报", 94, 623, 350, 25, { size: 16, color: COLORS.teal, bold: true });
    notes(
      s,
      "汇报聚焦一个问题：机器人根据当前视觉与本体状态，怎样生成一段动作，而不是只预测一个瞬时动作，并在环境变化后及时修正。论文将扩散模型从图像生成迁移到条件动作生成，再与滚动时域控制结合。汇报按问题、条件表示、训练、采样、执行和实验结果展开。",
      "Chi et al., Diffusion Policy: Visuomotor Policy Learning via Action Diffusion, IJRR 2025, 44(10–11):1684–1704；RSS 2023 Special Issue。",
    );
  }

  // 2. Problem and action-sequence formulation
  {
    const source = "Chi et al., IJRR 2025, §§1, 4.1, Figure 3, pp. 1685, 1688.";
    const s = newSlide(presentation, "问题设定：一幅观测，可能有多条有效动作路线", 2, source);
    addImage(s, paperDeck, "im/6xgry54n", "论文 Figure 3：Push-T 中多种有效动作模式", 72, 143, 594, 302);
    text(s, "Push-T 示意", 74, 450, 210, 25, { size: 15, color: COLORS.muted });
    text(s, "从不同方向接近目标，都可能完成任务。", 74, 480, 555, 35, { size: 19, bold: true });

    text(s, "单步确定性回归", 724, 150, 460, 32, { size: 20, color: COLORS.orange, bold: true });
    text(s, "左绕与右绕的平均位置，未必属于任何一条可行路线。", 724, 192, 460, 64, {
      size: 23, bold: true, valign: "top",
    });
    rule(s, 724, 275, 430, COLORS.line, 1.2);
    text(s, "动作块建模", 724, 296, 430, 30, { size: 20, color: COLORS.teal, bold: true });
    text(s, "Aₜ = [aₜ, aₜ₊₁, …, aₜ₊ₜₚ₋₁]", 724, 340, 490, 48, {
      size: 27, font: MATH, bold: true,
    });
    text(s, "学习条件分布  p(Aₜ | Oₜ)，一次生成一段时间上相互协调的动作。", 724, 402, 465, 76, {
      size: 21, color: COLORS.ink, valign: "top",
    });
    rule(s, 72, 542, 1138, COLORS.line, 1.2);
    text(s, "训练范式", 76, 564, 130, 28, { size: 17, color: COLORS.orange, bold: true });
    text(s, "行为克隆：从专家演示学习观测—动作对应关系；主实验不依赖在线奖励或试错。", 220, 558, 962, 45, {
      size: 21, bold: true,
    });
    text(s, "策略表示上，直接回归容易压缩多解；能量模型要处理难算的归一化与负样本；扩散通过噪声预测表示条件动作分布。", 76, 617, 1128, 30, {
      size: 16, color: COLORS.muted,
    });
    notes(
      s,
      "先看作者要解决的策略表示问题。Push-T 中，机械臂可以从目标物体不同方向接近；这些路线都可能成功，因此同一观测对应的是多个合理动作模式。确定性回归加 MSE 时，模型常趋向条件均值；但不同路线的平均动作可能落在低概率、甚至不可行的位置。策略表示上，显式策略直接输出动作；能量模型给候选动作打分，但需要处理难算的归一化常数和负样本；扩散模型用噪声预测逐步表示复杂条件动作分布。论文于是把未来动作组成一个动作块 A_t，并建模给定观测后的条件分布 p(A_t|O_t)。整段动作一起生成，也让模型能学习时间上的协调关系。训练仍属于行为克隆，监督来自专家示范，不是通过奖励进行在线强化学习。",
      source,
    );
  }

  // 3. Vision encoder and its learning path
  {
    const source = "Chi et al., IJRR 2025, §3.2, pp. 1687–1688; official implementation: multi_image_obs_encoder.py and diffusion_unet_hybrid_image_policy.py.";
    const s = newSlide(presentation, "视觉条件：像素怎样进入动作策略", 3, source);
    text(s, "观测编码", 74, 132, 190, 28, { size: 17, color: COLORS.teal, bold: true });
    const xs = [74, 335, 594, 862];
    const widths = [220, 215, 228, 320];
    const labels = [
      ["多视角图像", "最近 Tₒ 帧，每帧为像素张量"],
      ["ResNet-18", "卷积形成视觉特征图"],
      ["Spatial Softmax", "把空间响应转成位置特征"],
      ["特征拼接", "多视角特征 + 机器人本体状态"],
    ];
    for (let i = 0; i < labels.length; i++) {
      text(s, labels[i][0], xs[i], 173, widths[i], 34, {
        size: 22, bold: true, color: i === 3 ? COLORS.teal : COLORS.ink,
      });
      text(s, labels[i][1], xs[i], 211, widths[i], 52, {
        size: 17, color: COLORS.muted, valign: "top",
      });
      if (i < labels.length - 1) {
        text(s, "→", xs[i] + widths[i] + 9, 186, 36, 32, { size: 25, color: COLORS.orange, align: "center" });
      }
    }
    rule(s, 74, 286, 1134, COLORS.line, 1.2);
    text(s, "训练路径", 74, 310, 160, 28, { size: 17, color: COLORS.orange, bold: true });
    text(s, "专家动作块 Aₜ⁰", 74, 356, 208, 36, { size: 20, bold: true });
    text(s, "+ 已知噪声 ε", 74, 398, 208, 32, { size: 18, color: COLORS.muted });
    text(s, "→", 286, 367, 35, 32, { size: 24, color: COLORS.orange, align: "center" });
    text(s, "带噪动作 Aₜᵏ", 330, 356, 190, 36, { size: 20, bold: true });
    text(s, "输入观测 Oₜ 与级别 k", 330, 398, 228, 32, { size: 17, color: COLORS.muted });
    text(s, "→", 560, 367, 35, 32, { size: 24, color: COLORS.orange, align: "center" });
    text(s, "噪声预测器", 604, 356, 200, 36, { size: 20, bold: true });
    text(s, "ε̂ = εθ(Oₜ, Aₜᵏ, k)", 604, 398, 260, 32, { size: 19, font: MATH, color: COLORS.teal, bold: true });
    text(s, "→", 857, 367, 35, 32, { size: 24, color: COLORS.orange, align: "center" });
    text(s, "L = ‖ε − ε̂‖²", 898, 356, 270, 36, { size: 22, font: MATH, color: COLORS.ink, bold: true });
    text(s, "动作噪声误差", 898, 398, 250, 32, { size: 17, color: COLORS.muted });
    rule(s, 74, 463, 1134, COLORS.line, 1.2);
    text(s, "关键：视觉编码器参与训练", 74, 486, 355, 32, { size: 20, color: COLORS.teal, bold: true });
    text(s, "损失梯度可沿去噪网络回传到 ResNet 参数；模型学习任务相关视觉特征，不需要“杯子/机械臂”类别标签。", 435, 479, 770, 58, {
      size: 18, color: COLORS.ink,
    });
    text(s, "实现中多视角特征沿特征维拼接，不是把图像像素直接相加。", 74, 560, 1124, 31, {
      size: 17, color: COLORS.muted,
    });
    notes(
      s,
      "图像不是先被人工标注成‘杯子’或‘机械臂’类别，再把类别交给策略。论文为不同相机视角使用独立视觉编码器，每个时间步的图像独立编码。ResNet-18 得到特征图；Spatial Softmax 把空间响应转换成带位置的信息。多相机特征与机器人低维状态，例如末端位姿和夹爪状态，沿特征维拼接成观测条件 O_t。拼接是向量维度首尾相接，不是像素相加。训练时，专家动作块被加入已知噪声，网络在 O_t 和扩散级 k 条件下预测噪声，MSE 衡量预测值与实际噪声的误差。因为视觉编码器位于可微计算路径里，这个动作预测损失可以反向传播到 ResNet 参数，所以它与去噪网络一起训练。监督信号来自动作示范，编码器学到的是对控制有用的线索，而不是显式物体分类。",
      source,
    );
  }

  // 4. Denoiser architecture and conditioning design
  {
    const source = "Chi et al., IJRR 2025, §§2.3, 3.1–3.3, pp. 1686–1688.";
    const s = newSlide(presentation, "去噪网络：条件进入动作序列模型", 4, source);
    text(s, "唯一被逐步加噪、再去噪的对象", 74, 136, 520, 30, { size: 18, color: COLORS.muted });
    text(s, "Aₜᵏ  +  Oₜ  +  k", 74, 176, 548, 58, { size: 38, font: MATH, bold: true });
    text(s, "εθ(Oₜ, Aₜᵏ, k)", 74, 257, 548, 54, { size: 34, font: MATH, color: COLORS.teal, bold: true });
    text(s, "输出与动作块同形状的噪声估计 ε̂", 74, 321, 548, 34, { size: 19, color: COLORS.muted });
    rule(s, 646, 137, 1.5, COLORS.line, 318);

    text(s, "两种时序去噪器", 690, 138, 420, 30, { size: 18, color: COLORS.orange, bold: true });
    text(s, "CNN 方案", 690, 183, 210, 30, { size: 21, bold: true });
    text(s, "1D U-Net 沿时间维处理动作序列；FiLM 用观测条件调制网络特征。", 690, 219, 470, 65, {
      size: 18, color: COLORS.muted, valign: "top",
    });
    rule(s, 690, 302, 456, COLORS.line, 1);
    text(s, "Transformer 方案", 690, 322, 300, 30, { size: 21, bold: true });
    text(s, "动作 token 做因果自注意力；观测特征通过 cross-attention 提供上下文。", 690, 359, 470, 64, {
      size: 18, color: COLORS.muted, valign: "top",
    });

    rule(s, 74, 455, 1134, COLORS.line, 1.2);
    text(s, "建模边界", 74, 480, 160, 28, { size: 17, color: COLORS.teal, bold: true });
    text(s, "观察是条件，动作才是生成对象；论文不把图像与动作拼成一个长扩散序列，也不采用目标状态 inpainting 条件化。", 252, 473, 940, 61, {
      size: 19, bold: true,
    });
    text(s, "噪声强度随 k 变化；论文使用 iDDPM 的 Square Cosine Schedule。", 74, 565, 1120, 34, {
      size: 17, color: COLORS.muted,
    });
    text(s, "视觉网络用 GroupNorm 替代 BatchNorm，减少运行统计量与 EMA 平滑参数之间的不匹配。", 74, 603, 1120, 30, {
      size: 16, color: COLORS.muted,
    });
    notes(
      s,
      "模型的输入包括观测条件 O_t、带噪动作块 A_t^k 和扩散级 k，输出是与动作块同形状的噪声估计。论文比较了两种时序去噪结构。CNN 版本用 1D U-Net 在时间维处理动作序列，并通过 FiLM 把观测条件注入中间特征；Transformer 版本让动作 token 做因果自注意力，再通过 cross-attention 读取观测特征。二者都沿着同一建模原则：观察提供条件，动作序列是扩散对象。作者没有把观察和动作拼成一个共同去噪的长序列，也没有用 inpainting 把目标状态嵌入待生成序列。噪声日程决定不同扩散级的信号与噪声比例，论文采用 iDDPM 的 Square Cosine Schedule。论文还以 GroupNorm 替换视觉编码器中的 BatchNorm。BatchNorm 保存的运行统计量来自在线训练参数，而 EMA 模型使用平滑后的历史参数；两套状态可能不匹配。GroupNorm 不依赖跨批次运行统计，因此更容易与 EMA 参数平均配合。",
      source,
    );
  }

  // 5. Forward process and training objective
  {
    const source = "Chi et al., IJRR 2025, Eqs. (3), (5), §§2.2–2.3, 3.3, pp. 1686–1688.";
    const s = newSlide(presentation, "训练：把 DDPM 的数据对象换成动作块", 5, source);
    text(s, "标准 DDPM", 76, 143, 360, 29, { size: 18, color: COLORS.muted, bold: true });
    text(s, "xₖ = √ᾱₖ x₀ + √(1−ᾱₖ) ε", 76, 180, 520, 48, {
      size: 27, font: MATH, color: COLORS.ink,
    });
    text(s, "Diffusion Policy", 676, 143, 390, 29, { size: 18, color: COLORS.teal, bold: true });
    text(s, "Aₜᵏ = √ᾱₖ Aₜ⁰ + √(1−ᾱₖ) ε", 676, 180, 530, 48, {
      size: 27, font: MATH, color: COLORS.teal, bold: true,
    });
    rule(s, 76, 252, 1128, COLORS.line, 1.2);

    text(s, "一次训练样本", 76, 276, 200, 28, { size: 18, color: COLORS.orange, bold: true });
    const process = [
      ["1", "取示范", "观测 Oₜ 与干净动作块 Aₜ⁰"],
      ["2", "抽级别与噪声", "k 随机抽取；ε ~ N(0,I)"],
      ["3", "直接合成 Aₜᵏ", "无需逐步执行 k 次加噪"],
      ["4", "预测并比较", "ε̂ = εθ(Oₜ,Aₜᵏ,k)"],
    ];
    const px = [76, 365, 654, 943];
    for (let i = 0; i < process.length; i++) {
      text(s, process[i][0], px[i], 321, 32, 28, { size: 17, color: COLORS.orange, bold: true });
      text(s, process[i][1], px[i] + 38, 318, 228, 30, { size: 20, bold: true });
      text(s, process[i][2], px[i], 360, 244, 52, { size: 16, color: COLORS.muted, valign: "top" });
      if (i < 3) text(s, "→", px[i] + 252, 324, 30, 28, { size: 22, color: COLORS.teal, align: "center" });
    }

    rule(s, 76, 438, 1128, COLORS.line, 1.2);
    text(s, "训练目标", 76, 463, 165, 28, { size: 18, color: COLORS.orange, bold: true });
    text(s, "L = E₍O,A⁰,k,ε₎ [ ‖ ε − εθ(Oₜ, Aₜᵏ, k) ‖² ]", 76, 505, 815, 52, {
      size: 27, font: MATH, bold: true,
    });
    text(s, "MSE 逐元素平方后取平均；它比较的是噪声张量，不是让多条路线平均成一个动作。", 76, 574, 1120, 45, {
      size: 18, color: COLORS.muted,
    });
    notes(
      s,
      "这页对应 DDPM 前向扩散和训练。标准 DDPM 从干净样本 x_0 出发；Diffusion Policy 把数据对象换成专家动作块 A_t^0。alpha bar 是从第 1 到第 k 步信号保留率的累积乘积。两个平方根分别按方差比例缩放干净动作与标准高斯噪声，因此能控制混合后的总方差。实际训练不必从 A^0 一步一步加噪到 k，而是随机抽 k 和噪声 ε，用闭式公式直接合成 A_t^k。论文正文的 Eq. (5) 用 ε^k 表示该噪声级的扰动；页面采用 DDPM 常见的 alpha-bar 重参数化写法来连接前面学过的公式。网络根据观测、带噪动作和级别预测噪声，MSE 对每个张量元素计算平方误差再平均。优化器用梯度下降更新网络和视觉编码器参数。这里并非对不同路线的动作做普通回归平均，网络学习的是随噪声级变化的去噪方向。",
      source,
    );
  }

  // 6. Reverse process: canonical DDPM and paper sampler distinguished
  {
    const source = "Chi et al., IJRR 2025, Eqs. (1), (4), §§2.1–2.2, pp. 1685–1686; DDPM posterior parameterization summarized for comparison.";
    const s = newSlide(presentation, "反向采样：标准 DDPM 与论文动作采样式", 6, source);
    text(s, "标准 DDPM 后验参数化", 76, 132, 505, 30, { size: 18, color: COLORS.muted, bold: true });
    text(s, "xₖ₋₁ = 1/√αₖ [ xₖ − βₖ/√(1−ᾱₖ) · εθ(xₖ,k) ] + σₖ z", 76, 176, 1125, 54, {
      size: 25, font: MATH, bold: true,
    });
    text(s, "由高斯后验得到：估计 x₀，再代入 q(xₖ₋₁ | xₖ, x₀)；σₖ² 常取后验方差。", 76, 233, 1125, 38, {
      size: 17, color: COLORS.muted,
    });

    rule(s, 76, 294, 1128, COLORS.line, 1.2);
    text(s, "Diffusion Policy 的 Langevin-style 动作更新", 76, 317, 690, 30, { size: 18, color: COLORS.teal, bold: true });
    text(s, "Aₜᵏ⁻¹ = αₖ [ Aₜᵏ − γₖ εθ(Oₜ,Aₜᵏ,k) + σₖ z ]", 76, 358, 1120, 53, {
      size: 27, font: MATH, color: COLORS.teal, bold: true,
    });
    text(s, "ε̂ 给出隐式 score 方向；γₖ 控制修正幅度，σₖ z 保留采样随机性。", 76, 415, 1125, 37, {
      size: 18, color: COLORS.ink,
    });

    rule(s, 76, 477, 1128, COLORS.line, 1.2);
    text(s, "区分两者", 76, 501, 132, 28, { size: 18, color: COLORS.orange, bold: true });
    text(s, "上式是 DDPM 的后验均值形式；下式是论文定义的动作空间 Langevin 更新。符号 σ 相同，不代表方差设定相同。", 224, 494, 970, 63, {
      size: 19, bold: true,
    });
    notes(
      s,
      "这里特意把此前容易混在一起的两种公式并排解释。标准 DDPM 的反向均值公式来自高斯后验：前向过程给出 q(x_{k-1}|x_k,x_0)，训练时已知 x_0，因此能算后验均值和方差；生成时没有真实 x_0，就用噪声预测得到的 x̂_0 代入，代数整理后得到上面的表达。若反向分布方差设为后验方差，σ_k² 等于相应的后验方差；σ 是标准差，所以采样项写成 σ_k z，z 是与样本同形状的标准高斯噪声。论文的动作更新式不是把这条 DDPM 后验公式原样搬来，而是采用 Langevin-style 的迭代更新。噪声预测可以换算成条件动作分布的 score 方向，更新时按 γ_k 沿该方向修正当前动作样本，并按 σ_k 加入随机扰动。两种写法都出现 σ 和 z，但它们所处的采样算法与系数定义不同，不能直接把论文里的 σ_k 当成标准 DDPM 的平方根后验方差。",
      source,
    );
  }

  // 7. Receding horizon and efficient replanning
  {
    const source = "Chi et al., IJRR 2025, §§2.3, 3.4, 5.3.4–5.3.5, Figure 6, pp. 1687, 1689–1690.";
    const s = newSlide(presentation, "执行策略：滚动时域把生成接回真实观测", 7, source);
    const steps = [
      ["观测", "Oₜ"],
      ["生成计划", "未来 Tₚ 步"],
      ["执行前缀", "只执行 Tₐ 步"],
      ["重新观测", "更新 Oₜ₊ₜₐ"],
    ];
    const sx = [76, 354, 632, 910];
    for (let i = 0; i < steps.length; i++) {
      text(s, steps[i][0], sx[i], 150, 230, 34, { size: 21, bold: true, color: i === 2 ? COLORS.orange : COLORS.ink });
      text(s, steps[i][1], sx[i], 191, 230, 33, { size: 19, color: COLORS.muted });
      rule(s, sx[i], 239, 194, i === 2 ? COLORS.orange : COLORS.teal, 3);
      if (i < 3) text(s, "→", sx[i] + 222, 186, 38, 30, { size: 25, color: COLORS.teal, align: "center" });
    }
    text(s, "Tₐ < Tₚ：动作块提供连贯性，短前缀执行保留闭环修正机会。", 76, 282, 1118, 42, {
      size: 21, bold: true,
    });

    rule(s, 76, 348, 1128, COLORS.line, 1.2);
    text(s, "两项推理优化", 76, 372, 206, 28, { size: 18, color: COLORS.orange, bold: true });
    text(s, "DDIM 跳级", 76, 416, 196, 30, { size: 20, bold: true });
    text(s, "从噪声级 k 直接构造较干净的级别 j：\nAʲ = √ᾱⱼ Â⁰ + √(1−ᾱⱼ) ε̂", 76, 453, 510, 80, {
      size: 19, font: MATH, color: COLORS.ink, valign: "top",
    });
    text(s, "复用未执行后缀", 654, 416, 270, 30, { size: 20, bold: true });
    text(s, "上一计划未执行部分向前平移，作为新计划的初始化参考；再根据新观测条件去噪修正。", 654, 453, 518, 77, {
      size: 18, color: COLORS.muted, valign: "top",
    });
    text(s, "控制消融：Tₐ = 8 在多数任务中表现较好；仿真对最多 4 步时延仍较稳健。", 76, 566, 1125, 38, {
      size: 18, color: COLORS.teal, bold: true,
    });
    notes(
      s,
      "策略输出一段长度 T_p 的计划，但控制器只执行前 T_a 步，然后重新读取相机和机器人状态，再生成下一段。只执行前缀使动作块能维持短期协调，同时允许闭环根据新观测修正后续动作。T_a 小于 T_p。论文还讨论 DDIM 跳级：网络当前估计干净计划 Â^0 和噪声 ε̂ 后，可以按更低噪声级 j 重新组合 A^j，而不必逐级经过每一个 k，所以能减少去噪调用。另一项优化是 warm start：把上轮计划中尚未执行的后缀向前平移，作为新计划的初始化参考，再在新观测条件下去噪；它不是直接照搬旧动作，因为环境和观测可能已变化。Figure 6 的控制消融显示，T_a=8 在多数任务中表现较好，仿真延迟测试对最多四步时延仍保持鲁棒。",
      source,
    );
  }

  // 8. Evidence
  {
    const source = "Chi et al., IJRR 2025, Abstract, §§5–6, Figure 6, Table 6, Appendix B.2, pp. 1684, 1690–1694, 1702.";
    const s = newSlide(presentation, "实验结果：基准收益延伸到真实机器人", 8, source);
    text(s, "15", 78, 154, 172, 90, { size: 76, font: MATH, color: COLORS.teal, bold: true });
    text(s, "项任务 / 4 个基准", 80, 245, 330, 33, { size: 21, bold: true });
    text(s, "平均相对性能提升 46.9%", 80, 294, 446, 43, { size: 23, color: COLORS.ink, bold: true });
    text(s, "跨任务结果支持扩散策略对复杂动作分布的建模价值。", 80, 347, 454, 58, {
      size: 17, color: COLORS.muted,
    });

    rule(s, 590, 150, 1.5, COLORS.line, 289);
    text(s, "95%", 656, 154, 300, 90, { size: 76, font: MATH, color: COLORS.orange, bold: true });
    text(s, "UR5 真实 Push-T 成功率", 660, 245, 470, 33, { size: 21, bold: true });
    text(s, "136 条示范；20 次评测", 660, 294, 442, 32, { size: 19, color: COLORS.ink });
    text(s, "策略轨迹 IoU 0.80，示范轨迹 IoU 0.84。", 660, 337, 480, 38, { size: 19, color: COLORS.muted });

    rule(s, 76, 439, 1128, COLORS.line, 1.2);
    text(s, "对照与补充证据", 76, 463, 220, 28, { size: 18, color: COLORS.teal, bold: true });
    text(s, "真实 Push-T：LSTM-GMM 成功率 20%，IBC 为 0%。", 316, 458, 856, 34, { size: 19, bold: true });
    text(s, "双臂任务也有实机结果；控制消融显示短动作前缀与时延鲁棒性的重要性。", 76, 520, 1126, 48, {
      size: 18, color: COLORS.muted,
    });
    text(s, "46.9% 是跨任务平均相对提升，不是提高 46.9 个百分点。", 76, 590, 1124, 30, {
      size: 16, color: COLORS.orange, bold: true,
    });
    notes(
      s,
      "证据分两层。第一层是模拟基准：论文在 15 项任务、4 个基准上报告平均相对性能提升 46.9%，注意这是相对提升，不是增加 46.9 个百分点。第二层是实机验证：UR5 真实 Push-T 使用 136 条示范，20 次评测中成功率为 95%；生成轨迹与目标轨迹的 IoU 为 0.80，示范轨迹为 0.84。对照方法 LSTM-GMM 成功率为 20%，IBC 为 0%。论文还报告双臂任务，包括煎蛋、铺垫和折叠衣物任务，20 次试验成功率分别为 55%、75%、75%。这些结果说明方法不只在模拟器中成立，但也应保留实验范围：结果依赖示范覆盖与任务设置，不能据此推断所有真实机器人任务都能达到同样成功率。",
      source,
    );
  }

  // 9. Synthesis and limits
  {
    const source = "Chi et al., IJRR 2025, §§1, 6, 10, pp. 1685, 1693–1694.";
    const s = newSlide(presentation, "结论与适用边界", 9, source);
    text(s, "方法主线", 76, 142, 150, 28, { size: 18, color: COLORS.orange, bold: true });
    text(s, "视觉与本体状态 Oₜ  →  条件动作分布 p(Aₜ|Oₜ)  →  逐步去噪生成计划  →  执行前缀并重观测", 76, 187, 1120, 73, {
      size: 25, bold: true,
    });
    rule(s, 76, 290, 1128, COLORS.line, 1.2);
    text(s, "论文贡献", 76, 316, 190, 28, { size: 18, color: COLORS.teal, bold: true });
    text(s, "扩散模型把多峰动作分布与整段动作建模结合起来；滚动时域控制再把生成计划接回真实反馈。", 278, 309, 908, 60, {
      size: 21, bold: true,
    });
    text(s, "适用边界", 76, 408, 190, 28, { size: 18, color: COLORS.orange, bold: true });
    text(s, "性能受示范数据覆盖范围影响；迭代采样带来推理成本，高频控制需要兼顾时延。", 278, 401, 908, 58, {
      size: 20, color: COLORS.ink,
    });
    rule(s, 76, 495, 1128, COLORS.line, 1.2);
    text(s, "复现时优先核对", 76, 522, 210, 28, { size: 18, color: COLORS.teal, bold: true });
    text(s, "观测窗口与动作块长度  ·  执行前缀 Tₐ  ·  训练/推理噪声步数  ·  图像编码器与 EMA 设置", 300, 515, 890, 56, {
      size: 19, bold: true,
    });
    text(s, "核心结论：Diffusion Policy 的关键不只是“用 DDPM 去噪”，而是把条件动作分布、时序动作块和闭环执行放进同一控制流程。", 76, 600, 1125, 43, {
      size: 18, color: COLORS.teal, bold: true,
    });
    notes(
      s,
      "最后把论文压缩成一条因果链：视觉与机器人状态形成 O_t；条件扩散模型学习多峰动作块分布 p(A_t|O_t)；反向采样逐步生成计划；控制器只执行其中一段，随后用新观测重新规划。论文的价值不只是在机器人上调用 DDPM，而是把动作序列分布建模和闭环滚动控制配合起来。适用范围也有边界：行为克隆依赖演示覆盖，迭代采样产生计算成本，真实高频控制还要处理推理时延。若进入代码复现，优先确认观测窗口、动作预测长度与执行长度、噪声步数与采样器、视觉编码器是否参与反传，以及 EMA 与归一化设置。",
      source,
    );
  }

  const previewDir = path.join(BUILD, "previews_v8");
  await fs.mkdir(previewDir, { recursive: true });
  for (const [index, slide] of presentation.slides.items.entries()) {
    const png = await presentation.export({ slide, format: "png", scale: 1 });
    await writeBlob(path.join(previewDir, `slide-${String(index + 1).padStart(2, "0")}.png`), png);
  }

  const draftPath = path.join(BUILD, "candidate_v8.pptx");
  const pptx = await PresentationFile.exportPptx(presentation);
  await pptx.save(draftPath);

  const { finalizePresentation } = await import(pathToFileURL(
    path.join(SKILL_DIR, "container_tools/artifact_tool_utils.mjs"),
  ).href);
  const stagingDir = path.join(ROOT, ".codex_presentation_validation_v8");
  await fs.mkdir(stagingDir, { recursive: true });
  const requirements = {
    explicitTotalSlideCount: 9,
    requiredNativeTableOwnerSlides: [],
    requiredNativeChartOwnerSlides: [],
  };
  const result = await finalizePresentation({
    ...requirements,
    workspaceDir: ROOT,
    candidatePath: draftPath,
    finalPath: FINAL_PPTX,
    pythonExecutable: PYTHON,
    integrityValidatorPath: path.join(SKILL_DIR, "container_tools/inspect_presentation_package_integrity.py"),
    layoutValidatorPath: path.join(SKILL_DIR, "container_tools/inspect_presentation_layout_geometry.py"),
    layoutArgs: ["--expected-slide-size-emu", "12192000,6858000", "--validate-heading-fit"],
    fontPolicy: { basis: "design", families: [FONT, MATH], scriptFonts: { ea: FONT } },
    verifyArtifactToolImport: true,
    receiptPath: path.join(stagingDir, "diffusion_policy_advisor_report_rebuilt_v8.validation.json"),
  });
  console.log(JSON.stringify({ finalPath: FINAL_PPTX, draftPath, previewDir, result }, null, 2));
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
