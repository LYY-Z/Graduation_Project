from pathlib import Path

from docx import Document
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


ROOT = Path(r"G:\毕设\02_learning\04_review")
OUT = ROOT / "deliverables"


def set_cell_shading(cell, fill):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tc_pr.append(shd)
    shd.set(qn("w:fill"), fill)


def set_cell_margins(cell, top=100, start=120, bottom=100, end=120):
    tc = cell._tc
    tc_pr = tc.get_or_add_tcPr()
    tc_mar = tc_pr.first_child_found_in("w:tcMar")
    if tc_mar is None:
        tc_mar = OxmlElement("w:tcMar")
        tc_pr.append(tc_mar)
    for margin, value in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
        node = tc_mar.find(qn("w:" + margin))
        if node is None:
            node = OxmlElement("w:" + margin)
            tc_mar.append(node)
        node.set(qn("w:w"), str(value))
        node.set(qn("w:type"), "dxa")


def set_table_borders(table, color="D9D9D9", size="5"):
    tbl_pr = table._tbl.tblPr
    borders = tbl_pr.first_child_found_in("w:tblBorders")
    if borders is None:
        borders = OxmlElement("w:tblBorders")
        tbl_pr.append(borders)
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        tag = "w:" + edge
        element = borders.find(qn(tag))
        if element is None:
            element = OxmlElement(tag)
            borders.append(element)
        element.set(qn("w:val"), "single")
        element.set(qn("w:sz"), size)
        element.set(qn("w:space"), "0")
        element.set(qn("w:color"), color)


def set_repeat_table_header(row):
    tr_pr = row._tr.get_or_add_trPr()
    tbl_header = OxmlElement("w:tblHeader")
    tbl_header.set(qn("w:val"), "true")
    tr_pr.append(tbl_header)


def set_font(run, name="Microsoft YaHei", size=11, bold=None, italic=None, color="252A31"):
    run.font.name = name
    run._element.get_or_add_rPr().rFonts.set(qn("w:eastAsia"), name)
    run._element.get_or_add_rPr().rFonts.set(qn("w:ascii"), name)
    run._element.get_or_add_rPr().rFonts.set(qn("w:hAnsi"), name)
    run.font.size = Pt(size)
    run.font.color.rgb = RGBColor.from_string(color)
    if bold is not None:
        run.bold = bold
    if italic is not None:
        run.italic = italic


def add_page_field(paragraph):
    run = paragraph.add_run()
    fld_char1 = OxmlElement("w:fldChar")
    fld_char1.set(qn("w:fldCharType"), "begin")
    instr = OxmlElement("w:instrText")
    instr.set(qn("xml:space"), "preserve")
    instr.text = " PAGE "
    fld_char2 = OxmlElement("w:fldChar")
    fld_char2.set(qn("w:fldCharType"), "end")
    run._r.append(fld_char1)
    run._r.append(instr)
    run._r.append(fld_char2)
    set_font(run, size=8.5, color="646A70")


def setup_doc(title, subtitle, kind):
    doc = Document()
    section = doc.sections[0]
    section.page_width = Inches(8.5)
    section.page_height = Inches(11)
    section.top_margin = Inches(0.68)
    section.bottom_margin = Inches(0.64)
    section.left_margin = Inches(0.78)
    section.right_margin = Inches(0.78)
    section.header_distance = Inches(0.3)
    section.footer_distance = Inches(0.3)

    styles = doc.styles
    normal = styles["Normal"]
    normal.font.name = "Microsoft YaHei"
    normal._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
    normal._element.rPr.rFonts.set(qn("w:ascii"), "Microsoft YaHei")
    normal._element.rPr.rFonts.set(qn("w:hAnsi"), "Microsoft YaHei")
    normal.font.size = Pt(10.7)
    normal.font.color.rgb = RGBColor.from_string("252A31")
    normal.paragraph_format.space_after = Pt(4)
    normal.paragraph_format.line_spacing = 1.12

    for style_name, size, before, after in (("Heading 1", 16, 11, 5), ("Heading 2", 12.5, 7, 3), ("Heading 3", 11, 5, 2)):
        st = styles[style_name]
        st.font.name = "Microsoft YaHei"
        st._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
        st._element.rPr.rFonts.set(qn("w:ascii"), "Microsoft YaHei")
        st._element.rPr.rFonts.set(qn("w:hAnsi"), "Microsoft YaHei")
        st.font.size = Pt(size)
        st.font.bold = True
        st.font.color.rgb = RGBColor.from_string("000000")
        st.paragraph_format.space_before = Pt(before)
        st.paragraph_format.space_after = Pt(after)
        st.paragraph_format.keep_with_next = True

    title_style = styles["Title"]
    title_style.font.name = "Microsoft YaHei"
    title_style._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
    title_style.font.size = Pt(24)
    title_style.font.bold = True
    title_style.font.color.rgb = RGBColor.from_string("000000")
    title_style.paragraph_format.space_after = Pt(5)
    title_ppr = title_style._element.get_or_add_pPr()
    title_borders = title_ppr.find(qn("w:pBdr"))
    if title_borders is not None:
        title_ppr.remove(title_borders)

    header = section.header.paragraphs[0]
    header.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    set_font(header.add_run("DIFFUSION POLICY  " + kind), size=8.3, color="000000")
    footer = section.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
    set_font(footer.add_run("Diffusion Policy  ·  论文汇报复习材料     |     "), size=8.3, color="646A70")
    add_page_field(footer)

    p = doc.add_paragraph(style="Title")
    ppr = p._p.get_or_add_pPr()
    paragraph_borders = ppr.find(qn("w:pBdr"))
    if paragraph_borders is not None:
        ppr.remove(paragraph_borders)
    set_font(p.add_run(title), size=24, bold=True, color="000000")
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(12)
    set_font(p.add_run(subtitle), size=10.5, color="646A70")
    return doc


def add_label_paragraph(doc, label, text, italic=False):
    p = doc.add_paragraph()
    p.paragraph_format.keep_together = True
    p.paragraph_format.space_after = Pt(4)
    lead = p.add_run(label)
    set_font(lead, size=10.7, bold=True, color="252A31")
    body = p.add_run(normalize_notation(text))
    set_font(body, size=10.7, italic=italic, color="252A31")
    return p


def add_body(doc, text, style=None):
    p = doc.add_paragraph(style=style)
    p.paragraph_format.keep_together = True
    run = p.add_run(normalize_notation(text))
    set_font(run, size=10.7 if style is None else 10.3)
    return p


def normalize_notation(text):
    replacements = [
        ("A_t^{k−1}", "Aₜᵏ⁻¹"), ("A_t^{k-1}", "Aₜᵏ⁻¹"),
        ("A_t^0", "Aₜ⁰"), ("A_t^k", "Aₜᵏ"), ("A_t", "Aₜ"), ("O_t", "Oₜ"),
        ("T_o", "Tₒ"), ("T_p", "Tₚ"), ("T_a", "Tₐ"),
        ("ᾱ_{k−1}", "ᾱₖ₋₁"), ("ᾱ_{k-1}", "ᾱₖ₋₁"),
        ("ᾱ_k", "ᾱₖ"), ("ᾱ_j", "ᾱⱼ"),
        ("β̃_k", "β̃ₖ"), ("μ̃_k", "μ̃ₖ"),
        ("σ_k^2", "σₖ²"), ("β_k", "βₖ"), ("α_k", "αₖ"),
        ("σ_k", "σₖ"), ("γ_k", "γₖ"), ("ε_θ", "εθ"),
        ("μ_θ", "μθ"), ("D_a", "Dₐ"), ("c_1", "c₁"), ("c_2", "c₂"),
        ("∇_θL", "∇θ L"), ("∇_θ L", "∇θ L"), ("∇_A", "∇A"),
    ]
    for old, new in replacements:
        text = text.replace(old, new)
    return text


def m_el(name):
    return OxmlElement("m:" + name)


def m_text(value):
    run = m_el("r")
    text = m_el("t")
    text.text = value
    run.append(text)
    return run


def m_group(*parts):
    element = m_el("e")
    for part in parts:
        element.append(part)
    return element


def m_sub(base, index):
    node = m_el("sSub")
    node.append(m_group(base))
    sub = m_el("sub")
    sub.append(m_text(index) if isinstance(index, str) else index)
    node.append(sub)
    return node


def m_sup(base, power):
    node = m_el("sSup")
    node.append(m_group(base))
    sup = m_el("sup")
    sup.append(m_text(power) if isinstance(power, str) else power)
    node.append(sup)
    return node


def m_subsup(base, index, power):
    node = m_el("sSubSup")
    node.append(m_group(base))
    sub = m_el("sub")
    sub.append(m_text(index) if isinstance(index, str) else index)
    node.append(sub)
    sup = m_el("sup")
    sup.append(m_text(power) if isinstance(power, str) else power)
    node.append(sup)
    return node


def m_frac(numerator, denominator):
    node = m_el("f")
    num = m_el("num")
    den = m_el("den")
    num.append(m_group(*numerator) if isinstance(numerator, tuple) else m_group(numerator))
    den.append(m_group(*denominator) if isinstance(denominator, tuple) else m_group(denominator))
    node.append(num)
    node.append(den)
    return node


def m_sqrt(*parts):
    node = m_el("rad")
    props = m_el("radPr")
    hidden = m_el("degHide")
    hidden.set(qn("m:val"), "1")
    props.append(hidden)
    node.append(props)
    node.append(m_el("deg"))
    node.append(m_group(*parts))
    return node


def m_accent(base, accent_char):
    node = m_el("acc")
    props = m_el("accPr")
    char = m_el("chr")
    char.set(qn("m:val"), accent_char)
    props.append(char)
    node.append(props)
    node.append(m_group(base))
    return node


def m_bar_alpha(index):
    return m_sub(m_accent(m_text("α"), "¯"), index)


def m_eps_theta():
    return m_sub(m_text("ε"), "θ")


def m_eps_hat_k():
    return m_sub(m_accent(m_text("ε"), "ˆ"), "k")


def m_inputs():
    return m_parentheses(m_sub(m_text("O"), "t"), m_text(","), m_A("t", "k"), m_text(",k"))


def m_alpha_k():
    return m_sub(m_text("α"), "k")


def m_beta_k():
    return m_sub(m_text("β"), "k")


def m_sigma_k():
    return m_sub(m_text("σ"), "k")


def m_mu_theta():
    return m_sub(m_text("μ"), "θ")


def m_mu_tilde_k():
    return m_sub(m_accent(m_text("μ"), "~"), "k")


def m_beta_tilde_k():
    return m_sub(m_accent(m_text("β"), "~"), "k")


def m_A(index="t", power=None):
    return m_subsup(m_text("A"), index, power) if power is not None else m_sub(m_text("A"), index)


def m_parentheses(*parts):
    node = m_el("d")
    props = m_el("dPr")
    begin = m_el("begChr")
    begin.set(qn("m:val"), "(")
    end = m_el("endChr")
    end.set(qn("m:val"), ")")
    props.append(begin)
    props.append(end)
    node.append(props)
    node.append(m_group(*parts))
    return node


def equation_parts(name):
    a0 = m_A("t", "0")
    ak = m_A("t", "k")
    alpha_bar = m_bar_alpha("k")
    eps_theta = m_eps_theta()
    if name == "mse_point":
        return (m_accent(m_text("a"), "ˆ"), m_text("=E[a*|O]  (平方损失下的条件均值)"))
    if name == "energy_score":
        return (m_text("p(a|O)="), m_frac(m_text("exp[−E(O,a)]"), m_text("Z(O)")), m_text(",   ∇ₐ log p(a|O)=−∇ₐE(O,a)"))
    if name == "forward":
        return (ak, m_text("="), m_sqrt(alpha_bar), a0, m_text("+"), m_sqrt(m_text("1−"), alpha_bar), m_text("ε,   ε∼N(0,I)"))
    if name == "variance_scale":
        return (m_text("Var(cX)=c² Var(X)"),)
    if name == "noise_loss":
        inner = m_group(m_text("ε−"), eps_theta, m_inputs())
        return (m_sub(m_text("L"), "noise"), m_text("=E[‖"), inner, m_text("‖²]"))
    if name == "posterior":
        am1 = m_A("t", "k−1")
        return (m_text("q("), am1, m_text("|"), ak, m_text(","), a0, m_text(")=N("), m_mu_tilde_k(), m_text(","), m_beta_tilde_k(), m_text(" I)"))
    if name == "beta_tilde":
        top = (m_text("(1−"), m_bar_alpha("k−1"), m_text(")"), m_beta_k())
        bot = (m_text("1−"), alpha_bar)
        return (m_beta_tilde_k(), m_text("="), m_frac(top, bot), m_text(",   β_k=1−"), m_alpha_k())
    if name == "mu_tilde":
        c1 = m_frac((m_sqrt(m_bar_alpha("k−1")), m_beta_k()), (m_text("1−"), m_bar_alpha("k")))
        c2 = m_frac((m_sqrt(m_alpha_k()), m_text("(1−"), m_bar_alpha("k−1"), m_text(")")), (m_text("1−"), m_bar_alpha("k")))
        return (m_mu_tilde_k(), m_text("="), c1, a0, m_text("+"), c2, ak)
    if name == "x0hat":
        top = (ak, m_text("−"), m_sqrt(m_text("1−"), alpha_bar), eps_theta, m_inputs())
        ahat = m_subsup(m_accent(m_text("A"), "ˆ"), "t", "0")
        return (ahat, m_text("="), m_frac(top, m_sqrt(alpha_bar)))
    if name == "mu_theta":
        top = (m_beta_k(), eps_theta, m_inputs())
        bot = m_sqrt(m_text("1−"), alpha_bar)
        inside = (ak, m_text("−"), m_frac(top, bot))
        return (m_mu_theta(), m_text("="), m_frac(m_text("1"), m_sqrt(m_alpha_k())), m_parentheses(*inside))
    if name == "sample_standard":
        return (m_A("t", "k−1"), m_text("="), m_mu_theta(), m_text("+"), m_sigma_k(), m_text(" z,   z∼N(0,I),   "), m_sup(m_sigma_k(), "2"), m_text("="), m_beta_tilde_k())
    if name == "score":
        denom = m_sqrt(m_text("1−"), alpha_bar)
        frac = m_frac((eps_theta, m_inputs()), denom)
        score_hat = m_sub(m_text("ŝ"), "θ")
        pk = m_sub(m_text("p"), "k")
        return (score_hat, m_text("("), ak, m_text(",Oₜ,k)≈−"), frac, m_text("≈∇_{Aₜᵏ} log "), pk, m_text("(Aₜᵏ|Oₜ)"))
    if name == "langevin":
        return (m_A("t", "k−1"), m_text("="), m_alpha_k(), m_text("["), ak, m_text("−γ_k"), eps_theta, m_inputs(), m_text("+"), m_sigma_k(), m_text(" z]"))
    if name == "ddim_jump":
        eps_hat = m_text("ε̂_k")
        x0hat = m_text("Â_t^0")
        first = m_frac((ak, m_text("−"), m_sqrt(m_text("1−"), alpha_bar), eps_hat), m_sqrt(alpha_bar))
        aj = m_bar_alpha("j")
        target = m_A("t", "j")
        second = (target, m_text("="), m_sqrt(aj), x0hat, m_text("+"), m_sqrt(m_text("1−"), aj), m_eps_hat_k(), m_text(",   j<k"))
        return (x0hat, m_text("="), first, m_text(",   "), *second)
    if name == "rhc":
        return (m_text("生成 Tₚ 步  →  执行前 Tₐ 步  →  新观测  →  重新规划"),)
    if name == "relative_improvement":
        numerator = (m_text("DP_i−最佳基线_i"))
        denominator = m_text("最佳基线_i")
        return (m_text("平均相对提升="), m_frac(numerator, denominator), m_text(" 对任务取平均 ≈ 46.9%"))
    if name == "pipeline":
        return (m_text("(Oₜ,Aₜ⁰) → Aₜᵏ → εθ 预测 → 逐步去噪 → 执行前缀 → 新观测"),)
    raise KeyError("Unknown formula " + name)


def add_equation(doc, name, max_width=6.45):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(1)
    p.paragraph_format.space_after = Pt(7)
    p.paragraph_format.keep_together = True
    para = m_el("oMathPara")
    props = m_el("oMathParaPr")
    jc = m_el("jc")
    jc.set(qn("m:val"), "center")
    props.append(jc)
    para.append(props)
    equation = m_el("oMath")
    for part in equation_parts(name):
        equation.append(part)
    para.append(equation)
    p._p.append(para)
    return p


def add_timing_table(doc, rows):
    table = doc.add_table(rows=1, cols=3)
    table.autofit = False
    widths = [Inches(0.55), Inches(5.45), Inches(0.85)]
    for i, width in enumerate(widths):
        table.columns[i].width = width
    headers = ["页", "主题", "建议时长"]
    for i, value in enumerate(headers):
        cell = table.rows[0].cells[i]
        cell.width = widths[i]
        set_cell_shading(cell, "41474D")
        cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
        set_cell_margins(cell)
        p = cell.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.LEFT if i == 1 else WD_ALIGN_PARAGRAPH.CENTER
        set_font(p.add_run(value), size=9.3, bold=True, color="FFFFFF")
    set_repeat_table_header(table.rows[0])
    for ix, row in enumerate(rows):
        cells = table.add_row().cells
        for i, value in enumerate(row):
            cells[i].width = widths[i]
            cells[i].vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            set_cell_margins(cells[i], top=80, bottom=80)
            if ix % 2 == 1:
                set_cell_shading(cells[i], "F3F5F6")
            p = cells[i].paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.LEFT if i == 1 else WD_ALIGN_PARAGRAPH.CENTER
            set_font(p.add_run(str(value)), size=9.2, color="252A31")
    set_table_borders(table)
    doc.add_paragraph().paragraph_format.space_after = Pt(2)
    return table


def add_page_heading(doc, n, title, duration):
    p = doc.add_paragraph(style="Heading 1")
    p.paragraph_format.keep_with_next = True
    set_font(p.add_run(f"第 {n} 页  {title}"), size=16, bold=True, color="000000")
    q = doc.add_paragraph()
    q.paragraph_format.space_after = Pt(5)
    set_font(q.add_run("建议用时  " + duration), size=9.3, bold=True, color="78394C")


SPEECH = [
    ("论文汇报  /  VISUOMOTOR IMITATION LEARNING", "0:30",
     "各位老师好，今天汇报的是 Diffusion Policy。本文关注一个具体问题：机器人看到相机图像和自身状态后，怎样生成一段连贯的动作计划，并在执行中根据新观测及时调整。汇报先从单步动作回归为什么会遇到多解困难讲起，再看条件扩散怎样训练和采样，最后讨论闭环控制、实验结果与适用边界。",
     "",
     ""),
    ("单步动作回归难以表达多个有效解", "1:00",
     "先看 Push-T。对同一场景，机械臂可以从 T 形块左侧或右侧接近，两条轨迹都可能成功。如果模型只输出一个动作并用 MSE 拟合演示，不同路线会把预测拉向平均值；这个平均位置可能落在障碍物附近，反而不可行。若每个时刻各自选路线，还可能左右切换。问题因此不是“找一个平均动作”，而是要表示同一观测下多个连贯的动作方案。",
     "这就引出论文的建模对象：给定观测，生成一整段未来动作，而不是只预测下一步。",
     "讲到这里可指向图中的两条有效路线与虚线均值，强调平均动作不等于有效路线。"),
    ("扩散策略以迭代去噪表达条件动作分布", "0:55",
     "论文把几种策略表示放在一起比较。显式策略直接从观测输出动作，速度快，但单点回归不容易保留多个模式。能量模型给观测和动作打分，概率写成 exp(−E) 再除以归一化常数 Z；对动作求梯度时，Z 与动作无关，会消掉，但训练和搜索仍较复杂。Diffusion Policy 学习带噪动作的去噪方向，也就是条件动作分布的 score，用噪声回归提供直接监督。主实验属于行为克隆，数据来自专家示范，不靠在线奖励试错。",
     "接下来要回答的是：观测怎样进入去噪网络，而动作为什么是唯一被扩散的对象。",
     ""),
    ("观察提供条件，未来动作序列是生成对象", "1:10",
     "观测 O 包含最近几帧的多视角图像和机器人本体状态。每个相机视角由独立 ResNet-18 编码，再用 Spatial Softmax 保留空间位置信息；各视角特征与本体状态拼接成条件向量。这里不是把图片相加，也不要求网络先输出“杯子”这样的类别。噪声预测误差的梯度会回到视觉编码器，让它学到对动作有用的线索。模型只给未来动作块加噪，观测在一轮去噪中作为条件共享。CNN 版本用 FiLM 调制时序特征，Transformer 版本用 cross-attention 注入观察特征。作者用 GroupNorm 代替 BatchNorm，也让视觉编码器更容易与 EMA 平滑权重配合。",
     "明确了条件和生成对象后，下一页就可以把 DDPM 的训练公式直接换到动作块上。",
     ""),
    ("训练：已知噪声构成直接监督信号", "1:10",
     "训练时，干净样本不是图片，而是专家演示中未来 T_p 步的动作块 A⁰。先抽一个扩散级 k 和同形状的标准高斯噪声 ε，再按图中公式混合成带噪动作 Aᵏ。平方根系数来自方差比例：ᾱ 控制保留多少动作信号，1−ᾱ 控制噪声份额。网络看见观测、带噪动作和扩散级，预测刚才实际加入的 ε；损失对每个元素先平方再平均，所以正负误差不会抵消。这里的噪声预测 MSE 不等同于前面会把多条路线平均掉的动作回归 MSE。",
     "训练阶段知道加入了什么噪声；生成阶段没有专家动作，所以下一页要解释反向采样怎样补上这个缺口。",
     "请区分控制时刻 t 与扩散级 k；前者描述机器人什么时候看和动，后者是动作块内部的去噪等级。"),
    ("反向采样：后验均值如何变成下一步动作", "1:30",
     "反向公式不是凭空设计的。前向加噪是高斯过程；训练时又知道干净动作 A⁰，因此可用贝叶斯公式求 Aᵏ⁻¹ 在 Aᵏ 和 A⁰ 条件下的高斯后验。后验均值是 A⁰ 与 Aᵏ 的加权和，方差是 β̃。生成时没有真实 A⁰，先用噪声预测反推出估计值 Â⁰，再代回后验均值，整理系数后得到图中的 μθ。μθ 是下一步分布的中心，不是最终抽出的动作；若方差取 β̃，则标准差 σ 等于 √β̃，真正的样本还要加 σz。z 是每次反向采样新抽的张量，训练监督噪声 ε 则是另一阶段的量。最后一步通常不再加随机噪声。论文还给出 Langevin 风格的动作更新，系数定义与标准 DDPM 后验不同，不能把两套 σ 直接互换。",
     "理解了每一步怎样往回走，下一页再看如何少走一些扩散级、缩短实际推理时间。",
     "公式较多时，只需口头串起“贝叶斯后验—估计干净动作—代回得到均值—按标准差采样”四步，不必现场逐项展开所有系数。"),
    ("DDIM：训练噪声级数与推理步数可以分开", "0:55",
     "DDIM 使用同一个噪声预测器。当前动作块给出噪声预测后，先估计干净动作 Â⁰，再按目标噪声级 j 的信号和噪声比例重新组合成 Aʲ。由于前向过程有闭式表达，采样器可以直接从较噪的 k 跳到较干净的 j，不必每一级都走。论文主文的真实机器人示例使用 100 个训练噪声级、10 个推理迭代，在 RTX 3080 上约 0.1 秒；附录中的部分实机配置使用 16 个评估步，所以速度必须连同具体配置一起报告。",
     "采样器得到的是计划候选，实际机器人并不会把整段动作一次性开环执行完。",
     "跳级来自闭式重组，不是任意删去步骤；步数过少仍可能影响生成质量。"),
    ("滚动时域控制：部分执行，持续重规划", "1:05",
     "在每个真实控制时刻，模型读取最近 T_o 步观测，生成未来 T_p 步动作，但控制器只执行最前面的 T_a 步。执行后再读取新观测、重新规划，因此长动作块提供连续性，短执行前缀保留反馈能力。论文常见设置是 T_o=2、T_p=16，多数任务 T_a=8，实机 Push-T 用 6 步。T_a 太短会频繁截断计划，太长则对新情况反应慢。上一轮未执行的动作尾部还可作为下一轮 warm-start 初始参考，但它不是必须照搬的指令。",
     "这说明方法效果不仅由去噪网络决定，还依赖控制时域与执行方式。下一页看论文用哪些实验来验证整套系统。",
     "别把扩散级 k 与机器人执行步数 T_a 混为一谈；warm-start 是初始化参考，不是把旧计划不加判断地继续执行。"),
    ("实验结果：多峰轨迹质量也转化为任务成功", "1:15",
     "实验可以分三层看。模拟基准覆盖 4 个基准、15 项任务，论文报告平均相对最佳基线提升 46.9%；这是逐任务算相对提升再平均，不是成功率增加 46.9 个百分点，而且不同任务差异很大。真实 UR5 Push-T 使用 136 条示范、评测 20 次，成功率 95%，IoU 为 0.80，人工演示均值为 0.84；对照的 IBC 为 0%，LSTM-GMM 为 20%。期刊扩展还测试双臂任务，Egg Beater、Mat Unrolling、Shirt Folding 分别为 55%、75%、75%。这些结果支持方法在论文测试设置下有效，不代表所有任务都能成功，也不是安全保证。",
     "最后一页把方法贡献、系统条件和证据边界合在一起。",
     ""),
    ("结论与适用边界", "0:30",
     "总结来说，Diffusion Policy 把单步动作回归改为观测条件下的动作块生成，用噪声预测学习多模态动作分布，再通过部分执行和持续重规划接入闭环控制。论文实验支持它在所测任务中的效果，但它仍是行为克隆，受示范覆盖、推理延迟和分布外场景限制，也不提供安全证明。复现时应先确认动作定义、坐标系与归一化，再检查视觉监督、采样速度和闭环执行设置。我的汇报到这里，谢谢各位老师。",
     "",
     ""),
]


REVIEW = [
    {
        "title": "论文定位与全篇问题链",
        "claim": "Diffusion Policy 是一种视觉条件的动作生成策略：它在观测条件下生成未来动作块，执行一部分后再根据新观测重规划。",
        "sections": [
            ("这篇论文究竟研究什么", [
                "论文题目是《Diffusion Policy: Visuomotor Policy Learning via Action Diffusion》。它把扩散模型从图像生成任务迁移到机器人视觉操作：输入是视觉与机器人本体观测，生成对象是未来的一段机器人动作。论文先在 RSS 2023 发表，期刊扩展版发表于 IJRR 2025。",
                "主线不是“给机器人一张图，它就凭空知道怎么抓”，而是：专家演示提供监督；视觉编码器把观测变成条件特征；条件去噪网络从随机动作计划中逐步生成合理的动作块；控制器只执行其中一段，再读取新观测。"
            ], []),
            ("先固定三种时间索引", [
                "全文最容易混淆的是机器人控制时刻 t 与扩散级 k。O_t 表示机器人时刻 t 的观测；A_t^k 表示以该观测为条件、处于扩散级 k 的动作块。一次策略调用内部，k 从较噪的高等级逐步下降；动作执行若干步后，机器人控制时刻 t 才向前推进。",
                "T_o 是输入多少步历史观测，T_p 是计划包含多少步未来动作，T_a 是本轮实际执行多少步。它们都是控制设计长度，不是扩散采样步数。"
            ], []),
            ("自检", ["用一句话回答：被扩散的是观察图像，还是未来动作？答案是未来动作；观察提供条件。", "能否分别说出 t、k、T_o、T_p、T_a 的含义？如果不能，先复习本节再看公式。"], [])
        ],
        "source": "论文首页、§§2.1–2.3。"
    },
    {
        "title": "多模态动作与单步 MSE 的问题",
        "claim": "同一观测可能对应多个都有效的动作方案；单个点预测会把多个方案压成一个平均动作，而平均值可能不可行。",
        "sections": [
            ("Push-T 的左右绕行例子", [
                "假设末端可以从障碍物左边或右边绕过去。两条路线都能到达目标，所以专家演示在相近观测下可能给出差异很大的动作。多峰或多模态动作分布，指条件分布中存在多个高概率区域；它不是机器人随机乱动。",
                "若用一个确定动作拟合这些演示，MSE 的最优点是平方误差意义上的条件平均。用一维动作作简化例子：演示动作可能是 −1 或 +1，平均预测是 0。若 0 对应障碍物方向，这个“数学上平均误差较小”的输出却不是可执行的成功方案。"
            ], ["mse_point"]),
            ("动作多峰不等于输入多模态", [
                "“多模态输入”常指图像、关节状态、夹爪状态等不同输入来源；“多模态动作”指给定同一个条件 O，合理动作分布有多个模式。Diffusion Policy 面对的是后者，并使用前者作为观测条件。",
                "逐时刻独立预测还会产生时间不连贯：某一步选择左绕，下一步又选择右绕，形成抖动。把一段动作 A_t 作为联合生成对象，有助于在一次计划中维持同一条运动模式。"
            ], []),
            ("行为克隆与分布偏移", [
                "行为克隆（BC）用专家给出的观测—动作对训练策略，本文主实验不依靠奖励函数驱动在线探索。BC 的分布偏移是另一个问题：一次动作误差可能把机器人带到演示少见的状态，模型在那里更容易继续犯错。它与多模态有关但并非同一概念。"
            ], []),
            ("常见疑问", [
                "普通 MSE 并非任何情况下都不好；若每种观测只有一个稳定动作模式，它是合理的回归损失。问题在于多解被压成单点时，该点可能不属于任何有效模式。",
                "Diffusion Policy 训练也用 MSE，但它回归的是实际加入的噪声，不是直接把多个专家动作平均为一个动作。两种 MSE 的预测对象不同。"
            ], []),
            ("自检", ["左绕和右绕都能完成任务，它们属于输入多模态还是动作多模态？答案是动作多模态。", "为什么动作序列比每一步各自选模式更连贯？因为一次生成共同建模一段未来动作。"], [])
        ],
        "source": "论文 §§1–2、§4.1、Figure 3。"
    },
    {
        "title": "显式策略、能量模型与扩散策略",
        "claim": "扩散策略把动作分布表示为逐步去噪过程；噪声预测提供了可直接监督的训练目标。",
        "sections": [
            ("三类表示方式", [
                "显式策略直接输出一个动作或参数化分布。它推理简单，但确定性单点回归会压平多峰；若使用高斯混合等分布，又需选择模型形式或模式数量。",
                "能量模型为观测 O 与候选动作 a 计算能量 E(O,a)，低能量代表更合理。它的概率形式需要归一化常数 Z(O)。连续高维动作空间中的积分通常难算，训练和推理也可能需要负样本或搜索。",
                "Diffusion Policy 不先给每个候选动作计算一个显式总分，而是训练噪声预测器，再利用其方向迭代修正动作计划。它保留多峰表达能力，同时用人为注入且已知的噪声构造监督。"
            ], ["energy_score"]),
            ("为什么归一化常数的梯度会消失", [
                "由 log p(a|O)=−E(O,a)−log Z(O)，对动作 a 求梯度时，Z 只取决于 O，不随 a 变化，所以该项梯度为零。这说明能量模型的 score 与 −∇_a E 相同；但它不意味着 Z 在模型训练所有环节都自动变得容易计算。",
                "扩散网络的 score 不是对网络参数 θ 的训练梯度。score 是对动作变量 A 求的 log 概率梯度，描述动作空间里密度增大的方向；反向传播的 ∇_θ L 则是用于训练网络参数的梯度。"
            ], []),
            ("不要过度比较", [
                "扩散训练更直接，不等于能量模型永远不可用，也不等于扩散没有代价。扩散需要多次去噪，推理延迟更高；论文的核心取舍是以迭代采样换取复杂动作分布的表达能力。"
            ], []),
            ("自检", ["Z(O) 是否依赖动作 a？不依赖，因此对 a 求梯度时消失。", "score 对谁求导？对动作；训练梯度对谁求导？对参数 θ。"], [])
        ],
        "source": "论文 Figure 1、§§1–2、§2.3.2。"
    },
    {
        "title": "视觉观测如何进入策略",
        "claim": "多视角图像和机器人状态先编码为条件特征；扩散只作用于动作块，视觉编码器通过动作监督端到端学习任务相关线索。",
        "sections": [
            ("从像素到条件向量", [
                "观测 O_t 汇集最近 T_o 帧图像和机器人低维本体状态。各相机视角用独立 ResNet-18 提取特征；Spatial Softmax 将空间特征图压缩成带位置信息的表示。随后把不同视角特征与机器人状态沿特征维拼接。这里是向量拼接，不是把图像像素直接相加。",
                "ResNet 不是先把图片翻译成‘杯子’这个词。论文没有要求对象类别标签。网络只需找到能帮助预测专家动作的线索，例如目标与末端的相对位置、接触状态或夹爪开合。"
            ], []),
            ("为什么视觉编码器会学到有用特征", [
                "训练时噪声预测损失作用于去噪器；反向传播会沿计算链回到视觉 ResNet。若改变图像特征能降低条件动作噪声预测误差，参数更新就会保留这种变化。于是视觉表示被动作任务塑造。所谓“学会识别”，应理解为学会提取对控制有用的视觉信息，不一定形成可读的物体标签或人类语义。",
                "论文报告的实机视觉消融显示端到端微调优于冻结预训练特征。这个结果说明特征是否与控制目标匹配很重要；不能据此断言预训练特征在任何任务都无用。"
            ], []),
            ("FiLM 与 Transformer 条件注入", [
                "CNN 版本将动作序列送入 1D 时序 U-Net，用 FiLM 按观察和扩散级产生缩放、偏移量，调制中间时序特征。直观上，它让同一动作特征在不同场景条件下有不同解释。",
                "Transformer 版本把动作序列变成 token。因果自注意力让动作 token 关注自身和之前动作；cross-attention 再让它们读取观察嵌入。两种结构都让 O 条件化去噪，不会把 O 本身当成要生成和去噪的对象。"
            ], []),
            ("BatchNorm、GroupNorm 与 EMA", [
                "在线模型是当前迭代刚更新的参数；EMA 模型是对历史参数作指数平滑后得到的较稳定版本。BatchNorm 除了可训练参数，还保存训练批次的运行均值和方差，这些统计量对应在线训练过程。若评估时改用 EMA 权重，统计量可能与当前权重版本不完全匹配。",
                "GroupNorm 在单个样本内部的特征组上归一化，不依赖跨批次长期运行统计量，因此与 EMA 权重搭配更直接。可以把差异记成：EMA 平滑模型参数；GroupNorm 避免另带一份跨批次历史统计。"
            ], []),
            ("自检", ["无类别标签；各视角和状态向量拼接作条件，只扩散动作。（参见 Figure 2、§§2.3.2、3.1–3.2。）"], [])
        ],
        "source": "论文 Figure 2、§§2.3.2、3.1–3.2、5.4、6.1.2。"
    },
    {
        "title": "训练阶段与 DDPM 的动作化",
        "claim": "训练时从演示动作块构造带噪版本，网络根据观测和扩散级预测已知噪声，最小化噪声 MSE。",
        "sections": [
            ("张量里装的是什么", [
                "A_t^0 是演示中的未来动作块，形状为 [T_p,D_a]；加 batch 维后为 [B,T_p,D_a]。T_p 是计划长度，D_a 是每步动作维度。ε 与动作块同形，每个位置都是一个浮点噪声值。ε∼N(0,I) 表示逐元素按均值 0、方差 1 的高斯规则抽取；高斯是抽样规则，ε 才是实际数组。"
            ], []),
            ("前向加噪公式", [
                "α_k=1−β_k；β_k 是第 k 级新增噪声方差日程，α_k 表示该级保留比例，ᾱ_k=∏_{i=1}^k α_i 是累计保留比例。闭式公式可以一次性从干净动作得到任意级别 A_t^k，不必真的逐级执行前向加噪。"
            ], ["forward"]),
            ("平方根为什么出现", [
                "乘在随机量前的系数决定振幅；若随机量方差为 1，乘以 c 后方差变为 c²。因此当 ᾱ_k 和 1−ᾱ_k 表示信号与噪声的方差份额时，振幅系数必须是它们的平方根。它不是把动作平方，也不是装饰。",
                "k 越大，累计信号比例通常越小，噪声越显著。Square Cosine 日程是一种预先设计的噪声级表，通过余弦平方曲线安排不同级别的累计信号/噪声比例；它不是实际抽到的噪声图，也不是网络预测值。"
            ], ["variance_scale"]),
            ("噪声预测损失与 MSE", [
                "每次抽取专家样本 (O_t,A_t^0)、扩散级 k 和噪声 ε，构造 A_t^k，再让 ε_θ 预测实际加入的 ε。损失先对每个元素求差并平方，再对元素和样本平均；正负误差不会抵消。",
                "两种 MSE 的对象不同：直接动作回归可能把多种动作收缩到平均值；扩散噪声 MSE 训练网络还原加入的噪声，不把动作本身平均掉。"
            ], ["noise_loss"]),
            ("KL 散度在这里的位置", [
                "KL 散度比较两个概率分布，不是额外的数据样本或单个动作。在 DDPM 的变分推导中，KL 项描述模型反向分布与真实后验之间的差异；常见简化后可采用噪声预测 MSE 作为训练目标。论文实现采用噪声预测损失，不是再在 MSE 外机械地加一项独立 KL。"
            ], []),
            ("自检", ["动作块 16×7 时，ε 同形；k 是扩散级，t 是控制时刻。（参见 Eqs. (3)、(5)、§§2.2–2.3、3.3。）"], [])
        ],
        "source": "论文 Eqs. (3)、(5)、§§2.2–2.3、3.3。"
    },
    {
        "title": "反向 DDPM、贝叶斯后验与 sigma",
        "claim": "标准 DDPM 的反向均值来自已知高斯前向过程的贝叶斯后验；σ 来自该高斯分布的方差，而不是另造的参数。",
        "sections": [
            ("训练知道原图，生成不知道", [
                "前向规则规定从 A_t^{k−1} 加噪到 A_t^k。训练时两者以及专家干净动作 A_t^0 都可构造或读取，所以可以求 A_t^{k−1} 在 A_t^k 和 A_t^0 条件下的真实后验。反向贝叶斯公式中需要比较前向似然和先验；由于二者都是高斯，后验仍是高斯。",
                "后验写成 N(μ̃_k,β̃_k I)。μ̃_k 是中心，β̃_k 是每个动作元素的方差。方差决定中心周围不确定性有多大。"
            ], ["posterior", "beta_tilde", "mu_tilde"]),
            ("生成时怎样得到 μθ", [
                "推理没有演示动作 A_t^0，因此网络先预测 ε_θ，并从前向闭式公式反推出估计干净动作 Â_t^0。然后把 Â_t^0 替换到贝叶斯后验均值 μ̃_k=c_1A_t^0+c_2A_t^k 中。整理 A_t^k 的系数会得到 1/√α_k；整理噪声预测的系数会得到 −β_k/[√α_k√(1−ᾱ_k)]。把共同的 1/√α_k 提出，就得到标准 DDPM 的 μθ。"
            ], ["x0hat", "mu_theta"]),
            ("把代数整理看成系数收集", [
                "关键不是背公式，而是知道两个来源：真实后验均值本来由 A_t^0 和 A_t^k 线性组合；网络用噪声预测代替未知的 A_t^0。复杂系数是代入、合并同类项的结果，不是新增的经验规则。",
                "上述 μθ 是下一步分布的中心，单独还不是随机样本。高斯采样的一般写法是 X=μ+σz，z∼N(0,I)。若 DDPM 采用 fixed-small 方差设定 σ_k²=β̃_k，则 σ_k=√β̃_k。方差与标准差不能混为一谈。"
            ], ["sample_standard"]),
            ("ε、εθ、z 与最后一步", [
                "ε 是训练前向加噪时真实抽取、因此已知的监督目标。εθ 是网络根据带噪动作预测的噪声。z 是生成时为反向抽样新抽取的标准高斯张量；它与 ε 分布相同，但不是同一份数组，也不承担同一作用。最后一步通常令 z=0，避免在最终输出额外加噪。",
                "不同实现可选择不同的反向方差设置，因此讲 σ_k=√β̃_k 时应说明采用的是常见 fixed-small 设定。"
            ], []),
            ("score 为什么要除以噪声标准差", [
                "对固定干净样本，A^k 的高斯条件分布均值是 √ᾱ_k A^0，标准差是 √(1−ᾱ_k)。高斯 log 密度对 A^k 的导数等于负残差除以方差；而残差本身等于标准差乘 ε。因此结果是 −ε/√(1−ᾱ_k)。网络预测 εθ 后，就得到近似 score。",
                "score 是对动作 A 求导、指出概率密度上升方向的量；∇_θL 是对模型参数求导、用于训练的量。它们是不同变量上的梯度。"
            ], ["score"]),
            ("论文 Eq. (4) 与标准 DDPM 的关系", [
                "论文还把动作采样写成 Langevin 风格更新 A_t^{k−1}=α_k[A_t^k−γ_kε_θ+σ_kz]。它利用噪声预测所隐含的 score 方向，但参数化方式不同于前面的标准 DDPM 后验均值加 σz。两式目的相似，系数含义并不自动相同，尤其不能把两处 σ 互换。"
            ], ["langevin"]),
            ("自检", ["μθ 是下一步动作样本本身吗？不是，它是反向高斯分布的中心。", "β̃_k 与 σ_k 分别是什么？在 fixed-small 设定下，β̃_k 是方差，σ_k=√β̃_k 是标准差。", "训练的 ε 和推理的 z 是同一个张量吗？不是。"], [])
        ],
        "source": "论文 Eqs. (1)、(4)、§§2.1–2.3。标准后验系数按论文 DDPM 记号展开。"
    },
    {
        "title": "DDIM 的跳步采样",
        "claim": "DDIM 复用训练好的噪声预测器，先估计干净动作，再按选定目标噪声级重组动作，因此可以减少推理迭代次数。",
        "sections": [
            ("先估计干净动作，再构造目标级", [
                "给定当前较噪的动作 A_t^k 和预测噪声 ε̂_k，先从闭式前向式估计干净动作 Â_t^0。然后选较干净的级别 j<k，按该级的累计信号和噪声系数重新混合 Â_t^0 与同一噪声估计，得到 A_t^j。"
            ], ["ddim_jump"]),
            ("为什么允许跳过中间级", [
                "任意噪声等级的前向闭式表达都已知。只要有当前噪声估计，就能先回到干净动作估计，再直接构造目标等级样本，所以不需要把每一个相邻等级都单独抽样。跳步不是直接把 A^k 当成 A^j，也不是随意猜一个结果。",
                "训练级数与推理迭代次数可以分开设置，但步数减少通常意味着速度与采样质量之间需要权衡。若更换 DDIM 推理日程，一般不需要重新训练噪声网络。"
            ], []),
            ("论文报告的速度口径", [
                "主文的实机示例报告 100 个训练噪声级、10 个 DDIM 推理迭代，在 NVIDIA RTX 3080 上约 0.1 秒。附录的其他真实机器人配置可使用 16 个评估步。介绍延迟时要连同硬件、推理步数和具体配置一起说，不能把不同配置拼成一个数字。"
            ], []),
            ("自检", ["DDIM 跳级时，先做什么？先由噪声预测估计干净动作 Â^0，再按目标级 j 重组。", "DDIM 是另一个训练网络吗？这里主要是更换推理采样路径，复用噪声预测器。"], [])
        ],
        "source": "论文 §2.3、§3.4。速度示例见主文实机设置。"
    },
    {
        "title": "滚动时域控制与 warm-start",
        "claim": "模型预测较长动作块以保持时间协调，但只执行前缀；新观测到来后再规划，形成闭环。",
        "sections": [
            ("一轮控制怎样运行", [
                "每次控制调用读取最近 T_o 步观测，条件扩散器从噪声动作块生成 T_p 步未来计划。控制器只执行最前面的 T_a 步，然后再次感知、重新生成后续计划。长预测块负责协调动作，短执行段负责及时吸收环境变化。",
                "执行整段计划而不再观察属于开环；每步只预测一个动作又可能缺少跨时刻协调。滚动时域处在两者之间。"
            ], ["rhc"]),
            ("T_o、T_p、T_a 的取舍", [
                "论文常见图像任务配置为 T_o=2、T_p=16；多数任务执行 T_a=8 步，真实 Push-T 使用 6 步。T_a 太短会经常截断动作块、连续性变差；太长会减少重观察频率，遇到新情况反应变慢。论文消融中的多数任务结果支持 8 步左右的取值，但它不是所有机器人的固定常数。",
                "主文/附录若使用不同采样步数或控制配置，需标明任务和设置，不应混为一套通用超参数。"
            ], []),
            ("warm-start 如何使用旧动作", [
                "当预测长度大于执行长度时，上轮计划的尾部尚未执行。论文允许把这段动作移入下一轮的初始化位置，作为 warm-start 初始参考，让新计划不必完全从随机动作块开始。随后仍会根据新观测和去噪过程重新调整。它是初始化策略，不等于原封不动地照搬，也不是已经执行的指令。",
                "论文描述了用未执行动作初始化下一次推理，但具体张量平移和噪声注入实现可能随代码版本或采样器而变；不应把某一种细节说成论文唯一公式。"
            ], []),
            ("自检", ["A_t^K 是机器人要执行的随机动作吗？不是，它是去噪初始化。机器人执行的是生成完成后的动作计划前缀。", "warm-start 的旧尾部会不会自动执行？不会，它只是新一轮采样的初始参考。"], [])
        ],
        "source": "论文 §§2.1、3.4、5.3.4–5.3.5。"
    },
    {
        "title": "实验结果与消融证据",
        "claim": "论文通过基准、真实机器人与期刊双臂扩展评估方法；结果应按各自的比较口径解读。",
        "sections": [
            ("46.9% 的正确读法", [
                "论文汇总 4 个基准、15 项任务，报告相对最佳基线的平均提升约 46.9%。计算先逐任务比较，再对任务平均。它不是成功率统一增加 46.9 个百分点，也不能推出每一个新任务都会提升同样幅度。结果具有明显任务差异。"
            ], ["relative_improvement"]),
            ("真实 UR5 Push-T 与双臂扩展", [
                "UR5 Push-T 使用 136 条演示、20 次评测；成功率 95%，IoU 为 0.80，演示均值为 0.84。IBC 成功率为 0%，LSTM-GMM 为 20%。IoU 是交并比，比较机器人最终推动结果与目标区域的重合程度。",
                "期刊扩展加入双臂 Egg Beater、Mat Unrolling 和 Shirt Folding，报告成功率分别为 55%、75%、75%。它们补充了框架在双臂任务中的证据，但样本和任务范围并不等于普遍泛化证明。"
            ], []),
            ("消融实验是什么", [
                "消融实验是在整体方法中有控制地改变一个设计因素，观察性能如何变化，用来判断该因素在给定设置下是否重要。例如改变 T_a，可以观察执行长度对动作连续性和反馈速度的影响。消融说明特定因素与结果的关系，不代表单因素能解释所有任务表现。",
                "Figure 3 的 rollout 可帮助理解多峰轨迹：Diffusion Policy 的一次样本倾向于保持一个完整模式；但定性轨迹不是成功保证，每次生成和每个初始状态仍可能失败。"
            ], []),
            ("怎样严谨地表达实验结论", [
                "先说任务、数据和评测协议，再说指标和比较基线，最后补充适用范围。20 次实机评测得到的 95% 是该实验条件下观察到的成功率；它不能证明策略对未见物体、相机变化或危险场景均可靠。"
            ], []),
            ("自检", ["46.9% 是百分点还是相对提升？是逐任务相对提升再平均。", "高成功率是否等于安全保证？不是，安全保护需要独立的限位、避障和急停机制。"], [])
        ],
        "source": "论文 §§4–7、Figure 3、Tables 1–4、6、附录 C。"
    },
    {
        "title": "结论、适用边界与复现顺序",
        "claim": "扩散是动作分布建模工具，实际效果由动作表示、视觉条件、采样器和闭环控制共同决定。",
        "sections": [
            ("把全篇压缩成一条数据流", [
                "演示数据提供 (O_t,A_t^0)。观测经视觉编码和状态融合形成条件；动作块经前向加噪形成 A_t^k；去噪器在观察条件下预测 ε；采样器据此反复生成较干净动作；控制器执行前缀、采集新观测，再启动下一轮规划。"
            ], ["pipeline"]),
            ("论文支持什么，不支持什么", [
                "论文实验支持该方法在所测任务和控制协议下可以表达多峰动作，并取得较强的模拟与实机表现。不能据此推断它能自动处理演示未覆盖的恢复状态、任意相机/光照/物体变化，或保证机器人安全。它仍是行为克隆，也有迭代采样的推理成本。",
                "生成动作看起来平滑或合理，不等于满足机械限位、无碰撞或安全停止条件。真实部署仍需独立安全控制层。"
            ], []),
            ("复现时按依赖顺序排查", [
                "第一步核对动作的维度、坐标系、位置/旋转表示和归一化；如果动作定义错了，后面的噪声目标也会跟着错。第二步核对多视角数据、视觉特征和噪声监督是否正确连通。第三步核对采样器、DDIM 步数、硬件延迟。最后在闭环下调整 T_o、T_p、T_a、warm-start 和机器人接口。速度结果应连同推理步数及硬件报告。"
            ], []),
            ("两分钟口头复述", [
                "Diffusion Policy 是一种从专家演示学习的视觉行为克隆方法。它把未来动作块作为生成对象，用高斯加噪构造已知噪声监督；网络预测噪声，在观测条件下逐步去噪，因而能表达同一观测下多个连贯动作方案。推理时可用 DDIM 减少迭代，并采用滚动时域只执行计划前缀、持续重规划。基准与真实机器人实验支持其在论文设置下有效，但示范覆盖、推理延迟、分布外泛化和安全仍是边界。"
            ], []),
            ("学习材料索引", [
                "本复习文档综合了论文正文与附录、最终 10 页汇报稿，以及此前整理的符号与公式卡、高频疑问索引、论文复述与自测和 DDPM / Diffusion Policy 分节问答。再次复习时可按页序读本手册，用演讲稿做 10 分钟口头回忆，再用每节末尾的自检题查缺补漏。"
            ], [])
        ],
        "source": "论文 §§8–10；此前学习文档与问答汇总。"
    }
]


FORMULAS = {
    "mse_point": r"\hat a=\arg\min_{a}\,\mathbb{E}_{a^*\sim p(\cdot\mid O)}\left[\|a-a^*\|_2^2\right]=\mathbb{E}[a^*\mid O]",
    "energy_score": r"p(a\mid O)=\frac{\exp[-E(O,a)]}{Z(O)},\qquad \nabla_a\log p(a\mid O)=-\nabla_aE(O,a)",
    "forward": r"A_t^k=\sqrt{\bar{\alpha}_k}\,A_t^0+\sqrt{1-\bar{\alpha}_k}\,\epsilon,\qquad \epsilon\sim\mathcal{N}(0,I)",
    "variance_scale": r"\operatorname{Var}(cX)=c^2\operatorname{Var}(X)\quad\Longrightarrow\quad \text{振幅系数}=\sqrt{\text{方差比例}}",
    "noise_loss": r"\mathcal{L}_{\mathrm{noise}}=\mathbb{E}_{O_t,A_t^0,k,\epsilon}\left[\left\|\epsilon-\epsilon_\theta(O_t,A_t^k,k)\right\|_2^2\right]",
    "posterior": r"q(A_t^{k-1}\mid A_t^k,A_t^0)=\mathcal{N}(\tilde{\mu}_k,\tilde{\beta}_kI)",
    "beta_tilde": r"\tilde{\beta}_k=\frac{1-\bar{\alpha}_{k-1}}{1-\bar{\alpha}_k}\,\beta_k,\qquad \beta_k=1-\alpha_k",
    "mu_tilde": r"\tilde{\mu}_k=\frac{\sqrt{\bar{\alpha}_{k-1}}\beta_k}{1-\bar{\alpha}_k}A_t^0+\frac{\sqrt{\alpha_k}(1-\bar{\alpha}_{k-1})}{1-\bar{\alpha}_k}A_t^k",
    "x0hat": r"\hat{A}_t^0=\frac{A_t^k-\sqrt{1-\bar{\alpha}_k}\,\epsilon_\theta(O_t,A_t^k,k)}{\sqrt{\bar{\alpha}_k}}",
    "mu_theta": r"\mu_\theta=\frac{1}{\sqrt{\alpha_k}}\left(A_t^k-\frac{\beta_k}{\sqrt{1-\bar{\alpha}_k}}\epsilon_\theta(O_t,A_t^k,k)\right)",
    "sample_standard": r"A_t^{k-1}=\mu_\theta+\sigma_kz,\qquad z\sim\mathcal{N}(0,I),\qquad \sigma_k^2=\tilde{\beta}_k\;\;\text{(fixed-small)}",
    "score": r"\hat{s}_\theta(A_t^k,O_t,k)\approx-\frac{\epsilon_\theta(O_t,A_t^k,k)}{\sqrt{1-\bar{\alpha}_k}}\approx\nabla_{A_t^k}\log p_k(A_t^k\mid O_t)",
    "langevin": r"A_t^{k-1}=\alpha_k\left[A_t^k-\gamma_k\epsilon_\theta(O_t,A_t^k,k)+\sigma_kz\right]",
    "ddim_jump": r"\hat{A}_t^0=\frac{A_t^k-\sqrt{1-\bar{\alpha}_k}\hat{\epsilon}_k}{\sqrt{\bar{\alpha}_k}},\qquad A_t^j=\sqrt{\bar{\alpha}_j}\hat{A}_t^0+\sqrt{1-\bar{\alpha}_j}\hat{\epsilon}_k,\quad j<k",
    "rhc": r"\underbrace{\text{生成 }T_p\text{ 步}}_{\text{计划}}\;\longrightarrow\;\underbrace{\text{执行前 }T_a\text{ 步}}_{\text{控制}}\;\longrightarrow\;\text{新观测 }O_{t+T_a}\;\longrightarrow\;\text{重新规划}",
    "relative_improvement": r"\text{平均相对提升}=\frac{1}{N}\sum_{i=1}^{N}\frac{\text{DP}_i-\text{最佳基线}_i}{\text{最佳基线}_i}\approx46.9\%",
    "pipeline": r"(O_t,A_t^0)\;\longrightarrow\;\text{动作加噪 }A_t^k\;\longrightarrow\;\epsilon_\theta\text{ 预测}\;\longrightarrow\;\text{逐步去噪}\;\longrightarrow\;\text{执行前缀}\;\longrightarrow\;O_{t+T_a}",
}


def create_speech():
    doc = setup_doc(
        "Diffusion Policy 论文汇报演讲稿",
        "10 分钟逐页口述稿 对应 10 页汇报 PPT 面向导师组会汇报",
        "SPEAKING SCRIPT",
    )
    add_body(doc, "汇报主线：先说明单步回归为什么难以处理多种有效动作，再解释条件扩散如何训练和采样，最后把生成计划放回闭环控制，并用实验与边界收束。讲稿按正常语速设计，公式页预留指图和停顿时间。")
    add_timing_table(doc, [(str(i + 1), item[0], item[1]) for i, item in enumerate(SPEECH)])
    add_label_paragraph(doc, "开场前记住：", "每页只讲一个因果环节；第 6 页公式最多停留在“后验—估计干净动作—得到均值—采样”四步。")
    for i, (title, duration, speech, transition, prompt) in enumerate(SPEECH):
        doc.add_page_break()
        add_page_heading(doc, i + 1, title, duration)
        h = doc.add_paragraph(style="Heading 2")
        set_font(h.add_run("口述稿"), size=12.5, bold=True, color="000000")
        p = add_body(doc, speech)
        p.paragraph_format.line_spacing = 1.25
        p.paragraph_format.space_after = Pt(12)
        if transition:
            add_label_paragraph(doc, "承接下一页：", transition, italic=True)
        if prompt:
            add_label_paragraph(doc, "讲述提示：", prompt)
    add_body(doc, "论文依据：Chi et al., “Diffusion Policy: Visuomotor Policy Learning via Action Diffusion,” The International Journal of Robotics Research, 44(10–11), 1684–1704, 2025；最终汇报 PPT 的页序、图表和备注。")
    OUT.mkdir(parents=True, exist_ok=True)
    path = OUT / "diffusion_policy_10min_speech_script.docx"
    doc.save(path)
    return path


def add_review_chapter(doc, index, chapter):
    p = doc.add_paragraph(style="Heading 1")
    p.paragraph_format.page_break_before = True
    set_font(p.add_run(f"第 {index} 页  {chapter['title']}"), size=16, bold=True, color="000000")
    add_label_paragraph(doc, "本页结论：", chapter["claim"])
    for heading, paragraphs, formulas in chapter["sections"]:
        h = doc.add_paragraph(style="Heading 2")
        set_font(h.add_run(heading), size=12.5, bold=True, color="000000")
        for text in paragraphs:
            add_body(doc, text)
        for formula in formulas:
            add_equation(doc, formula)
    if index not in (4, 5):
        p = doc.add_paragraph()
        p.paragraph_format.keep_together = True
        p.paragraph_format.space_before = Pt(1)
        p.paragraph_format.space_after = Pt(0)
        set_font(p.add_run("论文定位："), size=9.5, bold=True, color="646A70")
        set_font(p.add_run(normalize_notation(chapter["source"])), size=9.5, color="646A70")


def create_review():
    doc = setup_doc(
        "Diffusion Policy 逐页知识回顾",
        "对应 10 页汇报 PPT 从问题定义到反向采样 闭环控制与实验边界",
        "KNOWLEDGE REVIEW",
    )
    add_body(doc, "这份手册按汇报页序复习论文。它不要求先记住全部公式，而是先确认每个变量属于哪个阶段，再追问公式从哪里来、它在系统中负责什么。建议先独立口述每节的“本页结论”，遇到公式再读推导说明；最后用自检题快速查漏。")
    add_label_paragraph(doc, "全篇一句话：", "在视觉与机器人状态条件下，用已知噪声监督学习动作块去噪，再通过部分执行和重新观测形成闭环策略。")
    add_label_paragraph(doc, "三个时间尺度：", "机器人控制时刻 t；动作扩散内部等级 k；观测历史、动作预测和实际执行长度 T_o、T_p、T_a。k 不是机器人执行了第几步。")
    add_label_paragraph(doc, "两个常见 MSE：", "直接动作回归 MSE 可能平均多种有效动作；扩散噪声 MSE 预测实际加入的 ε，训练对象不同。")
    add_label_paragraph(doc, "符号先看角色：", "O_t 是已知条件；A_t^0 是专家未来动作块；A_t^k 是其带噪版本；ε 是训练时注入的目标噪声；ε_θ 是网络预测；z 是推理时新抽取的噪声。")

    for index, chapter in enumerate(REVIEW, start=1):
        add_review_chapter(doc, index, chapter)

    p = doc.add_paragraph(style="Heading 1")
    p.paragraph_format.page_break_before = True
    set_font(p.add_run("公式与概念快速核对"), size=16, bold=True, color="000000")
    add_body(doc, "复习时把同一类变量放在一起，不要只背孤立公式。下表可作为上台前的最后检查。")
    quick = [
        ("ε", "训练前向过程实际抽取并加入的噪声，也是监督目标", "与动作块同形；训练时已知"),
        ("ε_θ", "去噪网络的噪声预测", "推理时根据它计算去噪/score 方向"),
        ("z", "反向高斯采样每一步重新抽取的噪声", "同样服从标准高斯，但不是训练的 ε"),
        ("β̃_k", "标准 DDPM 后验方差", "fixed-small 下 σ_k=√β̃_k"),
        ("σ_k", "高斯标准差或论文采样日程系数", "要说明属于哪一种反向参数化"),
        ("∇_A log p", "动作分布 score", "对动作求导，表示高密度方向"),
        ("∇_θ L", "训练损失对网络参数的梯度", "用于反向传播和参数更新"),
        ("t / k", "t 是机器人控制时刻；k 是扩散级", "一个策略调用内部 k 变化；执行后 t 推进"),
        ("T_o / T_p / T_a", "观测历史 / 预测动作长度 / 执行前缀长度", "是控制时域，不是扩散步数"),
        ("46.9%", "跨 15 项任务逐任务相对提升后取平均", "不是成功率提高 46.9 个百分点"),
    ]
    table = doc.add_table(rows=1, cols=3)
    table.autofit = False
    widths = [Inches(1.15), Inches(3.1), Inches(2.65)]
    for i, width in enumerate(widths):
        table.columns[i].width = width
    for i, text in enumerate(("符号", "含义", "易混点")):
        cell = table.rows[0].cells[i]
        cell.width = widths[i]
        cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
        set_cell_margins(cell)
        set_cell_shading(cell, "41474D")
        set_font(cell.paragraphs[0].add_run(text), size=9.3, bold=True, color="FFFFFF")
    set_repeat_table_header(table.rows[0])
    for ix, row in enumerate(quick):
        cells = table.add_row().cells
        for i, text in enumerate(row):
            cells[i].width = widths[i]
            cells[i].vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            set_cell_margins(cells[i], top=80, bottom=80)
            if ix % 2:
                set_cell_shading(cells[i], "F3F5F6")
            set_font(cells[i].paragraphs[0].add_run(normalize_notation(text)), size=8.8, bold=(i == 0), color="252A31")
    set_table_borders(table)

    doc.add_paragraph()
    p = doc.add_paragraph(style="Heading 2")
    set_font(p.add_run("建议复习顺序"), size=12.5, bold=True, color="000000")
    for line in [
        "第一遍：只看每页的“本页结论”，尝试不用公式讲完整条逻辑。",
        "第二遍：重点读第 5–7 页，画出训练加噪、标准 DDPM 反向、论文 Langevin 更新和 DDIM 跳步之间的区别。",
        "第三遍：读第 4、8、9、10 页，把视觉编码器、闭环控制、数据口径和安全边界接回方法主线。",
        "最后：用演讲稿限时复述；凡是卡住的地方，先判断属于变量、阶段、公式来源还是实验口径。"
    ]:
        add_body(doc, line)

    OUT.mkdir(parents=True, exist_ok=True)
    path = OUT / "diffusion_policy_slide_knowledge_review.docx"
    doc.save(path)
    return path


if __name__ == "__main__":
    speech = create_speech()
    review = create_review()
    print(speech)
    print(review)
