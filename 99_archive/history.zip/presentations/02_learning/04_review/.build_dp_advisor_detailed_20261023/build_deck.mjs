import fs from "node:fs/promises";
import path from "node:path";
import { pathToFileURL } from "node:url";
import { FileBlob, Presentation, PresentationFile } from "@oai/artifact-tool";

const ROOT = "G:/毕设";
const BUILD = "G:/毕设/02_learning/04_review/.build_dp_advisor_detailed_20261023";
const OUT = "G:/毕设/02_learning/04_review";
const FINAL_PPTX = path.join(OUT, "diffusion_policy_advisor_report_detailed_v6.pptx");
const SOURCE_DECK = "H:/Download/Diffusion Policy 论文组会汇报.pptx";
const SKILL_DIR = "C:/Users/laiyo/.codex/plugins/cache/openai-primary-runtime/presentations/26.1022.11436/skills/Presentations";
const PYTHON = "C:/Users/laiyo/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe";
const COLORS = {
  bg: "#F5F3F0",
  ink: "#252A31",
  muted: "#646A70",
  wine: "#78394C",
  gold: "#B58A4A",
  sage: "#78827B",
  line: "#D5D0C9",
  white: "#FFFEFC",
  paleWine: "#EEE4E6",
  paleGold: "#F1EBDD",
  paleSage: "#E7EBE7",
};
const FONT = "Microsoft YaHei";
const MATH = "Cambria Math";
const W = 1280;
const H = 720;

function text(slide, value, x, y, w, h, options = {}) {
  const shape = slide.shapes.add({
    geometry: "textbox",
    name: options.name ?? "editable-text",
    position: { left: x, top: y, width: w, height: h },
    fill: "none",
    line: { style: "solid", fill: "none", width: 0 },
  });
  shape.text = value;
  shape.text.style = {
    typeface: options.font ?? FONT,
    fontSize: options.size ?? 20,
    color: options.color ?? COLORS.ink,
    bold: options.bold ?? false,
    alignment: options.align ?? "left",
    verticalAlignment: options.valign ?? "middle",
    wrap: "square",
    autoFit: "shrinkText",
    insets: 0,
  };
  return shape;
}

function box(slide, x, y, w, h, fill, line = "none", radius = false) {
  return slide.shapes.add({
    geometry: radius ? "roundRect" : "rect",
    position: { left: x, top: y, width: w, height: h },
    fill,
    line: { style: "solid", fill: line, width: line === "none" ? 0 : 1 },
  });
}

function rule(slide, x, y, w, color = COLORS.line, thickness = 1.4) {
  box(slide, x, y, w, thickness, color);
}

function header(slide, title, page, source) {
  slide.background.fill = COLORS.bg;
  text(slide, title, 64, 30, 1152, 58, { size: 36, bold: true });
  rule(slide, 64, 104, 1152, COLORS.line, 1.5);
  rule(slide, 64, 104, 82, COLORS.wine, 3);
  rule(slide, 64, 668, 1152, COLORS.line, 1);
  text(slide, source, 64, 676, 1080, 22, { size: 13, color: COLORS.muted });
  text(slide, String(page).padStart(2, "0") + " / 11", 1152, 676, 64, 22, {
    size: 13,
    color: COLORS.muted,
    align: "right",
  });
}

function addImage(slide, sourceDeck, imageId, alt, x, y, w, h) {
  const image = sourceDeck.resolve(imageId);
  const bytes = image.bytes;
  const blob = bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength);
  slide.images.add({
    blob,
    contentType: image.contentType ?? "image/png",
    alt,
    fit: "contain",
    position: { left: x, top: y, width: w, height: h },
  });
}

function notes(slide, speech, source) {
  slide.speakerNotes.text = speech + "\n\n论文来源：" + source;
  slide.speakerNotes.setVisible(true);
}

function newSlide(presentation, title, page, source) {
  const s = presentation.slides.add();
  header(s, title, page, source);
  return s;
}

async function writeBlob(filePath, blob) {
  await fs.writeFile(filePath, new Uint8Array(await blob.arrayBuffer()));
}

async function main() {
  await fs.mkdir(BUILD, { recursive: true });
  await fs.mkdir(OUT, { recursive: true });
  const paperDeck = await PresentationFile.importPptx(await FileBlob.load(SOURCE_DECK));
  const presentation = Presentation.create({ slideSize: { width: W, height: H } });

  // 1. Cover: identify the paper and the through-line of the report.
  {
    const s = presentation.slides.add();
    s.background.fill = COLORS.bg;
    box(s, 72, 176, 7, 270, COLORS.wine);
    text(s, "论文汇报  /  ROBOT LEARNING", 108, 168, 870, 34, {
      size: 17, color: COLORS.wine, bold: true,
    });
    text(s, "Diffusion Policy", 104, 214, 1010, 90, { size: 68, bold: true });
    text(s, "Visuomotor Policy Learning via Action Diffusion", 108, 310, 1080, 42, {
      size: 27, font: MATH,
    });
    text(s, "面向视觉操作的动作扩散策略", 108, 360, 950, 42, {
      size: 25, color: COLORS.muted,
    });
    rule(s, 108, 430, 730, COLORS.line, 1.5);
    text(
      s,
      "核心问题：给定视觉与机器人状态，如何生成一段可执行、连贯且能响应新观测的动作计划？",
      108, 456, 1030, 78, { size: 24, bold: true },
    );
    text(s, "从 DDPM 的噪声预测，到条件动作生成与滚动时域控制", 108, 555, 900, 34, {
      size: 19, color: COLORS.sage,
    });
    text(
      s,
      "Cheng Chi et al. · RSS 2023 / IJRR 44(10–11), 2025（期刊版）",
      108, 620, 1030, 28, { size: 15, color: COLORS.muted },
    );
    text(s, "10 分钟论文汇报", 108, 650, 400, 24, { size: 14, color: COLORS.sage });
    notes(
      s,
      "汇报围绕一个问题展开：机器人看到当前场景后，怎样生成一段连贯、可执行、又能随新观测调整的动作计划？论文把条件扩散模型用于动作序列，而不只是把图像生成方法换个输入。接下来先从行为克隆里的多解问题出发，再回顾 DDPM 的训练和反向过程，最后看论文如何把它接入闭环机器人控制，以及实验到底支持什么结论。",
      "Chi et al., IJRR 2025, 44(10–11):1684–1704；Special Issue: RSS 2023。",
    );
  }

  // 2. Why a single deterministic action can fail.
  {
    const source = "Chi et al., IJRR 2025, §4.1, Figure 3, p. 1688.";
    const s = newSlide(presentation, "同一观测可能对应多个有效动作方案", 2, source);
    text(s, "多峰不是“随机乱动”，而是同一任务存在多条都能成功的路线。", 66, 126, 1145, 36, {
      size: 22, color: COLORS.wine, bold: true,
    });
    addImage(s, paperDeck, "im/6xgry54n", "Push-T 多模态行为对比：不同策略产生的机械臂轨迹", 66, 177, 635, 218);
    text(s, "Push-T：从 T 形块左侧或右侧接近，都可能完成推动。", 70, 401, 628, 27, {
      size: 15, color: COLORS.muted,
    });
    text(s, "单步回归的两个难点", 748, 178, 440, 34, { size: 22, bold: true });
    text(s, "1  平均值可能无效", 748, 228, 435, 30, { size: 19, color: COLORS.wine, bold: true });
    text(s, "MSE 学到条件均值；左绕和右绕的平均位置，可能落在障碍物上或低概率区域。", 748, 260, 435, 68, {
      size: 17, color: COLORS.muted, valign: "top",
    });
    text(s, "2  逐时刻预测可能切换模式", 748, 344, 435, 30, { size: 19, color: COLORS.wine, bold: true });
    text(s, "若每个时刻独立选路线，前一步左绕、后一步右绕，整段动作会抖动。", 748, 377, 435, 62, {
      size: 17, color: COLORS.muted, valign: "top",
    });
    rule(s, 66, 474, 1148, COLORS.line, 1);
    text(s, "建模对象", 70, 495, 140, 30, { size: 18, color: COLORS.gold, bold: true });
    text(s, "不是单个动作 aₜ，而是给定观测后的未来动作序列分布  p(Aₜ | Oₜ)。", 214, 490, 970, 42, {
      size: 23, bold: true,
    });
    text(s, "这同时要求策略保留多种解，并把一次采样得到的整段动作保持在同一行为模式内。", 214, 538, 970, 50, {
      size: 18, color: COLORS.muted,
    });
    notes(
      s,
      "Push-T 图示展示了同一初始观测下的多种合理操作方式，例如从 T 形块不同侧面接近。这里的多模态不是随机动作，而是条件动作分布有多个高概率区域。如果模型只回归一个动作并用均方误差训练，它倾向于拟合平均值；两条有效路线的平均点未必也是有效路线。即使使用多模态策略，若把每个时刻独立生成，也可能在相邻时刻切换模式，形成抖动。论文因此不是只问“下一步做什么”，而是把未来一段动作作为联合生成对象。",
      source,
    );
  }

  // 3. Position the paper among policy representations.
  {
    const source = "Chi et al., IJRR 2025, Figure 1 and §§1–2, pp. 1685–1686.";
    const s = newSlide(presentation, "策略表示：显式回归、能量模型与扩散生成", 3, source);
    addImage(s, paperDeck, "im/q1sbal07", "论文 Figure 1：显式、隐式能量和扩散策略表示对比", 82, 128, 1115, 254);
    // The source slide crops the original figure caption; mask the partial caption while preserving the panels.
    box(s, 82, 364, 1115, 20, COLORS.white);
    const x = [76, 463, 850];
    const titles = ["显式策略", "隐式能量策略", "Diffusion Policy"];
    const desc = [
      "直接从 O 预测 A。实现简单；若以单一输出拟合多解，容易把模式压成平均动作。",
      "p(A|O) ∝ exp(−E(O,A))。可表示复杂分布，但归一化常数 Z(O) 难算，训练常依赖负样本。",
      "学习带噪动作分布的 score 方向；从噪声初始化，按方向迭代采样，不显式计算 Z。",
    ];
    const tags = ["一次预测", "给动作打分", "预测噪声并逐步修正"];
    for (let i = 0; i < 3; i++) {
      if (i > 0) box(s, x[i] - 22, 410, 1.2, 144, COLORS.line);
      text(s, titles[i], x[i], 406, 330, 32, { size: 21, bold: true, color: i === 2 ? COLORS.wine : COLORS.ink });
      text(s, desc[i], x[i], 445, 330, 74, { size: 16, color: COLORS.muted, valign: "top" });
      text(s, tags[i], x[i], 535, 330, 28, { size: 15, color: i === 2 ? COLORS.wine : COLORS.gold, bold: true });
    }
    rule(s, 76, 585, 1120, COLORS.line, 1);
    text(s, "本文主线仍是行为克隆：动作监督来自专家演示，不依赖在线奖励或环境试错。", 78, 599, 1110, 36, {
      size: 18, bold: true,
    });
    notes(
      s,
      "论文 Figure 1 将策略表示分为三类。显式策略直接输出动作，推理简单，但确定性回归不擅长表达多个有效解。隐式能量策略对观测和候选动作评分，概率与能量满足 p(A|O) 正比于 exp(−E)，但要处理连续动作上的归一化常数 Z，实践中常用负样本近似。Diffusion Policy 不直接给动作打一个总分，而是在带噪动作上预测去噪方向；反复更新就能从多个可能的初始噪声中采出不同动作方案。要注意，论文主实验是行为克隆，训练信号来自专家演示，不是强化学习奖励。",
      source,
    );
  }

  // 4. Inputs, action chunk and network design.
  {
    const source = "Chi et al., IJRR 2025, Figure 2, §§2.3, 3.1–3.2, pp. 1686–1688.";
    const s = newSlide(presentation, "模型结构：观测作条件，动作序列作生成对象", 4, source);
    text(s, "输入", 76, 128, 200, 26, { size: 16, color: COLORS.gold, bold: true });
    box(s, 76, 161, 218, 72, COLORS.white, COLORS.line, true);
    text(s, "多视角相机图像\n最近 Tₒ 帧", 90, 170, 190, 54, { size: 17, align: "center" });
    box(s, 76, 258, 218, 62, COLORS.white, COLORS.line, true);
    text(s, "机器人本体状态\n末端位姿、夹爪等", 90, 263, 190, 52, { size: 15, align: "center", color: COLORS.muted });
    text(s, "→", 298, 179, 30, 30, { size: 22, color: COLORS.wine, align: "center" });
    text(s, "→", 298, 273, 30, 30, { size: 22, color: COLORS.wine, align: "center" });
    text(s, "特征提取与融合", 338, 128, 246, 26, { size: 16, color: COLORS.gold, bold: true });
    box(s, 338, 161, 250, 72, COLORS.white, COLORS.line, true);
    text(s, "ResNet-18 + Spatial Softmax\n逐视角提取视觉特征", 350, 169, 226, 54, { size: 16, align: "center" });
    box(s, 338, 258, 250, 62, COLORS.white, COLORS.line, true);
    text(s, "状态特征与视觉特征融合", 350, 272, 226, 34, { size: 15, align: "center", color: COLORS.muted });
    text(s, "→", 590, 211, 28, 30, { size: 22, color: COLORS.wine, align: "center" });
    text(s, "条件 Oₜ", 624, 128, 210, 26, { size: 16, color: COLORS.gold, bold: true });
    box(s, 624, 161, 220, 72, COLORS.paleSage, "none", true);
    text(s, "多视角 + 本体状态\n条件特征 Oₜ", 636, 172, 196, 50, { size: 17, bold: true, align: "center", color: COLORS.sage });
    box(s, 624, 258, 220, 62, COLORS.paleWine, "none", true);
    text(s, "带噪动作块 Aₜᵏ + 扩散级 k", 636, 270, 196, 37, { size: 15, bold: true, align: "center", color: COLORS.wine });
    text(s, "→", 846, 179, 30, 30, { size: 22, color: COLORS.wine, align: "center" });
    text(s, "条件去噪网络", 882, 128, 294, 26, { size: 16, color: COLORS.gold, bold: true });
    box(s, 882, 161, 294, 159, COLORS.white, COLORS.line, true);
    text(s, "εθ(Oₜ, Aₜᵏ, k)\n预测加入的噪声 ε̂\n\nCNN + FiLM  /  Transformer + cross-attention", 898, 172, 262, 137, {
      size: 17, align: "center",
    });
    rule(s, 76, 353, 1128, COLORS.line, 1);
    text(s, "网络实现", 78, 374, 165, 27, { size: 17, color: COLORS.gold, bold: true });
    text(s, "CNN：1D 时序 U-Net，以 FiLM 注入条件。", 246, 372, 430, 31, { size: 16, color: COLORS.ink });
    text(s, "Transformer：动作因果自注意力；观测经 cross-attention 提供上下文。", 680, 372, 512, 31, {
      size: 15, color: COLORS.ink,
    });
    rule(s, 78, 422, 1120, COLORS.line, 1);
    text(s, "建模边界", 78, 443, 165, 27, { size: 17, color: COLORS.gold, bold: true });
    text(s, "动作序列是唯一被扩散的对象；视觉与本体状态作为条件输入。一次生成整段动作，使时间结构参与联合建模。", 246, 437, 945, 49, {
      size: 16, color: COLORS.muted,
    });
    notes(
      s,
      "这一页先把策略的接口和网络结构定下来：输入是最近几帧图像与机器人状态，输出是一个未来动作块。图像与状态组成观测条件，扩散只作用于动作。CNN 方案用 FiLM 将条件注入 1D 时序 U-Net；Transformer 方案让动作 token 做因果自注意力，并通过 cross-attention 读取观测。一次生成整段动作有利于把时间结构纳入联合建模。下一页专门展开视觉编码器如何形成条件特征，以及动作噪声损失怎样训练它。",
      source,
    );
  }

  // 5. Vision encoder: representation, supervision path and inference use.
  {
    const source = "Chi et al., IJRR 2025, §3.2, pp. 1687–1688; official implementation: diffusion_unet_hybrid_image_policy.py and multi_image_obs_encoder.py.";
    const s = newSlide(presentation, "视觉编码器：从像素到动作条件", 5, source);
    text(s, "图像端不需要“杯子/机械臂”类别标签；它学习的是有助于预测演示动作的视觉表征。", 72, 126, 1128, 34, {
      size: 19, color: COLORS.wine, bold: true,
    });

    text(s, "视觉观测", 76, 181, 190, 28, { size: 17, color: COLORS.gold, bold: true });
    text(s, "每个视角、每帧", 76, 218, 205, 25, { size: 15, color: COLORS.muted });
    text(s, "Iₜ,ᵥ ∈ R³ˣᴴˣᵂ", 76, 249, 205, 37, { size: 23, font: MATH, bold: true });

    text(s, "ResNet-18", 318, 181, 210, 28, { size: 17, color: COLORS.gold, bold: true });
    text(s, "卷积层形成特征图", 318, 218, 224, 25, { size: 15, color: COLORS.muted });
    text(s, "Fₜ,ᵥ ∈ Rᶜˣʰˣʷ", 318, 249, 224, 37, { size: 22, font: MATH, bold: true });

    text(s, "Spatial Softmax", 578, 181, 220, 28, { size: 17, color: COLORS.gold, bold: true });
    text(s, "把空间响应压成位置特征", 578, 218, 230, 25, { size: 15, color: COLORS.muted });
    text(s, "fₜ,ᵥ = [(x₁,y₁), …]", 578, 249, 240, 37, { size: 21, font: MATH, bold: true });

    text(s, "按特征维拼接", 862, 181, 220, 28, { size: 17, color: COLORS.gold, bold: true });
    text(s, "多相机特征 + 机器人状态", 862, 218, 270, 25, { size: 15, color: COLORS.muted });
    text(s, "oₜ = [f₁; …; fᵥ; sₜ]", 862, 249, 300, 37, { size: 21, font: MATH, bold: true, color: COLORS.wine });

    text(s, "→", 267, 246, 44, 32, { size: 23, color: COLORS.wine, align: "center" });
    text(s, "→", 542, 246, 32, 32, { size: 23, color: COLORS.wine, align: "center" });
    text(s, "→", 814, 246, 42, 32, { size: 23, color: COLORS.wine, align: "center" });
    rule(s, 76, 307, 1128, COLORS.line, 1.2);

    text(s, "训练：动作噪声误差也训练视觉编码器", 76, 329, 570, 30, { size: 19, bold: true });
    text(s, "Aₜᵏ = √ᾱₖ Aₜ⁰ + √(1−ᾱₖ) ε", 76, 372, 560, 39, { size: 22, font: MATH, color: COLORS.ink });
    text(s, "ε̂ = εθ(oₜ, Aₜᵏ, k)     L = ‖ε − ε̂‖²", 76, 416, 590, 40, { size: 21, font: MATH, color: COLORS.wine, bold: true });
    text(s, "在全局条件实现中，L 的梯度经过去噪网络与 oₜ 回到视觉参数 φ。演示动作提供监督，不需要物体名称标签。", 76, 467, 586, 73, {
      size: 16, color: COLORS.muted, valign: "top",
    });
    text(s, "∂L / ∂φ", 76, 548, 190, 32, { size: 20, font: MATH, color: COLORS.wine, bold: true });
    text(s, "计算图保留梯度路径，参数由优化器更新。", 246, 550, 415, 29, { size: 15, color: COLORS.muted });

    box(s, 696, 329, 1, 247, COLORS.line);
    text(s, "推理：把训练好的特征用于每轮规划", 728, 329, 474, 30, { size: 19, bold: true });
    text(s, "当前图像 + 状态  →  oₜ  →  每一步动作去噪", 728, 374, 470, 47, { size: 18, font: MATH, color: COLORS.ink });
    text(s, "同一次采样中观测条件保持不变；执行动作块前缀后，机器人获得新观测，再编码并重新规划。", 728, 431, 468, 64, {
      size: 16, color: COLORS.muted, valign: "top",
    });
    text(s, "实现细节：GroupNorm 不依赖跨批次运行统计，更容易与 EMA 平滑参数配合。", 728, 513, 468, 52, {
      size: 15, color: COLORS.sage, bold: true, valign: "top",
    });
    text(s, "Spatial Softmax：pᵢⱼ = softmax(Fᵢⱼ)，(x̄,ȳ) = Σᵢⱼ pᵢⱼ (xⱼ,yᵢ)，保留特征响应的位置。", 76, 604, 1125, 27, {
      size: 15, color: COLORS.sage, bold: true,
    });
    notes(
      s,
      "这里回应两个容易混淆的问题：视觉网络怎样知道图里有什么，以及它是否参与训练。先看输入：每个相机视角的一帧是一个三通道图像张量。ResNet-18 的卷积层把像素逐层变成特征图；可以把它理解为从局部边缘、纹理和形状，到物体与机械臂相对位置等任务相关线索的数值表示。Spatial Softmax 对特征图的空间响应做归一化，并用加权位置形成坐标特征，保留‘哪里有响应’的信息；它不是输出‘这是杯子’这样的类别。多视角特征与机器人位姿、夹爪等本体状态沿特征维拼接，不是把像素加在一起；最近 T_o 帧形成时序条件。训练时，专家动作块先加已知高斯噪声，去噪网络根据条件预测这份噪声，MSE 衡量预测误差。在论文采用的全局条件路径和对应实现中，视觉编码器是可训练子模块，损失可以反向传播到编码器参数 φ，所以编码器不是固定的图像预处理器。它学到的标准是能否帮助预测演示动作，而不是物体分类准确率。推理时使用学好的参数，把当前观测编码成条件并送入每个反向去噪步骤；一次采样内条件固定，执行动作前缀之后，新的相机和机器人状态会触发重新编码和规划。实现中把视觉编码放在采样循环之前。论文还将视觉网络里的 BatchNorm 改为 GroupNorm，避免运行均值、方差与 EMA 平滑参数对应不齐。",
      source,
    );
  }

  // 6. Forward noising and noise-prediction training.
  {
    const source = "Chi et al., IJRR 2025, Eqs. (3), (5), §§2.2–2.3, 3.3, pp. 1686–1688.";
    const s = newSlide(presentation, "训练：把 DDPM 的噪声预测迁移到动作序列", 6, source);
    text(s, "标准 DDPM（数据可以是图像）", 74, 132, 510, 28, { size: 18, color: COLORS.muted, bold: true });
    text(s, "xₖ = √ᾱₖ · x₀ + √(1 − ᾱₖ) · ε", 74, 171, 520, 48, {
      size: 28, font: MATH, color: COLORS.ink,
    });
    text(s, "Diffusion Policy（数据换成专家动作块）", 666, 132, 540, 28, {
      size: 18, color: COLORS.wine, bold: true,
    });
    text(s, "Aₜᵏ = √ᾱₖ · Aₜ⁰ + √(1 − ᾱₖ) · ε", 666, 171, 550, 48, {
      size: 28, font: MATH, color: COLORS.wine,
    });
    rule(s, 74, 236, 1130, COLORS.line, 1.2);
    const steps = [
      ["01", "取专家样本", "(Oₜ, Aₜ⁰)"],
      ["02", "抽噪声等级", "k ~ Uniform{1…K}"],
      ["03", "合成带噪动作", "ε ~ N(0,I)，构造 Aₜᵏ"],
      ["04", "预测噪声", "ε̂ = εθ(Oₜ,Aₜᵏ,k)"],
    ];
    const xs = [76, 356, 636, 916];
    for (let i = 0; i < steps.length; i++) {
      text(s, steps[i][0], xs[i], 260, 46, 26, { size: 16, color: COLORS.gold, bold: true, font: MATH });
      text(s, steps[i][1], xs[i], 291, 245, 28, { size: 17, bold: true });
      text(s, steps[i][2], xs[i], 325, 245, 42, { size: 15, color: COLORS.muted });
      if (i < 3) text(s, "→", xs[i] + 244, 296, 32, 28, { size: 21, color: COLORS.wine, align: "center" });
    }
    box(s, 76, 386, 1128, 104, COLORS.white, COLORS.line, true);
    text(s, "训练目标：让预测噪声接近刚才实际加入的噪声", 98, 397, 680, 28, {
      size: 17, color: COLORS.muted,
    });
    text(s, "L = E [ ‖ ε − εθ(Oₜ, Aₜᵏ, k) ‖² ]", 98, 433, 730, 42, {
      size: 27, font: MATH, bold: true,
    });
    text(s, "MSE：逐元素平方后取平均；不是直接回归一个平均动作。", 830, 426, 346, 52, {
      size: 16, color: COLORS.wine, bold: true,
    });
    text(s, "ε 与 Aₜ 同形：预测时长 Tₚ × 动作维度 dₐ。平方根系数控制信号与噪声的幅度；ᾱₖ = ∏ᵢ₌₁ᵏ αᵢ。", 80, 515, 1115, 48, {
      size: 17, color: COLORS.muted,
    });
    text(s, "噪声日程决定不同 k 的信噪比；论文实测采用 iDDPM 的 Square Cosine Schedule。", 80, 570, 1115, 34, {
      size: 16, color: COLORS.sage, bold: true,
    });
    notes(
      s,
      "这一步是从最初学的 DDPM 到 Diffusion Policy 的直接映射。标准 DDPM 把干净数据 x_0 与高斯噪声 ε 按噪声日程混合；Diffusion Policy 将 x_0 换成专家动作块 A_t^0。这里 ε 不是单个数字，而是与动作块同形状的张量，例如预测时长乘每步动作维度。训练随机抽 k 和 ε，用闭式式子合成 A_t^k，然后让网络 εθ(O_t,A_t^k,k) 预测实际加入的 ε。损失是逐元素平方误差的平均，所以正负误差不会抵消。平方根是信号与噪声的幅度系数，控制二者方差比例，不是把动作本身做平方。ᾱ_k 是前 k 个信号保留系数的乘积。论文选择 iDDPM 的 Square Cosine Schedule。需要区分：动作噪声预测 MSE 是实际训练目标；它不是让策略直接输出动作均值的 MSE。",
      source,
    );
  }

  // 6. Standard DDPM reverse posterior derived using Bayes.
  {
    const source = "Chi et al., IJRR 2025, §§2.1–2.2, Eqs. (1)–(3), p. 1686; standard DDPM posterior notation.";
    const s = newSlide(presentation, "标准 DDPM 反向式：高斯后验与贝叶斯推导", 7, source);
    text(s, "前向条件分布已知；训练阶段还知道原始数据 x₀，因此可以得到解析后验。", 72, 126, 1125, 34, {
      size: 19, color: COLORS.wine, bold: true,
    });
    text(s, "已知 x₀ 时的后验", 76, 180, 510, 30, { size: 20, bold: true });
    text(s, "q(xₖ₋₁ | xₖ, x₀) = N( μ̃ₖ, β̃ₖ I )", 76, 220, 540, 38, {
      size: 23, font: MATH,
    });
    text(s, "β̃ₖ = βₖ · (1 − ᾱₖ₋₁) / (1 − ᾱₖ)", 76, 268, 540, 37, {
      size: 20, font: MATH, color: COLORS.muted,
    });
    text(s, "μ̃ₖ = [√ᾱₖ₋₁ βₖ /(1−ᾱₖ)] x₀  +  [√αₖ (1−ᾱₖ₋₁)/(1−ᾱₖ)] xₖ", 76, 313, 545, 92, {
      size: 18, font: MATH, color: COLORS.muted, valign: "top",
    });
    box(s, 638, 180, 1, 268, COLORS.line);
    text(s, "生成时没有 x₀：用预测噪声代替", 675, 180, 515, 30, { size: 20, bold: true });
    text(s, "x̂₀ = [ xₖ − √(1−ᾱₖ) εθ(xₖ,k) ] / √ᾱₖ", 675, 220, 520, 48, {
      size: 20, font: MATH, color: COLORS.muted,
    });
    text(s, "μθ = 1/√αₖ · [ xₖ − βₖ/√(1−ᾱₖ) · εθ(xₖ,k) ]", 675, 281, 530, 72, {
      size: 21, font: MATH, bold: true, color: COLORS.wine,
    });
    text(s, "xₖ₋₁ = μθ + √β̃ₖ · z,     z ~ N(0,I)", 675, 366, 530, 46, {
      size: 21, font: MATH,
    });
    box(s, 76, 474, 1128, 102, COLORS.paleGold, "none", true);
    text(s, "系数的来源", 94, 488, 140, 28, { size: 17, color: COLORS.gold, bold: true });
    text(s, "先由贝叶斯公式得到后验均值 μ̃ₖ 与方差 β̃ₖ；再用 x̂₀ 替换未知原图并整理，得到 μθ。", 245, 486, 930, 35, {
      size: 17, bold: true,
    });
    text(s, "常见 fixed-small 设定：σₖ²=β̃ₖ，因此 σₖ=√β̃ₖ；也有实现采用其他方差日程。z 是新抽的标准高斯噪声。", 94, 530, 1080, 30, {
      size: 16, color: COLORS.muted,
    });
    text(s, "注意：这是通用 DDPM 的贝叶斯后验参数化，下一页才是论文的策略采样式。", 78, 604, 1120, 28, {
      size: 17, color: COLORS.wine, bold: true,
    });
    notes(
      s,
      "为了不把公式混在一起，这里先单独复习标准 DDPM。前向过程给出 x_k 在 x_{k−1} 条件下的高斯分布；如果再知道干净样本 x_0，就可以用贝叶斯公式得到 x_{k−1} 在 x_k 和 x_0 条件下的后验，它仍是高斯，均值是 μ̃_k、方差是 β̃_k。推理时没有 x_0，于是先从噪声预测 εθ 反推一个 x̂_0，把它代入后验均值并整理，得到 μθ 的简化表达。最后从均值为 μθ、方差为 β̃_k 的高斯分布采样：x_{k−1}=μθ+√β̃_k z。公式中的 σ_k 是标准差，所以等于方差平方根；z 是新抽的、与样本同形的标准高斯张量。这里的推导来源是高斯贝叶斯后验。论文的动作采样式并不是把这条公式原封不动换变量，下一页会对照。",
      source,
    );
  }

  // 7. The paper's conditional Langevin-style action sampler.
  {
    const source = "Chi et al., IJRR 2025, Eqs. (1), (2), (4), §§2.1, 2.3.2, p. 1686.";
    const s = newSlide(presentation, "论文策略采样：噪声预测对应 score 方向", 8, source);
    text(s, "论文的条件动作更新（Eq. 4）", 75, 130, 540, 30, {
      size: 18, color: COLORS.muted, bold: true,
    });
    text(s, "Aₜᵏ⁻¹ = αₖ [ Aₜᵏ − γₖ εθ(Oₜ, Aₜᵏ, k) + σₖ z ]", 74, 175, 760, 88, {
      size: 27, font: MATH, bold: true, color: COLORS.wine,
    });
    text(s, "z ~ N(0,I)", 74, 267, 350, 28, { size: 18, font: MATH, color: COLORS.muted });
    box(s, 867, 132, 1, 254, COLORS.line);
    text(s, "噪声预测与 score", 898, 137, 290, 30, { size: 19, bold: true });
    text(s, "sθ ≈ − εθ / √(1 − ᾱₖ)", 898, 180, 310, 44, {
      size: 23, font: MATH, color: COLORS.wine,
    });
    text(s, "≈ ∇ₐ log pₖ(Aₜᵏ | Oₜ)", 898, 232, 310, 44, {
      size: 20, font: MATH,
    });
    text(s, "score 指向带噪动作密度增大的方向；反复沿此方向更新，逐步得到高概率动作计划。", 898, 285, 302, 80, {
      size: 16, color: COLORS.muted, valign: "top",
    });
    text(s, "系数角色", 76, 342, 140, 28, { size: 18, color: COLORS.gold, bold: true });
    text(s, "αₖ：整体缩放     γₖ：去噪步长     σₖ：扰动标准差     z：每步新采的随机量", 213, 337, 1000, 36, {
      size: 17, bold: true,
    });
    box(s, 76, 416, 1128, 118, COLORS.white, COLORS.line, true);
    text(s, "共同点", 96, 434, 100, 27, { size: 17, color: COLORS.sage, bold: true });
    text(s, "都用“预测噪声”作为训练信号，并从噪声逐步得到样本。", 200, 430, 970, 34, { size: 17 });
    text(s, "不同点", 96, 478, 100, 27, { size: 17, color: COLORS.wine, bold: true });
    text(s, "标准 DDPM：高斯后验均值 + 后验方差采样；本文：Langevin 风格 score 更新，系数由动作扩散噪声日程设定。", 200, 470, 980, 48, {
      size: 16, bold: true,
    });
    text(s, "同一个字母 α 或 σ，不代表这里与 DDPM 后验中的 αₖ、σₖ 定义相同。", 78, 571, 1120, 34, {
      size: 17, color: COLORS.wine, bold: true,
    });
    notes(
      s,
      "论文把噪声预测器解释为动作分布 score 的估计。score 是对动作求的 log 概率梯度，告诉采样器往哪个方向移动会进入更高密度的动作区域。对高斯加噪参数化，噪声预测和 score 的关系是负的噪声预测除以噪声标准差，因此出现 √(1−ᾱ_k) 作为分母。论文的动作更新包含三部分：把当前动作计划整体缩放的 α_k，控制沿预测方向移动幅度的 γ_k，以及标准差 σ_k 乘以新抽噪声 z 的随机扰动。作者把它解释为 Langevin 风格的带噪梯度下降。它与上一页标准 DDPM 反向后验不同：上一页由已知高斯前向过程和贝叶斯后验推出；这里是条件 score 的随机优化更新。二者训练都用噪声预测，但采样公式不能混为一谈。同名系数也不能不加说明地视为同一个参数定义。",
      source,
    );
  }

  // 8. Receding-horizon inference and DDIM.
  {
    const source = "Chi et al., IJRR 2025, §2.3.1, §3.4, §4.3, §§5.3.4–5.3.5, pp. 1686, 1688, 1692.";
    const s = newSlide(presentation, "执行层：动作块采样、执行前缀、重新规划", 9, source);
    text(s, "两个时间索引", 75, 131, 220, 28, { size: 18, color: COLORS.gold, bold: true });
    text(s, "t：机器人与环境交互的真实时刻     k：一次动作生成内部的扩散级", 250, 128, 930, 34, {
      size: 18, bold: true,
    });
    const xs = [78, 363, 648, 933];
    const labels = [
      ["1  观测", "最近 Tₒ 帧图像与状态"],
      ["2  生成", "从随机动作块去噪，得 Tₚ 步计划"],
      ["3  执行", "只执行开头 Tₐ 步"],
      ["4  重规划", "新观测到来，重新生成计划"],
    ];
    for (let i = 0; i < labels.length; i++) {
      box(s, xs[i], 196, 238, 110, i === 2 ? COLORS.paleWine : COLORS.white, i === 2 ? COLORS.wine : COLORS.line, true);
      text(s, labels[i][0], xs[i] + 14, 207, 210, 30, { size: 18, bold: true, color: i === 2 ? COLORS.wine : COLORS.ink });
      text(s, labels[i][1], xs[i] + 14, 244, 210, 46, { size: 15, color: COLORS.muted, align: "center" });
      if (i < 3) text(s, "→", xs[i] + 244, 233, 38, 30, { size: 22, color: COLORS.wine, align: "center" });
    }
    text(s, "未执行的动作后缀", 81, 336, 190, 29, { size: 17, color: COLORS.sage, bold: true });
    text(s, "当 Tₚ > Tₐ 时，可把上一计划中未执行的部分作为下一次推理的 warm start，再根据新观测修正。", 269, 333, 920, 46, {
      size: 16, color: COLORS.muted,
    });
    rule(s, 78, 400, 1124, COLORS.line, 1);
    text(s, "时域取舍", 82, 420, 130, 29, { size: 18, color: COLORS.gold, bold: true });
    text(s, "Tₒ：观测历史；视觉任务通常用较短历史。   Tₚ：一次预测整段动作。   Tₐ：执行越长越平滑但响应越慢；多数任务 8 步较优。", 216, 416, 965, 52, {
      size: 16, bold: true,
    });
    text(s, "推理加速与口径", 82, 488, 190, 29, { size: 18, color: COLORS.gold, bold: true });
    text(s, "DDIM 将训练扩散步与推理步解耦。正文：100 → 10 步、RTX 3080 约 0.1 s；附录实机配置表：16 步。", 269, 484, 915, 55, {
      size: 16, color: COLORS.muted,
    });
    text(s, "闭环不是每一步都从头执行全计划：它只执行短前缀，用新观测抵消长计划的过时风险。", 80, 565, 1110, 38, {
      size: 17, color: COLORS.wine, bold: true,
    });
    notes(
      s,
      "机器人推理不是一次性生成后把整段轨迹执行到底。每个真实控制时刻 t，策略读取最近 T_o 帧图像和状态，从噪声动作块开始，在内部扩散级 k 上迭代去噪，生成未来 T_p 步动作；但只执行前 T_a 步。随后传感器得到新观测，再生成下一段。这样在动作序列一致性和对新情况响应之间折中。若 T_p 大于 T_a，论文还允许把上一轮未执行动作作为下一次采样的 warm start；新观测会提供校正条件。T_o、T_p、T_a 是控制时间尺度，k 是扩散生成内部尺度，不能混为一谈。DDIM 允许训练和推理采用不同去噪步数。正文报告 100 个训练扩散步、10 个推理步、RTX 3080 上约 0.1 秒；附录的实机超参数表对真实任务列出 16 个推理步，因此汇报时需说明两处口径。",
      source,
    );
  }

  // 9. Evaluation evidence and ablations.
  {
    const source = "Chi et al., IJRR 2025, Abstract, §§5–6, Figure 6, Table 6, Appendix B.2, pp. 1684, 1690–1694, 1702.";
    const s = newSlide(presentation, "实验：整体提升、真实机器人与控制消融", 10, source);
    addImage(s, paperDeck, "im/m1sb6pgf", "论文 Figure 6：动作执行时域与时延鲁棒性消融", 68, 142, 485, 246);
    text(s, "15", 594, 142, 126, 70, { size: 56, bold: true, color: COLORS.wine, font: MATH, align: "center" });
    text(s, "任务 / 4 个基准", 720, 159, 250, 34, { size: 19, bold: true });
    text(s, "46.9%", 594, 236, 180, 62, { size: 46, bold: true, color: COLORS.wine, font: MATH });
    text(s, "相对最佳基线的平均相对提升", 776, 250, 388, 33, { size: 18, bold: true });
    text(s, "不是成功率增加 46.9 个百分点；论文先逐任务算相对增幅，再取平均。", 594, 300, 585, 48, {
      size: 15, color: COLORS.muted,
    });
    rule(s, 68, 411, 1138, COLORS.line, 1.2);
    text(s, "真实 Push-T（UR5）", 74, 430, 280, 29, { size: 20, bold: true });
    text(s, "136 条示范 · 20 次评测", 74, 467, 280, 28, { size: 16, color: COLORS.muted });
    text(s, "95%", 74, 504, 170, 58, { size: 45, font: MATH, color: COLORS.wine, bold: true });
    text(s, "Diffusion Policy 成功率", 230, 516, 270, 31, { size: 17, bold: true });
    box(s, 527, 431, 1, 143, COLORS.line);
    text(s, "对照结果", 555, 430, 170, 29, { size: 18, color: COLORS.gold, bold: true });
    text(s, "IBC 0%  ·  LSTM-GMM 20%", 555, 468, 360, 31, { size: 18, bold: true });
    text(s, "末端状态 IoU：策略 0.80；演示 0.84。", 555, 511, 400, 31, { size: 16, color: COLORS.muted });
    box(s, 938, 431, 1, 143, COLORS.line);
    text(s, "消融结论", 966, 430, 195, 29, { size: 18, color: COLORS.gold, bold: true });
    text(s, "Tₐ≈8 步在多数任务较优；仿真中最多 4 步延迟仍保持峰值表现。位置控制更适合整段动作预测。", 966, 466, 230, 102, {
      size: 15, color: COLORS.muted, valign: "top",
    });
    text(s, "期刊版扩展的双臂任务：打蛋器 55%，展开垫子 75%，叠衣服 75%（每项 20 次试验）。", 76, 596, 1110, 33, {
      size: 16, color: COLORS.sage, bold: true,
    });
    notes(
      s,
      "实验结果分三层看。第一，论文在四个机器人操作基准的十五项任务上，报告相对最佳基线平均提升 46.9%。这个数是逐任务算相对提升后再平均，不是成功率增加 46.9 个百分点。第二，真实 UR5 Push-T 使用 136 条示范、20 次评测，Diffusion Policy 成功率 95%，末端状态 IoU 为 0.80，演示为 0.84；对照中的 IBC 为 0%，LSTM-GMM 为 20%。第三，控制消融说明模型之外的工程选择也重要：多数任务执行时域 T_a 约 8 步较优，太短牺牲连续性，太长响应变慢；位置控制更适合序列动作预测，并且仿真中对最多 4 步延迟仍保持峰值表现。期刊扩展还加入双臂操作任务，打蛋器、展开垫子、叠衣服分别报告 55%、75%、75%，每项 20 次试验。这些数据支持在论文设置下的有效性，不应直接外推到未测试的机器人或任务。",
      source,
    );
  }

  // 10. Synthesis, scope and limitations.
  {
    const source = "Chi et al., IJRR 2025, §§9–10, p. 1698.";
    const s = newSlide(presentation, "结论：动作表示、闭环时域与视觉条件共同决定效果", 11, source);
    text(s, "论文贡献不只是把“图像去噪”换成“动作去噪”。", 74, 130, 1110, 39, {
      size: 23, color: COLORS.wine, bold: true,
    });
    const blocks = [
      ["表示", "策略建模 p(Aₜ | Oₜ)，一次生成动作块，保留多峰方案与时间相关性。"],
      ["学习", "用合成的高斯噪声监督 score / 噪声预测，以简单的 MSE 学复杂条件动作分布。"],
      ["控制", "只执行生成计划的前缀，再根据新观测重规划；DDIM 控制推理步数。"],
    ];
    const bx = [77, 458, 839];
    for (let i = 0; i < 3; i++) {
      text(s, blocks[i][0], bx[i], 202, 320, 31, { size: 19, color: i === 1 ? COLORS.gold : COLORS.wine, bold: true });
      text(s, blocks[i][1], bx[i], 244, 320, 101, { size: 17, color: COLORS.ink, valign: "top" });
      if (i < 2) box(s, bx[i] + 350, 204, 1, 150, COLORS.line);
    }
    rule(s, 77, 385, 1120, COLORS.line, 1);
    text(s, "论文支持的判断", 78, 405, 220, 30, { size: 18, color: COLORS.sage, bold: true });
    text(s, "条件扩散适合表达多模态、高维动作序列；真实部署效果还依赖动作空间、控制器、观测条件和重规划时域的协同。", 300, 400, 875, 52, {
      size: 17, bold: true,
    });
    text(s, "适用边界", 78, 483, 220, 30, { size: 18, color: COLORS.gold, bold: true });
    text(s, "行为克隆受示范覆盖限制；多步采样增加推理成本，高频控制仍有挑战；生成策略不等于安全证明，限位、碰撞约束与急停仍由控制系统负责。", 300, 477, 875, 73, {
      size: 16, color: COLORS.muted, valign: "top",
    });
    box(s, 78, 581, 1117, 50, COLORS.paleWine, "none", true);
    text(s, "复现时优先核对：动作定义与归一化 · Tₒ / Tₚ / Tₐ · 推理时延与机器人控制接口", 98, 589, 1080, 32, {
      size: 18, color: COLORS.wine, bold: true, align: "center",
    });
    notes(
      s,
      "最后把论文的逻辑压缩成三件事：第一，动作表示从单点回归改为条件动作序列分布，使多种有效方案可以保留在一个模型中；第二，噪声预测提供可训练的监督目标，推理时等价于沿 score 方向逐步生成；第三，滚动时域让整段生成与环境反馈并存。实验说明效果不是单靠扩散损失获得，而是动作表示、视觉条件、控制模式、执行时域和推理速度共同作用。论文作者也指出，行为克隆仍受示范覆盖不足限制，扩散带来额外计算与推理延迟，高频控制仍有挑战。机器人安全不能交给生成策略单独保证，部署还需独立的限位、碰撞约束和急停机制。实际复现时，优先核对动作定义和归一化、三个时域参数，以及推理速度能否满足控制接口。",
      source,
    );
  }

  if (presentation.slides.items.length !== 11) {
    throw new Error("Expected 11 slides, got " + presentation.slides.items.length);
  }

  // Save previews and an editable draft for visual inspection before finalization.
  const previewDir = path.join(BUILD, "previews");
  await fs.mkdir(previewDir, { recursive: true });
  for (const [index, slide] of presentation.slides.items.entries()) {
    const png = await presentation.export({ slide, format: "png", scale: 1 });
    await writeBlob(path.join(previewDir, "slide-" + String(index + 1).padStart(2, "0") + ".png"), png);
  }
  const draft = path.join(BUILD, "candidate.pptx");
  await (await PresentationFile.exportPptx(presentation)).save(draft);

  process.env.RUNTIME_NODE_MODULES =
    "C:/Users/laiyo/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules";
  const { finalizePresentation } = await import(pathToFileURL(
    path.join(SKILL_DIR, "container_tools/artifact_tool_utils.mjs"),
  ).href);
  await fs.mkdir("G:/毕设/.codex_presentation_validation_v6", { recursive: true });
  const result = await finalizePresentation({
    explicitTotalSlideCount: 11,
    requiredNativeTableOwnerSlides: [],
    requiredNativeChartOwnerSlides: [],
    workspaceDir: ROOT,
    candidatePath: draft,
    finalPath: FINAL_PPTX,
    pythonExecutable: PYTHON,
    integrityValidatorPath: path.join(SKILL_DIR, "container_tools/inspect_presentation_package_integrity.py"),
    layoutValidatorPath: path.join(SKILL_DIR, "container_tools/inspect_presentation_layout_geometry.py"),
    layoutArgs: [
      "--expected-slide-size-emu",
      "12192000,6858000",
      "--validate-bullet-geometry",
      "--validate-heading-fit",
    ],
    fontPolicy: { basis: "design", families: [FONT, MATH] },
    verifyArtifactToolImport: true,
    receiptPath: "G:/毕设/.codex_presentation_validation_v6/diffusion_policy_advisor_report_detailed_v6.validation.json",
  });
  console.log("FINAL", FINAL_PPTX);
  console.log(JSON.stringify(result, null, 2));
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
