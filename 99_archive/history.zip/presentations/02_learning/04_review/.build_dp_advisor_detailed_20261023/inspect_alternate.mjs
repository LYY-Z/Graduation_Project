import fs from 'node:fs/promises';
import path from 'node:path';
import { FileBlob, PresentationFile } from '@oai/artifact-tool';

const source = 'H:/Download/Diffusion Policy 论文组会汇报.pptx';
const buildDir = 'G:/毕设/02_learning/04_review/.build_dp_advisor_detailed_20261023';
const outDir = path.join(buildDir, 'alternate-reference-preview');
await fs.mkdir(outDir, { recursive: true });
const presentation = await PresentationFile.importPptx(await FileBlob.load(source));
const result = await presentation.inspect({
  select: '$.slides[*]',
  include: ['id', 'index', 'title', 'elements.id', 'elements.text', 'notes.text'],
});
await fs.writeFile(path.join(buildDir, 'alternate-reference-inspect.ndjson'), result.ndjson, 'utf8');
for (const [index, slide] of presentation.slides.items.entries()) {
  const blob = await presentation.export({ slide, format: 'png', scale: 1 });
  await fs.writeFile(path.join(outDir, `slide-${String(index + 1).padStart(2, '0')}.png`), new Uint8Array(await blob.arrayBuffer()));
}
console.log(JSON.stringify({ slideCount: presentation.slides.items.length, titles: result.records.map((r) => r.title), previewDir: outDir }, null, 2));
