import fs from 'node:fs/promises';
import path from 'node:path';
import { FileBlob, PresentationFile } from '@oai/artifact-tool';

const buildDir = 'G:/毕设/02_learning/04_review/.build_dp_advisor_detailed_20261023';
const draftPath = path.join(buildDir, 'diffusion_policy_advisor_report_10min_refined_v3_draft.pptx');
const outDir = path.join(buildDir, 'previews_v3');
await fs.mkdir(outDir, { recursive: true });
const presentation = await PresentationFile.importPptx(await FileBlob.load(draftPath));
for (const [index, slide] of presentation.slides.items.entries()) {
  const blob = await presentation.export({ slide, format: 'png', scale: 1 });
  await fs.writeFile(path.join(outDir, `slide-${String(index + 1).padStart(2, '0')}.png`), new Uint8Array(await blob.arrayBuffer()));
}
const inspection = await presentation.inspect({
  select: '$.slides[*]',
  include: ['id', 'index', 'title', 'elements.id', 'elements.kind', 'elements.text', 'elements.position', 'elements.style', 'notes.text'],
});
await fs.writeFile(path.join(buildDir, 'v3-inspect.ndjson'), inspection.ndjson, 'utf8');
console.log(JSON.stringify({ slideCount: presentation.slides.items.length, previewDir: outDir, titles: inspection.records.map((record) => record.title) }, null, 2));
