import fs from 'node:fs/promises';
import { FileBlob, PresentationFile } from '@oai/artifact-tool';

const input = 'G:/毕设/02_learning/04_review/diffusion_policy_advisor_report_10min_final.pptx';
const p = await PresentationFile.importPptx(await FileBlob.load(input));
const result = await p.inspect({
  select: '$.slides[*]',
  include: ['id','index','layout','title','elements.id','elements.kind','elements.name','elements.text','elements.position','elements.style','notes.text'],
});
await fs.writeFile('G:/毕设/02_learning/04_review/.build_dp_advisor_detailed_20261023/base-inspect.ndjson', result.ndjson, 'utf8');
console.log(result.ndjson);
