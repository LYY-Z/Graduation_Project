import fs from 'node:fs/promises';
import path from 'node:path';
import { FileBlob, PresentationFile } from '@oai/artifact-tool';

const workspaceDir = 'G:/毕设/02_learning/04_review';
const buildDir = path.join(workspaceDir, '.build_dp_advisor_detailed_20261023');
const sourcePath = path.join(workspaceDir, 'deliverables', 'diffusion_policy_advisor_report_10min_refined_v2.pptx');
const draftPath = path.join(buildDir, 'diffusion_policy_advisor_report_10min_refined_v3_draft.pptx');
const C = { bg: '#F5F3F0', ink: '#252A31', muted: '#646A70', plum: '#78394C', ochre: '#B58A4A', line: '#DED9D2', white: '#FFFFFF', palePlum: '#F0E8EA', paleGold: '#F4EFE5', paleGreen: '#E9EDE8' };
const FONT = 'Microsoft YaHei';
const MATH = 'Cambria Math';
const presentation = await PresentationFile.importPptx(await FileBlob.load(sourcePath));

function setText(id, value) {
  const shape = presentation.resolve(id);
  if (!shape?.text) throw new Error(`Text shape not found: ${id}`);
  shape.text = value;
}

function text(slide, name, value, x, y, w, h, options = {}) {
  const shape = slide.shapes.add({
    geometry: 'textbox', name,
    position: { left: x, top: y, width: w, height: h },
    fill: 'none', line: { style: 'solid', fill: 'none', width: 0 },
  });
  shape.text = value;
  shape.text.style = {
    typeface: options.font ?? FONT,
    fontSize: options.size ?? 18,
    color: options.color ?? C.ink,
    bold: options.bold ?? false,
    alignment: options.align ?? 'left',
    verticalAlignment: options.valign ?? 'middle',
    wrap: 'square', autoFit: 'shrinkText', insets: 0,
  };
  return shape;
}

function rect(slide, name, x, y, w, h, fill = C.white, stroke = C.line) {
  return slide.shapes.add({
    geometry: 'rect', name,
    position: { left: x, top: y, width: w, height: h },
    fill, line: { style: 'solid', fill: stroke, width: stroke === 'none' ? 0 : 1 },
  });
}

function rule(slide, name, x, y, w, h = 1.5, color = C.line) {
  return rect(slide, name, x, y, w, h, color, 'none');
}

function header(slide, title, page, citation, subtitle) {
  rect(slide, 'slide-background', 0, 0, 1280, 720, C.bg, 'none');
  text(slide, 'slide-title', title, 64, 38, 1135, 62, { size: 38, bold: true });
  rule(slide, 'header-rule', 64, 113, 1152, 1.5, C.line);
  rule(slide, 'header-accent', 64, 113, 72, 3, C.plum);
  text(slide, 'slide-subtitle', subtitle, 66, 132, 1120, 42, { size: 21, color: C.plum, bold: true });
  rule(slide, 'footer-rule', 64, 668, 1152, 1, C.line);
  text(slide, 'slide-citation', citation, 64, 679, 1085, 22, { size: 14, color: C.muted });
  text(slide, 'slide-page', `${String(page).padStart(2, '0')} / 10`, 1155, 679, 61, 22, { size: 14, color: C.muted, align: 'right' });
}

// Slide 2: make the failure mode concrete with the reference deck's MSE-averaging illustration.
const problemSlide = presentation.slides.items[1];
presentation.delete(['im/mpcv2l0b']);
setText('sh/a10jqpsj', '参考汇报中的 Push-T 示意；论文背景见 Chi et al., IJRR 2025, §§1–2');
setText('sh/w3i1sfa9', '同一观测下有多个有效动作区域；点预测会把不兼容的方案压成平均值。');
setText('sh/bip8jmho', '逐时刻决策会切换模式');
setText('sh/cnupgny5', '若每一步独立选择路线，机器人可能左右切换，造成动作抖动。');
setText('sh/t8byxkn2', '两条有效路线的 MSE 均值可能落入不可行动作区域。');
setText('sh/76twva5c', '建模目标因此变为：学习条件动作块分布 pθ(Aₜ⁰ | Oₜ)，并联合生成时间连贯的整段动作。');
const mseIllustration = new Uint8Array(await fs.readFile(path.join(buildDir, 'alternate-reference-preview', 'slide-03.png')));
problemSlide.images.add({
  blob: mseIllustration,
  contentType: 'image/png',
  alt: '两条有效 Push-T 动作路线及其错误的 MSE 平均路线示意',
  fit: 'contain',
  crop: { left: 0.58, top: 0.29, right: 0.08, bottom: 0.22 },
  position: { left: 680, top: 190, width: 465, height: 355 },
});
presentation.resolve('sh/t8byxkn2').position = { left: 676, top: 548, width: 476, height: 34 };
presentation.resolve('sh/t8byxkn2').text.fontSize = 15.5;
problemSlide.speakerNotes.text = [
  '行为克隆把专家演示当作监督数据。一个观测可能对应多条都正确的轨迹，例如推 T 形块时从左右两侧接近都能成功。',
  '若直接用 MSE 回归单个动作，模型会受到两种答案的共同拉动，输出它们的平均动作。这个均值不一定仍然可行，图中的虚线就是这一问题的几何示意。',
  '此外，逐时刻独立做选择可能让相邻动作在不同模式间切换。本文的目标因此是条件动作块分布 p(A_t^0|O_t)，让一次生成共同确定未来一段动作。下一页比较它与显式策略和隐式能量策略的差异。',
  '',
  '参考：Diffusion Policy 组会汇报源文件，问题背景页；Chi et al., IJRR 2025, §§1–2。',
].join('\n');

// Slide 3: show the reason score learning avoids the energy model's normalization integral.
setText('sh/v6l4jq94', '学习动作分布的 score。能量归一化项 Z(O) 与动作无关，求梯度时消失。');
presentation.resolve('sh/v6l4jq94').text.fontSize = 16;
setText('sh/w7ulsvqp', '为何训练更直接：p(a|O)=exp[−E(O,a)]/Z(O)，故 ∇ₐlog p=−∇ₐE；Diffusion Policy 以噪声 MSE 学习相应 score，无需估计 Z(O)。');
presentation.resolve('sh/w7ulsvqp').position = { left: 70, top: 607, width: 1138, height: 48 };
presentation.resolve('sh/w7ulsvqp').text.fontSize = 16;
const representationSlide = presentation.slides.items[2];
representationSlide.speakerNotes.text = [
  '显式策略直接给动作或动作概率。单一回归输出不易覆盖多解；GMM 或分类能表示多个模式，但要预设分量或类别数。',
  '隐式能量策略 E(O,a) 给观察与动作打分，推理时搜索低能量动作。把能量变为归一化概率时要除以 Z(O)，它需要对连续动作空间积分，通常难以计算；负样本近似又增加训练与采样难度。',
  '关键关系是 log p(a|O)=−E(O,a)−log Z(O)。对动作 a 求梯度时，Z(O) 不依赖 a，因此 ∇a log p=−∇a E。Diffusion Policy 以逐级加噪的已知噪声作为监督，训练去噪器；按噪声尺度转换后，预测方向对应条件动作分布的 score。它无需显式求能量归一化常数。',
  '这不是说扩散在所有方面都优于能量模型：论文强调的是在保留多模态表达能力的同时，使用直接、稳定的噪声回归目标。主实验是行为克隆，监督信号来自演示，不依赖在线奖励试错。',
  '',
  '参考：Chi et al., IJRR 2025, Figure 1, §§1–2。',
].join('\n');

// Slide 4: make the visual encoder's task-driven learning and the ablation comparison explicit.
setText('sh/knex8j21', '无类别标签；ε-MSE 梯度回传视觉编码器，端到端微调优于冻结特征。CNN+FiLM 易训；Transformer 更灵活，但成本更高。');
presentation.resolve('sh/knex8j21').position = { left: 70, top: 608, width: 535, height: 53 };
presentation.resolve('sh/knex8j21').text.fontSize = 15;
const encoderSlide = presentation.slides.items[3];
encoderSlide.speakerNotes.text = [
  '观察 O_t 汇集最近 T_o 帧多视角图像和机器人低维状态。每个相机视角由独立的 ResNet-18 编码，再用 Spatial Softmax 把空间特征压缩为带位置信息的表示；不同视角和本体状态沿特征维拼接。它们不是把图片相加。',
  '网络不会因为看过图片就天然知道“这是杯子”。论文没有要求对象类别标签。噪声预测 MSE 的梯度经过动作去噪网络回传到视觉 ResNet，让编码器逐渐保留对动作有用的线索，例如目标相对位置、接触关系和夹爪状态。特征能否被人解释不是训练目标。实机消融显示，端到端微调视觉编码器优于冻结预训练编码器。',
  '论文把 BatchNorm 换成 GroupNorm。BatchNorm 保存由在线训练批次积累的运行均值和方差；EMA 参数则是在线网络历史参数的平滑版本。两套状态可能不完全对应。GroupNorm 不依赖跨批次运行统计，更容易与 EMA 参数配合。',
  '条件特征在一轮去噪过程中共享。CNN 版本用 FiLM 调制时序卷积特征；Transformer 版本通过 cross-attention 把观察嵌入注入动作 token。图像提供条件，扩散只作用于动作块。',
  '',
  '参考：Chi et al., IJRR 2025, Figure 2, §§3.2, 5.4, 6.1.2。',
].join('\n');

// Slide 6: replace the crowded sampler page with the Bayes-to-sample derivation and the paper's distinct Eq. (4).
const samplerSlide = presentation.slides.items[5];
setText('sh/va98j210', '反向采样：后验均值如何变成下一步动作');
setText('sh/7m98ru9g', '有演示动作时可用贝叶斯公式求后验；生成时用噪声预测替代未知的干净动作。');
presentation.resolve('sh/7m98ru9g').position = { left: 66, top: 135, width: 1120, height: 32 };
presentation.resolve('sh/7m98ru9g').text.fontSize = 20;
const samplerRecord = (await presentation.inspect({ select: '$.slides[*]', include: ['id', 'index', 'elements.id', 'elements.position'] })).records.find((r) => r.index === 5);
const samplerBodyIds = samplerRecord.elements
  .filter((element) => element.position?.top >= 180 && element.position?.top < 668)
  .map((element) => element.id);
presentation.delete(samplerBodyIds);

rect(samplerSlide, 'sampler-ddpm-card', 66, 184, 556, 460, C.white, C.line);
text(samplerSlide, 'sampler-ddpm-title', '标准 DDPM：贝叶斯后验给出反向分布', 84, 194, 520, 30, { size: 19, color: C.plum, bold: true });
text(samplerSlide, 'posterior-known-x0-label', '已知干净动作 Aₜ⁰ 时', 84, 228, 520, 24, { size: 16, color: C.muted, bold: true });
text(samplerSlide, 'posterior-distribution', 'q(Aₜᵏ⁻¹ | Aₜᵏ, Aₜ⁰) = N(μ̃ₖ, β̃ₖ I)', 84, 251, 520, 30, { size: 17, font: MATH, align: 'center' });
text(samplerSlide, 'posterior-mean-form', 'μ̃ₖ = c₁Aₜ⁰ + c₂Aₜᵏ', 84, 283, 520, 28, { size: 18, font: MATH, align: 'center' });
text(samplerSlide, 'posterior-coefficients', 'c₁=√ᾱₖ₋₁ βₖ/(1−ᾱₖ)\nc₂=√αₖ (1−ᾱₖ₋₁)/(1−ᾱₖ)', 84, 311, 520, 48, { size: 15.5, font: MATH, align: 'center', color: C.muted });
rule(samplerSlide, 'posterior-divider', 84, 365, 520, 1, C.line);
text(samplerSlide, 'posterior-generation-label', '生成时没有 Aₜ⁰：先由 εθ 估计它', 84, 373, 520, 24, { size: 16, color: C.plum, bold: true });
text(samplerSlide, 'posterior-x0-estimate', 'Âₜ⁰ = [Aₜᵏ − √(1−ᾱₖ) εθ] / √ᾱₖ', 84, 399, 520, 32, { size: 16.5, font: MATH, align: 'center' });
text(samplerSlide, 'posterior-reduced-mean', 'μθ = 1/√αₖ [Aₜᵏ − βₖ εθ / √(1−ᾱₖ)]', 84, 434, 520, 34, { size: 17.5, font: MATH, align: 'center' });
text(samplerSlide, 'posterior-sample', 'Aₜᵏ⁻¹ = μθ + σₖ z', 84, 472, 520, 31, { size: 20, font: MATH, align: 'center' });
text(samplerSlide, 'posterior-variance', 'σₖ² = β̃ₖ = βₖ (1−ᾱₖ₋₁)/(1−ᾱₖ)', 84, 505, 520, 29, { size: 16, font: MATH, align: 'center', color: C.muted });
text(samplerSlide, 'posterior-intuition', 'μθ 是下一步分布的中心；β̃ₖ 是方差，σₖ 是标准差。最后一步通常令 z=0，不再注入新噪声。', 84, 540, 520, 74, { size: 15.5, color: C.muted });

rect(samplerSlide, 'sampler-score-paper-card', 646, 184, 568, 460, C.palePlum, C.line);
text(samplerSlide, 'sampler-score-title', '噪声预测的两种读法', 666, 194, 528, 30, { size: 19, color: C.plum, bold: true });
text(samplerSlide, 'sampler-score-equation', 'ŝθ ≈ −εθ(Oₜ,Aₜᵏ,k) / √(1−ᾱₖ)', 666, 230, 528, 38, { size: 20, font: MATH, align: 'center' });
text(samplerSlide, 'sampler-score-why', '为什么除以 √(1−ᾱₖ)', 666, 272, 528, 26, { size: 16.5, color: C.plum, bold: true });
text(samplerSlide, 'sampler-score-explanation', '前向过程把动作噪声按 √(1−ᾱₖ) 缩放后加进去；εθ 预测这份残差。除以噪声标准差，才换算到 score 的尺度，即动作分布的高概率方向。', 666, 299, 528, 68, { size: 15.5, color: C.muted });
rule(samplerSlide, 'sampler-score-divider', 666, 372, 528, 1, '#D8C8CC');
text(samplerSlide, 'sampler-eq4-label', '论文 Eq. (4)：Langevin 风格参数化', 666, 383, 528, 25, { size: 16.5, color: C.plum, bold: true });
text(samplerSlide, 'sampler-eq4-equation', 'Aₜᵏ⁻¹ = αₖ [Aₜᵏ − γₖ εθ(Oₜ,Aₜᵏ,k) + σₖ z]', 660, 413, 540, 38, { size: 17, font: MATH, align: 'center' });
text(samplerSlide, 'sampler-eq4-explanation', '它与标准 DDPM 都用噪声预测推动去噪，但系数遵循各自定义，不能直接互换。', 666, 454, 528, 46, { size: 15.5, color: C.muted });
rect(samplerSlide, 'sampler-epsilon-z-callout', 666, 519, 528, 96, C.paleGold, C.line);
text(samplerSlide, 'sampler-epsilon-z-title', '训练里的 ε 与推理里的 z 不是同一份噪声', 682, 528, 496, 27, { size: 16, color: C.plum, bold: true });
text(samplerSlide, 'sampler-epsilon-z-body', 'ε：前向加噪时抽取，网络训练要预测的已知目标。\nz：反向采样时每步新抽取的标准高斯张量。', 682, 556, 496, 48, { size: 15.5, color: C.ink });
setText('sh/98rqt4r6', 'Chi et al., IJRR 2025, Eqs. (1), (4), §§2.1–2.3, pp. 1686, 1688');
samplerSlide.speakerNotes.text = [
  '前向扩散是已知高斯过程。训练时我们同时知道专家干净动作 A_t^0 和加噪后的 A_t^k，因此可以用贝叶斯公式求 q(A_t^{k−1}|A_t^k,A_t^0)。它是高斯分布，均值 μ̃_k 是 A_t^0 与 A_t^k 的加权和，方差 β̃_k=β_k(1−ᾱ_{k−1})/(1−ᾱ_k)。',
  '生成时没有专家动作 A_t^0。由闭式前向公式 A_t^k=√ᾱ_k A_t^0+√(1−ᾱ_k)ε，先用网络预测 εθ，再反推出 Â_t^0=[A_t^k−√(1−ᾱ_k)εθ]/√ᾱ_k。把 Â_t^0 放入后验均值并整理，得到 μθ=1/√α_k[A_t^k−β_k εθ/√(1−ᾱ_k)]。因此这个均值不是凭空设定，而是贝叶斯后验代入网络估计后的代数结果。',
  '采样写作 A_t^{k−1}=μθ+σ_k z。高斯抽样的一般形式是 X=μ+σz，z~N(0,I)。这里 σ_k^2=β̃_k，所以 σ_k 是标准差，β̃_k 是方差。最后一步通常令 z=0。',
  '噪声预测也可换算为 score：ŝθ≈−εθ/√(1−ᾱ_k)。除以该尺度是因为 εθ 是加噪残差，而 score 定义在动作变量的概率密度尺度上。',
  '本文 Eq. (4) 另写为 Langevin 风格更新。它和标准 DDPM 的高斯后验公式都使用噪声预测，但系数定义不同。训练目标 ε 是前向加噪时已知的监督噪声；z 是反向采样时重新抽取的随机量。',
  '',
  '参考：Chi et al., IJRR 2025, Eqs. (1), (4), §§2.1–2.3。',
].join('\n');

// New slide 7: explain why DDIM can take fewer inference iterations than training noise levels.
const ddimSlide = presentation.slides.insert({ after: samplerSlide, background: { fill: C.bg } }).slide;
header(
  ddimSlide,
  'DDIM：训练噪声级数与推理步数可以分开',
  7,
  'Chi et al., IJRR 2025, §2.3, §3.4, p. 1688',
  '利用同一噪声预测先估计干净动作，再直接构造目标级别的动作样本。',
);
rect(ddimSlide, 'ddim-reconstruction-card', 66, 184, 676, 440, C.white, C.line);
text(ddimSlide, 'ddim-reconstruction-title', '从噪声级 k 得到较干净的级别 j', 88, 199, 632, 30, { size: 20, color: C.plum, bold: true });
text(ddimSlide, 'ddim-step-one-label', '① 由当前动作块和噪声估计反推干净动作', 88, 246, 632, 27, { size: 16.5, color: C.muted, bold: true });
text(ddimSlide, 'ddim-x0-equation', 'Âₜ⁰ = [Aₜᵏ − √(1−ᾱₖ) ε̂ₖ] / √ᾱₖ', 88, 278, 632, 42, { size: 21, font: MATH, align: 'center' });
text(ddimSlide, 'ddim-step-two-label', '② 按目标级别 j 的噪声比例重新组合', 88, 345, 632, 27, { size: 16.5, color: C.muted, bold: true });
text(ddimSlide, 'ddim-jump-equation', 'Aₜʲ = √ᾱⱼ Âₜ⁰ + √(1−ᾱⱼ) ε̂ₖ，  j < k', 88, 378, 632, 42, { size: 20, font: MATH, align: 'center' });
rule(ddimSlide, 'ddim-reconstruction-divider', 88, 444, 632, 1, C.line);
text(ddimSlide, 'ddim-why-jump', '为什么能跳级：前向过程已有闭式表达。得到 Âₜ⁰ 后，可以直接按 j 的噪声强度重建样本，不必逐级经过每个 k。', 88, 460, 632, 92, { size: 17, color: C.ink });

rect(ddimSlide, 'ddim-speed-card', 766, 184, 448, 440, C.palePlum, C.line);
text(ddimSlide, 'ddim-speed-title', '推理可以稀疏选级', 790, 199, 400, 30, { size: 20, color: C.plum, bold: true });
text(ddimSlide, 'ddim-ddpm-label', 'DDPM：每个训练噪声级都逐步采样', 790, 248, 400, 28, { size: 16.5, color: C.muted, bold: true });
text(ddimSlide, 'ddim-ddpm-levels', 'K，K−1，K−2，…，0', 790, 279, 400, 35, { size: 19, font: MATH, align: 'center' });
rule(ddimSlide, 'ddim-speed-divider', 790, 326, 400, 1, '#D8C8CC');
text(ddimSlide, 'ddim-sparse-label', 'DDIM：只走选定的少数噪声级', 790, 341, 400, 28, { size: 16.5, color: C.plum, bold: true });
text(ddimSlide, 'ddim-sparse-levels', 'K，…，j，…，0', 790, 373, 400, 35, { size: 19, font: MATH, align: 'center' });
text(ddimSlide, 'ddim-real-time-result', '主文实机示例', 790, 432, 400, 25, { size: 16.5, color: C.muted, bold: true });
text(ddimSlide, 'ddim-real-time-numbers', '100 → 10\n约 0.1 秒', 790, 460, 400, 89, { size: 31, color: C.plum, bold: true, align: 'center' });
text(ddimSlide, 'ddim-hardware', 'NVIDIA RTX 3080；不同实机附录配置使用 16 个评估步。', 790, 560, 400, 44, { size: 14.5, color: C.muted, align: 'center' });
ddimSlide.speakerNotes.text = [
  'DDIM 的核心是把训练时使用的噪声等级数与推理实际运行的迭代次数分开。给定当前较噪动作 A_t^k 和噪声预测 ε̂_k，先按前向闭式公式估计干净动作 Â_t^0。',
  '然后选一个较干净的级别 j<k，按 A_t^j=√ᾱ_j Â_t^0+√(1−ᾱ_j)ε̂_k 重组。因为每一级的闭式关系都已知，采样器可以直接跳过若干中间等级。这里的“跳”不是随意猜下一张图，而是用估计的干净动作和目标级别的噪声比例构造新的样本。',
  '主文真实机器人示例使用 100 个训练噪声级、10 个推理迭代，在 NVIDIA RTX 3080 上约 0.1 秒。论文附录的其他实机配置使用 16 个评估步，因此介绍速度时要说明对应配置。',
  '',
  '参考：Chi et al., IJRR 2025, §2.3, §3.4, p. 1688。',
].join('\n');
ddimSlide.speakerNotes.setVisible(true);

// Preserve the paper's qualitative multimodal rollout figure for the results page, not the problem setup.
const experimentRecord = (await presentation.inspect({ select: '$.slides[*]', include: ['id', 'index', 'title', 'elements.id'] })).records.find((r) => r.title === '实验结果支持多模态建模与闭环控制设计');
if (!experimentRecord) throw new Error('Could not locate the original experiment slide by its title.');
const experimentSlide = presentation.resolve(experimentRecord.id);
const experimentIds = experimentRecord.elements.map((element) => element.id);
presentation.delete(experimentIds);
header(
  experimentSlide,
  '实验结果：多峰轨迹质量也转化为任务成功',
  9,
  'Chi et al., IJRR 2025, Figure 3, Tables 1–4, Table 6, §§4–6, pp. 1688–1694',
  '基准任务、真实 UR5 与期刊双臂扩展，从不同层面检验整套策略。',
);

text(experimentSlide, 'benchmarks-heading', '模拟基准', 70, 191, 480, 28, { size: 18, color: C.plum, bold: true });
text(experimentSlide, 'benchmarks-large-stat', '15 项任务', 70, 225, 225, 61, { size: 42, color: C.plum, bold: true });
text(experimentSlide, 'benchmarks-small-stat', '4 个基准', 304, 238, 200, 39, { size: 25, color: C.ink, bold: true });
text(experimentSlide, 'benchmark-average-improvement', '46.9%', 70, 286, 245, 78, { size: 57, color: C.ochre, bold: true });
text(experimentSlide, 'benchmark-averaging-definition', '逐任务计算 (DP−最佳基线)/最佳基线，再取平均。\n这是相对提升，不是增加 46.9 个百分点。', 70, 360, 480, 53, { size: 15.5, color: C.ink });
text(experimentSlide, 'benchmark-examples', '任务差异明显：BlockPush p2 +32%，Kitchen p4 +213%。', 70, 414, 480, 39, { size: 15, color: C.muted });
rule(experimentSlide, 'benchmark-divider', 70, 460, 470, 1.3, C.line);
text(experimentSlide, 'realrobot-heading', '真实机器人 · UR5 Push-T', 70, 473, 480, 27, { size: 18, color: C.plum, bold: true });
text(experimentSlide, 'realrobot-success', '95%', 70, 508, 190, 62, { size: 48, color: C.ink, bold: true });
text(experimentSlide, 'realrobot-trials', '20 次评测\n136 条示范', 266, 513, 150, 52, { size: 16, color: C.muted });
text(experimentSlide, 'realrobot-iou', 'IoU：DP 0.80，演示均值 0.84', 70, 572, 480, 27, { size: 16, color: C.ink });
text(experimentSlide, 'realrobot-baselines', '基线成功率：IBC 0%，LSTM-GMM 20%', 70, 602, 480, 27, { size: 15.5, color: C.muted });

const multimodalImage = new Uint8Array(await fs.readFile(path.join(buildDir, 'previews_final_v2', 'slide-02.png')));
experimentSlide.images.add({
  blob: multimodalImage,
  contentType: 'image/png',
  alt: '同一初始状态下 Diffusion Policy、LSTM-GMM、BET 与 IBC 的多模态 Push-T 轨迹对比',
  fit: 'contain',
  crop: { left: 0.4414, top: 0.3336, right: 0.0508, bottom: 0.3863 },
  position: { left: 580, top: 202, width: 625, height: 194 },
});
text(experimentSlide, 'multimodal-caption', '同一初始条件的多次 rollout：DP 保持一条连贯路线；基线会偏向单一模式或出现轨迹不一致。', 585, 405, 620, 48, { size: 15.5, color: C.ink });
rule(experimentSlide, 'bimanual-divider', 580, 467, 625, 1.3, C.line);
text(experimentSlide, 'bimanual-heading', 'IJRR 双臂扩展', 585, 480, 620, 27, { size: 18, color: C.plum, bold: true });
text(experimentSlide, 'bimanual-egg-beater', '55%', 585, 514, 180, 42, { size: 32, color: C.ochre, bold: true, align: 'center' });
text(experimentSlide, 'bimanual-egg-label', 'Egg Beater', 585, 557, 180, 28, { size: 15.5, color: C.ink, align: 'center' });
rule(experimentSlide, 'bimanual-vdiv-1', 778, 516, 1, 69, C.line);
text(experimentSlide, 'bimanual-mat', '75%', 799, 514, 180, 42, { size: 32, color: C.ochre, bold: true, align: 'center' });
text(experimentSlide, 'bimanual-mat-label', 'Mat Unrolling', 799, 557, 180, 28, { size: 15.5, color: C.ink, align: 'center' });
rule(experimentSlide, 'bimanual-vdiv-2', 991, 516, 1, 69, C.line);
text(experimentSlide, 'bimanual-shirt', '75%', 1010, 514, 180, 42, { size: 32, color: C.ochre, bold: true, align: 'center' });
text(experimentSlide, 'bimanual-shirt-label', 'Shirt Folding', 1010, 557, 180, 28, { size: 15.5, color: C.ink, align: 'center' });
text(experimentSlide, 'bimanual-context', '扩展沿用同一条件扩散框架；结果仍取决于任务与评测设置。', 585, 604, 620, 30, { size: 14.5, color: C.muted, align: 'center' });
experimentSlide.speakerNotes.text = [
  '定量结果先看基准：论文在 4 个基准、15 项任务上报告平均相对最佳基线提升 46.9%。这个数字先逐任务计算 (ours−best baseline)/best baseline，再对任务取平均，不是成功率增加 46.9 个百分点，也不能保证迁移到其他任务。结果差异很大，例如 BlockPush p2 +32%、Kitchen p4 +213%。',
  '图中多模态 rollout 展示同一初始状态下不同策略的轨迹。Diffusion Policy 的一次采样会选定一种完整的动作模式，整段轨迹更一致；LSTM-GMM 和 IBC 容易偏向一种模式，BET 缺少时间一致性。该图是定性对比，不意味着每次采样都保证成功。',
  '真实 UR5 Push-T 使用 136 条示范并评测 20 次，成功率 95%，IoU 0.80，人工示范均值 0.84；IBC 成功率 0%，LSTM-GMM 20%。IJRR 期刊扩展新增双臂任务：Egg Beater 55%，Mat Unrolling 75%，Shirt Folding 75%。这些结果说明扩散策略可以扩展到双臂场景，但不是说同一策略已经获得任务无关的普适能力。',
  '',
  '参考：Chi et al., IJRR 2025, Figure 3, Tables 1–4, Table 6, §§4–6。',
].join('\n');
experimentSlide.speakerNotes.setVisible(true);

// Keep the existing conclusion layout; attach a synthesis note without relying on stale element IDs.
const conclusionRecord = (await presentation.inspect({ select: '$.slides[*]', include: ['id', 'title'] })).records.find((r) => r.title === '结论与适用边界');
if (!conclusionRecord) throw new Error('Could not locate the conclusion slide by its title.');
const conclusionSlide = presentation.resolve(conclusionRecord.id);
conclusionSlide.speakerNotes.text = [
  '结论可以分成两层。方法层面，Diffusion Policy 把策略从预测一个动作，改为在观察条件下生成一段动作的条件分布；噪声预测提供直接的监督，支持多模态动作并保留时间一致性。系统层面，视觉编码、动作表示、采样步数、位置控制和执行长度共同决定真实表现。',
  '实验证据支持它在论文所测的 15 个任务与真实 Push-T 上有效，但论文没有证明任意分布外场景都能恢复，也没有提供安全保证。因此部署仍需要独立的限位、避障和急停机制。',
  '复现时沿数据流排查更有效：先确认动作维度、坐标系和归一化；然后确认视觉特征是否参与梯度训练、噪声目标是否对齐；再验证反向采样、DDIM 推理步数与延迟；最后在闭环下调执行长度和 warm-start，并用一致协议评测。',
  '',
  '参考：Chi et al., IJRR 2025, §§8–10。',
].join('\n');

// Page numbers update automatically after adding a dedicated DDIM page.
const pageRecords = await presentation.inspect({ select: '$.slides[*]', include: ['index', 'elements.id', 'elements.text'] });
for (const record of pageRecords.records) {
  for (const element of record.elements ?? []) {
    if (typeof element.text === 'string' && /^\d{2} \/ 09$/.test(element.text)) {
      setText(element.id, `${String(record.index + 1).padStart(2, '0')} / 10`);
    }
  }
}

if (presentation.slides.items.length !== 10) throw new Error(`Expected 10 slides, got ${presentation.slides.items.length}`);
await fs.mkdir(buildDir, { recursive: true });
const exported = await PresentationFile.exportPptx(presentation);
await exported.save(draftPath);
console.log(`Saved draft: ${draftPath}`);
