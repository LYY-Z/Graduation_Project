import fs from 'node:fs/promises';
import path from 'node:path';
import { FileBlob, PresentationFile } from '@oai/artifact-tool';

const finalPath = 'G:/毕设/02_learning/04_review/deliverables/diffusion_policy_advisor_report_10min_refined.pptx';
const outDir = 'G:/毕设/02_learning/04_review/.build_dp_advisor_detailed_20261023/previews_final';
await fs.mkdir(outDir, { recursive: true });
const p = await PresentationFile.importPptx(await FileBlob.load(finalPath));
for (const [i, slide] of p.slides.items.entries()) {
  const png = await p.export({ slide, format: 'png', scale: 1 });
  await fs.writeFile(path.join(outDir, `slide-${String(i + 1).padStart(2, '0')}.png`), new Uint8Array(await png.arrayBuffer()));
}
const inspection = await p.inspect({
  select: '$.slides[*]',
  include: ['id','index','title','elements.text','notes.text'],
});
await fs.writeFile('G:/毕设/02_learning/04_review/.build_dp_advisor_detailed_20261023/final-inspect.ndjson', inspection.ndjson, 'utf8');
console.log(JSON.stringify({ slideCount: p.slides.items.length, previewDir: outDir, titles: inspection.records.map(x => x.title) }, null, 2));
