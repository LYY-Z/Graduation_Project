import fs from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const skillDir = 'C:/Users/laiyo/.codex/plugins/cache/openai-primary-runtime/presentations/26.1022.11436/skills/Presentations';
const workspaceDir = 'G:/毕设/02_learning/04_review';
const buildDir = path.join(workspaceDir, '.build_dp_advisor_detailed_20261023');
const draftPath = path.join(buildDir, 'diffusion_policy_advisor_report_10min_refined_draft.pptx');
const finalPath = path.join(workspaceDir, 'deliverables', 'diffusion_policy_advisor_report_10min_refined.pptx');
const receiptPath = path.join(buildDir, 'diffusion_policy_advisor_report_10min_refined.validation.json');
const sourcePath = path.join(workspaceDir, 'diffusion_policy_advisor_report_10min_final.pptx');
const sourceSha256 = 'cf694ab351a490e8a1b87e040593b516950a9c8ce95bbe5893bcfc7069389713';
const expectedSlideSizeEmu = '12192000,6858000';
const runtimePython = 'C:/Users/laiyo/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe';
process.env.RUNTIME_NODE_MODULES = 'C:/Users/laiyo/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules';

const { finalizePresentation } = await import(pathToFileURL(
  path.join(skillDir, 'container_tools/artifact_tool_utils.mjs'),
).href);
await fs.mkdir(path.dirname(finalPath), { recursive: true });

const result = await finalizePresentation({
  explicitTotalSlideCount: 8,
  sourceTemplatePath: sourcePath,
  requiredTemplateReferenceSlides: [1, 2, 3, 4, 5, 6, 7, 8],
  minimumTemplateCoverageRatio: 1,
  requiredNativeTableOwnerSlides: [],
  requiredNativeChartOwnerSlides: [],
  workspaceDir,
  candidatePath: draftPath,
  finalPath,
  pythonExecutable: runtimePython,
  integrityValidatorPath: path.join(skillDir, 'container_tools/inspect_presentation_package_integrity.py'),
  layoutValidatorPath: path.join(skillDir, 'container_tools/inspect_presentation_layout_geometry.py'),
  layoutArgs: ['--expected-slide-size-emu', expectedSlideSizeEmu, '--validate-bullet-geometry', '--validate-heading-fit'],
  fontPolicy: {
    basis: 'reference',
    families: ['Microsoft YaHei', 'Cambria Math'],
    referencePath: sourcePath,
    referenceSha256: sourceSha256,
  },
  verifyArtifactToolImport: true,
  receiptPath,
});
console.log(JSON.stringify(result, null, 2));
