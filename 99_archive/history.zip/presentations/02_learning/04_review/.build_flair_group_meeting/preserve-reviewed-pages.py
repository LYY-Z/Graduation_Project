from pathlib import Path
from xml.etree import ElementTree as ET
from zipfile import ZIP_DEFLATED, ZipFile
import re
import sys

original_path, generated_path, candidate_path = map(Path, sys.argv[1:])
opc_relationships = "http://schemas.openxmlformats.org/package/2006/relationships"
office_relationships = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
presentation_ns = "http://schemas.openxmlformats.org/presentationml/2006/main"
new_slide_relationship_id = "rIdResearchPlan12"

def slide_parts(number):
    return [
        f"ppt/slides/slide{number}.xml",
        f"ppt/slides/_rels/slide{number}.xml.rels",
        f"ppt/notesSlides/notesSlide{number}.xml",
        f"ppt/notesSlides/_rels/notesSlide{number}.xml.rels",
    ]

def append_before(xml_bytes, pattern, make_element):
    xml = xml_bytes.decode("utf-8-sig")
    matches = list(re.finditer(pattern, xml))
    if len(matches) != 1:
        raise ValueError(f"Expected one matching end element, found {len(matches)}")
    match = matches[0]
    xml = xml[:match.start()] + make_element(match) + xml[match.start():]
    ET.fromstring(xml)
    return xml.encode("utf-8-sig" if xml_bytes.startswith(b"\xef\xbb\xbf") else "utf-8")

with ZipFile(original_path) as original, ZipFile(generated_path) as generated:
    original_names = set(original.namelist())
    edited_parts = {name: generated.read(name) for i in (10, 11, 12) for name in slide_parts(i)}
    for i in (10, 11, 12):
        for relationships_path in slide_parts(i)[1::2]:
            for relation in ET.fromstring(edited_parts[relationships_path]):
                target = relation.get("Target")
                if relation.get("TargetMode") != "External" and target.lstrip("/") not in original_names | edited_parts.keys():
                    raise ValueError(f"Unresolved relationship: {relationships_path} -> {target}")

    presentation_path = "ppt/presentation.xml"
    relationships_path = "ppt/_rels/presentation.xml.rels"
    content_types_path = "[Content_Types].xml"
    entries = ET.fromstring(original.read(presentation_path)).find(f"{{{presentation_ns}}}sldIdLst")
    assert len(entries) == 11
    new_numeric_id = max(int(entry.get("id")) for entry in entries) + 1
    edited_parts[presentation_path] = append_before(
        original.read(presentation_path), r"</(?P<prefix>[A-Za-z]+:)?sldIdLst>",
        lambda match: f'<{match.group("prefix") or ""}sldId id="{new_numeric_id}" xmlns:r="{office_relationships}" r:id="{new_slide_relationship_id}" />',
    )
    edited_parts[relationships_path] = append_before(
        original.read(relationships_path), r"</(?P<prefix>[A-Za-z]+:)?Relationships>",
        lambda match: f'<{match.group("prefix") or ""}Relationship Type="{office_relationships}/slide" Target="/ppt/slides/slide12.xml" Id="{new_slide_relationship_id}" />',
    )
    overrides = {entry.get("PartName"): entry.get("ContentType") for entry in ET.fromstring(generated.read(content_types_path))}
    new_names = ("/ppt/slides/slide12.xml", "/ppt/notesSlides/notesSlide12.xml")
    edited_parts[content_types_path] = append_before(
        original.read(content_types_path), r"</(?P<prefix>[A-Za-z]+:)?Types>",
        lambda match: "".join(
            f'<{match.group("prefix") or ""}Override PartName="{name}" ContentType="{overrides[name]}" />'
            for name in new_names
        ),
    )
    with ZipFile(candidate_path, "w", compression=ZIP_DEFLATED) as candidate:
        for name in original.namelist():
            candidate.writestr(name, edited_parts[name] if name in edited_parts else original.read(name))
        for name in sorted(edited_parts.keys() - original_names):
            candidate.writestr(name, edited_parts[name])
    with ZipFile(candidate_path) as candidate:
        preserve = original_names - edited_parts.keys()
        assert all(original.read(name) == candidate.read(name) for name in preserve)
        assert all(name in preserve for number in range(1, 10) for name in slide_parts(number))
        assert candidate.testzip() is None
        print(f"Preserved {len(preserve)} original package parts byte-for-byte, including all slide and notes XML for slides 1–9.")

