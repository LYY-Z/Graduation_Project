import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath, pathToFileURL} from 'node:url';
import {Presentation, PresentationFile} from '@oai/artifact-tool';

const work=path.dirname(fileURLToPath(import.meta.url));
const root=path.dirname(work);
const target=path.join(root,'deliverables','flair','FLAIR_Group_Meeting_Blue.CN.pptx');
const p=Presentation.create({slideSize:{width:1280,height:720}});
const font='Microsoft YaHei';
const c={white:'#FFFFFF',navy:'#132844',blue:'#154EAE',ink:'#17283F',muted:'#465C76',pale:'#ECF3FF',lighter:'#F6F9FF',rule:'#D5E1F0',line:'#A9BCD8'};
const paper='https://doi.org/10.1038/s41467-026-70256-y';
const supplement='https://static-content.springer.com/esm/art%3A10.1038%2Fs41467-026-70256-y/MediaObjects/41467_2026_70256_MOESM1_ESM.pdf';
const repo='https://github.com/adaptive-intelligent-robotics/FLAIR/tree/v1.0.0';
const data='https://zenodo.org/records/14546657';
const study='G:/毕设/02_learning/';

function box(s,x,y,w,h,color,name='色块'){
 return s.shapes.add({name,geometry:'rect',position:{left:x,top:y,width:w,height:h},fill:color,line:{fill:'none',width:0}});
}
function text(s,str,x,y,w,h,o={}){
 const q=s.shapes.add({name:str.split('\n')[0].slice(0,35),geometry:'textbox',position:{left:x,top:y,width:w,height:h},fill:'none',line:{fill:'none',width:0}});
 q.text=str;
 q.text.style={typeface:font,fontSize:o.size??25,bold:o.bold??false,color:o.color??c.ink,alignment:o.align??'left',verticalAlignment:'top',insets:0,wrap:'none',autoFit:'none'};
 return q;
}
function slide(title,sub){
 const s=p.slides.add();
 s.background.fill=c.white;
 box(s,0,0,1280,9,c.blue,'页眉蓝线');
 if(title)text(s,title,68,58,1144,64,{size:46,bold:true,color:c.navy});
 if(sub)text(s,sub,70,133,1142,38,{size:22,color:c.muted});
 return s;
}
function note(s,script,refs){s.speakerNotes.text=[script,'参考资料',...refs].join('\n\n');}
function horizontal(s,x,y,w,color=c.rule,h=2){box(s,x,y,w,h,color,'分隔线');}
function heading(s,label,body,x,y,w,opts={}){
 text(s,label,x,y,w,40,{size:opts.head??27,bold:true,color:c.blue});
 text(s,body,x,y+49,w,opts.height??80,{size:opts.size??24});
}
async function img(s,file,x,y,w,h,alt,fit='contain'){
 const b=await fs.readFile(path.join(work,file));
 s.images.add({blob:b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength),contentType:'image/png',position:{left:x,top:y,width:w,height:h},fit,alt});
}
function comparisonTable(s,rows,x,y,ws,hs){
 const w=ws.reduce((a,b)=>a+b,0);
 const h=hs.reduce((a,b)=>a+b,0);
 const t=s.tables.add({rows:rows.length,columns:ws.length,left:x,top:y,width:w,height:h,columnWidths:ws,values:rows});
 t.styleOptions={headerRow:false,firstColumn:false,bandedRows:false,bandedColumns:false};
 t.borders.assign({style:'solid',fill:c.rule,width:0.7});
 for(let i=0;i<rows.length;i++){
  t.rows[i].height=hs[i];
  for(let j=0;j<ws.length;j++){
   const color=i===0?c.blue:j===0?c.pale:i%2===0?c.lighter:c.white;
   t.cells.block({row:i,column:j,rowCount:1,columnCount:1}).assign({fill:color,margins:{left:17,right:12,top:7,bottom:7},anchor:'middle'});
   t.getCell(i,j).text.style={typeface:font,fontSize:i===0?22:21,color:i===0?c.white:c.ink,bold:i===0||j===0,verticalAlignment:'middle'};
  }
 }
}

// 1. Cover
{
 const s=slide();
 box(s,614,74,598,498,c.pale,'实机照片浅蓝衬底');
 await img(s,'gvr_bot2.png',634,94,558,431,'FLAIR 的履带机器人 GVR-Bot 在论文实机赛道上','cover');
 text(s,'FLAIR',68,141,520,118,{size:102,bold:true,color:c.blue});
 text(s,'论文研读与六足仿真复现',72,278,535,64,{size:40,bold:true,color:c.navy});
 text(s,'Go2-W 扰动恢复研究计划',73,368,530,52,{size:27,color:c.muted});
 text(s,'GVR-Bot · FLAIR 实机评测平台',646,536,545,27,{size:17,color:c.muted,align:'right'});
 horizontal(s,70,600,1142);
 text(s,'Allard 等 · Nature Communications · 2026',70,623,1137,35,{size:19,color:c.muted});
 note(s,'这次汇报先讲 FLAIR 如何恢复受扰机器人的指令跟踪，以及论文分别用哪些实机和仿真实验验证。接着汇报已完成的六足复现，最后提出 Go2-W 的课题：用主动试探获得反馈，能不能让在线补偿恢复得更快。',[paper,'封面实机图来自作者公开示例 '+repo+'/fast_adaptation/example/gifs/gvr_bot.gif']);
}

// 2. Paper question and method
{
 const s=slide('FLAIR 的研究问题与方法');
 text(s,'Question  研究问题',70,162,1140,40,{size:25,bold:true,color:c.blue});
 text(s,'机器人在运行中受扰后，能否用新反馈恢复指令跟踪？',69,216,1143,67,{size:39,bold:true,color:c.navy});
 text(s,'例如期望直行，但单侧驱动减弱后，同样的指令会使机器人偏转。',70,294,1142,44,{size:23,color:c.muted});
 horizontal(s,70,375,1142);
 text(s,'Method  在线学习与补偿',70,404,1143,40,{size:25,bold:true,color:c.blue});
 heading(s,'采集响应','配对已执行的指令\n与实际车体运动。',70,484,355,{head:29,size:24});
 heading(s,'在线拟合','全局模型估计整体偏差，\n局部高斯过程细化预测。',456,484,355,{head:29,size:24});
 heading(s,'修正指令','在原有底层控制器前补偿，\n使实际运动接近期望。',842,484,365,{head:29,size:24});
 note(s,'论文的核心问题是恢复可操控性。速度指令的含义没有变，机器人的响应可能因驱动降额或外界扰动而变化。FLAIR 在原控制器前增加一层补偿，用近期指令与反馈在线拟合响应。全局模型先解释大范围偏差，再由局部高斯过程细化预测。作者利用响应模型修正下一条速度指令，底层控制器继续执行。六足默认代码的状态模型求逆细节见学习文档。',[paper+' Introduction、Methods 与 Fig. 2',study+'flair/02_feedback_and_adaptation.md']);
}

// 3. Paper evaluation. Platform, scenario, comparators, and metrics.
{
 const s=slide('实机与仿真评测','实机检验真实场景下的补偿表现，六足仿真检验方法在另一平台上的适用性。');
 comparisonTable(s,[
  ['评测维度','GVR-Bot 履带车实机','Brax 六足机器人仿真'],
  ['Benchmark','3 条赛道，5 个评价区段','Chicane 弯道，16 个航点跑两圈'],
  ['扰动设置','履带降额、模拟风与颠簸\n包括运行中变化的场景','右侧中腿两处执行器减力\n从回合初始化开始生效'],
  ['Baseline','Driver、LQR、L₁ 自适应控制、在线残差 RL\n另含无扰动参考组','健康与减力各比 FLAIR 开、关\n四组使用相同的底层步态库'],
  ['评价指标','VICON 测量的跟踪误差、完成时间','前进速度和偏航率的跟踪误差、完成时间']
 ],69,186,[210,490,443],[49,61,82,86,64]);
 text(s,'实机结果',70,579,163,44,{size:26,bold:true,color:c.blue});
 text(s,'按论文汇总口径，FLAIR 消除了 74.4% 的扰动额外跟踪误差。',231,581,979,50,{size:24,bold:true,color:c.navy});
 note(s,'实机实验使用作者自建的赛道和扰动组合。Driver 是无在线补偿的原始驾驶器，另外用 LQR、L₁ 自适应控制和在线残差强化学习作对照。残差 RL 没有完成 Chicane，相关评测范围应按原文报告。74.4% 是实机多区段汇总的额外误差恢复比例，分母由健康参考构造。六足实验考查固定减力时开关补偿有何变化，四组各 20 回合。',[paper+' Results、Fig. 4、表 1',supplement+' Supplementary Baselines 和 Hexapod Results']);
}

// 4. Reproduction evidence
{
 const s=slide('六足仿真复现结果','沿用原版 Chicane 路线、扰动设置和步态库，独立重跑健康与减力四组。');
 box(s,69,192,410,329,c.lighter,'六足场景衬底');
 text(s,'80 / 80',91,386,357,78,{size:59,bold:true,color:c.blue});
 text(s,'正式回合全部到达末航点',95,470,354,36,{size:22,color:c.muted});
 await img(s,'hexapod1.png',89,210,370,161,'作者示例中的 Brax 六足机器人');
 horizontal(s,537,200,675,c.rule);
 text(s,'减力组跟踪误差',538,220,420,35,{size:25,bold:true});
 text(s,'0.05036 → 0.04379',538,273,423,54,{size:38,bold:true,color:c.navy});
 text(s,'下降 13.0%',975,279,237,45,{size:30,bold:true,color:c.blue,align:'right'});
 horizontal(s,537,355,675,c.rule);
 text(s,'减力组完成时间',538,376,420,34,{size:25,bold:true});
 text(s,'197.05 → 170.60 秒',538,429,430,54,{size:36,bold:true,color:c.navy});
 text(s,'缩短 26.45 秒',974,433,238,45,{size:29,bold:true,color:c.blue,align:'right'});
 horizontal(s,69,559,1143);
 text(s,'先复算作者数据，原版四组各试跑 1 回合，再用 CPU 加速入口完成四组各 20 回合。',70,581,1142,43,{size:21,color:c.muted});
 text(s,'右侧为组中位数，箭头表示从关闭到开启 FLAIR。',70,625,1142,29,{size:18,color:c.muted});
 note(s,'本次从作者发布的四组数据复算开始，再独立跑通原版，最后用 CPU 加速入口完成各 20 回合。加速实现与原版核对过六批网格数据和同种子前 110 个控制步，整圈逐值一致性尚未验证。独立数据按作者统计口径，减力时的总跟踪误差降低约 13.0%，完成时间缩短 26.45 秒，方向与作者一致。作者报告的 138.8% 用因减力增加的额外误差作分母。现有证据针对六足固定减力。',[data,repo,study+'flair_results/comparison_metrics.csv',study+'flair_reproduction_execution.md']);
}

// 5. Link reproduction to the research direction.
{
 const s=slide('Go2-W 选题与基线','研究机器人遇到突发轮端降额或打滑时，怎样更快恢复速度跟踪。');
 box(s,69,196,1143,116,c.pale,'主基线摘要');
 text(s,'FLAIR',91,220,220,52,{size:32,bold:true,color:c.blue});
 text(s,'主基线',92,266,220,30,{size:19,bold:true,color:c.muted});
 text(s,'六足仿真已跑通，补偿作用在车体速度层。\nGo2-W 可沿用这个接口，比较不同恢复策略。',312,219,879,79,{size:25});
 horizontal(s,69,341,1143);
 text(s,'TAM',92,374,220,46,{size:28,bold:true,color:c.navy});
 text(s,'基于历史修正机械臂的关节力矩。',312,378,870,44,{size:25});
 horizontal(s,69,447,1143);
 text(s,'LocoFormer',92,480,219,45,{size:28,bold:true,color:c.navy});
 text(s,'通过长历史在不同本体上适应运动。',312,484,876,43,{size:25});
 horizontal(s,69,550,1143);
 text(s,'研究变量',69,584,173,37,{size:25,bold:true,color:c.blue});
 text(s,'在同一底层策略和补偿器上，比较主动试探带来的恢复收益。',240,584,971,40,{size:24,bold:true,color:c.navy});
 note(s,'选 FLAIR 的主要原因是它研究的也是受扰后的在线恢复，而且它的动作接口就在车体速度层。我们在 Go2-W 上继续用同一底层速度跟踪策略，可以把实验变量集中到上层。TAM 研究的是机械臂力矩补偿，LocoFormer 的核心是跨本体和历史适应，二者为相关工作。后续用运行中扰动明确划定恢复时窗，在已有 FLAIR 能力之上考查主动试探的具体价值。',[paper,'TAM https://github.com/Dongwon-Son/TAM','LocoFormer https://generalist-locomotion.github.io/',study+'flair/04_go2w_paper_plan.md']);
}

// 6. Innovation in one slide
{
 const s=slide('用试探反馈的恢复收益训练 PPO','用同动作对照衡量采到的数据能否改善后续补偿。');
 box(s,69,198,1143,85,c.blue,'共同试探');
 text(s,'同一次试探',90,221,254,47,{size:32,bold:true,color:c.white});
 text(s,'两条仿真分支共享动作、反馈和试探结束时的状态',358,226,828,40,{size:24,color:c.white});
 box(s,357,283,2,32,c.line,'分支连接线');
 box(s,929,283,2,32,c.line,'分支连接线');
 box(s,69,315,558,144,c.pale,'采纳反馈分支');
 box(s,654,315,558,144,c.lighter,'屏蔽反馈分支');
 heading(s,'A  采纳反馈','用本次反馈更新 FLAIR，再继续恢复。',88,338,520,{head:28,size:22});
 heading(s,'B  屏蔽反馈','跳过这批反馈的模型更新，再继续恢复。',673,338,521,{head:28,size:22});
 text(s,'比较试探结束后的跟踪误差',70,499,1142,47,{size:31,bold:true,color:c.navy});
 text(s,'把误差差值作为 PPO 的辅助训练信号，学习何时试探以及试探幅度。',70,559,1140,43,{size:24,color:c.muted});
 note(s,'同一次短时小幅转向本身就可能纠偏，所以两支使用同样的试探和末态。唯一干预是这批反馈能否进入 FLAIR 模型。随后在相同参考及评估时窗内计算 B 的累计跟踪误差减 A 的误差，正值表明反馈改善了闭环恢复。PPO 用该差值作为辅助信号，主奖励仍反映任务表现、稳定性和试探代价。研究贡献要由消融验证，即普通试探 PPO 与加入这一信号的 PPO 是否表现不同。',[study+'flair/04_go2w_paper_plan.md','主动诊断近邻工作 https://papers.ssrn.com/sol3/papers.cfm?abstract_id=7345456','反事实探索近邻工作 https://arxiv.org/abs/2106.00266']);
}

// 7. Work plan, with concrete stages and evaluation
{
 const s=slide('后续工作计划','先验证试探反馈是否有效，再在 Go2-W 上训练和测试。');
 const stages=[
  ['六足机制验证','用已有仿真跑通同动作双分支，检查采用反馈后能否稳定改善跟踪。'],
  ['Go2-W 仿真','接入 FLAIR，模拟途中降额与打滑，按相同仿真预算比较试探策略。'],
  ['Go2-W 实机','核对测速与时间同步，选择有代表性的扰动开展重复验证。']
 ];
 for(const [i,[title,body]] of stages.entries()){
  const y=190+117*i;
  horizontal(s,69,y,1143);
  text(s,title,70,y+25,250,37,{size:28,bold:true,color:c.blue});
  text(s,body,324,y+29,888,52,{size:23});
 }
 box(s,69,553,1143,111,c.pale,'对照与评价');
 text(s,'对照',91,573,116,35,{size:22,bold:true,color:c.blue});
 text(s,'原 FLAIR、普通试探 PPO、加入反馈收益的 PPO',200,573,993,36,{size:22});
 text(s,'指标',91,617,116,35,{size:22,bold:true,color:c.blue});
 text(s,'恢复时间、累计跟踪误差、试探次数与失稳率',200,617,993,35,{size:22});
 note(s,'下一步先用六足现有环境验证双分支，并确认反馈开关确实能改变后续恢复。如果机制成立，再在同一 Go2-W 底层策略上接入三种比较方法。仿真实验以回合中途发生的扰动为主，在相同预算下比较恢复速度和稳定性。最后选择可重复的代表性场景开展实机试验。',[study+'flair/04_go2w_paper_plan.md','Robot Lab Go2-W 任务 https://github.com/fan-ziqi/robot_lab/tree/v2.3.2/source/robot_lab/robot_lab/tasks/manager_based/locomotion/velocity/config/wheeled/unitree_go2w']);
}

const candidate=path.join(work,'candidate-group-meeting-blue.pptx');
await (await PresentationFile.exportPptx(p)).save(candidate);
const skill='C:/Users/laiyo/.codex/plugins/cache/openai-primary-runtime/presentations/26.1112.11217/skills/presentations';
const python='C:/Users/laiyo/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe';
const {finalizePresentation}=await import(pathToFileURL(path.join(skill,'container_tools','artifact_tool_utils.mjs')).href);
await finalizePresentation({
 workspaceDir:root,candidatePath:candidate,finalPath:target,pythonExecutable:python,
 integrityValidatorPath:path.join(skill,'container_tools','inspect_presentation_package_integrity.py'),
 layoutValidatorPath:path.join(skill,'container_tools','inspect_presentation_layout_geometry.py'),
 layoutArgs:['--expected-slide-size-emu','12192000,6858000','--validate-heading-fit','--require-native-table-slide','3'],
 requiredNativeTableOwnerSlides:[3],explicitTotalSlideCount:7,
 fontPolicy:{basis:'design',families:[font]},verifyArtifactToolImport:true,
 receiptPath:path.join(work,'validation-group-meeting-blue.json')
});
console.log(target);

