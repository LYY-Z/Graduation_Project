import fs from 'node:fs/promises';
import path from 'node:path';

import {fileURLToPath, pathToFileURL} from 'node:url';
import {Presentation, PresentationFile} from '@oai/artifact-tool';

const work=path.dirname(fileURLToPath(import.meta.url));
const root=path.dirname(work);
const target=path.join(root,'deliverables','flair','FLAIR_Paper_Review_and_Go2W_Research.EN.pptx');
const p=Presentation.create({slideSize:{width:1280,height:720}});
const font='Microsoft YaHei';
const c={white:'#FFFFFF',navy:'#132844',blue:'#154EAE',ink:'#17283F',muted:'#465C76',pale:'#ECF3FF',lighter:'#F6F9FF',rule:'#D5E1F0',line:'#A9BCD8'};
const paper='https://doi.org/10.1038/s41467-026-70256-y';
const supplement='https://static-content.springer.com/esm/art%3A10.1038%2Fs41467-026-70256-y/MediaObjects/41467_2026_70256_MOESM1_ESM.pdf';
const repo='https://github.com/adaptive-intelligent-robotics/FLAIR/tree/v1.0.0';
const data='https://zenodo.org/records/14546657';
const study='G:/毕设/02_learning/';

function box(s,x,y,w,h,color,name='Color block'){
 return s.shapes.add({name,geometry:'rect',position:{left:x,top:y,width:w,height:h},fill:color,line:{fill:'none',width:0}});
}
function text(s,str,x,y,w,h,o={}){
 const q=s.shapes.add({name:str.split('\n')[0].slice(0,35),geometry:'textbox',position:{left:x,top:y,width:w,height:h},fill:'none',line:{fill:'none',width:0}});
 q.text=str;
 q.text.style={typeface:font,fontSize:o.size??25,bold:o.bold??false,color:o.color??c.ink,alignment:o.align??'left',verticalAlignment:'top',insets:0,wrap:'none',autoFit:'none'};
 return q;
}
function slide(title,sub){
 const s=p.slides.add();
 s.background.fill=c.white;
 box(s,0,0,1280,9,c.blue,'Blue top rule');
 if(title)text(s,title,68,58,1144,64,{size:46,bold:true,color:c.navy});
 if(sub)text(s,sub,70,133,1142,38,{size:22,color:c.muted});
 return s;
}
function note(s,script,refs){s.speakerNotes.text=[script,'References',...refs].join('\n\n');}
function horizontal(s,x,y,w,color=c.rule,h=2){box(s,x,y,w,h,color,'Separator rule');}
function heading(s,label,body,x,y,w,opts={}){
 text(s,label,x,y,w,40,{size:opts.head??27,bold:true,color:c.blue});
 text(s,body,x,y+49,w,opts.height??80,{size:opts.size??24});
}
async function img(s,file,x,y,w,h,alt,fit='contain'){
 const b=await fs.readFile(path.join(work,file));
 s.images.add({blob:b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength),contentType:'image/png',position:{left:x,top:y,width:w,height:h},fit,alt});
}
function comparisonTable(s,rows,x,y,ws,hs,emphasis=[]){
 const w=ws.reduce((a,b)=>a+b,0);
 const h=hs.reduce((a,b)=>a+b,0);
 const t=s.tables.add({rows:rows.length,columns:ws.length,left:x,top:y,width:w,height:h,columnWidths:ws,values:rows});
 t.styleOptions={headerRow:false,firstColumn:false,bandedRows:false,bandedColumns:false};
 t.borders.assign({style:'solid',fill:c.rule,width:0.7});
 for(let i=0;i<rows.length;i++){
  t.rows[i].height=hs[i];
  for(let j=0;j<ws.length;j++){
   const highlighted=rows[i][0]==='FLAIR'||rows[i][0]==='减力，FLAIR 开'||emphasis.some(([row,col])=>i===row&&j===col);
   const color=i===0?c.blue:highlighted?c.pale:j===0?c.pale:i%2===0?c.lighter:c.white;
   t.cells.block({row:i,column:j,rowCount:1,columnCount:1}).assign({fill:color,margins:{left:17,right:12,top:7,bottom:7},anchor:'middle'});
   t.getCell(i,j).text.style={typeface:font,fontSize:i===0?22:21,color:i===0?c.white:c.ink,bold:i===0||j===0||highlighted,verticalAlignment:'middle'};
  }
 }
}

// 1. Cover
{
 const s=slide();
 box(s,614,74,598,498,c.pale,'Photo background');
 await img(s,'gvr_bot2.png',634,94,558,431,'GVR-Bot on one of the paper’s real-world test courses','cover');
 text(s,'FLAIR',68,135,520,122,{size:102,bold:true,color:c.blue});
 text(s,'Online Recovery\nUnder Disturbances',72,265,530,115,{size:43,bold:true,color:c.navy});
 text(s,'Paper review, hexapod reproduction,\nand Go2-W research plan',73,408,530,91,{size:26,color:c.muted});
 text(s,'GVR-Bot hardware platform',646,537,545,29,{size:18,color:c.muted,align:'right'});
 horizontal(s,70,601,1142);
 text(s,'Allard et al., Nature Communications, 2026',70,622,1138,38,{size:19,color:c.muted});
 note(s,'Today I will discuss the FLAIR paper, our reproduction of its simulated hexapod experiments, and our research plan for Go2-W. The photo shows the tracked robot used in the paper’s hardware experiments. I will first explain how FLAIR recovers command tracking during motion, then report what we reproduced. The last part asks which brief probing actions can collect useful data for a wheeled quadruped after a disturbance.',[paper,'GVR-Bot photo '+repo+'/fast_adaptation/example/gifs/gvr_bot.gif']);
}

// 2. Research question and contribution
{
 const s=slide('Research Question and Contributions');
 text(s,'How can a robot recover velocity tracking\nafter a disturbance during motion?',69,144,1141,113,{size:45,bold:true,color:c.navy});
 text(s,'For example, loss of drive on one side can make a straight command turn the robot.',70,272,1140,45,{size:25,color:c.muted});
 box(s,69,331,1143,67,c.pale,'Challenge');
 text(s,'Challenge',89,346,170,41,{size:23,bold:true,color:c.blue});
 text(s,'Adapt to unknown, changing disturbances while moving, with limited and noisy data.',259,347,930,41,{size:22});
 text(s,'Contributions',70,421,1140,39,{size:24,bold:true,color:c.blue});
 const rows=[
  ['Control interface','Correct body-velocity commands before they reach the existing low-level controller.'],
  ['Online adaptation','Combine global and local response models, with a reset when conditions change.'],
  ['Evaluation','Test the compensation layer on a tracked robot and a simulated hexapod.']
 ];
 rows.forEach(([a,b],i)=>{const y=478+56*i;text(s,a,70,y,211,36,{size:22,bold:true,color:c.navy});text(s,b,284,y,925,36,{size:22});});
 note(s,'Imagine that the robot receives a straight-ahead command. With one track weakened, the same command can make the robot turn. The control objective is to bring measured forward velocity and yaw rate back toward the operator’s intent. The disturbance may be unknown and may change during the run. FLAIR places an adaptive layer above the existing low-level controller. The paper contributes the compensation architecture, the online model and reset mechanism, and evaluation across tracked hardware and a simulated legged platform.',[paper+' Introduction, Methods and Discussion']);
}

// 3. Related methods
{
 const s=slide('Related Control Methods','The categories differ in how they produce compensation at deployment.');
 comparisonTable(s,[
  ['Approach','Representative methods','Strengths and assumptions'],
  ['Fixed-model feedback','LQR','Fast and interpretable.\nFixed gains depend on model accuracy.'],
  ['Online disturbance estimation','L₁ adaptive control','Estimates disturbances during operation.\nDepends on the reference model and assumptions.'],
  ['Learned control policies','Online residual TD3 (baseline)\nRMA and LocoFormer (related)','TD3 learns corrections through interaction.\nRMA and LocoFormer use training and history.'],
  ['Online response modeling','FLAIR and OSRAM','Learns how commands affect motion.\nNeeds usable feedback and command coverage.']
 ],69,181,[270,325,548],[48,80,80,86,86]);
 text(s,'LQR, L₁ and online TD3 are hardware baselines in the FLAIR paper.',70,598,1140,34,{size:22,bold:true,color:c.blue});
 text(s,'The related methods illustrate approaches evaluated under different settings.',70,635,1140,31,{size:19,color:c.muted});
 note(s,'LQR applies feedback with fixed gains in the paper’s implementation. L₁ estimates the disturbance online. Residual TD3 learns the corrective action directly and must collect interactions from a cold start in this comparison. RMA and LocoFormer learn from training beforehand and use interaction history at deployment. FLAIR instead fits a command-to-response model online and uses it to select a correction. OSRAM is a related example of closed-loop response modeling. The direct hardware comparisons in this paper are LQR, L₁ and residual TD3.',[supplement+' Supplementary Baselines','RMA https://arxiv.org/abs/2107.04034','LocoFormer https://generalist-locomotion.github.io/','OSRAM https://arxiv.org/abs/2609.28878']);
}

// 4. How FLAIR learns
{
 const s=slide('How FLAIR Learns and Compensates','An online model predicts how the robot will respond to a candidate velocity command.');
 const steps=[
  ['Collect','Align each issued command with the later measured response.\nRetain samples across different commands.'],
  ['Fit','Estimate the global bias by least squares. Refine local predictions\nwith a Gaussian process.'],
  ['Compensate','Choose the command whose predicted response best matches the target velocity.\nSend it to the existing low-level controller.'],
  ['Reset','Monitor prediction errors. On a detected change in conditions,\nclear old data and fit again.']
 ];
 steps.forEach(([a,b],i)=>{const y=183+i*92;horizontal(s,69,y,1143);text(s,a,70,y+19,189,39,{size:27,bold:true,color:c.blue});text(s,b,265,y+17,943,66,{size:22});});
 box(s,69,568,1143,78,c.pale,'Offline and online components');
 text(s,'The compensation model is fit online. The simulated hexapod uses a gait library built offline.',87,590,1101,44,{size:22,bold:true,color:c.navy});
 note(s,'The first step is to pair a command with the corresponding measured response. Alignment matters because measurements immediately after a new command may still reflect the preceding one. The global model estimates broad effects such as a consistent yaw bias under forward commands. A local Gaussian process refines the response around particular commands. FLAIR then chooses a suitable command and lets the original controller execute it. The model is fit online. The simulated hexapod uses the authors’ offline gait repertoire.',[paper+' Methods and Algorithm 1',supplement+' Hexapod Results']);
}

// 5. Benchmarks
{
 const s=slide('Benchmarks and Evaluation Protocol','Hardware tests cover several disturbances. Hexapod tests use a different low-level controller.');
 comparisonTable(s,[
  ['Design','GVR-Bot hardware','Brax hexapod simulation'],
  ['Task and platform','Autonomous driver\n3 courses, 5 settings','18-DoF hexapod, 2 laps of Chicane'],
  ['Disturbances','Fixed or changing derating, ramp slip and bumps\nHeading-dependent simulated wind','Two weakened actuators on the right middle leg\nDerating starts at episode initialization'],
  ['Comparisons','Driver, LQR, L₁ and online residual TD3\nUndisturbed Driver is the reference','FLAIR on/off × healthy/weakened\nShared gait library across all four groups'],
  ['Evaluation','VICON tracks actual motion.\n20 repeats for error and completion time.','Simulated velocity and logged time\nGroup median over 20 episodes']
 ],69,181,[195,485,463],[49,72,89,89,89]);
 text(s,'Velocity tracking error is the primary metric. Completion time gives a second measure of task performance.',70,607,1141,48,{size:21,bold:true,color:c.blue});
 note(s,'The tracked GVR-Bot follows a course with an autonomous driver. The five settings are static and dynamic Chicane, ramp, simulated wind and the robustness course with bumps and obstacles. VICON is used for external evaluation. The simulator uses an 18-degree-of-freedom hexapod and a fixed weakening of two actuators on its right middle leg. The simulation crosses healthy or weakened hardware with FLAIR on or off. These designs test several real-world conditions and reuse of the compensation layer with a distinct gait controller.',[paper+' Results and Figures 3–4',supplement+' Hexapod Results and Supplementary Results']);
}

// 6. Hardware results
{
 const s=slide('Where FLAIR Improves Hardware Performance','Values are increases relative to undisturbed Driver. Lower is better.');
 comparisonTable(s,[
  ['Method','Excess tracking error','Excess completion time','Excess error on dynamic Chicane'],
  ['Driver','39.3%','53.3%','39.3%'],
  ['LQR','20.6%','18.9%','24.6%'],
  ['L₁ adaptive','25.6%','20.8%','30.3%'],
  ['FLAIR','10.3%','9.5%','17.1%']
 ],69,179,[192,267,278,406],[51,49,49,49,49]);
 text(s,'FLAIR has lower tracking error than LQR and L₁ on dynamic Chicane, the ramp, simulated wind and bumps.',70,453,1140,43,{size:21,bold:true,color:c.blue});
 text(s,'On static Chicane, L₁ and FLAIR are close (7.4% vs. 7.5%). Online TD3 did not complete Chicane.',70,507,1140,42,{size:22});
 text(s,'The first two metrics are medians across five settings. The median fraction of excess tracking error removed is 74.4%.',70,570,1140,42,{size:19,color:c.muted});
 note(s,'The values are relative to the undisturbed Driver in the relevant setting. FLAIR’s median excess tracking error is 10.3%, compared with 20.6% for LQR and 25.6% for L₁. The dynamic Chicane column isolates the case in which the disturbance changes during motion. FLAIR has 17.1% excess error there, compared with 24.6% and 30.3%. The static Chicane results are close. Online TD3 did not complete Chicane. The 74.4% is the median of the five shares of excess tracking error removed, calculated separately for each setting.',[paper+' Table 1 and Figure 4',supplement+' Tables 3–4 and RL baseline']);
}

// 7. Evidence and limitations
{
 const s=slide('Experimental Evidence and Limitations');
 const rows=[
  ['System-wide response changes','Global model learns velocity scaling','Fixed derating and hexapod weakening'],
  ['Disturbance changes during motion','Detect changes and refit','Dynamic Chicane and\nramp-to-wind transition'],
  ['State-dependent bias and noisy data','State-conditioned model and sample filtering','Heading-dependent wind and bumpy terrain']
 ];
 comparisonTable(s,[['Challenge','Design','Supporting test'],...rows],69,160,[343,385,415],[47,64,69,65]);
 text(s,'Median model update time across five settings is 218 ms. Recovery time is measured from disturbance onset.',70,428,1140,32,{size:19,color:c.muted});
 box(s,69,467,1143,171,c.pale,'Limitations');
 text(s,'Limitations',89,478,1087,42,{size:28,bold:true,color:c.blue});
 text(s,'•  Recovery depends on usable feedback and remaining actuation authority.\n•  The global prior assumes differential-drive-like responses. Complex bodies and independent lateral forces have less evidence.\n•  Course results evaluate the full method. Isolating individual contributions requires targeted comparisons.',89,527,1100,102,{size:18});
 note(s,'The experimental settings correspond to different reasons a controller can lose performance. Fixed derating tests the overall response model. Dynamic Chicane and a transition between course sections address changing conditions. Simulated wind and bumps test the combined handling of state dependence and noisy feedback. The course results support the full method and leave individual effects for targeted experiments. The reported 218 ms measures model updates. Event-level recovery also includes collecting useful feedback and applying the correction. The usable range depends on feedback quality, attainable actions and the suitability of the differential-drive prior.',[paper+' Methods, Figure 5 and Discussion',supplement+' Boundary Analysis']);
}

// 8. Reproduction workflow
{
 const s=slide('Hexapod Reproduction Workflow','We fixed FLAIR v1.0.0, the original gait library and the Chicane route.');
 heading(s,'Verify the published data','Recompute results for all four groups and check the\nreported 138.8% reduction in excess tracking error.',69,181,601,{head:25,size:20});
 horizontal(s,69,290,566);
 heading(s,'Run the official release','Run one episode per group in an independent CPU setup.',69,311,601,{head:25,size:20});
 horizontal(s,69,410,566);
 heading(s,'Run independent repeats','Identify the grid-processing bottleneck and validate\na faster entry point. Run 80 episodes in 4 seed batches.',69,430,595,{head:25,size:20});
 await img(s,'../../flair_results/smoke-v100-long_trajectories.png',675,172,536,419,'Official-code smoke-test trajectories and reference waypoints');
 text(s,'Official-code smoke tests. Dashed lines are reference routes.',676,608,533,34,{size:16,color:c.muted,align:'right'});
 note(s,'We first recomputed the four groups from the released data and notebook. Then we set up an independent Conda and JAX CPU environment and ran one episode per group using the official release. The plots on the right are from those smoke tests. For the 80 formal runs, we used an external acceleration entry point for grid processing while retaining the official source. The comparison against the official path covered six grid batches and the first 110 control steps under the same seed. The full runs comprise four seed batches, each with four groups of five episodes.',[repo,data,study+'flair_reproduction_execution.md',study+'flair_results/smoke-v100-long_trajectories.png']);
}

// 9. Reproduction results
{
 const s=slide('Reproduced Gains Under Fixed Derating','We crossed healthy and weakened conditions with FLAIR on and off. All 80 episodes reached the final waypoint.');
 comparisonTable(s,[
  ['Group (20 episodes each)','Published error','Reproduced error','Reproduced time'],
  ['Healthy, FLAIR off','0.04599','0.04596','180.25 s'],
  ['Healthy, FLAIR on','0.04370','0.04371','151.60 s'],
  ['Weakened, FLAIR off','0.05032','0.05036','197.05 s'],
  ['Weakened, FLAIR on','0.04431','0.04379','170.60 s']
 ],69,181,[326,213,255,349],[49,49,49,49,49],[[4,1],[4,2],[4,3]]);
 text(s,'13.0% lower',70,459,520,64,{size:43,bold:true,color:c.blue});
 text(s,'Total tracking error under fixed derating',71,525,540,38,{size:22});
 text(s,'26.45 s faster',648,459,565,64,{size:43,bold:true,color:c.blue});
 text(s,'Completion time under fixed derating',650,525,561,38,{size:22});
 text(s,'Table values are group medians. With native Brax yaw rate and time alignment, error still drops by about 12.1%.',70,596,1140,45,{size:19,color:c.muted});
 note(s,'All 80 runs reached the final waypoint. With weakened actuators, the median total tracking error decreases from 0.05036 to 0.04379, a relative decrease of 13.0%. Completion time drops from 197.05 to 170.60 seconds, a difference of 26.45 seconds. The published 138.8% uses excess error above the healthy reference as its denominator. The 13.0% uses the total error in our weakened FLAIR-off group. Recomputing the aligned metric with native Brax yaw rate still shows a decrease of about 12.1%. These are fixed-derating reproduction results.',[study+'flair_results/comparison_metrics.csv',study+'flair_results/formal_trials.csv',data]);
}

// 10. Research topic
{
 const s=slide('Go2-W Research Topic');
 text(s,'Working title',70,150,1138,35,{size:22,bold:true,color:c.blue});
 text(s,'Active Probing for Disturbance Recovery in Wheeled Quadrupeds\nUsing Upcoming Motion Commands',69,190,1144,106,{size:34,bold:true,color:c.navy});
 text(s,'After a disturbance, does an upcoming straight segment or turn change which probe is worth making?',70,302,1140,42,{size:22});
 horizontal(s,69,363,1143);
 text(s,'FLAIR data bins',70,387,280,41,{size:25,bold:true,color:c.blue});
 text(s,'Preserve feedback for different commands. After a disturbance, there may be\nlittle fresh data near commands needed for the next maneuver.',355,388,845,69,{size:22});
 horizontal(s,69,474,1143);
 text(s,'Proposed decision',70,497,280,41,{size:25,bold:true,color:c.blue});
 text(s,'Use recent feedback and known upcoming commands to decide whether and\nhow to probe. Score the data by its effect on subsequent tracking.',355,498,845,69,{size:22});
 box(s,69,606,1143,58,c.pale,'Scope');
 text(s,'Scope   Recovery of body-velocity tracking on Go2-W after in-run single-wheel derating or slip.',87,621,1103,35,{size:21,bold:true,color:c.navy});
 note(s,'The research question is whether the upcoming maneuver changes what feedback is worth collecting after a disturbance. FLAIR already maintains samples across different commands. Following a sudden change, the relevant part of the command space may still lack fresh measurements. The hypothesis is that a brief probe can fill a useful gap if we know which commands the path follower will request next. Straight segments can already contain steering corrections, so we will inspect the issued commands and the samples accepted by FLAIR. This turns a coverage concern into a testable question about recovery.',[paper+' Command-aware Data Storage','BARL https://papers.neurips.cc/paper_files/paper/2022/hash/b90cb10d4dae058dd167388e76168c1b-Abstract-Conference.html','SIP https://www.ifaamas.org/Proceedings/aamas2024/pdfs/p1346.pdf','Information value https://arxiv.org/html/2610.40030v1']);
}

// 11. Paired experiment
{
 const s=slide('Measuring the Effect of Probe Feedback','Run one brief steering probe after the disturbance. Save the simulator state, FLAIR model and buffer at its end.');
 box(s,69,192,1143,69,c.blue,'Shared snapshot');
 text(s,'Both branches start from the same snapshot and track the same subsequent turn.',88,211,1104,43,{size:24,bold:true,color:c.white});
 box(s,347,261,2,29,c.line,'Branch A connector');
 box(s,929,261,2,29,c.line,'Branch B connector');
 box(s,69,290,558,163,c.pale,'Admit feedback');
 box(s,654,290,558,163,c.lighter,'Withhold feedback');
 text(s,'A   Use the probe data to update FLAIR',89,308,515,46,{size:24,bold:true,color:c.blue});
 text(s,'Subsequent cumulative tracking error',89,371,385,38,{size:20,color:c.muted});
 text(s,'11',485,354,115,74,{size:52,bold:true,color:c.navy,align:'right'});
 text(s,'B   Withhold only the probe data',674,308,514,46,{size:24,bold:true,color:c.blue});
 text(s,'Subsequent cumulative tracking error',674,371,385,38,{size:20,color:c.muted});
 text(s,'18',1071,354,114,74,{size:52,bold:true,color:c.navy,align:'right'});
 text(s,'Value of the feedback for this turn   18 − 11 = 7',70,490,1140,58,{size:34,bold:true,color:c.navy});
 text(s,'Both branches inherit the motion caused by the probe. The error gap measures the effect of using its data.',70,556,1141,43,{size:21});
 text(s,'Illustrative values. Both branches use the same reference commands and evaluation window.',70,623,1140,32,{size:19,color:c.muted});
 note(s,'The steering probe is executed once. Its motion is already reflected in the saved simulator state. The branches share that state and the compensator’s current state. Branch A admits the paired probe samples to the standard online update. Branch B withholds only those samples. Both branches continue normal updates with later feedback and follow the same turn. In this illustrative example, withholding adds seven units of subsequent cumulative tracking error. The paired difference measures how using the probe data affects subsequent control.',[paper+' Dataset Creation and Learning Adaptation','Local source G:/毕设/03_code/references/FLAIR/fast_adaptation/example/flair_example.py:356']);
}

// 12. Mechanism hypothesis
{
 const s=slide('Does the Next Maneuver Change the Best Probe?','Start from the same disturbed scenario and test a brief forward-speed probe and a brief steering probe.');
 text(s,'For each probe, start from its end state and test both future commands. Each cell compares using and withholding its data.',70,186,1140,43,{size:20});
 comparisonTable(s,[
  ['Probe now','Continue straight afterward','Enter a turn afterward'],
  ['Change forward speed','Gain 5','Gain 2'],
  ['Change yaw rate','Gain 1','Gain 7']
 ],69,252,[407,367,369],[47,68,68],[[1,1],[2,2]]);
 text(s,'Straight: 5 > 1 favors the forward probe. Turn: 7 > 2 favors the steering probe.',70,469,1140,43,{size:24,bold:true,color:c.blue});
 text(s,'Illustrative values. The mechanism test checks whether the ranking consistently changes with the next command.',70,525,1140,37,{size:19,color:c.muted});
 box(s,69,586,1143,82,c.pale,'PPO decision');
 text(s,'PPO policy',88,605,152,36,{size:21,bold:true,color:c.blue});
 text(s,'Use upcoming commands to choose direct compensation, a forward probe or a steering probe.\nKeep the task reward and use the paired gain as an auxiliary training signal.',263,602,929,60,{size:19,bold:true,color:c.navy});
 note(s,'Rows show probes. Columns show the motion requested afterward. Each cell is a separate pair of closed-loop runs with the same future reference. In the example, a forward probe provides more useful data before straight motion, while a steering probe helps more before a turn. The numbers are illustrative. We will test whether this change in ranking is reproducible. If so, the high-level PPO policy can use the known upcoming command to choose a probe or continue normal compensation. The auxiliary gain is used in training alongside the task reward, which includes the cost of probing.',[paper,'BARL https://papers.neurips.cc/paper_files/paper/2022/hash/b90cb10d4dae058dd167388e76168c1b-Abstract-Conference.html','Information value https://arxiv.org/html/2610.40030v1']);
}

// 13. Work plan
{
 const s=slide('Research Plan','Test whether upcoming commands change probe value and whether that signal improves recovery.');
 const stages=[
  ['Hexapod\nmechanism test','Start with one probe, one subsequent command and two branches.\nThen cross two probes with two future commands and compare the rankings.'],
  ['Go2-W simulation','Integrate FLAIR and test in-run wheel derating and low traction.\nCompare both PPO variants using matched inputs, actions, task rewards and budgets.'],
  ['Go2-W hardware','Check body-velocity measurements and synchronization.\nRepeat representative disturbances on hardware.']
 ];
 stages.forEach(([a,b],i)=>{const y=184+i*111;horizontal(s,69,y,1143);text(s,a,70,y+20,260,76,{size:26,bold:true,color:c.blue});text(s,b,325,y+19,885,70,{size:21});});
 box(s,69,533,1143,130,c.pale,'Comparison and metrics');
 text(s,'Baselines',89,551,151,37,{size:22,bold:true,color:c.blue});
 text(s,'Original FLAIR, fixed probing, standard probing PPO, and PPO with feedback gain',242,551,948,38,{size:21});
 text(s,'Metrics',89,605,151,36,{size:22,bold:true,color:c.blue});
 text(s,'From disturbance onset: cumulative error, recovery time, probing cost and instability rate',242,605,948,38,{size:21});
 note(s,'We begin in the existing hexapod environment with a single paired test, then cross the two probe types with straight and turning reference commands. In Go2-W simulation, the comparisons are original FLAIR, fixed probing, standard probing PPO and PPO with the auxiliary feedback gain. Both PPO variants have the same access to upcoming commands, and the extra branches count against the simulation budget. Measure performance from disturbance onset so that probing costs are included. Finally, we will verify body-velocity measurements and timing, then test representative repeatable disturbances on the Go2-W hardware.',[study+'flair/02_feedback_and_adaptation.md','Go2-W Robot Lab https://github.com/fan-ziqi/robot_lab/tree/v2.3.2/source/robot_lab/robot_lab/tasks/manager_based/locomotion/velocity/config/wheeled/unitree_go2w']);
}


const candidate=path.join(work,'candidate-flair-review-en.pptx');
await (await PresentationFile.exportPptx(p)).save(candidate);
const skill='C:/Users/laiyo/.codex/plugins/cache/openai-primary-runtime/presentations/26.1112.11217/skills/presentations';
const python='C:/Users/laiyo/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe';
const {finalizePresentation}=await import(pathToFileURL(path.join(skill,'container_tools','artifact_tool_utils.mjs')).href);
const tables=[3,5,6,7,9,12];
await finalizePresentation({
 workspaceDir:root,candidatePath:candidate,finalPath:target,pythonExecutable:python,
 integrityValidatorPath:path.join(skill,'container_tools','inspect_presentation_package_integrity.py'),
 layoutValidatorPath:path.join(skill,'container_tools','inspect_presentation_layout_geometry.py'),
 layoutArgs:['--expected-slide-size-emu','12192000,6858000','--validate-heading-fit',...tables.flatMap(i=>['--require-native-table-slide',String(i)])],
 requiredNativeTableOwnerSlides:tables,explicitTotalSlideCount:13,
 fontPolicy:{basis:'reference',families:[font],referencePath:'G:/毕设/02_learning/04_review/.build_flair_group_meeting/candidate-command-preview-20261116.pptx',referenceSha256:'32b164c14cceb41797bb70ef5c42aee8226ece310b57119e3e88fca60ea2289b'},verifyArtifactToolImport:true,
 receiptPath:path.join(work,'validation-flair-review-en.json')
});
console.log(target);



