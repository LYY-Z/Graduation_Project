import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { Presentation, PresentationFile } from '@oai/artifact-tool';

const work = path.dirname(fileURLToPath(import.meta.url));
const root = path.dirname(work);
const out = path.join(root,'deliverables','flair','FLAIR_Group_Meeting.CN.pptx');
const p = Presentation.create({slideSize:{width:1280,height:720}});
const font = 'Microsoft YaHei';
const c = {bg:'#F8F6F2', ink:'#211D20', muted:'#615860', accent:'#72384E', dark:'#352331', subtle:'#DED4D7', blush:'#F0E5EA', paper:'#FFFEFC', white:'#FFFFFF', pale:'#F0DCE4'};
const paper='https://www.nature.com/articles/s41467-026-70256-y';
const supplement='https://static-content.springer.com/esm/art%3A10.1038%2Fs41467-026-70256-y/MediaObjects/41467_2026_70256_MOESM1_ESM.pdf';
const archive='https://zenodo.org/records/18336476';
const data='https://zenodo.org/records/14546657';
const code='https://github.com/adaptive-intelligent-robotics/FLAIR';
const local='G:/毕设/02_learning/';

function txt(s,value,x,y,w,h,o={}){
  const q=s.shapes.add({name:o.name??String(value).slice(0,30),geometry:'textbox',position:{left:x,top:y,width:w,height:h},fill:'none',line:{fill:'none',width:0}});
  q.text=value;
  q.text.style={typeface:font,fontSize:o.size??24,bold:o.bold??false,color:o.color??c.ink,alignment:o.align??'left',verticalAlignment:o.valign??'top',wrap:o.wrap??'none',autoFit:'none',insets:0};
  return q;
}
function rule(s,x,y,w,color=c.subtle,h=1){s.shapes.add({name:'分隔线',geometry:'rect',position:{left:x,top:y,width:w,height:h},fill:color,line:{fill:'none',width:0}});}
function page(title,sub){const s=p.slides.add();s.background.fill=c.bg;txt(s,title,68,44,1143,67,{size:47,bold:true});if(sub)txt(s,sub,69,119,1140,34,{size:22,color:c.muted});return s;}
function note(s,body,refs=[]){s.speakerNotes.text=[body,...(refs.length?['参考资料',...refs]:[])].join('\n\n');}
async function pic(s,file,x,y,w,h,alt,fit='contain'){
 const b=await fs.readFile(path.join(work,file));
 s.images.add({blob:b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength),contentType:'image/png',position:{left:x,top:y,width:w,height:h},fit,alt});
}
function table(s,rows,x,y,widths,heights,{size=22,hilite=[],headSize=22}={}){
 const t=s.tables.add({rows:rows.length,columns:widths.length,left:x,top:y,width:widths.reduce((a,b)=>a+b,0),height:heights.reduce((a,b)=>a+b,0),columnWidths:widths,values:rows});
 t.styleOptions={headerRow:false,firstColumn:false,bandedRows:false,bandedColumns:false};
 t.borders.assign({style:'solid',fill:c.subtle,width:0.7});
 for(let i=0;i<rows.length;i++){
  t.rows[i].height=heights[i];
  for(let j=0;j<widths.length;j++){
   const cell=t.getCell(i,j); const shade=i===0?c.accent:hilite.includes(i)?c.blush:i%2===0?c.bg:c.paper;
   const range=t.cells.block({row:i,column:j,rowCount:1,columnCount:1});
   range.assign({fill:shade,margins:{left:14,right:12,top:6,bottom:6},anchor:'middle'});
   cell.text.style={typeface:font,fontSize:i===0?headSize:size,bold:i===0||j===0||hilite.includes(i),color:i===0?c.white:c.ink,verticalAlignment:'middle'};
  }
 }
 return t;
}
function labeled(s,label,body,x,y,w){txt(s,label,x,y,w,35,{size:25,bold:true,color:c.accent});txt(s,body,x,y+39,w,65,{size:22,color:c.ink});}

// 1. Title
{
 const s=p.slides.add(); s.background.fill=c.dark;
 await pic(s,'gvr_bot2.png',572,126,638,347,'GVR-Bot 行驶在 FLAIR 实机实验赛道');
 txt(s,'FLAIR',68,160,495,108,{size:100,bold:true,color:c.white});
 txt(s,'扰动下的在线恢复',72,288,500,57,{size:43,bold:true,color:c.white});
 txt(s,'论文阅读、六足仿真复现与研究计划',72,375,495,60,{size:22,color:c.pale});
 rule(s,72,540,1138,'#76616C');
 txt(s,'Allard 等，Nature Communications，2026',72,563,800,34,{size:19,color:c.pale});
 txt(s,'GVR-Bot 原论文实机平台',905,486,305,30,{size:17,color:c.pale,align:'right'});
 note(s,'这次汇报围绕一个具体问题：运动过程中发生扰动以后，怎样让机器人重新按原先的速度指令运动。先讲论文的方法与验证，再介绍已经完成的六足仿真复现，最后说明下一步的 Go2-W 研究。',[paper,'封面实机图取自官方代码库示例动画 '+code+'/blob/v1.0.0/fast_adaptation/example/gifs/gvr_bot.gif']);
}

// 2. Question
{
 const s=page('扰动发生后，怎样恢复指令跟踪？');
 await pic(s,'operability.png',895,127,270,476,'原文图 1B 和 1D，履带机器人发生跑偏以及补偿后的运动示例');
 txt(s,'驾驶者仍要求直行，\n机器人却开始偏转。',70,180,760,145,{size:52,bold:true});
 rule(s,71,360,709,c.subtle);
 labeled(s,'目标','让实际前进速度和偏航率重新接近期望指令。',72,391,760);
 labeled(s,'约束','保留原有底层控制器，用在线反馈学习偏差。',72,510,760);
 note(s,'可操控性在本文中指期望指令和实际运动之间能否保持对应。减力、打滑或者其他扰动会打破这个对应。作者把现有控制器作为黑箱，在上层加一个修正速度指令的模块。主动适应扰动是研究动机，本文的主要证据集中在其测试条件下的跟踪与完成时间。',['Figure 1B、1D 与正文引言 '+paper]);
}

// 3. Method
{
 const s=page('FLAIR 的在线响应学习与补偿','期望速度 → FLAIR 修正指令 → 底层控制器 → 实际车身运动');
 const row=[
  ['采集反馈','把实际下发的速度指令\n与稍后的车身运动配对。'],
  ['拟合响应','全局模型估计整体偏差，\n局部高斯过程细化预测。'],
  ['选择补偿','用模型反推应下发的指令，\n让实际运动接近期望速度。']
 ];
 row.forEach(([a,b],i)=>{const x=70+385*i;rule(s,x,215,330,c.accent,3);txt(s,a,x,240,335,50,{size:34,bold:true});txt(s,b,x,308,350,100,{size:23,color:c.muted});});
 rule(s,70,475,1140,c.subtle);
 txt(s,'直行目标下的补偿',70,506,325,44,{size:27,bold:true,color:c.accent});
 txt(s,'如果前进会引起偏转，FLAIR 会给出反向转向指令。',400,508,810,43,{size:25});
 txt(s,'显著工况变化时，可重置在线数据并重新拟合。',400,562,810,39,{size:21,color:c.muted});
 note(s,'FLAIR 在线训练的是命令至车体运动的响应模型。全局层描述大范围的变化，局部高斯过程补充细节。原文方法通过候选指令寻找更接近期望的响应。需要区分开源六足默认 STATE_FAST，在该分支最终发令时按状态相关全局模型求逆并限幅。GP 更新流程仍会被调用。',['正文图 2E 与 Methods '+paper,'六足默认配置与补偿分支 '+code+'/blob/v1.0.0/fast_adaptation/src/flair/functionality_controller/functionality_controller.py']);
}

// 4. Benchmark / baseline
{
 const s=page('实机与仿真的评测设计','两套评测共用跟踪误差与完成时间，比较对象和扰动设置各有侧重。');
 table(s,[
  ['评测维度','实机 · GVR-Bot 履带车','仿真 · Brax 六足机器人'],
  ['Benchmark','3 条赛道，5 个评价区段','Chicane 连续弯道，32 个航点'],
  ['扰动设置','履带降额（固定或途中切换）、模拟风、颠簸','右侧中腿减力，初始化时施加'],
  ['Baseline','Driver、LQR、L₁ 自适应控制、在线残差 RL\n另设无扰动参考组','健康与减力各做 FLAIR 开、关对照'],
  ['评测口径','VICON 运动捕捉，按 20 次重复统计中位数','Brax 仿真运动数据，四组各 20 回合']
 ],69,184,[184,490,465],[48,62,70,84,65],{size:20});
 txt(s,'实机扰动额外误差消除约 74.4%',70,549,550,42,{size:26,bold:true,color:c.accent});
 txt(s,'本次复现覆盖六足仿真四组主对照',650,549,560,42,{size:26,bold:true,color:c.accent});
 note(s,'这里要把 benchmark 与 baseline 分开。实机是作者自建的三个赛道五个评价区段，受控扰动主要通过履带速度缩放产生，含随航点改变的扰动和随朝向改变的模拟风。VICON 同时供自动驾驶和外部评估使用，FLAIR 在线学习用机载反馈。实机残差 RL 在平地弯道未完成，作者因安全原因未扩展到更复杂赛道。74.4% 是原论文分区汇总的额外跟踪误差恢复指标。六足仿真用于展示跨本体可用性，固定中右腿减力，四组共用既有 MAP-Elites 步态库。',['正文 Results、表 1 '+paper,'Supplementary Hexapod Results，图 1 和表 1 '+supplement]);
}

// 5. Reproduction steps
{
 const s=page('六足仿真复现流程','固定 FLAIR v1.0.0、官方步态库和 Chicane 路线。');
 await pic(s,'hexapod1.png',688,194,523,284,'官方六足 Brax 仿真动画帧');
 txt(s,'官方 Brax 六足模型',688,490,523,30,{size:17,color:c.muted,align:'right'});
 labeled(s,'复算作者结果','用官方 CSV 和 notebook 核对 138.8% 的口径。',70,185,605);
 labeled(s,'独立运行原版','服务器独立 Conda 环境，四组各跑通 1 回合。',70,298,605);
 labeled(s,'重新生成正式数据','加速 CPU 网格操作，四组各跑 20 回合。',70,411,605);
 rule(s,70,539,1140);
 txt(s,'加速一致性核对覆盖 6 批网格输入和同种子前 110 个控制步。',70,569,1140,42,{size:23,color:c.muted});
 note(s,'先用同一套分析函数复算作者数据，然后在服务器独立建立 Python 3.10、JAX CPU 环境。原版四组都跑到终点，开启补偿的原版回合在服务器约需 36 至 40 分钟。耗时主要卡在数据缓存网格加样和筛选。独立加速入口核对了六批网格数据以及同种子的前 110 个控制步。正式 80 回合使用加速版。整圈逐值一致性仍待核验。',['官方源码归档 '+archive,'官方日志和 notebook '+data,'复现执行记录 '+local+'flair_reproduction_execution.md','六足图取自 '+code+'/blob/v1.0.0/fast_adaptation/example/gifs/hexapod.gif']);
}

// 6. Quantitative evidence
{
 const s=page('六足复现再现了减力条件下的补偿收益','独立重跑 80 回合，全部到达末航点。表内为组中位数。');
 table(s,[
  ['实验条件','跟踪误差\n作者／独立重跑','完成时间（秒）\n作者／独立重跑'],
  ['健康，关 FLAIR','0.04599 / 0.04596','180.75 / 180.25'],
  ['健康，开 FLAIR','0.04370 / 0.04371','151.65 / 151.60'],
  ['减力，关 FLAIR','0.05032 / 0.05036','196.95 / 197.05'],
  ['减力，开 FLAIR','0.04431 / 0.04379','170.95 / 170.60']
 ],70,183,[335,350,453],[64,56,56,56,56],{size:23,headSize:20,hilite:[4]});
 txt(s,'13.0%',73,503,300,73,{size:61,bold:true,color:c.accent});
 txt(s,'独立减力组总跟踪误差下降',74,583,460,33,{size:22});
 txt(s,'26.45 秒',625,503,460,73,{size:61,bold:true,color:c.accent});
 txt(s,'独立减力组中位完成时间缩短',627,583,510,33,{size:22});
 txt(s,'138.8% 是作者数据按减力额外误差计算的恢复率。',74,653,1090,33,{size:18,color:c.muted});
 note(s,'表格按作者 notebook 的同一分析口径计算，完成时间取六足日志时间戳。关键是看减力时开和关 FLAIR 的差异。重跑得 13.0% 是以减力无补偿组的总误差为分母。138.8% 以减力较健康无补偿状态额外增加的误差为分母。用 Brax 原生偏航率并时间对齐重算，减力组误差仍下降约 12.1%。以逐回合同一行日志误差作额外检查，20 对减力回合方向一致。六足减力从仿真初始化起生效，这组结果适用于固定减力下的整段表现。',['作者数据 '+data,'独立重跑与作者口径对照 '+local+'flair_results/comparison_metrics.csv','复现范围 '+local+'flair_reproduction_summary.md']);
}

// 7. Innovation
{
 const s=page('试探反馈能否改善后续补偿？','从同一扰动后状态出发，用对照实验量化反馈对 FLAIR 的价值。');
 table(s,[
  ['分支','执行动作','FLAIR 如何处理试探数据'],
  ['① 常规补偿','按 FLAIR 正常输出运行','按原流程更新'],
  ['② 试探＋更新','执行短时速度试探','本次试探数据正常进入更新'],
  ['③ 同样试探','与②执行完全相同的动作','本次试探数据跳过上层模型更新']
 ],70,190,[258,430,450],[48,61,61,61],{size:22,hilite:[2,3]});
 txt(s,'② 与 ③ 的恢复差值',70,473,410,41,{size:29,bold:true,color:c.accent});
 txt(s,'给出这批反馈改善后续补偿的收益，作为 PPO 的辅助训练信号。',70,529,1138,52,{size:26});
 txt(s,'PPO 的主奖励继续衡量恢复表现、稳定性和试探代价。',70,606,1140,36,{size:22,color:c.muted});
 note(s,'举个例子，同样一次小幅转向可能直接纠偏，也可能让 FLAIR 从新反馈学到规律。让②与③在试探期间共享同样的动作与状态记录，只切换样本是否进入上层模型。其后两组都继续补偿，比较跟踪表现。①衡量试探整体是否划算。方法贡献是把反馈产生的额外闭环收益用于辅助训练上层 PPO，主要奖励仍按实际恢复表现。三分支只在仿真训练和分析中使用。本页是计划中的方法。',['FLAIR 原文 '+paper,'主动诊断强化学习近邻工作 https://arxiv.org/abs/2405.04938','信息价值辅助训练近邻工作 https://borowiecki.dev/pdf/2610.40030']);
}

// 8. Work plan
{
 const s=page('后续研究计划','先在已跑通的六足环境验证对照，再迁移 Go2-W。');
 const stages=[['六足分支验证','固定同一次试探，核对数据开关及补偿变化。'],['Go2-W 仿真基线','接入 FLAIR，在运行中引入单轮降额或低附着。'],['训练与对照','同预算比较普通试探 PPO 和辅助学习版。'],['实机验证','选代表性扰动进行重复试验。']];
 stages.forEach(([a,b],i)=>{const y=193+i*103;rule(s,70,y-13,649);txt(s,a,70,y,660,39,{size:26,bold:true});txt(s,b,70,y+40,660,38,{size:21,color:c.muted});});
 rule(s,770,181,439,c.accent,3);
 txt(s,'关键对照',770,204,438,45,{size:31,bold:true,color:c.accent});
 txt(s,'原 FLAIR\n普通试探 PPO\n反事实辅助学习 PPO',770,269,438,125,{size:25});
 txt(s,'评价指标',770,418,438,43,{size:29,bold:true,color:c.accent});
 txt(s,'累计跟踪误差、恢复时间\n试探次数、失稳率',770,480,450,90,{size:23});
 note(s,'第一步是从现有六足代码实现试探数据开关，确认两条分支在试探阶段动作一致，分支后差异只由样本使用方式引入。Go2-W 仿真沿用同一底层速度跟踪策略，加入可重复的扰动。在留出轮位、强度或路面条件上测恢复时间等指标。普通试探 PPO 与辅助学习版的动作和观测一致，额外分支计算计入总仿真预算。实机要先核对车体速度反馈与时间同步。',['当前六足结果 '+local+'flair_reproduction_summary.md','Go2-W 平地任务 https://github.com/fan-ziqi/robot_lab/blob/v2.3.2/source/robot_lab/robot_lab/tasks/manager_based/locomotion/velocity/config/wheeled/unitree_go2w/__init__.py']);
}

const candidate=path.join(work,'candidate.pptx');
await (await PresentationFile.exportPptx(p)).save(candidate);
if(process.argv.includes('--draft-only')) {console.log(candidate);process.exit(0);}
const skill='C:/Users/laiyo/.codex/plugins/cache/openai-primary-runtime/presentations/26.1112.11217/skills/presentations';
const py='C:/Users/laiyo/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe';
const {finalizePresentation}=await import(pathToFileURL(path.join(skill,'container_tools','artifact_tool_utils.mjs')).href);
const tables=[4,6,7];
await finalizePresentation({
 workspaceDir:root,candidatePath:candidate,finalPath:out,pythonExecutable:py,
 integrityValidatorPath:path.join(skill,'container_tools','inspect_presentation_package_integrity.py'),
 layoutValidatorPath:path.join(skill,'container_tools','inspect_presentation_layout_geometry.py'),
 layoutArgs:['--expected-slide-size-emu','12192000,6858000','--validate-heading-fit',...tables.flatMap(i=>['--require-native-table-slide',String(i)])],
 requiredNativeTableOwnerSlides:tables,explicitTotalSlideCount:8,
 fontPolicy:{basis:'design',families:[font]},verifyArtifactToolImport:true,
 receiptPath:path.join(work,'validation.json')
});
console.log(out);
