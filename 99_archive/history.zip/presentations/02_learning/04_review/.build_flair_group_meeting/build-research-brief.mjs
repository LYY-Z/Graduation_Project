import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { Presentation, PresentationFile } from '@oai/artifact-tool';

const work=path.dirname(fileURLToPath(import.meta.url));
const root=path.dirname(work);
const out=path.join(root,'deliverables','flair','FLAIR_Research_Brief.CN.pptx');
const p=Presentation.create({slideSize:{width:1280,height:720}});
const font='Microsoft YaHei';
const C={bg:'#F6F5EF', ink:'#1E3030', mid:'#4B6261', teal:'#11695D', dark:'#152F30', bright:'#BCE6D7', line:'#D5DCD4', tint:'#E3EDE5', warm:'#F0E1D5', rust:'#8B442C', white:'#FFFFFF'};
const paper='https://doi.org/10.1038/s41467-026-70256-y';
const sup='https://static-content.springer.com/esm/art%3A10.1038%2Fs41467-026-70256-y/MediaObjects/41467_2026_70256_MOESM1_ESM.pdf';
const code='https://github.com/adaptive-intelligent-robotics/FLAIR/tree/v1.0.0';
const data='https://zenodo.org/records/14546657';
const local='G:/毕设/02_learning/';
const loco='https://generalist-locomotion.github.io/';
const tam='https://github.com/Dongwon-Son/TAM';
const runall='https://github.com/nico-bohlinger/one_policy_to_run_them_all';
const cross='https://github.com/rail-berkeley/crossformer';

function rect(s,x,y,w,h,fill,name='背景色块'){
  return s.shapes.add({name,geometry:'rect',position:{left:x,top:y,width:w,height:h},fill,line:{fill:'none',width:0}});
}
function line(s,x,y,w,color=C.line,h=1){return rect(s,x,y,w,h,color,'分隔线');}
function txt(s,str,x,y,w,h,o={}){
  const t=s.shapes.add({name:o.name??str.slice(0,36),geometry:'textbox',position:{left:x,top:y,width:w,height:h},fill:'none',line:{fill:'none',width:0}});
  t.text=str;
  t.text.style={typeface:font,fontSize:o.size??24,bold:o.bold??false,color:o.color??C.ink,alignment:o.align??'left',verticalAlignment:'top',insets:0,wrap:o.wrap?'wrap':'none',autoFit:'none'};
  return t;
}
function page(title,sub){
  const s=p.slides.add();s.background.fill=C.bg;
  line(s,67,41,48,C.teal,4);
  txt(s,title,67,58,1146,61,{size:43,bold:true});
  if(sub)txt(s,sub,69,129,1142,35,{size:21,color:C.mid});
  return s;
}
function note(s,body,refs){s.speakerNotes.text=body+'\n\n参考资料\n'+refs.join('\n');}
async function pic(s,file,x,y,w,h,alt,fit='contain'){
  const b=await fs.readFile(path.resolve(work,file));
  s.images.add({blob:b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength),contentType:'image/png',position:{left:x,top:y,width:w,height:h},fit,alt});
}
function group(s,title,body,x,y,w,o={}){
  txt(s,title,x,y,w,40,{size:o.head??26,bold:true,color:o.color??C.teal});
  txt(s,body,x,y+48,w,o.height??92,{size:o.size??22,color:o.bodyColor??C.ink});
}
function table(s,rows,x,y,ws,hs,o={}){
  const t=s.tables.add({rows:rows.length,columns:ws.length,left:x,top:y,width:ws.reduce((a,b)=>a+b,0),height:hs.reduce((a,b)=>a+b,0),columnWidths:ws,values:rows});
  t.styleOptions={headerRow:false,firstColumn:false,bandedRows:false,bandedColumns:false};
  t.borders.assign({style:'solid',fill:C.line,width:0.7});
  for(let i=0;i<rows.length;i++){
    t.rows[i].height=hs[i];
    for(let j=0;j<ws.length;j++){
      const isHighlight=o.highlight?.includes(i);
      t.cells.block({row:i,column:j,rowCount:1,columnCount:1}).assign({fill:i===0?C.teal:isHighlight?C.tint:i%2===0?C.bg:C.white,margins:{left:15,right:11,top:6,bottom:5},anchor:'middle'});
      t.getCell(i,j).text.style={typeface:font,fontSize:i===0?20:(o.size??21),bold:i===0||j===0||isHighlight,color:i===0?C.white:C.ink,verticalAlignment:'middle'};
    }
  }
}
function band(s,heading,body,y){
  rect(s,68,y,1144,91,C.tint);
  txt(s,heading,85,y+14,1100,33,{size:24,bold:true,color:C.teal});
  txt(s,body,85,y+50,1100,33,{size:20,color:C.ink});
}

// Thesis of the presentation
{
  const s=p.slides.add();s.background.fill=C.dark;
  await pic(s,'gvr_bot2.png',624,102,588,348,'FLAIR 论文 GVR-Bot 在原文测试赛道', 'cover');
  line(s,68,108,68,C.bright,4);
  txt(s,'从在线补偿到主动恢复',67,155,550,128,{size:51,bold:true,color:C.white});
  txt(s,'FLAIR 六足仿真复现\n与 Go2-W 论文研究计划',70,285,528,104,{size:31,color:C.bright});
  txt(s,'FLAIR 论文实机平台 GVR-Bot',640,464,570,29,{size:17,color:C.bright,align:'right'});
  line(s,70,548,1142,'#5B7A76');
  txt(s,'机器人运行中受扰时，什么样的试探值得做？',69,578,1143,49,{size:28,color:C.white});
  note(s,'这次汇报从已经完成的 FLAIR 六足复现出发。先交代原论文如何验证在线补偿，再说明这个复现为新课题提供了什么。最后讲 Go2-W 的论文要解决的问题：在扰动发生后，主动试探收集的反馈能否带来可测量的恢复收益。',[paper,'实机图片来自作者公开示例 '+code]);
}

// Question
{
  const s=page('FLAIR 解决的是受扰后的指令失配','同一个前进和转向指令，会随地面条件或执行器能力产生不同的运动。');
  await pic(s,'operability.png',873,174,320,470,'论文图 1 的指令失配与补偿示意');
  group(s,'控制任务','让车体的实际前进速度和偏航率跟上驾驶指令。',69,204,770);
  line(s,70,302,733);
  group(s,'运行中变化','单侧驱动力下降时，原本能让车直行的指令会使车偏转。',69,331,789);
  line(s,70,428,733);
  group(s,'论文问题','保留底层控制器，能否从刚刚发生的运动中学到偏差，\n并及时修正下一条速度指令？',69,453,790,{head:28,size:24,height:100});
  note(s,'论文关心 operability，也就是给出的命令能不能产生用户想要的动作。以直行为例，驾驶器的目标没变，但车可能因为驱动减弱而转向。作者在现有控制器前接一层学习器，用最近的动作和测量更新响应，再修正即将发送的命令。右图是论文用于说明这一问题的示例。',[paper+' Introduction 与 Fig. 1B、1D']);
}

// Method
{
  const s=page('用已执行指令学习响应，再反推补偿','FLAIR 的学习量是速度指令到车体运动的映射。');
  const names=['期望运动','补偿指令','实际响应']; const ys=[209,209,209];
  const xs=[70,459,850];
  const vals=['Driver 要求直行\n(v*, ω*)','FLAIR 估计该发什么\n(uᵥ, uω)','底层执行后测到\n(v, ω)'];
  for(let i=0;i<names.length;i++){line(s,xs[i],190,330,C.teal,3); group(s,names[i],vals[i],xs[i],ys[i],345,{head:28,size:24});}
  txt(s,'→',406,245,48,48,{size:32,color:C.teal,align:'center'});
  txt(s,'→',797,245,48,48,{size:32,color:C.teal,align:'center'});
  line(s,70,361,1141);
  group(s,'在线更新','把实际发出的指令，与稍后测到的响应对齐。\n全局模型估计整体偏差，局部 GP 细化响应预测。',69,397,622,{head:28});
  group(s,'六足默认实现','STATE_FAST 由状态分量获得偏差系数，\n对二维速度响应模型求逆并限幅。',715,397,495,{head:28});
  txt(s,'数据用于拟合执行效果，期望指令用于选择和评估补偿。',70,594,1141,54,{size:27,bold:true,color:C.teal});
  note(s,'先从已发命令和随后真实响应得到配对数据，再将学到的模型用于新指令。假设小幅前进引起向左偏转，补偿器就可以计算哪条带反向转向的命令更接近直行。论文方法包括全局先验和局部 GP。默认六足发令采用状态相关先验求逆。读源码时还核对到变量名 yaw 与 Brax v1 的实际欧拉分量顺序有差异，详见源码导读。',[paper+' 方法与 Fig. 2',code+' 默认配置及 functionality_controller.py',local+'flair/02_feedback_and_adaptation.md']);
}

// Benchmarks, baselines, distributions
{
  const s=page('实机与六足仿真验证不同的能力','前者包含途中变化，后者检查固定减力下的补偿及跨平台可用性。');
  table(s,[
    ['比较维度','实机 GVR-Bot 履带车','仿真 Brax 六足机器人'],
    ['Benchmark','3 条赛道，5 个评价区段','Chicane 连续弯道，16 点两圈'],
    ['扰动设置','履带降额、方向相关模拟风、颠簸\n包含途中变更的场景','右侧中腿两处执行器减力\n回合初始化时生效'],
    ['Baseline','Driver、LQR、L₁ 自适应控制、在线残差 RL\n加无扰动参考组','健康、减力分别比较 Driver 与 Driver＋FLAIR\n共用 MAP-Elites 步态库'],
    ['指标与重复','VICON 追踪误差、完成时间\n按 20 次重复统计','车体前进和偏航跟踪误差、完成时间\n四组各 20 回合']
  ],68,179,[189,481,474],[49,65,84,92,88],{size:20});
  txt(s,'论文实机汇总消除约 74.4% 的扰动额外跟踪误差。',69,588,1138,47,{size:26,bold:true,color:C.teal});
  note(s,'Benchmark 是在哪些任务和扰动上评，baseline 是跟谁比。实机中残差 RL 在 Chicane 未完成，因此不能将它理解成所有赛段都做了完整对照。74.4% 的分母是按无扰动 Driver 参考计算的额外跟踪误差。六足主实验把健康和腿部减力各拆成开关补偿两组，主要观察固定故障下的补偿效果。后续 Go2-W 需要单独设计事件发生后的恢复时窗。',[paper+' Results 与表 1',sup+' Hexapod Results 及 Baselines']);
}

// Reproduction steps and one actual example
{
  const s=page('从路径点到独立重跑','用作者公开步态库，复现六足 Chicane 四组对照。');
  group(s,'复算作者数据','用发布的四份 CSV 和 notebook 核对指标。',69,192,598,{size:21});
  line(s,69,285,598);
  group(s,'走通原版代码','四组各跑 1 回合，用末航点与仿真反馈验收。',69,307,598,{size:21});
  line(s,69,402,598);
  group(s,'生成独立量化结果','CPU 网格操作加速后，四组各跑 20 回合。\n用网格单测和同种子前 110 个控制步对照。',69,426,598,{size:21});
  await pic(s,'../../flair_results/smoke-v100-long_trajectories.png',700,178,512,405,'原版四组试跑代表轨迹');
  txt(s,'原版试跑轨迹，蓝线为航点连线',707,595,504,32,{size:17,color:C.mid,align:'right'});
  txt(s,'验收依据是末航点和日志。',69,612,610,40,{size:22,bold:true,color:C.teal});
  note(s,'代码从航点产生两维车体速度指令，FLAIR 修正后查步态库，把 24 个参数转成每个物理步的 18 个关节动作。Brax 更新状态，产生反馈并记录轨迹。作者数据、原版各一回合、加速版的 80 回合是三套证据。CPU 加速针对网格加样和筛选，检查过六批网格输入与一条 110 控制步短轨迹，整圈逐值等价仍待核验。',[code,data,local+'flair_reproduction_execution.md',local+'flair_results/smoke-v100-long_trajectories.png']);
}

// Results
{
  const s=page('六足复现重现了减力组的改善','按作者 notebook 计算误差。表中每组均为 20 回合的组中位数。');
  table(s,[
    ['条件','作者误差','独立重跑误差'],
    ['健康，关 FLAIR','0.04599','0.04596'],
    ['健康，开 FLAIR','0.04370','0.04371'],
    ['减力，关 FLAIR','0.05032','0.05036'],
    ['减力，开 FLAIR','0.04431','0.04379']
  ],68,187,[276,205,251],[52,68,68,68,68],{highlight:[4],size:22});
  txt(s,'13.0%',837,199,370,86,{size:65,bold:true,color:C.teal});
  txt(s,'减力组跟踪总误差下降',840,288,371,40,{size:23});
  line(s,838,344,365);
  txt(s,'26.45 s',836,361,378,81,{size:56,bold:true,color:C.teal});
  txt(s,'减力组完成时间缩短',840,447,373,40,{size:23});
  band(s,'这组数据为后续研究提供了固定减力基线','保留 Brax 原生偏航率重算，误差仍下降约 12.1%。',560);
  note(s,'同一口径下，独立减力组误差从 0.05036 降至 0.04379，日志完成时间从 197.05 秒降至 170.60 秒。作者 138.8% 使用减力造成的额外误差作分母，13.0% 使用无补偿减力组的总误差作分母。另保留 Brax 原生偏航率对齐复算，改善约 12.1%。80 回合均到达末航点，证据覆盖六足固定减力，Go2-W 运行中变化的恢复指标需要重新测。',[data,local+'flair_results/comparison_metrics.csv',local+'flair_results/formal_trials.csv']);
}

// Compare advisor references and action interfaces
{
  const s=page('为什么选 FLAIR 作为主基线','优先比较能回答同一控制问题、接入同一动作接口的工作。');
  table(s,[
    ['工作','研究重心','对 Go2-W 论文的用途'],
    ['FLAIR','在线拟合车体响应，\n修正速度指令','有已复现的闭环和在线样本入口。\n迁移后沿用同一底层，直接比较恢复策略。'],
    ['TAM','用历史预测机械臂残差力矩','与本课题的速度层接口不同。\n实机复现涉及机械臂力矩接口与桥接。'],
    ['LocoFormer','跨本体长历史适应','提供历史适应的相关工作。\n官方页提供论文和演示。'],
    ['One Policy / CrossFormer','跨本体共享运动或操作策略','提供跨本体接口设计的参考。\n本论文实验聚焦单平台的扰动恢复。']
  ],68,182,[257,323,564],[50,87,84,80,84],{highlight:[1],size:20});
  txt(s,'实验接口固定在车体前进速度与偏航率，底层策略保持一致。',69,600,1140,45,{size:24,bold:true,color:C.teal});
  note(s,'从最匹配的接口出发，FLAIR 与我们的 Go2-W 速度控制都接受车体命令。TAM 的官方仓库提供模拟工作流和推理权重，研究变量在关节力矩层。LocoFormer 的长历史适应值得读，但当前作者页没有训练代码入口。另两项工作主要回答跨本体共享策略问题。这些是相关工作与选型理由，Go2-W 的量化主对照使用相同接口和同一底层。',[paper,tam,loco,runall,cross]);
}

// Intervention diagram
{
  const s=page('研究切口是试探反馈对恢复的贡献','一次小幅转向既可能立刻纠偏，也可能给模型提供有价值的新数据。');
  rect(s,69,208,362,295,C.dark);
  txt(s,'同一次试探',91,247,323,52,{size:34,bold:true,color:C.white});
  txt(s,'同一扰动后状态\n同一段速度指令\n同一份反馈和试探末态',92,327,324,132,{size:25,color:C.bright});
  line(s,431,354,67,C.teal,3);
  rect(s,497,250,3,216,C.teal,'分支连线');
  line(s,498,250,47,C.teal,3);
  line(s,498,463,47,C.teal,3);
  group(s,'分支 A · 采纳反馈','样本进入 FLAIR 更新，记录后续恢复误差。',563,209,645,{head:28,size:22});
  group(s,'分支 B · 屏蔽反馈','同一批样本跳过模型更新，记录后续恢复误差。',563,422,647,{head:28,size:22});
  txt(s,'反馈收益 = 屏蔽组误差 − 采纳组误差',70,553,1140,52,{size:34,bold:true,color:C.teal});
  txt(s,'按相同后续参考、扰动和时窗计分。常规 FLAIR 另作总体恢复对照。',70,619,1140,30,{size:20,color:C.mid});
  note(s,'例如单轮降额后，小幅转向可能直接把车头摆回来。我们只执行一次试探，把相同的动作、反馈和末态复制到两个仿真分支。两支都继续按同样目标恢复。A 可以让这一批反馈进入 FLAIR，B 屏蔽它，然后比较后续跟踪误差。两个分支的差值归因于这批反馈通过模型和补偿影响了后续控制。原 FLAIR 另用来判断试探是否总体值得。',[local+'flair/04_go2w_paper_plan.md',paper]);
}

// Innovation justification and PPO
{
  const s=page('用闭环反馈收益训练试探策略','把同动作对照得到的反馈收益，加入 PPO 的试探训练目标。');
  group(s,'普通试探 PPO','以跟踪、稳定性和试探代价计算任务奖励。',70,196,545,{head:28,size:22});
  group(s,'本课题的 PPO','共用任务奖励，再给试探决策加入反馈的恢复收益。\n两版共用动作、观测与测试条件。',70,312,580,{head:28,size:22});
  line(s,676,185,535,C.teal,3);
  group(s,'为什么选这个问题','主动诊断用试探辨识故障。本文直接衡量\n试探数据是否让后续控制更好。',677,210,535,{head:27,size:21});
  group(s,'与前期选题的取舍','分段模型复用依赖轮端与车体模型可重组。\n当前方案只需对同一补偿器做数据干预。',677,391,534,{head:27,size:21});
  band(s,'主检验','与普通试探 PPO 比较，同总仿真预算下是否恢复更快、试探更少。',564);
  note(s,'底层 Go2-W 策略负责将车体指令变成关节与轮端目标。新增上层 PPO 选择是否、何时试探及试探方式。主奖励仍衡量运动表现与代价，两版 PPO 的差异在于有无反馈收益的辅助信号。主动诊断与反事实探索分别已有近邻工作，待验证的新问题是该信号能否提升在线补偿的实际恢复。早期双模型复用需额外验证轮地分解，当前方案首先用一个既有补偿器做清晰的因果对照。',['ADAPT https://arxiv.org/abs/2312.17606','Active Self-Diagnosis https://papers.ssrn.com/sol3/papers.cfm?abstract_id=7345456','CEN https://arxiv.org/abs/2106.00266',local+'flair/04_go2w_paper_plan.md']);
}

// Work plan
{
  const s=page('每个阶段交付一项论文证据','先证明机制，再训练策略，最后做代表性实机试验。');
  table(s,[
    ['阶段','实施与验收','写入论文的材料'],
    ['已完成\n六足 FLAIR','四组原版试跑和 80 回合结果。\n核对指标、源码版本与数据。','基线复现表、地图和轨迹'],
    ['下一步\n双分支原型','同一试探末态可复制。只切换试探数据使用。\n测量模型更新与后续跟踪差值。','机制图、试探收益与恢复曲线'],
    ['仿真主实验\nGo2-W ＋ PPO','接入公用底层和 FLAIR。途中注入轮降额、\n进入低附着区，同预算训练并做留出测试。','三组主对照、辅助信号消融'],
    ['实机与定稿\nGo2-W','确认测速与同步。选代表性扰动重复测试，\n整理边界案例与完整复现材料。','实机轨迹、失败案例和代码数据']
  ],68,177,[230,522,392],[49,90,90,90,90],{highlight:[2],size:20});
  txt(s,'先完成六足样本干预与恢复评价，再决定 PPO 训练规模。',69,613,1140,46,{size:23,bold:true,color:C.teal});
  note(s,'下一步先做六足的最小机制实验，避免分支状态复制、样本控制和延迟问题混到 Go2-W 迁移里。之后在 Isaac Lab 和 Robot Lab 的 Go2-W 速度任务上建立健康跟踪基线，选择运行中的单轮降额和附着变化作为主测试。正式对照共用事件、底层和测量。实机提供代表性场景的重复证据。', [local+'flair/04_go2w_paper_plan.md','Go2-W 平地任务 https://github.com/fan-ziqi/robot_lab/tree/v2.3.2/source/robot_lab/robot_lab/tasks/manager_based/locomotion/velocity/config/wheeled/unitree_go2w']);
}

// Paper deliverable and publication criterion
{
  const s=p.slides.add();s.background.fill=C.dark;
  line(s,68,48,49,C.bright,4);
  txt(s,'拟产出一篇轮足机器人扰动恢复论文',67,67,1155,68,{size:45,bold:true,color:C.white});
  txt(s,'暂定题目《基于反事实试探收益学习的轮足机器人扰动恢复》',69,153,1142,48,{size:26,color:C.bright});
  const claims=[
    ['方法证据','同一次试探，反馈如何经由 FLAIR 改变后续控制？'],
    ['性能证据','同预算与留出扰动下，是否减少累计误差和恢复时间？'],
    ['实机证据','代表性事件能否重复验证，并保持进度和稳定性？']
  ];
  claims.forEach(([a,b],i)=>{const y=246+i*91;line(s,69,y-13,1140,'#4D6D67');txt(s,a,69,y,221,41,{size:27,bold:true,color:C.bright});txt(s,b,286,y+3,925,41,{size:25,color:C.white});});
  line(s,69,525,1140,'#4D6D67');
  txt(s,'配套产出',69,557,221,41,{size:24,bold:true,color:C.bright});
  txt(s,'方法代码、试验配置、逐回合数据与代表性视频',286,557,923,44,{size:24,color:C.white});
  note(s,'预期产出是一篇方法论文。已完成的六足复现进入基线验证。第一项结果说明能不能分离可归因的反馈收益。第二项回答该收益用于训练是否改善留出事件的恢复。第三项检查仿真结论在 Go2-W 实机上的适用范围。按这三项证据决定论文主张，论文同时交付代码、配置、逐回合统计和代表性视频。',[local+'flair/04_go2w_paper_plan.md']);
}

const candidate=path.join(work,'candidate-research-brief.pptx');
await (await PresentationFile.exportPptx(p)).save(candidate);
const skill='C:/Users/laiyo/.codex/plugins/cache/openai-primary-runtime/presentations/26.1112.11217/skills/presentations';
const python='C:/Users/laiyo/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe';
const {finalizePresentation}=await import(pathToFileURL(path.join(skill,'container_tools','artifact_tool_utils.mjs')).href);
const tables=[4,6,7,10];
await finalizePresentation({
 workspaceDir:root,candidatePath:candidate,finalPath:out,pythonExecutable:python,
 integrityValidatorPath:path.join(skill,'container_tools','inspect_presentation_package_integrity.py'),
 layoutValidatorPath:path.join(skill,'container_tools','inspect_presentation_layout_geometry.py'),
 layoutArgs:['--expected-slide-size-emu','12192000,6858000','--validate-heading-fit',...tables.flatMap(i=>['--require-native-table-slide',String(i)])],
 requiredNativeTableOwnerSlides:tables,explicitTotalSlideCount:11,
 fontPolicy:{basis:'design',families:[font]},verifyArtifactToolImport:true,
 receiptPath:path.join(work,'validation-research-brief.json')
});
console.log(out);

