import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath, pathToFileURL} from 'node:url';
import {Presentation, PresentationFile} from '@oai/artifact-tool';

const work=path.dirname(fileURLToPath(import.meta.url));
const root=path.dirname(work);
const target=path.join(root,'deliverables','flair','FLAIR_Paper_Review_and_Reproduction.CN.pptx');
const p=Presentation.create({slideSize:{width:1280,height:720}});
const font='Microsoft YaHei';
const c={white:'#FFFFFF',navy:'#132844',blue:'#154EAE',ink:'#17283F',muted:'#465C76',pale:'#ECF3FF',lighter:'#F6F9FF',rule:'#D5E1F0',line:'#A9BCD8'};
const paper='https://doi.org/10.1038/s41467-026-70256-y';
const supplement='https://static-content.springer.com/esm/art%3A10.1038%2Fs41467-026-70256-y/MediaObjects/41467_2026_70256_MOESM1_ESM.pdf';
const repo='https://github.com/adaptive-intelligent-robotics/FLAIR/tree/v1.0.0';
const data='https://zenodo.org/records/14546657';
const study='G:/毕设/02_learning/';

function box(s,x,y,w,h,color,name='色块'){
 return s.shapes.add({name,geometry:'rect',position:{left:x,top:y,width:w,height:h},fill:color,line:{fill:'none',width:0}});
}
function text(s,str,x,y,w,h,o={}){
 const q=s.shapes.add({name:str.split('\n')[0].slice(0,35),geometry:'textbox',position:{left:x,top:y,width:w,height:h},fill:'none',line:{fill:'none',width:0}});
 q.text=str;
 q.text.style={typeface:font,fontSize:o.size??25,bold:o.bold??false,color:o.color??c.ink,alignment:o.align??'left',verticalAlignment:'top',insets:0,wrap:'none',autoFit:'none'};
 return q;
}
function slide(title,sub){
 const s=p.slides.add();
 s.background.fill=c.white;
 box(s,0,0,1280,9,c.blue,'页眉蓝线');
 if(title)text(s,title,68,58,1144,64,{size:46,bold:true,color:c.navy});
 if(sub)text(s,sub,70,133,1142,38,{size:22,color:c.muted});
 return s;
}
function note(s,script,refs){s.speakerNotes.text=[script,'参考资料',...refs].join('\n\n');}
function horizontal(s,x,y,w,color=c.rule,h=2){box(s,x,y,w,h,color,'分隔线');}
function heading(s,label,body,x,y,w,opts={}){
 text(s,label,x,y,w,40,{size:opts.head??27,bold:true,color:c.blue});
 text(s,body,x,y+49,w,opts.height??80,{size:opts.size??24});
}
async function img(s,file,x,y,w,h,alt,fit='contain'){
 const b=await fs.readFile(path.join(work,file));
 s.images.add({blob:b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength),contentType:'image/png',position:{left:x,top:y,width:w,height:h},fit,alt});
}
function comparisonTable(s,rows,x,y,ws,hs){
 const w=ws.reduce((a,b)=>a+b,0);
 const h=hs.reduce((a,b)=>a+b,0);
 const t=s.tables.add({rows:rows.length,columns:ws.length,left:x,top:y,width:w,height:h,columnWidths:ws,values:rows});
 t.styleOptions={headerRow:false,firstColumn:false,bandedRows:false,bandedColumns:false};
 t.borders.assign({style:'solid',fill:c.rule,width:0.7});
 for(let i=0;i<rows.length;i++){
  t.rows[i].height=hs[i];
  for(let j=0;j<ws.length;j++){
   const highlighted=rows[i][0]==='FLAIR'||rows[i][0]==='减力，FLAIR 开';
   const color=i===0?c.blue:highlighted?c.pale:j===0?c.pale:i%2===0?c.lighter:c.white;
   t.cells.block({row:i,column:j,rowCount:1,columnCount:1}).assign({fill:color,margins:{left:17,right:12,top:7,bottom:7},anchor:'middle'});
   t.getCell(i,j).text.style={typeface:font,fontSize:i===0?22:21,color:i===0?c.white:c.ink,bold:i===0||j===0||highlighted,verticalAlignment:'middle'};
  }
 }
}

// 1. 封面
{
 const s=slide();
 box(s,614,74,598,498,c.pale,'实机照片浅蓝衬底');
 await img(s,'gvr_bot2.png',634,94,558,431,'论文 GVR-Bot 实机赛道','cover');
 text(s,'FLAIR',68,135,520,122,{size:102,bold:true,color:c.blue});
 text(s,'扰动下的在线恢复',72,270,530,67,{size:46,bold:true,color:c.navy});
 text(s,'论文研读、六足仿真复现\n与 Go2-W 研究计划',73,366,530,112,{size:29,color:c.muted});
 text(s,'论文实机平台 GVR-Bot',645,537,546,29,{size:18,color:c.muted,align:'right'});
 horizontal(s,70,601,1142);
 text(s,'Allard 等，Nature Communications，2026',70,622,1138,38,{size:19,color:c.muted});
 note(s,'这次汇报想回答三个问题。第一，FLAIR 怎样恢复受扰机器人的指令跟踪，实验能支持多强的结论。第二，我们独立复现了原论文中的哪些结果。第三，在 Go2-W 上怎样利用主动试探，把现有在线补偿推进到一个可以对照验证的课题。',[paper,'实机图 '+repo+'/fast_adaptation/example/gifs/gvr_bot.gif']);
}

// 2. Question, challenge, contribution
{
 const s=slide('研究问题与主要贡献');
 text(s,'运行中受扰后，怎样恢复速度指令跟踪？',68,154,1143,66,{size:43,bold:true,color:c.navy});
 text(s,'例如单侧驱动力下降后，原本让机器人直行的指令会引起偏转。',70,224,1140,43,{size:25,color:c.muted});
 box(s,69,294,1143,68,c.pale,'主要挑战');
 text(s,'Challenge',89,311,170,39,{size:23,bold:true,color:c.blue});
 text(s,'扰动未知且可能变化，控制器需要边运行、边从有限的带噪数据中适应。',260,311,930,40,{size:22});
 text(s,'Contribution',70,405,1140,39,{size:24,bold:true,color:c.blue});
 const rows=[
  ['控制接口','在现有底层控制器前修正车体速度指令。'],
  ['在线适应','联合全局与局部响应模型，检测到工况变化时重置模型。'],
  ['实验验证','在履带车实机和六足仿真上检验上层补偿的效果。']
 ];
 rows.forEach(([a,b],i)=>{const y=466+59*i;text(s,a,70,y,167,36,{size:23,bold:true,color:c.navy});text(s,b,237,y,970,36,{size:23});});
 note(s,'可操控性在这里是用户发出的速度要求与机器人实际运动的一致性。作者没有针对所有可能扰动重新设计底层，而是加了一层可以在线学习的指令补偿。论文的贡献包括补偿结构、在线学习及工况切换、跨平台实验。贡献聚焦速度层恢复，实验不涉及重新规划任务目标。',[paper+' Introduction、Methods、Discussion']);
}

// 3. Methods in the field and paper baselines
{
 const s=slide('相关方法的分类与比较','按部署时如何产生补偿划分。优势要结合动作接口、反馈条件和评测任务判断。');
 comparisonTable(s,[
  ['方法类别','代表方法','优势与适用条件'],
  ['固定模型反馈','LQR','算得快、容易解释。名义模型偏差较大时，\n固定增益的补偿能力受限。'],
  ['在线扰动估计','L₁ 自适应控制','逐步估计扰动并反馈补偿。效果受所选\n参考模型和扰动假设影响。'],
  ['学习控制策略','论文基线：在线残差 TD3\n相关路线：RMA、LocoFormer','TD3 直接学习补偿动作，冷启动需要交互。\nRMA 和 LocoFormer 依靠预训练与历史推断。'],
  ['在线学习响应模型','FLAIR、OSRAM','直接学指令与运动的关系，可接在已有控制器前。\n需要可用的运动反馈和足够的指令覆盖。']
 ],69,185,[241,327,575],[48,74,74,83,83]);
 text(s,'LQR、L₁ 和在线 TD3 是原文实机基线。其他相关方法的实验设置不同。',70,585,1140,43,{size:22,bold:true,color:c.blue});
 note(s,'LQR 和 L₁ 都使用反馈，但前者在论文配置中用固定增益，后者会在运行中估计扰动。论文的残差 TD3 从零开始学习上层修正动作，和 FLAIR 共用数据预处理。RMA 和 LocoFormer 作为另一条适应路线，先在仿真中训练，再从部署历史中推断条件。OSRAM 与 FLAIR 接近，关注指令到运动的闭环建模。它们使用的任务和指标不同，原文结果只支持同一实验条件下的比较。',[supplement+' Supplementary Baselines','RMA https://arxiv.org/abs/2107.04034','LocoFormer https://generalist-locomotion.github.io/','OSRAM https://arxiv.org/abs/2609.28878']);
}

// 4. Learning and method, without implementation tutorial
{
 const s=slide('FLAIR 如何学习与补偿','在线学习上层响应模型，根据预测修正下一条速度指令。');
 const steps=[
  ['采集','将实际发出的命令与稍后的车体响应对齐，保留不同指令下的样本。'],
  ['拟合','用最小二乘拟合全局偏差，再用局部高斯过程细化各指令的响应预测。'],
  ['补偿','选择预测结果最接近期望速度的指令，交给原底层执行。'],
  ['切换','持续检查预测和实测的差异，识别工况变化后清理旧数据并重拟合。']
 ];
 steps.forEach(([a,b],i)=>{const y=198+i*86;horizontal(s,69,y,1143);text(s,a,70,y+19,159,39,{size:29,bold:true,color:c.blue});text(s,b,242,y+22,960,43,{size:24});});
 box(s,69,565,1143,82,c.pale,'训练阶段说明');
 text(s,'上层补偿模型在运行中拟合。六足仿真使用事先离线生成的底层步态库。',87,589,1101,40,{size:23,bold:true,color:c.navy});
 note(s,'训练数据是执行过的速度指令、当时状态和对齐后的实测运动。全局模型使用差速运动先验和最小二乘拟合整体偏差，局部高斯过程细化预测。指令用模型反算或搜索。数据按指令覆盖存储并过滤异常值，工况变化后清掉旧样本。论文的补偿层无需针对当前任务预训练。六足底层步态用 MAP-Elites 离线生成，默认 STATE_FAST 发令路径主要用全局状态模型求逆。',[paper+' Methods、算法 1',supplement+' Hexapod Results',study+'flair/02_feedback_and_adaptation.md']);
}

// 5. Experimental protocol
{
 const s=slide('Benchmark 与评价协议','实机检验不同扰动下的恢复，六足仿真检验换用另一种底层后能否补偿。');
 comparisonTable(s,[
  ['评测设计','GVR-Bot 履带车实机','Brax 六足仿真'],
  ['任务与环境','自动驾驶器通过 3 条赛道、5 个评价区段','18 自由度六足，沿 Chicane 弯道行驶两圈'],
  ['扰动分布','固定或途中切换的降额、方向相关模拟风\n以及坡道打滑和颠簸','右侧中腿两处执行器减力\n从回合开始生效'],
  ['对照设置','Driver、LQR、L₁、在线残差 TD3\n用无扰动 Driver 作为健康参照','健康与减力分别比较 FLAIR 开关\n四组共用底层步态库'],
  ['评价方式','VICON 记录实际速度，以 20 次重复统计\n跟踪误差和完赛时间','读取仿真速度与日志时间\n每组 20 回合，报告组中位数']
 ],69,182,[199,475,469],[50,68,87,88,88]);
 text(s,'主指标是速度跟踪误差。完赛时间用于辅助判断实际任务表现。',70,589,1141,43,{size:23,bold:true,color:c.blue});
 note(s,'Benchmark 需要说清平台、任务、扰动、对照和指标。实机用自动 Driver，五区段包括静态弯道、动态弯道、坡道、模拟风和鲁棒性赛段。VICON 提供外部评估，FLAIR 在线学习使用机载反馈。TD3 只尝试 Chicane。六足扰动直接写入仿真模型，试验回答的是固定减力条件下在线补偿是否有收益。跟踪误差比较期望与经时间对齐的实测前进和偏航响应。',[paper+' Results、Fig. 3–4',supplement+' Hexapod Results 和 Supplementary Results']);
}

// 6. Benchmark results and edge cases
{
 const s=slide('FLAIR 在哪些实机条件下更有效','以下百分数为相对无扰动 Driver 的增加量，越低越好。');
 comparisonTable(s,[
  ['方法','额外跟踪误差','额外完赛时间','动态弯道额外误差'],
  ['Driver','39.3%','53.3%','39.3%'],
  ['LQR','20.6%','18.9%','24.6%'],
  ['L₁ 自适应','25.6%','20.8%','30.3%'],
  ['FLAIR','10.3%','9.5%','17.1%']
 ],69,179,[270,276,265,332],[50,49,49,49,49]);
 text(s,'动态弯道、坡道、模拟风和颠簸赛段的跟踪误差均低于 LQR 与 L₁。',70,457,1140,43,{size:24,bold:true,color:c.blue});
 text(s,'静态弯道中 L₁ 与 FLAIR 接近（7.4% / 7.5%）。在线 TD3 未完成 Chicane。',70,511,1140,45,{size:22});
 text(s,'前两项指标为五区段中位数。按区段汇总，额外跟踪误差恢复率为 74.4%。',70,570,1140,43,{size:20,color:c.muted});
 note(s,'表中的前两列是各方法在五个区段的额外跟踪误差和额外完赛时间的中位数，动态弯道列单列便于看途中变化。FLAIR 在这四类较复杂赛段的额外跟踪误差较低，静态弯道时 L₁ 的名义误差 7.4%，FLAIR 为 7.5%。L₁ 在部分区段完赛更快，原文解释要同时看是否超过驾驶器速度要求。TD3 冷启动在安全终止规则下没有完成 Chicane，就没有同口径完赛指标。74.4% 是先算各区段消除的额外误差比例，再汇总。额外完赛时间恢复率为 72.2%。',[paper+' Table 1、Fig. 4',supplement+' Table 3–4、RL baseline']);
}

// 7. Challenge-method-task fit and limitations
{
 const s=slide('实验怎样验证设计，结论到哪里为止');
 const rows=[
  ['整体响应改变','全局模型学习速度缩放','固定降额与六足减力'],
  ['扰动在途中变化','检测工况变化并重拟合','动态弯道与坡道进入模拟风区'],
  ['偏差随状态变化、反馈有噪声','状态条件建模与异常样本筛选','方向相关模拟风与颠簸赛段']
 ];
 comparisonTable(s,[['挑战','对应设计','支撑实验'],...rows],69,160,[357,396,390],[47,65,65,65]);
 text(s,'五区段的模型更新耗时中位数为 218 ms。完整恢复时间需按扰动事件另测。',70,413,1140,31,{size:20,color:c.muted});
 box(s,69,461,1143,176,c.pale,'适用边界');
 text(s,'Limitations',89,476,1087,42,{size:28,bold:true,color:c.blue});
 text(s,'•  恢复取决于可用的反馈和剩余执行能力。传感器失效或动作不可达时会受限。\n•  全局先验依赖差速型响应。复杂本体与独立侧向外力仍缺同等强度的验证。\n•  赛道结果支持整套方法。单个模块贡献还需要更直接的对照。',89,525,1100,100,{size:21});
 note(s,'挑战、设计和测试工况能对上。固定降额用于检验能否学到整体变化，动态弯道用于检验工况切换，方向相关扰动和颠簸检验状态模型与数据筛选的组合。对应关系不等于单模块因果证据，正式表格的主指标是整段跟踪和完赛。论文还区分模型更新用时和完整回到稳定跟踪所用的时间。能力边界包括反馈质量、可达动作集合与差速型先验；作者对独立于执行器的侧向外力也保留结论。',[paper+' Methods、Fig. 5、Discussion',supplement+' Boundary Analysis']);
}

// 8. Reproduction work
{
 const s=slide('已完成的六足复现工作','固定官方 FLAIR v1.0.0、步态库和 Chicane 路线。');
 heading(s,'核对作者数据','复算四组指标，核对额外误差恢复率 138.8%。',69,188,562,{size:22});
 horizontal(s,69,286,567);
 heading(s,'跑通官方原版','在独立 CPU 环境跑通四组，每组 1 回合。',69,308,562,{size:22});
 horizontal(s,69,407,567);
 heading(s,'独立重复实验','定位网格处理瓶颈，验证加速入口，\n按 4 个种子分片完成 80 回合。',69,430,562,{size:22});
 await img(s,'../../flair_results/smoke-v100-long_trajectories.png',675,172,536,419,'四组官方原版试跑轨迹与参考航点');
 text(s,'原版试跑轨迹，虚线为航点路线',680,603,529,36,{size:18,color:c.muted,align:'right'});
 note(s,'本次工作先用作者四份 CSV 和 notebook 复算，再搭建独立 Conda 和 JAX CPU 环境，用官方入口跑通每组一回合。随后把网格加样和筛选做成外部加速入口，保留官方源码。验证覆盖 6 批网格输入和同种子前 110 个控制步，然后运行四个种子分片、每片四组各五回合。完整回合逐值等价尚未验证，因此单独标出正式批次用的加速入口。这里放的是原版试跑的四条示例轨迹。',[repo,data,study+'flair_reproduction_execution.md',study+'flair_results/smoke-v100-long_trajectories.png']);
}

// 9. Independent results
{
 const s=slide('独立复现重现了固定减力下的补偿收益','健康与减力各做 FLAIR 开、关，共 80 回合，全部到达末航点。');
 comparisonTable(s,[
  ['实验组（各 20 回合）','作者误差','本次误差','本次完赛时间'],
  ['健康，FLAIR 关','0.04599','0.04596','180.25 s'],
  ['健康，FLAIR 开','0.04370','0.04371','151.60 s'],
  ['减力，FLAIR 关','0.05032','0.05036','197.05 s'],
  ['减力，FLAIR 开','0.04431','0.04379','170.60 s']
 ],69,181,[325,242,243,333],[49,49,49,49,49]);
 text(s,'下降 13.0%',70,459,520,64,{size:42,bold:true,color:c.blue});
 text(s,'减力组总跟踪误差',71,524,539,38,{size:22});
 text(s,'缩短 26.45 s',648,459,565,64,{size:42,bold:true,color:c.blue});
 text(s,'减力组完赛时间',650,524,562,38,{size:22});
 text(s,'表中为组中位数。保留 Brax 原生偏航率对齐重算，减力组误差仍下降约 12.1%。',70,597,1141,43,{size:20,color:c.muted});
 note(s,'80 个正式回合均满足末航点验收。在作者统计口径下，独立减力组开启补偿的总跟踪误差比关闭组低约 13.0%，完赛时间缩短 26.45 秒。作者的 138.8% 用健康参考之外的额外误差作分母，因此和 13.0% 的口径不同。采用 Brax 原生偏航率重算仍有约 12.1% 的改善。这为后续搭建同接口基线提供可运行证据，尚未验证 Go2-W 途中突变。',[study+'flair_results/comparison_metrics.csv',study+'flair_results/formal_trials.csv',data]);
}

// 10. Research novelty and selection rationale
{
 const s=slide('用试探反馈的价值训练 PPO','研究轮足机器人在途中发生轮端降额或打滑时，哪些试探能加快恢复。');
 box(s,69,187,1143,74,c.blue,'同一次短时试探');
 text(s,'同一次短时试探',89,205,322,47,{size:30,bold:true,color:c.white});
 text(s,'共享动作、反馈与试探结束时的仿真状态',417,210,776,39,{size:24,color:c.white});
 box(s,347,261,2,28,c.line,'连接线 A');box(s,927,261,2,28,c.line,'连接线 B');
 box(s,69,289,558,110,c.pale,'A 采纳');box(s,654,289,558,110,c.lighter,'B 屏蔽');
 text(s,'A  用本次反馈更新 FLAIR',88,326,516,43,{size:25,bold:true,color:c.blue});
 text(s,'B  屏蔽本次反馈，继续原补偿',673,326,515,43,{size:25,bold:true,color:c.blue});
 text(s,'用后续误差差值作为辅助信号，训练 PPO 选择试探时机与幅度。',70,433,1140,45,{size:25,bold:true,color:c.navy});
 horizontal(s,70,500,1140);
 heading(s,'为什么选这个切入点','试探动作本身就可能纠偏。同动作对照可以单独衡量反馈的贡献。\nFLAIR 已有在线更新入口，便于在现有控制链路上检验这一点。',70,525,1140,{head:25,size:22});
 note(s,'主动试探可能同时产生两个效果：动作本身能把车头摆回来，取得的反馈也可能帮 FLAIR 更快掌握新工况。方案在仿真中从同一次试探的末态分支，只改变这批数据是否更新 FLAIR。两支继续闭环并统计固定窗口内的误差，屏蔽组误差减采纳组误差是数据收益。把该量用于 PPO 的辅助训练，主奖励仍保留跟踪、安全和动作代价。该接口可复用现有 FLAIR，明确的普通试探 PPO 对照能检验额外信号是否值得。',[study+'flair/04_go2w_paper_plan.md',paper]);
}

// 11. Work plan
{
 const s=slide('后续工作计划','先验证数据的独立作用，再比较 Go2-W 上的恢复效果。');
 const stages=[
  ['六足机制验证','用固定短时试探跑通双分支，检查收益是否稳定、可重复。'],
  ['Go2-W 仿真','接入 FLAIR，分别测试途中轮端降额与低附着，做同预算训练和留出测试。'],
  ['Go2-W 实机','核对车体速度反馈与时间同步，选可重复的代表性扰动验证。']
 ];
 stages.forEach(([a,b],i)=>{const y=183+i*113;horizontal(s,69,y,1143);text(s,a,70,y+26,259,42,{size:29,bold:true,color:c.blue});text(s,b,324,y+30,884,59,{size:22});});
 box(s,69,540,1143,118,c.pale,'核心对照与指标');
 text(s,'核心对照',89,560,146,36,{size:22,bold:true,color:c.blue});
 text(s,'原 FLAIR、普通试探 PPO、带反馈收益的 PPO',239,561,952,36,{size:22});
 text(s,'恢复指标',89,605,149,36,{size:22,bold:true,color:c.blue});
 text(s,'扰动后累计跟踪误差、恢复时间、试探次数和失稳率',239,606,951,36,{size:22});
 note(s,'短期先解决快照、样本干预和评测口径，判断反馈效应能否在六足可重复测到。迁移 Go2-W 时统一底层控制器、测试环境与动作边界。主对照中两种 PPO 使用相同动作和观测，比较有无辅助信号，并把额外分支计入仿真预算。留出扰动参数，统计故障后的恢复误差和时间。实机从可控且可重复的代表场景开始。',[study+'flair/04_go2w_paper_plan.md','Go2-W Robot Lab https://github.com/fan-ziqi/robot_lab/tree/v2.3.2/source/robot_lab/robot_lab/tasks/manager_based/locomotion/velocity/config/wheeled/unitree_go2w']);
}

const candidate=path.join(work,'candidate-paper-review.pptx');
await (await PresentationFile.exportPptx(p)).save(candidate);
const skill='C:/Users/laiyo/.codex/plugins/cache/openai-primary-runtime/presentations/26.1112.11217/skills/presentations';
const python='C:/Users/laiyo/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe';
const {finalizePresentation}=await import(pathToFileURL(path.join(skill,'container_tools','artifact_tool_utils.mjs')).href);
await finalizePresentation({
 workspaceDir:root,candidatePath:candidate,finalPath:target,pythonExecutable:python,
 integrityValidatorPath:path.join(skill,'container_tools','inspect_presentation_package_integrity.py'),
 layoutValidatorPath:path.join(skill,'container_tools','inspect_presentation_layout_geometry.py'),
 layoutArgs:['--expected-slide-size-emu','12192000,6858000','--validate-heading-fit',...[3,5,6,7,9].flatMap(i=>['--require-native-table-slide',String(i)])],
 requiredNativeTableOwnerSlides:[3,5,6,7,9],explicitTotalSlideCount:11,
 fontPolicy:{basis:'design',families:[font]},verifyArtifactToolImport:true,
 receiptPath:path.join(work,'validation-paper-review.json')
});
console.log(target);



