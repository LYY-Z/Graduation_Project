from pathlib import Path
import re

path = Path(r"G:\毕设\02_learning\04_review\deliverables\ur7e_deployment_brief.md")
text = path.read_text(encoding="utf-8-sig")
fence = chr(96) * 3
assert "### 代码组织与模块交接" not in text

diagram = """flowchart TB
    subgraph INPUT["已有设备与接口"]
        CAM["腕部相机与 Orbbec 驱动"]
        ROBOT["UR7e 控制柜"]
    end
    CAM -->|"ROS RGB"| BRIDGE["图像桥接<br/>预处理与帧交接"]
    ROBOT -->|"RTDE 状态"| OBS["观察构造<br/>时间配对与位置映射"]
    BRIDGE --> OBS
    OBS --> POLICY["原版 Diffusion Policy<br/>生成动作序列"]
    POLICY --> GUARD["输出适配<br/>坐标转换 平滑 限幅"]
    GUARD --> CHECK["发送前复查<br/>状态 目标 输入时效"]
    CHECK --> CONTROL["私有控制模块<br/>发送 TCP 目标"]
    CONTROL --> ROBOT
    ROBOT --> FEEDBACK["实际反馈<br/>位置 速度 控制进度"]
    FEEDBACK --> DONE{"到位并停稳"}
    DONE -->|"是 读取新观察"| OBS
    DONE -->|"未完成且状态正常"| FEEDBACK
    FEEDBACK -->|"异常或超时"| EXIT["尝试停止并记录退出"]

    classDef reused fill:#F0F0F0,stroke:#777,color:#111;
    classDef adapter fill:#EAF3FA,stroke:#527B9F,color:#111;
    class CAM,ROBOT,POLICY reused;
    class BRIDGE,OBS,GUARD,CHECK,CONTROL,FEEDBACK,EXIT adapter;
"""
start = text.index("整体流程为：")
end = text.index("\n适配层连接了模型", start)
text = text[:start] + "整体流程如下。灰色表示已有设备或原版策略，蓝色表示本项目接入和编排的环节。\n\n" + fence + "mermaid\n" + diagram + fence + "\n" + text[end:]

old = "这一设计将硬件差异集中在输入适配层，使原策略可以按原有接口计算。裁剪是否覆盖完整任务区域、腕部视角是否适合任务，需要在后续任务实验中进一步确认。"
new = old + "\n\n当前一次输入包含两张 RGB 图片和两个对应的二维位置，数组形状分别为 image [1,2,3,96,96] 和 agent_pos [1,2,2]。这里的尺寸和排列由所选 checkpoint 决定，适配层负责满足这一输入约定。"
assert old in text
text = text.replace(old, new, 1)

old = "当前运行保留原 checkpoint 的采样流程。为了先验证实机接口，每轮仅选取可用动作段的第一个目标；待其执行完成后，再读取新观察、重新推理。"
new = old + "\n\n代码中，观察转换为模型张量后，推理封装直接调用原策略，核心调用为：\n\n" + fence + "python\nwith torch.inference_mode():\n    result = policy.predict_action(tensors)\n" + fence + "\n\n原策略负责视觉编码和动作采样；我们编写的封装负责准备输入、加载权重和整理返回结果，使模型计算与硬件操作保持清晰的接口。"
assert old in text
text = text.replace(old, new, 1)

old = "这层约束实际作用于最终目标。例如，首轮预测换算出的原始目标距离约为 46.4 毫米，经过处理后提交的运动目标约为 0.5 毫米。单步距离、累计路程和执行次数均设置了小范围上限。"
new = old + "\n\n从预测到候选目标，主流程中的关键交接是：\n\n" + fence + "python\nraw = output[\"action\"][0, 0]\ndesired = mapping.to_base(raw)\ntarget = guard.propose(desired, actual_pose, source_age_s=source_age_s)\n" + fence + "\n\n三行分别完成“选择本轮动作、换回真实坐标、生成受限目标”。它们还不发送运动；实际发送及反馈检查由后面的控制模块负责。"
assert old in text
text = text.replace(old, new, 1)

old = "修改后的代码独立编译为项目专用控制模块，状态读取仍使用原接收接口。"
new = "修改后的代码在服务器独立编译为 Python 可加载的项目专用模块，状态读取仍使用原接收接口。外层动作约束负责决定“允许提交多大的目标”，修改后的控制库负责约束“目标在通信异常时如何处理”，两者分别作用于目标计算和指令传输。"
assert old in text
text = text.replace(old, new, 1)

old = "工程按采集、推理和控制三个模块组织，保留原论文代码及权重来源；每次运行记录实际输入、原始预测、最终目标和运动反馈，便于复查和后续实验复现。"
new = old + "\n\n主程序的执行顺序为：加载模型与启动采集 → 等待有效观察并预热 → 建立执行基线 → 获取新观察并推理 → 处理目标、执行和确认 → 进入下一轮或清理退出。当前短测至多提交三条目标。\n\n### 代码组织与模块交接\n\n下图展示重构版的主要调用关系，实机结果仍对应保留的原部署版本。主流程负责组织步骤，硬件、推理和控制模块分别实现各自接口。\n\n" + fence + "mermaid\n" + """flowchart LR
    ENTRY["cli.py<br/>选择模式与读取配置"] --> PIPE["pipeline.py<br/>组织运行流程"]
    PIPE --> HW["hardware<br/>图像 状态 观察历史"]
    PIPE --> INF["inference/policy.py<br/>加载与调用策略"]
    PIPE --> CTRL["geometry 与 control<br/>坐标 约束 执行反馈"]
    PIPE -.-> LOG["recording.py<br/>保存输入与事件"]
    INF --> ORIGINAL["third_party/diffusion_policy<br/>原版策略计算"]
    CTRL --> SDK["项目私有 ur_rtde 扩展<br/>控制通信"]
""" + fence + "\n\n主要业务结构如下：\n\n" + fence + "text\n" + """diffusion_policy_ur7e_refactored/
├── src/dp_ur7e/
│   ├── cli.py / config.py         运行入口与配置
│   ├── pipeline.py                采集到执行的主流程
│   ├── hardware/
│   │   ├── camera_bridge.py       ROS 图像桥接
│   │   ├── camera.py              图片处理与帧文件
│   │   ├── robot_state.py         RTDE 状态读取
│   │   └── observations.py        双帧观察与时间配对
│   ├── inference/policy.py        原策略加载与推理封装
│   ├── geometry.py               真实坐标与模型坐标转换
│   ├── control/
│   │   ├── safety.py              动作限幅和平滑
│   │   └── robot.py               发送、反馈与控制库核验
│   └── recording.py              运行证据保存
├── third_party/
│   ├── diffusion_policy/          固定版本论文源码
│   └── ur_rtde_guarded/           修改后的控制源码与补丁
├── models/                        checkpoint 与来源清单
├── scripts/                       环境、下载、编译和验证工具
└── runs/                          每次运行的输入与反馈记录
""" + fence + "\n\n原论文模型和第三方依赖保留来源，新增适配集中在 src/dp_ur7e。这样的组织使硬件调整、模型更换和执行行为修改各有明确位置，也便于对照原版与适配代码。"
assert old in text
text = text.replace(old, new, 1)

text = text.replace(
    "[原部署实机记录](../../../03_code/diffusion_policy_ur7e/runs/guarded_execution/20261025T085457Z_live/README.md)",
    "[原部署实机记录](../../../03_code/diffusion_policy_ur7e/runs/guarded_execution/20261025T085457Z_live/README.md) · [重构版主流程](../../../03_code/diffusion_policy_ur7e_refactored/src/dp_ur7e/pipeline.py)"
)
path.write_text(text, encoding="utf-8")
print("Updated report", len(text), "characters")
print("Mermaid diagrams", text.count(fence + "mermaid"))
print("Python excerpts", text.count(fence + "python"))
print("Code fences balanced", sum(line.startswith(fence) for line in text.splitlines()) % 2 == 0)
for link in re.findall(r"\]\(([^)]+)\)", text):
    if not link.startswith("http"):
        assert (path.parent / link).resolve().is_file(), link
print("Local references verified")

