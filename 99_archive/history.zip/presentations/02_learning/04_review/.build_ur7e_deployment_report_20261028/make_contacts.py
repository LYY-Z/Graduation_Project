from PIL import Image, ImageDraw
from pathlib import Path
folder = Path(r"G:\毕设\02_learning\04_review\.build_ur7e_deployment_report_20261028\render")
images = sorted(folder.glob("page-*.png"))
for start in range(0, len(images), 6):
    group = images[start:start + 6]
    w, h = Image.open(group[0]).size
    canvas = Image.new("RGB", (w * 3, (h + 26) * 2), "#d0d0d0")
    draw = ImageDraw.Draw(canvas)
    for j, path in enumerate(group):
        x, y = (j % 3) * w, (j // 3) * (h + 26)
        draw.text((x + 10, y + 5), path.stem, fill="black")
        canvas.paste(Image.open(path).convert("RGB"), (x, y + 26))
    canvas.save(folder / ("contact_%02d.png" % (start // 6 + 1)))
print("Inspected page images:", len(images), "dimensions:", w, h)
