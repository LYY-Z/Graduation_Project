from pathlib import Path
import ast, re
path = Path(r"G:\毕设\02_learning\04_review\deliverables\ur7e_deployment_brief.md")
text = path.read_text(encoding="utf-8")
fence = chr(96)*3
blocks = re.findall(fence + r"python\n(.*?)" + fence, text, re.S)
for b in blocks:
    ast.parse(b)
policy = Path(r"G:\毕设\03_code\diffusion_policy_ur7e_refactored\src\dp_ur7e\inference\policy.py").read_text(encoding="utf-8")
pipeline = Path(r"G:\毕设\03_code\diffusion_policy_ur7e_refactored\src\dp_ur7e\pipeline.py").read_text(encoding="utf-8")
assert all(line.strip() in policy for line in blocks[0].strip().splitlines())
assert all(line.strip() in pipeline for line in blocks[1].strip().splitlines())
assert len(blocks)==2
assert text.count(fence + "mermaid")==2
assert all(x in text for x in ["0.4950","0.7510","0.8314","132","原部署版本","重新验收"])
print("Two source excerpts match implementation and parse successfully")
print("Two diagrams and historical result boundaries retained")
print("Main headings:",len(re.findall(r"^## ",text,re.M)))
