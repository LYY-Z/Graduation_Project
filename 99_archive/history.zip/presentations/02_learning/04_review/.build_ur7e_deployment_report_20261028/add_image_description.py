from docx import Document
from pathlib import Path
path = Path(r"G:\毕设\02_learning\04_review\deliverables\ur7e_diffusion_policy_deployment_report.docx")
document = Document(path)
assert len(document.inline_shapes) == 1
properties = document.inline_shapes[0]._inline.docPr
properties.set("title", "从真实设备到受限运动的闭环流程")
properties.set("descr", "腕部相机图像与 UR7e 状态经观察构造进入原版策略；策略输出经坐标映射、平滑限幅后交给 RTDE 执行，反馈到位后重新采集。")
document.save(path)
print("Added accessible diagram description")
