from pathlib import Path
path = Path(r"G:\毕设\02_learning\04_review\.build_ur7e_deployment_report_20261028\build_report.py")
text = path.read_text(encoding="utf-8")
old = 'style_font(styles["Title"],21,True)\n'
new = '''style_font(styles["Title"],21,True)
title_ppr = styles["Title"].element.get_or_add_pPr()
title_borders = title_ppr.find(qn("w:pBdr"))
if title_borders is not None:
    title_ppr.remove(title_borders)
'''
assert text.count(old) == 1
text = text.replace(old, new)
old = "def newpage(): doc.add_page_break()"
new = '''page_break_counter = 0
def newpage():
    global page_break_counter
    page_break_counter += 1
    if page_break_counter == 8:
        doc.add_page_break()
'''
assert text.count(old) == 1
text = text.replace(old, new)
path.write_text(text, encoding="utf-8")
