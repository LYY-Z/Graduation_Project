from pathlib import Path
from collections import Counter
import json, math
from PIL import Image, ImageDraw, ImageFont
from docx import Document
from docx.shared import Cm, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.section import WD_SECTION
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.opc.constants import RELATIONSHIP_TYPE as RT

root = Path(r"G:\毕设")
build = root / "02_learning" / "04_review" / ".build_ur7e_deployment_report_20261028"
out = root / "02_learning" / "04_review" / "deliverables" / "ur7e_diffusion_policy_deployment_report.docx"
run = root / "03_code" / "diffusion_policy_ur7e" / "runs" / "guarded_execution" / "20261025T085457Z_live"
events_path = run / "records" / "20261025T085510Z_f38f3fe7" / "events.jsonl"
events = [json.loads(x) for x in events_path.read_text(encoding="utf-8").splitlines() if x.strip()]
counts = Counter(x["event"] for x in events)
motions = [x for x in events if x["event"] == "motion" and x.get("completed")]
assert len(motions) == 3 and counts["motion_feedback"] == 132
def dist(a,b):
    return 1000 * math.sqrt(sum((a[i]-b[i])**2 for i in range(3)))
rows = []
for i, m in enumerate(motions, 1):
    rows.append([str(i), f'{dist(m["target"],m["actual_before"]):.4f}',
                 f'{dist(m["actual_after"],m["actual_before"]):.4f}',
                 f'{dist(m["target"],m["actual_after"]):.4f}'])
net = dist(motions[-1]["actual_after"], motions[0]["actual_before"])
trial = json.loads((run / "trial_result.json").read_text(encoding="utf-8"))
accept = json.loads((root / "02_learning" / "06_refactored_code" / "verification" / "acceptance.json").read_text(encoding="utf-8"))
proposal = trial["proposals"][0]["candidate"]
raw = proposal["raw_action_px"]
desired = proposal["desired_base_xyz_m"]
raw_travel = dist(desired, motions[0]["actual_before"])
assert 46 < raw_travel < 47 and abs(net-2.0222595852)<1e-6
assert accept["offline_tests"]["passed"] == 131 and accept["offline_tests"]["skipped"] == 5

def font(size, bold=False):
    return ImageFont.truetype(r"C:\Windows\Fonts\msyhbd.ttc" if bold else r"C:\Windows\Fonts\msyh.ttc", size)

im = Image.new("RGB", (2100, 700), "white")
dr = ImageDraw.Draw(im)
navy, blue, border, soft = (38, 65, 94), (42, 86, 125), (170, 187, 204), (235, 242, 248)
labels = [
    ("真实设备", "腕部 RGB\nUR7e 状态"),
    ("观察构造", "时间配对\n图像与位置"),
    ("原版策略", "视觉编码\n动作去噪"),
    ("目标处理", "坐标映射\n平滑与限幅"),
    ("实机反馈", "RTDE 执行\n实际到位")
]
xs=[45,455,865,1275,1685]; y0,y1=105,335
for i,(title,subtitle) in enumerate(labels):
    x=xs[i]
    dr.rounded_rectangle((x,y0,x+360,y1),radius=16,fill=soft,outline=border,width=3)
    dr.text((x+180, y0+30),title,fill=navy,font=font(51, True),anchor="ma")
    dr.multiline_text((x+180,y0+110),subtitle,fill=(35,40,46),font=font(38),anchor="ma",align="center",spacing=8)
    if i<4:
        dr.line((x+368,220,x+402,220),fill=blue,width=7)
        dr.polygon([(x+405,220),(x+389,209),(x+389,231)],fill=blue)
dr.line((1870,440,1870,515,240,515,240,450),fill=blue,width=6)
dr.polygon([(240,440),(229,457),(251,457)],fill=blue)
dr.text((1050,560),"到位后重新采集，按当前短测设置最多提交三条目标",font=font(37),fill=(55,65,75),anchor="ma")
diagram = build / "deployment_flow.png"
im.save(diagram)

doc=Document()
sec=doc.sections[0]
sec.page_width=Cm(21); sec.page_height=Cm(29.7)
sec.top_margin=Cm(1.65); sec.bottom_margin=Cm(1.55)
sec.left_margin=Cm(2.0); sec.right_margin=Cm(2.0)
sec.header_distance=Cm(0.7); sec.footer_distance=Cm(0.7)
doc.core_properties.title="UR7e 腕部相机与 Diffusion Policy 部署汇报"
doc.core_properties.author=""
styles=doc.styles

def style_font(s, size, bold=False):
    s.font.name="Microsoft YaHei"
    s.font.size=Pt(size)
    s.font.bold=bold
    s.font.color.rgb=RGBColor(0,0,0)
    s.element.get_or_add_rPr().get_or_add_rFonts().set(qn("w:eastAsia"),"Microsoft YaHei")
    s.element.get_or_add_rPr().get_or_add_rFonts().set(qn("w:ascii"),"Arial")
    s.element.get_or_add_rPr().get_or_add_rFonts().set(qn("w:hAnsi"),"Arial")
normal=styles["Normal"]; style_font(normal,10.5)
normal.paragraph_format.space_after=Pt(4)
normal.paragraph_format.line_spacing=1.22
style_font(styles["Title"],21,True)
title_ppr = styles["Title"].element.get_or_add_pPr()
title_borders = title_ppr.find(qn("w:pBdr"))
if title_borders is not None:
    title_ppr.remove(title_borders)
styles["Title"].paragraph_format.space_after=Pt(8)
for name, size in [("Heading 1",15),("Heading 2",11.5)]:
    style_font(styles[name],size,True)
    styles[name].paragraph_format.space_before=Pt(7)
    styles[name].paragraph_format.space_after=Pt(5)

header=sec.header.paragraphs[0]
header.alignment=WD_ALIGN_PARAGRAPH.RIGHT
r=header.add_run("Diffusion Policy 实机部署  |  汇报提纲")
r.font.size=Pt(8); r.font.color.rgb=RGBColor(65,65,65)
footer=sec.footer.paragraphs[0]
footer.alignment=WD_ALIGN_PARAGRAPH.RIGHT
r=footer.add_run("第 "); r.font.size=Pt(8)
field=OxmlElement("w:fldSimple"); field.set(qn("w:instr"),"PAGE"); footer._p.append(field)
r=footer.add_run(" 页"); r.font.size=Pt(8)

def para(text="", bold_prefix=None, style=None, size=None, after=4, before=0):
    p=doc.add_paragraph(style=style)
    p.paragraph_format.space_before=Pt(before); p.paragraph_format.space_after=Pt(after)
    if bold_prefix and text.startswith(bold_prefix):
        p.add_run(bold_prefix).bold=True
        p.add_run(text[len(bold_prefix):])
    else: p.add_run(text)
    if size:
        for run in p.runs: run.font.size=Pt(size)
    return p

def heading(text):
    return doc.add_heading(text, level=1)

def sub(text):
    return doc.add_heading(text, level=2)

def speech(text):
    p=doc.add_paragraph()
    p.paragraph_format.space_before=Pt(6)
    p.paragraph_format.space_after=Pt(3)
    r=p.add_run("口述参考  "); r.bold=True
    p.add_run(text)
    return p

def source_line(text):
    p=doc.add_paragraph()
    p.paragraph_format.space_after=Pt(2)
    r=p.add_run(text); r.font.size=Pt(8.3); r.font.color.rgb=RGBColor(75,75,75)
    return p

def table(headers, data, widths=None, font_size=9.3):
    t=doc.add_table(rows=1, cols=len(headers))
    t.alignment=WD_TABLE_ALIGNMENT.CENTER
    t.autofit=False
    tblPr=t._tbl.tblPr
    borders=tblPr.find(qn("w:tblBorders"))
    if borders is None:
        borders=OxmlElement("w:tblBorders"); tblPr.append(borders)
    for edge in ("top","left","bottom","right","insideH","insideV"):
        el=OxmlElement("w:"+edge); el.set(qn("w:val"),"single")
        el.set(qn("w:sz"),"4"); el.set(qn("w:color"),"D9D9D9"); borders.append(el)
    mar=OxmlElement("w:tblCellMar")
    for edge,v in [("top","55"),("bottom","55"),("left","90"),("right","90")]:
        el=OxmlElement("w:"+edge); el.set(qn("w:w"),v); el.set(qn("w:type"),"dxa"); mar.append(el)
    tblPr.append(mar)
    def cell_fill(cell, val):
        tcPr=cell._tc.get_or_add_tcPr()
        shd=tcPr.find(qn("w:shd"))
        if shd is None: shd=OxmlElement("w:shd"); tcPr.append(shd)
        shd.set(qn("w:fill"),val)
    def put(cell,text,header=False,center=False):
        cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
        p=cell.paragraphs[0]; p.paragraph_format.space_after=Pt(0)
        p.paragraph_format.line_spacing=1.14
        if center: p.alignment=WD_ALIGN_PARAGRAPH.CENTER
        run=p.add_run(str(text)); run.bold=header; run.font.size=Pt(font_size)
        run.font.color.rgb=RGBColor(255,255,255) if header else RGBColor(0,0,0)
        rpr=run._element.get_or_add_rPr(); rfonts=rpr.rFonts
        if rfonts is None: rfonts=OxmlElement("w:rFonts"); rpr.insert(0,rfonts)
        rfonts.set(qn("w:eastAsia"),"Microsoft YaHei")
    hdr=t.rows[0]
    trPr=hdr._tr.get_or_add_trPr(); repeat=OxmlElement("w:tblHeader"); repeat.set(qn("w:val"),"true"); trPr.append(repeat)
    for j,h in enumerate(headers):
        put(hdr.cells[j],h,True, len(headers)>2)
        cell_fill(hdr.cells[j],"2C4A67")
    for i,row in enumerate(data):
        cells=t.add_row().cells
        for j,v in enumerate(row):
            put(cells[j],v,False, len(headers)>2 and j==0)
            if i%2==1: cell_fill(cells[j],"F2F6F9")
    if widths:
        for row in t.rows:
            for j,cm in enumerate(widths): row.cells[j].width=Cm(cm)
    doc.add_paragraph().paragraph_format.space_after=Pt(0)
    return t

def hyperlink(p, label, url):
    rel = p.part.relate_to(url, RT.HYPERLINK, is_external=True)
    link = OxmlElement("w:hyperlink"); link.set(qn("r:id"),rel)
    run=OxmlElement("w:r"); props=OxmlElement("w:rPr")
    color=OxmlElement("w:color"); color.set(qn("w:val"),"254B70"); props.append(color)
    underline=OxmlElement("w:u"); underline.set(qn("w:val"),"single"); props.append(underline)
    run.append(props); txt=OxmlElement("w:t"); txt.text=label; run.append(txt); link.append(run)
    p._p.append(link)

def refs(label,url):
    p=doc.add_paragraph()
    p.paragraph_format.space_after=Pt(2)
    hyperlink(p,label,url)

page_break_counter = 0
def newpage():
    global page_break_counter
    page_break_counter += 1
    if page_break_counter == 8:
        doc.add_page_break()


# 1
doc.add_paragraph("UR7e 腕部相机与 Diffusion Policy 部署汇报", style="Title")
para("真实硬件输入到受限运动的实现过程与验证",size=12,after=7)
para("汇报建议：正文按顺序讲述约 10 分钟；附录用于回答代码、来源和复现实验方面的追问。",size=9.5)
para("本阶段目标是复用论文公开策略，在 UR7e 和单腕部相机上建立可追溯的数据到运动链路。原部署版本完成一次受看护的三目标短测；目前的结果证明接口与受限运动链路可用。")
doc.add_picture(str(diagram), width=Cm(16.7))
para("阶段范围：现用权重来自仿真 Push-T，真实腕部相机与仿真观察存在差异；工程映射尚未完成任务标定，尚无真实 Push-T 任务成功率。",after=3)
speech("老师好，这次汇报的是把 Diffusion Policy 接到现有 UR7e 和腕部相机上的工作。目标先是让真实图像和机械臂状态经过原版模型，形成经过限制的目标，并由机械臂执行。我们已经用原部署版本完成一轮真实短测，下面按数据如何流动、为什么这样设计、如何验证三个方面说明。")

# 2
newpage(); heading("一 系统组成与复用边界")
para("系统由已有硬件与软件、论文策略和权重、以及新增适配与执行层组成。")
table(["组成","来源","在当前链路中的作用"],[
["机械臂与相机","现有 UR7e 与 Gemini 335L","控制柜提供状态，腕部相机提供 RGB"],
["相机驱动与 ROS 2","服务器已有 Orbbec 驱动与 ROS Humble","采集图片并发布图像话题"],
["论文实现","官方 Diffusion Policy 固定版本","复用策略、视觉编码、动作采样与归一化"],
["模型权重","官方仿真 Push-T 图像 Transformer","提供 EMA 参数和训练时归一化信息"],
["适配与执行层","本项目新增和整理","采集、配对、坐标映射、限幅、执行与反馈"],
["控制通信","ur_rtde 1.6.5 和项目私有控制扩展","只读状态；受控发送短运动目标"]
],widths=[3.2,5.0,8.8],font_size=9.0)
para("具体复用的是原版策略类，而当前运行入口使用本项目的采集和执行代码。原版实机 RealEnv、RealSense 采集器及插值控制器保留作参考。")
speech("系统可以分成三部分：第一，服务器已有 UR 控制器、相机驱动和 ROS；第二，保留论文的策略实现和公开权重；第三，为单腕部相机与 UR7e 增加观察构造、坐标转换、受限执行和反馈记录。这样既能追溯原模型来源，也能把硬件适配和模型本身清楚分开。")
source_line("依据：原论文仓库固定提交 5ba07ac…；模型清单与项目源文件清单。")

# 3
newpage(); heading("二 硬件输入与观察构造")
para("相机驱动通过 ROS 2 发布 RGB；桥接进程验证图像来源和时间，将画面中心裁剪并缩放至 96 × 96，写入最新帧文件。模型进程通过 RTDE Receive 获取 TCP 位姿与关节状态。两条采集通路持续更新，并按主机接收时间选取最近两次图像及对应的先行机器人状态。")
table(["数据","输入前处理","模型入口形状"],[
["图像","RGB，裁剪缩放，通道前置，像素除以 255","[1, 2, 3, 96, 96]"],
["末端位置","实际 TCP 的 X、Y 相对会话起点映射到二维模型坐标","[1, 2, 2]"]
],widths=[2.7,9.2,5.1],font_size=9.1)
sub("真实位置怎样对应模型位置")
para("以会话开始时的 TCP 位置为 p₀，将其映射到模型坐标 [256,256]；当前比例为 1000 模型坐标单位／米。实际 X 相对 p₀ 增加 1 mm，对应模型坐标增加 1。该映射由工程配置确定，尚不是相机与桌面的标定结果。")
para("模型输入中的图片和位置来自相近时刻；两张图片必须为不同帧。ROS 图像时间、控制器时间和主机单调时钟分别记录，软件配对不能等同于硬件同步。")
speech("输入适配需要解决格式和时间两个问题。相机图片先变成模型要求的尺寸，机械臂通过 RTDE 提供真实 TCP 状态。系统选取两次图像，并分别匹配时间接近的机器人状态；再把米制位置转换到仿真模型使用的二维尺度。这个映射让数据接口可以衔接，但它仍需要后续标定，不能直接说明真实动作方向已经准确。")

# 4
newpage(); heading("三 原版策略怎样产生动作")
para("模型加载时校验 checkpoint 大小和 SHA-256，按权重中的配置实例化原策略，严格加载 EMA 参数与内嵌归一化器。在一次推理中，真实观察先按训练时的规则归一化，视觉编码器提取图像特征，并与二维位置组成条件。")
para("采样从 10 步、每步 2 维的高斯随机动作计划开始。Transformer 在每个扩散级别预测噪声，DDPM 调度器根据预测更新动作；当前权重使用 100 次迭代。完成后按训练时规则反归一化，得到原模型的二维任务坐标。")
table(["输出","形状","含义"],[
["action_pred","[1,10,2]","完整 10 步预测"],
["action","[1,8,2]","与观察时间对齐的 8 步可用动作"],
["本轮处理对象","[2]","当前执行流程取 action 的第一个目标"]
],widths=[3.7,4.4,8.9],font_size=9.2)
para("视觉特征在该次去噪循环中重复使用。100 次去噪属于一次模型计算，不是 100 次机械臂运动。")
speech("模型部分尽量保持论文实现。权重加载后，输入先经过归一化和视觉编码，然后从随机动作计划开始，通过 Transformer 和 DDPM 反复更新，得到十步预测，再按原策略取出八步可用动作。目前控制层每轮只取第一个目标，实际完成后再采集新观察并重新推理。")

# 5
newpage(); heading("四 动作适配与运动约束")
para("策略输出属于仿真任务坐标。执行层先按会话原点与比例反向映射到真实 TCP 目标，读取推理结束后的实际位姿，计算当前位置到原始目标的位移；再依次进行单步限幅、平滑、累计预算与目标范围检查。")
para(f'实测首轮原始输出为 [{raw[0]:.2f}, {raw[1]:.2f}]，换算后的原始目标距离发送前实际位置约 {raw_travel:.1f} mm；最终受限命令长度为 {dist(motions[0]["target"],motions[0]["actual_before"]):.4f} mm。')
table(["项目","本次短测的约束"],[
["单条命令位移","≤ 1 mm，按二维位移长度限制"],
["平滑","系数 0.5，首次从零位移开始"],
["累计命令路程","≤ 3 mm"],
["相对初始位置范围","半径 ≤ 3 mm"],
["执行次数与速度","最多 3 条；速度 2 mm/s，加速度 5 mm/s²"],
["其余自由度","目标高度和朝向保持参考值；夹爪不发送命令"]
],widths=[5.1,11.9],font_size=9.0)
para("发送前再次确认状态、活动 TCP、目标可达性和原始观察时效。软件限幅约束的是运动命令，现场空间和碰撞条件仍需要实际确认。")
speech("输出适配解决了模型坐标不能直接用于机器人这一问题。系统先反向映射，再以当前实测位置计算位移，限制单步长度并平滑；同时约束累计路程、启动位置周围范围和命令次数。首轮原始目标距离约四十六毫米，最终发送的目标约半毫米，说明限制作用于真实目标生成过程。")

# 6
newpage(); heading("五 启动编排与反馈确认")
para("运行分为三个进程：现场已有或人工启动的相机驱动、独立启动的 ROS 图像桥接、使用隔离环境启动的模型主程序。主程序内部自动建立只读 RTDE 连接、加载策略、构造观察、推理并执行所选模式。")
table(["模式","主要检查","运动控制"],[
["inspect","配置、输入契约和权重指纹","无"],
["capture","真实图像与状态采集、观察配对","无"],
["shadow","真实输入与模型推理、记录预测","无"],
["preview","推理后生成受限候选目标","无控制连接"],
["execute","发送受限目标、监测并确认到位","建立控制连接"]
],widths=[3.0,10.4,3.6],font_size=9.0)
para("执行模式先使用一组真实观察进行预热，并丢弃预热结果；随后记录静止基线，取得新观察并生成正式目标。私有控制模块通过异步 moveL 发送目标，RTDE 持续返回实际位姿、速度和关节状态。")
para("完成判据同时要求异步运动结束、TCP 接近目标、速度足够低，并连续满足反馈条件。命令被确认与机械臂实际到位是两项不同证据。")
speech("运行时相机驱动和桥接分别提供数据，主程序再按所选模式工作。执行前先预热并丢弃首次结果，再重新采集数据、检查控制柜状态。运动命令采用异步方式，程序持续读取实际位姿和速度。只有控制进度结束、位置接近目标并且已经停稳，才把这条运动记录为完成。")

# 7
newpage(); heading("六 实机结果与证据")
para("2026 年 10 月 25 日，原部署版本完成一次受看护的三目标短测。输入为真实腕部 RGB 和 UR7e 状态，使用官方仿真 Push-T 权重进行推理，输出经过映射和约束后发送至机械臂。")
table(["目标","命令距离 mm","实际位移 mm","末端误差 mm"],rows,widths=[2.3,4.4,4.9,5.4],font_size=9.5)
para(f'三条运动均得到控制确认并满足到位条件，共记录 {counts["motion_feedback"]} 条运动反馈；累计命令距离为 {sum(dist(m["target"],m["actual_before"]) for m in motions):.4f} mm，首条运动前至末条运动后的净实测位移为 {net:.4f} mm。')
para("事件记录同时保存动作预测、发送意图、命令确认和实际反馈；观测数组保留实际输入。每轮推理耗时约 0.60 s。结果证明本次硬件输入到受限运动的链路连通，不能作为真实 Push-T 成功率。")
speech("验证结果来自实际控制器反馈。三条指令长度分别约为零点五、零点七七和零点八四毫米，记录的实际起止位移分别约为零点四九、零点七五和零点八三毫米。每条都有命令确认、连续反馈和到位记录，三条完成后净位移约两毫米。这是一次短测中的三条运动，不是三次独立的 Push-T 任务成功。")
source_line("来源：原始 events.jsonl、metadata.json、trial_result.json；具体文件位置见附录。")

# 8
newpage(); heading("七 代码状态与下一阶段")
table(["内容","已经完成","仍需完成"],[
["原部署版本","一次真实硬件到受限运动的短测","扩大实验覆盖并评估任务行为"],
["重构副本","模块整理；131 项离线测试通过、5 项跳过","服务器环境、ROS、推理、控制后端及实机重新验收"],
["模型与任务","官方仿真 Push-T 权重已接入","面向单腕相机和真实任务的数据采集及模型验证"],
["坐标与视觉","提供可复核的工程映射与图片处理","确认视野、任务平面和物理坐标对应关系"]
],widths=[3.3,6.8,6.9],font_size=9.1)
para("重构保留原部署版本，新增工程按 hardware、inference、control 分模块；原论文策略保留在 third_party。离线测试说明代码重组后的部分行为可对照，不能替代新版本在目标服务器和真实硬件上的验收。")
para("下一步按依赖顺序开展：先验收重构版本的数据与执行链路；再确定单腕相机的任务视野和动作定义；随后采集真实演示，训练或微调适合该输入的模型，最后评价真实任务效果。")
speech("目前已经完成的是平台接口验证，代码也整理出保留原版和模块化副本两条清晰路径。新版目前只有离线测试结果，接下来需要在服务器逐层验收。为了让系统真正完成 Push-T，下一步还需要确定相机视野与任务坐标，采集真实示范，并训练或微调匹配单腕相机的策略。")

# 9
newpage(); heading("附录一 代码结构与调用位置")
para("重构版主目录：G:\\毕设\\03_code\\diffusion_policy_ur7e_refactored。以下文件属于项目适配层，运行时由 pipeline 按选定模式调用。",size=9.6)
table(["文件","职责"],[
["cli.py / config.py","选择 inspect、capture、shadow、preview、execute 并检查配置"],
["pipeline.py","组织模型加载、采集、预热、预测、执行和清理"],
["hardware/camera_bridge.py","订阅 ROS 图像并发布本机帧文件"],
["hardware/camera.py","解码 RGB、裁剪缩放、转换张量、读写帧"],
["hardware/robot_state.py","建立 RTDE Receive 连接，读取一致状态"],
["hardware/observations.py","采集线程、历史缓存、双帧和状态配对"],
["inference/policy.py","核验 checkpoint，调用原策略和返回预测"],
["geometry.py","TCP 位姿处理、模型坐标正反映射"],
["control/safety.py","计算单步、平滑、累计和范围约束"],
["control/robot.py","校验私有后端、发送 moveL、监控实际反馈"],
["recording.py","保存元数据、观察和 JSONL 事件"],
["third_party/diffusion_policy/","原论文固定提交的源码副本"],
["third_party/ur_rtde_guarded/","ur_rtde 1.6.5 已应用补丁的源码与修改依据"],
["models/","checkpoint、原配置和来源清单"],
["scripts/","环境、权重、构建、传输和运行汇总工具"]
],widths=[6.2,10.8],font_size=8.6)
para("脚本包含 prepare_environment、check_environment、fetch_checkpoint、build_backend、verify_bundle、deploy 和 summarize_run；它们服务于准备与核验，日常推理由统一入口调用。",size=9.4)

# 10
newpage(); heading("附录二 依赖来源与启动关系")
table(["组件","来源或历史版本","当前作用"],[
["论文策略","官方仓库提交 5ba07ac…","视觉编码与动作生成"],
["checkpoint","官方仿真 Push-T image Transformer","EMA 权重与训练归一化参数"],
["PyTorch / torchvision","1.12.1 / 0.13.1","张量、神经网络与视觉组件"],
["diffusers / robomimic","0.11.1 / 0.2.0","DDPM 调度与观察编码组件"],
["ur_rtde","1.6.5，第三方库","RTDE 状态接收；私有控制扩展的上游"],
["ROS / 相机驱动","服务器已有 ROS Humble 与 Orbbec 驱动","发布 RGB；驱动精确提交号未锁定"],
["NumPy / OpenCV","历史环境 1.23.3 / 4.6.0","数组、几何与图像处理"]
],widths=[4.0,6.1,6.9],font_size=8.8)
para("历史服务器模型环境为 Python 3.9.18；ROS 桥接使用系统 Python 3.10。依赖来自隔离环境的安装记录，当前重构副本的目标服务器安装状态需要重新检查。",size=9.6)
sub("手动与自动")
para("操作者启动或复用相机驱动，再单独启动相机桥接，最后选择主程序的 capture、shadow、preview 或 execute。主程序自动连接 RTDE、加载模型并完成所选模式；它不会自动启动其他验证模式。",size=9.8)
para("相机桥接和驱动是独立进程；主程序退出时只清理自身拥有的连接和线程。编译后的控制模块作为库由执行模式加载，不需要单独启动服务。",size=9.8)

# 11
newpage(); heading("附录三 常见追问与证据来源")
items=[
("为什么只使用 X 和 Y", "当前仿真 checkpoint 的输入与动作都是二维；执行层将目标补成完整 TCP 位姿。六个关节由控制器协调。"),
("为什么只有一个腕部相机", "当前仿真 checkpoint 接收一路图像；与它训练时的仿真画面仍有域差异。论文两视角实机模型不能直接少一路输入。"),
("首次裁剪是否丢失画面", "会。640 × 480 中心裁剪为 480 × 480 时左右各丢失 80 列，随后缩小也会损失细节；工作区视野需要重新确认。"),
("100 次去噪是否发送 100 次运动", "不是。100 次属于一次策略推理；当前流程每轮只选一个目标，完成后重新采集与推理。"),
("状态接收和运动控制是什么关系", "普通 ur_rtde Receive 读取状态；项目私有编译控制模块负责受约束的运动通信，命令确认之后仍需实际反馈。"),
("能否宣称复现真实 Push T", "当前证据只支持一次受限数据到运动链路短测；尚未完成真实任务成功率、视野与动作标定的评估。"),
("重构版本是否已实机通过", "没有。原部署版本已有实机记录，重构副本目前通过的是离线测试，需在目标服务器重新验收。")
]
for title, body in items:
    para(title+"  "+body,bold_prefix=title,size=9.5,after=3)
sub("原始来源")
refs("论文与项目主页", "https://diffusion-policy.cs.columbia.edu/")
refs("Diffusion Policy 官方代码", "https://github.com/real-stanford/diffusion_policy")
refs("官方仿真 Push T 图像 Transformer 权重", "https://diffusion-policy.cs.columbia.edu/data/experiments/image/pusht/diffusion_policy_transformer/train_0/checkpoints/epoch=0100-test_mean_score=0.748.ckpt")
refs("ur_rtde Quick Start", "https://sdurobotics.gitlab.io/ur_rtde/pages/getting_started/quick_start.html")
refs("Orbbec ROS 2 驱动上游", "https://github.com/orbbec/OrbbecSDK_ROS2")
para("本地历史证据：03_code/diffusion_policy_ur7e/runs/guarded_execution/20261025T085457Z_live/，其中 events.jsonl 保存逐条反馈，trial_result.json 保存当次结果。",size=8.8)
para("重构验证依据：02_learning/06_refactored_code/verification/acceptance.json。",size=8.8)

out.parent.mkdir(parents=True,exist_ok=True)
doc.save(out)
print("CREATED",out)
print("VERIFIED_LOG_COUNTS",dict(counts))
print("MEASURED_MM",rows,"NET_MM",round(net,4),"RAW_MM",round(raw_travel,2))
print("MAIN_SPEECH_PARAGRAPHS",sum(1 for p in doc.paragraphs if p.text.startswith("口述参考")))
