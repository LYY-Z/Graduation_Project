from PIL import Image, ImageDraw
from pathlib import Path
folder = Path(r"G:\毕设\02_learning\04_review\.build_ur7e_deployment_report_20261028\render_final")
images = sorted(folder.glob("page-*.png"), key=lambda p: int(p.stem.split("-")[-1]))
for start in range(0, len(images), 4):
    group = images[start:start+4]
    w, h = Image.open(group[0]).size
    canvas = Image.new("RGB", (w*2, (h+24)*2), "#d0d0d0")
    draw = ImageDraw.Draw(canvas)
    for j, path in enumerate(group):
        x, y = (j%2)*w, (j//2)*(h+24)
        draw.text((x+10,y+4),path.stem,fill="black")
        canvas.paste(Image.open(path).convert("RGB"), (x,y+24))
    canvas.save(folder / ("contact_%02d.png" % (start//4+1)))
print("page_count",len(images))

