"""Stage-1 software check only: no robot communication and no training."""
import argparse
import importlib.metadata as metadata
import json
from pathlib import Path
import sys

root = Path('/home/robotic_dog/lyy_ws/locoformer_go2w')
report = {'python': sys.version, 'executable': sys.executable, 'prefix': sys.prefix}
for name in ['torch', 'torchvision', 'isaacsim', 'isaaclab', 'isaaclab_assets',
             'isaaclab_tasks', 'isaaclab_rl', 'robot_lab', 'rsl-rl-lib', 'numpy']:
    try:
        report.setdefault('packages', {})[name] = metadata.version(name)
    except metadata.PackageNotFoundError:
        report.setdefault('missing', []).append(name)

import torch
assert torch.cuda.is_available()
report['cuda'] = {'torch_cuda': torch.version.cuda, 'devices': []}
for i in range(torch.cuda.device_count()):
    with torch.cuda.device(i):
        a = torch.randn(64, 64, device=f'cuda:{i}')
        b = a @ a.T
        torch.cuda.synchronize(i)
        assert torch.isfinite(b).all()
    report['cuda']['devices'].append({'index': i, 'name': torch.cuda.get_device_name(i),
                                     'capability': torch.cuda.get_device_capability(i)})

from isaaclab.app import AppLauncher
parser = argparse.ArgumentParser()
AppLauncher.add_app_launcher_args(parser)
args = parser.parse_args()
launcher = AppLauncher(args)
app = launcher.app
env = None
try:
    import gymnasium as gym
    import isaaclab_tasks
    import robot_lab
    from isaaclab_tasks.utils import parse_env_cfg

    task = 'RobotLab-Isaac-Velocity-Flat-Unitree-Go2W-v0'
    assert task in gym.registry
    cfg = parse_env_cfg(task, device='cuda:0', num_envs=1)
    cfg.seed = 42
    env = gym.make(task, cfg=cfg)
    obs, info = env.reset()
    actions = torch.zeros(env.unwrapped.action_space.shape, device=env.unwrapped.device)
    for _ in range(12):
        obs, reward, terminated, truncated, info = env.step(actions)
        assert torch.isfinite(reward).all()
    robot = env.unwrapped.scene['robot']
    report['simulation'] = {'task': task, 'steps': 12, 'num_envs': 1,
                            'joint_names': robot.joint_names,
                            'num_joints': robot.num_joints,
                            'action_shape': list(actions.shape),
                            'observation_shapes': {k: list(v.shape) for k, v in obs.items()},
                            'joint_position_finite': bool(torch.isfinite(robot.data.joint_pos).all())}
    assert robot.num_joints == 16
    assert report['simulation']['joint_position_finite']
    report['status'] = 'pass'
    (root/'logs/stage1/verification.json').write_text(json.dumps(report, indent=2)+'\n')
    print('STAGE1_VERIFICATION_PASS', json.dumps(report), flush=True)
finally:
    if env is not None:
        env.close()
    app.close()
