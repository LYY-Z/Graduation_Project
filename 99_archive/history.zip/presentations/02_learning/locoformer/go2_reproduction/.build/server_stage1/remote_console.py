"""Temporary SSH/SFTP operator. Password is prompted and never saved."""
import getpass
import json
from pathlib import Path
import sys

sys.path.insert(0, r"G:\毕设\03_code\ur7e_deployment_reference\preparation_tools\dependencies")
import paramiko

client = paramiko.SSHClient()
client.load_host_keys(str(Path.home() / ".ssh" / "known_hosts"))
client.set_missing_host_key_policy(paramiko.RejectPolicy())
client.connect("frp-mix.com", port=26589, username="robotic_dog",
               password=getpass.getpass("SSH password: "),
               allow_agent=False, look_for_keys=False, timeout=20,
               auth_timeout=20, banner_timeout=20)
client.get_transport().set_keepalive(25)
sftp = client.open_sftp()
print("SSH_READY", flush=True)
for line in sys.stdin:
    if not line.strip():
        continue
    try:
        request = json.loads(line)
        op = request["op"]
        if op == "run":
            stdin, stdout, stderr = client.exec_command(request["command"], timeout=request.get("timeout", 90))
            out = stdout.read().decode("utf-8", "replace")
            err = stderr.read().decode("utf-8", "replace")
            print(json.dumps({"exit_code": stdout.channel.recv_exit_status(), "stdout": out, "stderr": err}, ensure_ascii=False), flush=True)
        elif op == "put":
            remote = request["remote"]
            if not remote.startswith("/home/robotic_dog/lyy_ws/locoformer_go2w/") or ".." in Path(remote).parts:
                raise ValueError("Upload outside the dedicated workspace")
            sftp.put(request["local"], remote)
            print(json.dumps({"uploaded": remote, "bytes": sftp.stat(remote).st_size}), flush=True)
        elif op == "get":
            sftp.get(request["remote"], request["local"])
            print(json.dumps({"downloaded": request["local"]}), flush=True)
        elif op == "quit":
            break
        else:
            raise ValueError("Unknown operation")
    except Exception as e:
        print(json.dumps({"error": str(e)}, ensure_ascii=False), flush=True)
sftp.close()
client.close()
