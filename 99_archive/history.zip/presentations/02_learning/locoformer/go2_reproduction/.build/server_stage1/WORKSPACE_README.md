# LocoFormer Go2-W workspace

This workspace contains the isolated stage-1 simulation environment and pinned upstream sources.

```text
locoformer_go2w/
├── third_party/   # IsaacLab and robot_lab pinned source snapshots
├── scripts/       # environment, installation and verification entry points
├── downloads/     # transferred archives and verified downloads
├── logs/stage1/   # installation logs, source provenance and verification
├── docs/          # setup records
└── runs/          # future experiments
```

## Environment

```bash
cd ~/lyy_ws/locoformer_go2w
source scripts/activate.sh
python -c "import sys; print(sys.executable)"
```

The interpreter must resolve to:

```text
/home/robotic_dog/.conda/envs/lyy_locoformer_go2w_py311/bin/python
```

## Verification

```bash
bash scripts/verify.sh
```

This bounded check runs one simulated Go2-W environment with zero actions. It does not train a policy or communicate with a physical robot. See `logs/stage1/verification.json` for the measured result. An installation log alone does not prove verification passed.

## GUI

From a terminal in the existing VNC desktop:

```bash
cd ~/lyy_ws/locoformer_go2w
bash scripts/launch_gui.sh
```

This opens Isaac Sim. It does not start a training job or a robot controller.

## Provenance and isolation

Upstream commits and archive hashes are recorded in `downloads/sources.json` and each source tree's `UPSTREAM_SOURCE.json`. The source trees were transferred as complete fixed-commit archives; they are not Git clones with upstream history. Python dependencies use the dedicated Conda prefix. Host drivers, other Conda environments, VNC services and shell startup files are outside this setup.
