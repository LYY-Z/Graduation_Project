"""Fetch the official CUDA wheel in verified HTTP ranges, then verify SHA256."""
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
from pathlib import Path
import re
import time
import urllib.request

root = Path('/home/robotic_dog/lyy_ws/locoformer_go2w/downloads/wheels')
root.mkdir(parents=True, exist_ok=True)
name = 'torch-2.7.0+cu128-cp311-cp311-manylinux_2_28_x86_64.whl'
url = 'https://download.pytorch.org/whl/cu128/' + name.replace('+', '%2B')
with urllib.request.urlopen(urllib.request.Request(url, headers={'Range': 'bytes=0-0'}), timeout=30) as r:
    assert r.status == 206
    total = int(r.headers['Content-Range'].split('/')[-1])
    expected_hash = r.headers['x-amz-meta-checksum-sha256']
    assert re.fullmatch('[0-9a-f]{64}', expected_hash)
parts = root / '.torch_parts'
parts.mkdir(exist_ok=True)
chunk = 8 * 1024 * 1024
target = root / name

def digest(p):
    h = hashlib.sha256()
    with p.open('rb') as f:
        while b := f.read(4 * 1024 * 1024):
            h.update(b)
    return h.hexdigest()

if target.exists() and target.stat().st_size == total and digest(target) == expected_hash:
    print('OFFICIAL_TORCH_WHEEL_ALREADY_VERIFIED', flush=True)
    raise SystemExit(0)

def fetch(i):
    start = i * chunk
    end = min(start + chunk, total) - 1
    final = parts / f'{i:04d}'
    if final.exists() and final.stat().st_size == end - start + 1:
        return final.stat().st_size
    partial = final.with_suffix('.part')
    for attempt in range(5):
        try:
            req = urllib.request.Request(url, headers={'Range': f'bytes={start}-{end}', 'Accept-Encoding': 'identity'})
            with urllib.request.urlopen(req, timeout=60) as r, partial.open('wb') as f:
                assert r.status == 206
                assert r.headers['Content-Range'] == f'bytes {start}-{end}/{total}'
                while data := r.read(1024 * 1024):
                    f.write(data)
            assert partial.stat().st_size == end - start + 1
            partial.replace(final)
            return final.stat().st_size
        except Exception:
            if attempt == 4:
                raise
            time.sleep(attempt + 1)

start_time = time.time()
done = 0
count = (total + chunk - 1) // chunk
with ThreadPoolExecutor(max_workers=16) as pool:
    for future in as_completed([pool.submit(fetch, i) for i in range(count)]):
        done += future.result()
        print(f'wheel {done/total:.1%} {done/1024**2:.1f} MiB elapsed={time.time()-start_time:.1f}s', flush=True)
temporary = target.with_suffix('.assembling')
with temporary.open('wb') as f:
    for i in range(count):
        with (parts / f'{i:04d}').open('rb') as source:
            while b := source.read(4 * 1024 * 1024):
                f.write(b)
assert digest(temporary) == expected_hash
temporary.replace(target)
(root / 'torch.sha256').write_text(expected_hash + '  ' + name + '\n')
print('OFFICIAL_TORCH_WHEEL_SHA256_VERIFIED', expected_hash, flush=True)
