"""Download pinned source archives for transfer; no local package installation."""
from pathlib import Path
import hashlib
import json
import urllib.request

root = Path(__file__).parent
repos = [
    ("IsaacLab", "isaac-sim/IsaacLab", "37ddf626871758333d6ed89cf64ad702aef127d0"),
    ("robot_lab", "fan-ziqi/robot_lab", "09f6a9dfdf48f32f38bb851dfa3a7d44db32b270"),
]
records = []
for name, repo, commit in repos:
    path = root / f"{name}-{commit[:12]}.tar.gz"
    url = f"https://codeload.github.com/{repo}/tar.gz/{commit}"
    if not path.exists():
        with urllib.request.urlopen(url, timeout=90) as response, path.with_suffix(".part").open("wb") as f:
            while chunk := response.read(1024 * 1024):
                f.write(chunk)
        path.with_suffix(".part").replace(path)
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    records.append({"name": name, "repository": f"https://github.com/{repo}", "commit": commit,
                    "archive": path.name, "sha256": digest, "bytes": path.stat().st_size})
    print(json.dumps(records[-1]), flush=True)
(root / "sources.json").write_text(json.dumps(records, indent=2), encoding="utf-8")
