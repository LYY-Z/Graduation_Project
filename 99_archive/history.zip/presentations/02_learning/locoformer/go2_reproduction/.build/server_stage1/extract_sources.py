"""Verify source archives and extract inside the dedicated workspace."""
import hashlib
import json
from pathlib import Path
import tarfile

root = Path('/home/robotic_dog/lyy_ws/locoformer_go2w').resolve()
sources = json.loads((root/'downloads/sources.json').read_text())
for record in sources:
    archive = root/'downloads'/record['archive']
    assert hashlib.sha256(archive.read_bytes()).hexdigest() == record['sha256'], archive
    target = root/'third_party'/record['name']
    if target.exists():
        raise RuntimeError(f'Existing source directory must be inspected: {target}')
    with tarfile.open(archive, 'r:gz') as tar:
        members = tar.getmembers()
        top = members[0].name.split('/')[0]
        for member in members:
            resolved = (root/'third_party'/member.name).resolve()
            if not resolved.is_relative_to(root/'third_party'):
                raise RuntimeError('Unsafe archive path')
            if member.issym() or member.islnk():
                base = resolved.parent if member.issym() else root/'third_party'
                if not (base/member.linkname).resolve().is_relative_to(root/'third_party'):
                    raise RuntimeError('Unsafe archive link')
        tar.extractall(root/'third_party', filter='data')
    (root/'third_party'/top).rename(target)
    (target/'UPSTREAM_SOURCE.json').write_text(json.dumps(record, indent=2)+'\n')
    print(record['name'], record['commit'], 'SHA256 verified', flush=True)
(root/'logs/stage1/sources.verified.json').write_text(json.dumps(sources, indent=2)+'\n')
