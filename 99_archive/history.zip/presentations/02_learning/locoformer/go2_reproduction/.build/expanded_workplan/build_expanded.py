from pathlib import Path
P=Path(__file__).parent
helper=P.parent/'go2w_presentation'/'build_workplan.py'
header=helper.read_text(encoding='utf-8').split('# 1 cover')[0]
header=header.replace("Path(__file__).with_name('build_deck.py')",f"Path({str(helper.with_name('build_deck.py'))!r})")
exec(header)
OUT=Path(r'G:\毕设\02_learning\04_review\deliverables\locoformer\go2w_reproduction_workplan.detailed.CN.pptx')
TOTAL=24
original_table=table
def table(slide,heads,rows,widths,y=1.55,row_h=.76,fs=13):
    row_h=min(row_h,(6.12-y-.48)/len(rows))
    return original_table(slide,heads,rows,widths,y,row_h,fs)
PRODUCT='https://www.unitree.com/go2-w/'
URDF='https://github.com/unitreerobotics/unitree_ros/blob/master/robots/go2w_description/urdf/go2w_description.urdf'
SDK='https://github.com/unitreerobotics/unitree_sdk2_python/blob/master/example/go2w/low_level/go2w_stand_example.py'
LAB='https://github.com/fan-ziqi/robot_lab/tree/v2.3.2'
BABY='https://github.com/linden713/BabyLocoFormer'
LOCAL='https://github.com/lucidrains/locoformer'
GEN='https://github.com/BoAi01/embodiment-scaling-laws'
URMA='https://github.com/nico-bohlinger/one_policy_to_run_them_all'

def footer(slide,chapter,explain='',sources=''):
    line(slide,.68,7.12,12.65,7.12,LINE,.7)
    txt(slide,chapter,.73,7.18,10,.18,9,MUTED,margin=0)
    txt(slide,f'{len(prs.slides):02d} / {TOTAL}',11.75,7.16,.9,.21,9,MUTED,align=PP_ALIGN.RIGHT,margin=0)
    slide.notes_slide.notes_text_frame.text=explain+'\n\n资料来源：\n'+sources

def lead(s,t): txt(s,t,.85,1.28,11.65,.45,17,INK,True)
def takeaway(s,t,y=6.42):
    txt(s,t,.92,y,11.5,.43,14,WINE,True)
def node(s,t,x,y,w,h,fill=BLUE,size=14,color=INK):
    rect(s,x,y,w,h,fill,line=LINE)
    txt(s,t,x+.07,y+.05,w-.14,h-.1,size,color,True,PP_ALIGN.CENTER)
def arrow(s,x1,y1,x2,y2,c=WINE):
    line(s,x1,y1,x2,y2,c,1.5)
    from pptx.oxml.xmlchemy import OxmlElement
    ln=s.shapes[-1]._element.spPr.get_or_add_ln()
    a=OxmlElement('a:tailEnd');a.set('type','triangle');ln.append(a)
def picture(s,path,x,y,w): s.shapes.add_picture(str(path),Inches(x),Inches(y),width=Inches(w))

# 01
s=base()
rect(s,.78,1.5,.065,3.8,WINE)
txt(s,'LocoFormer 复现实施方案',1.1,1.72,11,.72,36,INK,True)
txt(s,'Go2-W 平台、参考项目与分阶段工作计划',1.14,2.7,10.9,.55,24,WINE,True)
txt(s,'从硬件与接口条件出发，明确可复用组件、适配工作和验证路径。',1.16,3.8,10.6,.55,18,MUTED)
txt(s,'当前阶段：资料调研与方案规划，复现实施尚未启动',1.16,4.8,10.7,.42,17,INK,True)
txt(s,'组会工作计划汇报  ·  2026.11',1.16,6.6,10.6,.28,11,MUTED)
footer(s,'复现规划')

# 02
s=base('汇报范围与工作组织')
lead(s,'最终目标：完成 LocoFormer 核心机制复现，并在 Go2-W 上开展实机验证。')
table(s,['汇报部分','需要回答的问题','对应决策'],[
('平台条件','Go2-W 有哪些执行器与传感器？\n哪些量可读、哪些命令可控？','确定状态来源、动作类型\n和仿真模型检查项'),
('软件与参考项目','现有项目原本做什么？\n有哪些组件值得复用？','选定主仿真栈\n划分复用与新增代码'),
('实施与验证','先完成什么，后续依赖什么？\n如何判断每阶段完成？','形成任务、产物、验收\n及实验对照')],[2.0,5.5,4.0],1.98,1.12,15)
takeaway(s,'本次呈现实施前的技术方案。环境部署、算法改造、训练及实机实验均列入后续计划。')
footer(s,'复现规划','先说明尚未启动实施，再从硬件出发组织计划。论文学习已完成，本次重点是复现资源和工作安排。')

# 03
s=base('Go2-W 平台概况与厂商性能参数')
picture(s,P/'go2w_product.png',.75,1.65,6.05)
txt(s,'Unitree 官方产品图',.92,5.0,5.6,.28,10,MUTED)
table(s,['项目','公开规格'],[
('站立尺寸 / 重量','70 × 43 × 50 cm / 约 18 kg（含电池）'),
('执行器 / 轮胎','12 腿关节 + 4 轮电机 / 7 英寸充气轮胎'),
('载荷','约 8 kg，最大约 12 kg'),
('速度','0–2.5 m/s'),
('越障高度 / 爬坡','＜70 cm / 最大爬坡角 35°')],[1.7,4.1],1.62,.81,13.3)
# right-align the table to the photo
sh=s.shapes[-1];sh.left=Inches(6.73)
txt(s,'厂商性能用于描述平台能力。\n训练任务的指令范围和地形难度需要单独设计。',.98,5.6,5.6,.7,15,WINE,True)
takeaway(s,'Go2-W 是轮足平台，仿真和输出适配都需要同时覆盖腿部姿态与车轮驱动。')
footer(s,'01  Go2-W 平台','先从厂商规格建立平台认知。随后展开16路执行器的真实结构，避免把轮足平台当作普通12关节四足。',PRODUCT)

# 04 editable kinematic tree
s=base('机械结构：四条独立轮足链与固定安装部件')
node(s,'机身 base\n浮动基座',5.05,1.45,3.18,.72,WINE_LIGHT,17,WINE)
line(s,1.9,2.5,11.45,2.5,BLUE_DARK,1.4);line(s,6.64,2.17,6.64,2.5,BLUE_DARK,1.4)
for i,(leg,idx,wheel) in enumerate([('FR 右前','0 / 1 / 2','12'),('FL 左前','3 / 4 / 5','13'),('RR 右后','6 / 7 / 8','14'),('RL 左后','9 / 10 / 11','15')]):
    x=.9+i*3.15
    line(s,x+1.0,2.5,x+1.0,2.78,BLUE_DARK,1.4)
    txt(s,leg,x,2.76,2.4,.34,16,BLUE_DARK,True)
    for j,t in enumerate(['hip：髋部外展 / 内收','thigh：大腿俯仰','calf：膝部屈伸','wheel：连续轮转动']):
        yy=3.24+j*.58
        node(s,t,x,yy,2.55,.43,GOLD_LIGHT if j==3 else BLUE,12.3)
        if j<3: line(s,x+1.26,yy+.43,x+1.26,yy+.58,BLUE_DARK,1)
    txt(s,f'腿部索引 {idx}\n轮索引 {wheel}',x,5.67,2.6,.52,11.5,MUTED)
takeaway(s,'四条链共 16 个主动关节。IMU、雷达及外壳的 fixed 连接不增加可控自由度。',6.46)
footer(s,'01  Go2-W 平台','该图依据URDF关节拓扑绘制，可编辑。12个腿关节和4个车轮均有电机驱动。浮动基座的平移和转动由接触与关节动作共同产生，不是额外6路电机。固定安装件也不是需要独立控制的随动关节。',URDF)

# 05 SDK mapping and local axes
s=base('关节作用、轴向与 SDK 电机通道')
picture(s,ASSET/'go2w_joint_map.png',.7,1.38,6.55)
table(s,['部位','hip / thigh / calf','wheel'],[
('FR 右前','0 / 1 / 2','12'),('FL 左前','3 / 4 / 5','13'),('RR 右后','6 / 7 / 8','14'),('RL 左后','9 / 10 / 11','15')],[1.2,2.6,1.2],1.6,.62,13)
s.shapes[-1].left=Inches(7.5)
txt(s,'模型关节轴',7.62,4.68,4.3,.34,17,WINE,True)
txt(s,'hip 绕局部 X 轴\nthigh、calf、wheel 绕局部 Y 轴\n左右与前后方向仍须逐关节核对',7.62,5.16,4.55,.92,14,INK)
takeaway(s,'统一策略槽位、模型 joint 顺序与 SDK 索引之间，需要一张明确的逐关节映射表。')
footer(s,'01  Go2-W 平台','图以机器人自身左右为准，前方朝上。SDK索引从0开始。URDF的轴向是局部坐标轴定义，不能仅凭同名就推断所有机器人的数值正方向相同。',URDF+'\nhttps://github.com/unitreerobotics/unitree_sdk2_python/blob/master/example/go2w/low_level/unitree_legged_const.py')

# 06 sensor graph
s=base('传感器分布、状态来源与策略输入')
node(s,'机身 base',1.0,2.4,3.05,1.3,BLUE,23)
node(s,'IMU\n机身附近固定安装',.95,1.45,3.1,.66,GREEN,14)
line(s,2.5,2.11,2.5,2.4,GREEN_DARK)
node(s,'LiDAR\n机身前部模型挂点',4.42,2.62,2.3,.83,GOLD_LIGHT,14)
arrow(s,4.05,3.04,4.42,3.04,BLUE_DARK)
node(s,'关节 / 车轮电机反馈\n分布在 16 路执行器',1.0,4.18,4.05,.8,WINE_LIGHT,14)
line(s,2.5,3.7,2.5,4.18,WINE)
txt(s,'挂点示意，未按尺寸绘制',1.0,5.24,5.2,.25,11,MUTED)
table(s,['来源','提供的信息 / 计划用途'],[
('IMU','姿态、角速度等反馈\n计算投影重力与机体状态'),
('电机状态','q、dq 等反馈\n组织腿 / 轮状态与跟踪记录'),
('相机 / LiDAR','图像 / 空间感知\n首版本体感觉策略不依赖这些输入'),
('指令 / 动作历史','速度目标与上一动作由软件维护\n与传感器测量共同组成观测')],[1.35,4.35],1.6,1.03,12.8)
s.shapes[-1].left=Inches(6.78)
takeaway(s,'URDF 挂点：IMU 约 (−25.57, 0, 42.32) mm，雷达约 (289.45, 0, −46.825) mm，均相对 base。')
footer(s,'01  Go2-W 平台','传感器图只表达公开模型的安装关系。相机具体标定参数、真实配置和传感器更新率需在设备接入阶段记录。URDF挂点不是相机光心。仿真接触力/真值速度可用于奖励或Critic，不能未经处理直接当作实机可测量的Actor输入。',URDF+'\n'+PRODUCT)

# 07 joint limits
s=base('关节限位、速度与力矩：区分模型字段和实机约束')
lead(s,'下表为官方公开 URDF 的模型值，后续需与仿真执行器配置及实机驱动约束分别对齐。')
table(s,['关节','位置范围（rad）','effort（N·m）','速度（rad/s）'],[
('hip','−1.0472 ～ 1.0472','23.7','30.1'),('前腿 thigh','−1.5708 ～ 3.4907','23.7','30.1'),('后腿 thigh','−0.5236 ～ 4.5379','23.7','30.1'),('calf','−2.7227 ～ −0.83776','35.55','20.07'),('wheel','continuous，无有限位置区间','23.7','30.1')],[2.1,4.7,2.3,2.4],1.96,.65,14)
txt(s,'厂商产品页约 45 N·m 指最大规格电机的最大扭矩，各电机并不统一。',.98,6.0,11.3,.4,15,WINE,True)
takeaway(s,'实现时分别记录：URDF 范围、训练动作范围、仿真执行器限制、实机软限幅与驱动限制。')
footer(s,'01  Go2-W 平台','位置采用弧度。轮关节可持续旋转，不能按腿部有限角度区间处理。effort和velocity是模型字段；模型、仿真执行器和真实硬件三层限制需要分开。',URDF+'\n'+PRODUCT)

# 08 full device utilities
s=base('电源、计算与通信条件')
table(s,['子系统','厂商公开信息','对复现的意义'],[
('电源与续航','33.6 V，15 Ah 电池\n标称续航 1.5–3 h，充电器 33.6 V / 9 A','记录供电、负载与测试时长\n续航不作为实际实验保证值'),
('机载计算','8 核高性能 CPU\nOrin NX 等扩展模块为选配','训练位于服务器\n策略推理位置需结合实机配置测量'),
('通信与操作','Wi-Fi 6、4G、Bluetooth\nAPP、遥控器、前灯与语音功能','开发接口按 SDK2 网络配置接入\n不能从无线功能推断低层控制权限'),
('开发与维护','支持二次开发与 OTA\n官方列出基础动作功能','记录设备固件、SDK 与网络配置\n策略接管需协调内置运动控制模式')],[2.0,5.0,4.5],1.6,1.12,14)
takeaway(s,'公开产品规格用于设备画像；机载选件、固件和实际通信配置在后续设备登记环节核对。')
footer(s,'01  Go2-W 平台','本页补齐供电、计算、通信和维护条件。厂商规格还列出12个月保修，其属于产品服务条款，不影响本项目算法配置。产品页没有给出所有传感器精度或频率，报告不推测缺失数据。',PRODUCT)

# 09 concrete interface findings
s=base('现成 Go2-W 任务提供了可追溯的数据与控制合同')
lead(s,'Robot Lab v2.3.2 的 Go2-W 任务与 Unitree 官方示例，可以共同约束首版接口设计。')
table(s,['环节','源码可见的设置','计划采用方式'],[
('状态输入','角速度、重力方向、速度指令\n16 路相对位置、16 路速度、上一动作','逐字段提取与核对\n轮位置项在任务中被置零'),
('动作输出','12 路腿部位置目标 + 4 路轮速目标\n髋位移 scale 0.125，其他腿关节 0.25\n轮速 scale 5.0','保留混合动作语义\n记录默认角度、单位与动作缩放'),
('执行时序','Robot Lab：物理步长 5 ms，decimation=4\nSDK2 示例：命令发送间隔 2 ms','策略周期约 20 ms / 50 Hz\n低层发送周期独立配置与测量')],[1.7,6.2,3.6],1.95,1.17,13.6)
takeaway(s,'这些数值来自参考任务和 SDK 示例，是初期复用依据；接入后仍需验证训练与部署一致。')
footer(s,'02  复现条件','本次源码审查确认轮与腿的动作不同。Robot Lab joint_pos_rel_without_wheel保留位置向量宽度，将轮关节位置项置零；这里轮电机真实存在，零值不能理解为缺失关节mask。按列出的项计算基础向量为57标量，最终仍以实际环境导出的张量为准。官方SDK示例腿q目标、轮kp=0且dq目标。示例2ms发送周期不等于策略频率。',LAB+'/source/robot_lab/robot_lab/tasks/manager_based/locomotion/velocity/config/wheeled/unitree_go2w/rough_env_cfg.py\n'+LAB+'/source/robot_lab/robot_lab/tasks/manager_based/locomotion/velocity/mdp/observations.py\n'+LAB+'/source/robot_lab/robot_lab/tasks/manager_based/locomotion/velocity/velocity_env_cfg.py\n'+SDK)

# 10 software architecture
s=base('软件路线：由物理仿真逐层连接到实机接口')
items=[('Isaac Sim 5.1','场景、刚体、接触与资产运行',BLUE),('Isaac Lab 2.3.2','并行环境、任务接口与训练工作流',GREEN),('Robot Lab 2.3.2','Go2-W 资产、速度任务与奖励',GOLD_LIGHT),('LocoFormer 适配实现','策略、PPO、TXL 与跨 Trial 采集',WINE_LIGHT)]
for i,(a,b,f) in enumerate(items):
    y=1.62+i*1.02;node(s,a,1.0,y,4.05,.72,f,16);txt(s,b,5.48,y+.08,6.2,.48,16,INK)
    if i<3: arrow(s,3.0,y+.72,3.0,y+.98,BLUE_DARK)
txt(s,'辅助验证：MuJoCo / MJCF 用于模型与控制约定交叉核对。\n实机通信：Unitree SDK2 读状态、发命令，适配层负责字段和动作转换。',1.0,5.94,11.2,.75,15,WINE,True)
footer(s,'02  复现条件','拟定版本组合为兼容性起点，实施开始后先做安装验证并固定commit。Isaac Sim5.1文档已标unsupported，选择依据是Lab2.3.2配套关系，不能称为最新受支持版本。RobotLab和Baby、GenBot中各自修改的rsl_rl不能混装后默认兼容。','https://isaac-sim.github.io/IsaacLab/v2.3.2/source/setup/installation/index.html\n'+LAB+'\nhttps://docs.isaacsim.omniverse.nvidia.com/5.1.0/installation/install_faq.html')

# 11 server
s=base('服务器资源与实施前的容量评估')
table(s,['资源','既有资源记录','规划用途 / 测量内容'],[
('GPU','RTX PRO 5000 Blackwell ×2\n每卡约 48 GiB','先做单卡基线，再评估双卡训练\n测环境数、吞吐和显存峰值'),
('CPU / RAM','96 逻辑处理器 / 约 251 GiB RAM','仿真调度、数据缓存与多实验\n控制进程数和内存峰值'),
('系统 / 存储','Ubuntu 22.04.5\n资源记录时约 445 GiB 可用','存储资产、权重与日志\n按预算保留视频和中间模型'),
('环境规划','独立 Conda + Python 3.11\n拟部署锁定版本仿真栈','先兼容性检查及单环境启动\n再做并行量与多卡扩展')],[1.9,4.5,5.1],1.6,1.08,14)
takeaway(s,'Isaac Sim 5.1 最低容量：16 GB 显存、32 GB 内存、50 GB SSD；并行量和训练周期需实测。')
footer(s,'02  复现条件','硬件资源来自2026-11-06既有服务器记录，本页不表示复现任务已经开工。两卡显存不会自动变成单个96GiB地址空间。IsaacSim5.1基线为32GB内存、16GB显存，当前资源高于容量基线，但需实际兼容测试。LocoFormer补充材料给出32/64/128GPU规模对照，本服务器用于较小规模复现，不预先承诺数值对齐。','既有服务器只读资源记录（2026-11-06）\nhttps://docs.isaacsim.omniverse.nvidia.com/5.1.0/installation/requirements.html\nhttps://generalist-locomotion.github.io/resources/locoformer_corl_2025.pdf')

# 12 refs map
s=base('参考项目按工作缺口组织')
table(s,['需要补齐的环节','主要参考','借鉴重点'],[
('Go2-W 仿真与任务','Robot Lab；Unitree RL Lab','轮足资产、状态动作、奖励、控制部署'),
('历史策略与训练接线','lucidrains/locoformer；BabyLocoFormer','TXL、PPO、缓存边界、Isaac Lab 接线'),
('多本体资产与划分','GenBot-1K / embodiment-scaling-laws','生成与转换、资产检查、整机留出'),
('不同身体的统一表示','URMA；MetaMorph；Body Transformer','结构描述、掩码、共享编解码与关节信息交换'),
('四足形态与新机器人适配','GenLoco','形态随机化、关节方向、初始化与控制配置'),
('模型与真实通信','官方 URDF；SDK2；Unitree MuJoCo','joint 到通道、命令类型、仿真对照')],[3.0,4.25,4.25],1.62,.73,13.1)
takeaway(s,'主路线使用一套仿真与训练栈，其他项目提供模块或对照，避免同时维护多套训练框架。')
footer(s,'03  参考项目','后续按每个项目的原始目的、已包含的模块、值得借鉴的部分和移植边界展开。参考项目具有不同的训练目标和后端，不等于完整LocoFormer复现包。',LAB+'\n'+BABY+'\n'+LOCAL+'\n'+GEN+'\n'+URMA)

# 13 Robotlab image
s=base('Go2-W 基线参考：Robot Lab 与 Unitree RL Lab')
picture(s,P/'robotlab_sim_preview.png',.9,1.68,5.45)
txt(s,'Robot Lab 官方仓库中的 Go2-W 场景图',1.0,5.69,5.3,.27,10,MUTED)
txt(s,'Robot Lab：仿真任务扩展',6.72,1.63,5.5,.38,19,WINE,True)
txt(s,'原用途：在 Isaac Lab 中提供多种机器人任务。\n已包含：Go2-W 资产、平地 / 粗糙地形、腿位置与轮速动作、PPO 配置。\n参考重点：先建立可运行的单体基线，再替换策略。',6.72,2.18,5.45,1.58,15,INK)
txt(s,'Unitree RL Lab：厂商学习与部署流程',6.72,4.12,5.5,.4,17,BLUE_DARK,True)
txt(s,'原用途：Unitree 机器人的强化学习与策略部署。\n参考重点：观测与动作缩放、控制配置、部署程序。普通 Go2 配置仍需核对轮足差异。',6.72,4.68,5.45,1.25,15,INK)
takeaway(s,'选型：Robot Lab 作为 Go2-W 主基线，Unitree RL Lab 作为厂商控制和部署的交叉参考。')
footer(s,'03  参考项目','图来自RobotLab仓库，作为资产与任务存在的证据，不表示本项目已经运行。v2.3.2源码具有明确Go2W配置。主基线先平地后粗糙地形，避免首轮同时改变算法与任务。',LAB+'\nhttps://github.com/unitreerobotics/unitree_rl_lab')

# 14 code / baby
s=base('算法参考：核心模块与仿真训练管线分别借鉴')
table(s,['项目与原始用途','包含的实现','值得借鉴与接入边界'],[
('lucidrains/locoformer\n第三方通用 PyTorch 实现','TXL、Actor / Critic、PPO\n多输入宽度编码器和动作选择器\n另有 Microduck 双足训练示例','阅读网络、缓存与 PPO 更新\n需接 Go2-W 环境和统一 I/O\n并非作者完整训练工程'),
('BabyLocoFormer\n非官方 Isaac Lab 学习实现','多形态四足生成、有限随机化\n训练 / 评估入口、自定义 rsl_rl\n改造的 Transformer-XL','参考环境到历史策略的接线\n审查 RoPE 等改动和边界处理\nGo2-W 轮足适配仍需实现')],[3.0,4.0,4.5],1.85,1.66,14)
takeaway(s,'优先在 Robot Lab 的 PPO 管线内接历史策略；Baby 参考训练集成，lucidrains 参考核心模块。')
footer(s,'03  参考项目','本地locoformer为已保存的第三方版本，其state_id由调用者选择编码器。Baby包含flash attention、RoPE、SwiLU改造，其结果定位为学习参考。两者均不能直接作为作者论文的原版工程或官方权重。',LOCAL+'\n'+BABY)

# 15 Genbot
s=base('多本体参考：GenBot-1K 资产与训练工程')
txt(s,'原项目研究训练身体数量与未见身体泛化的关系',.92,1.35,11.4,.4,19,INK,True)
labels=[('生成多种身体','人形 / 四足 / 六足'),('训练各身体专家','独立 RL 策略'),('采集演示数据','观测与专家动作'),('蒸馏共享策略','URMA 系列学生')]
for i,(a,b) in enumerate(labels):
    x=.92+i*3.05;node(s,a,x,2.17,2.55,.75,[BLUE,GREEN,GOLD_LIGHT,WINE_LIGHT][i],15)
    txt(s,b,x,3.03,2.55,.35,12.8,MUTED,align=PP_ALIGN.CENTER)
    if i<3:arrow(s,x+2.55,2.55,x+2.96,2.55)
table(s,['本项目借鉴','具体内容','需要独立完成'],[
('资产与生成工具','约 1,000 种身体及生成 / 转换线索\n关节描述、初始高度和模型配置','筛选物理可行的少量身体\n轮足变体单独设计或选取'),
('实验组织','训练 / 测试划分、专家和蒸馏评测','沿用 LocoFormer 的 PPO / 历史主线\n不把蒸馏流程替代论文方法')],[2.0,5.25,4.25],3.83,.99,14)
takeaway(s,'公开专家与蒸馏权重可用于该项目的参考验证，不能当作 LocoFormer 或 Go2-W 的直接部署权重。')
footer(s,'03  参考项目','GenBot原项目有资产、专家训练、数据采集和URMA蒸馏，并提供部分权重下载链接。应按当前工作包取用，初期无需下载全体资产或完整蒸馏数据。README称完整数据约4TB，超过本服务器记录的空闲磁盘，因此计划选少量资产开展在线PPO。',GEN+'\nhttps://embodiment-scaling-laws.github.io/\n'+GEN+'/blob/main/README_advanced.md')

# 16 other references
s=base('统一表示与机器人接入的补充参考')
table(s,['项目','原先解决的问题','本项目值得参考的部分'],[
('URMA / One Policy\nto Run Them All','跨不同腿式身体共享运动策略\n基于 MuJoCo / RL-X 的实现','关节描述、共享编解码\n新增机器人所需配置清单'),
('MetaMorph','形态条件化的 Transformer\n通用模块化机器人控制','结构信息、有效位与动作过滤\n作为统一输入设计的对照'),
('GenLoco','四足形态随机化与参考动作模仿\n向不同四足平台迁移步态','关节名称与方向、初态、PD\n资产接入和形态随机化'),
('Body Transformer','利用身体连接结构学习策略\n包含 A1 sim-to-real 示例','关节之间的信息交换\n结构化观察和动作映射')],[2.6,4.45,4.45],1.63,1.06,13.6)
takeaway(s,'这些项目用于回答表示和适配问题。主路线保持 LocoFormer 的长历史 PPO，架构变化单独做对照。')
footer(s,'03  参考项目','GenLoco主要是12关节四足与参考运动，不能直接覆盖四轮独立动作。URMA和BoT的结构思路值得借鉴，但选择其中某个结构会构成对LocoFormer实现的改变，需在实验中说明。',URMA+'\nhttps://github.com/agrimgupta92/metamorph\nhttps://github.com/HybridRobotics/GenLoco\nhttps://github.com/carlosferrazza/BodyTransformer')

# 17 independent modules
s=base('拟实施架构与新增代码范围')
labels=[('环境与资产','Robot Lab / GenBot'),('统一观测适配','字段 / 槽位 / 归一化'),('历史策略与 PPO','借鉴 LocoFormer 实现'),('动作与硬件适配','腿位置 / 轮速 / SDK2')]
for i,(a,b) in enumerate(labels):
    x=.92+i*3.05;node(s,a,x,1.75,2.55,.84,[BLUE,GREEN,GOLD_LIGHT,WINE_LIGHT][i],15)
    txt(s,b,x,2.74,2.55,.53,12.6,MUTED,align=PP_ALIGN.CENTER)
    if i<3:arrow(s,x+2.55,2.18,x+2.96,2.18)
table(s,['新增工作包','需要固定的内容','验证方式'],[
('统一输入输出','canonical 关节语义、单位、方向\n缺失位、有效位与动作类型','逐字段样例\n正反映射和无效位检查'),
('历史与训练接线','segment 长度、缓存生命周期\nTrial 重置、PPO 序列与边界','跨段 / 跨 Trial 小样例\n保留历史与清空历史对照'),
('实机适配','状态时戳、低层命令、频率\n限幅、异常终止与反馈日志','先离线与仿真验证\n再分级接入硬件')],[2.15,5.5,3.85],3.5,.84,13.8)
takeaway(s,'统一关节空间在目标身体清单确定后冻结，并用配置文件维护各机器人的映射与有效位。')
footer(s,'04  实施计划','本页连接参考项目与实际开发任务：可复用的是模块，项目仍需完成统一接口、缓存边界和硬件适配。所有计划都在实施前，新增代码应与上游参考版本解耦并保留来源。',LAB+'\n'+LOCAL+'\n'+BABY+'\n'+SDK)

# 18 overall roadmap
s=base('分阶段实施路线与前置依赖')
phases=[('A  平台与单体基线','部署仿真栈\n检查 Go2-W\n运行现成 PPO','模型与动作正确\n基线可重复',BLUE),('B  策略与长历史','统一 I/O\n接入历史策略\n跨 Trial 采集','保存加载一致\n缓存与对照成立',GREEN),('C  多本体复现','筛选身体资产\n共享策略训练\n完整身体留出','未见身体评测\n适应曲线',GOLD_LIGHT),('D  Go2-W 实机','模型交叉核对\nSDK2 状态与动作\n分级实机闭环','命令与反馈一致\n运行指标可追溯',WINE_LIGHT)]
for i,(name,tasks,gate,fill) in enumerate(phases):
    x=.92+i*3.05
    node(s,name,x,1.78,2.55,.8,fill,14)
    if i<3:arrow(s,x+2.55,2.18,x+2.96,2.18)
    txt(s,tasks,x+.08,2.94,2.4,1.16,16,INK,valign=MSO_ANCHOR.TOP)
    line(s,x+.08,4.36,x+2.47,4.36,LINE,1)
    txt(s,'阶段验收',x+.08,4.62,2.35,.34,14,WINE,True)
    txt(s,gate,x+.08,5.07,2.35,.8,14,INK,valign=MSO_ANCHOR.TOP)
txt(s,'实施顺序',1.0,6.18,1.4,.34,16,WINE,True)
txt(s,'先隔离模型与控制问题，再验证历史机制和跨本体泛化，最后迁移实机。',2.5,6.1,9.55,.5,16,INK)
footer(s,'04  实施计划','所有阶段尚未启动。采用依赖和验收驱动的顺序，工期在平台吞吐和基线训练成本测量后细化，不预设缺乏依据的完成日期。')

# 19 phase A
s=base('阶段 A：建立可重复的 Go2-W 仿真基线')
table(s,['步骤','实施任务','产物与完成标准'],[
('A1 环境与版本','独立 Conda，验证 GPU / Isaac 兼容性\n固定 Isaac Sim、Lab、Robot Lab 与依赖','版本清单和启动日志\n单环境可启动'),
('A2 模型与执行器','核对 12+4 关节、初态、碰撞与接触\n逐路检查腿关节和轮动作','关节 / 电机表与动作记录\n关节作用符合预期'),
('A3 现成 PPO 基线','先平地速度跟踪，再扩展地形\n保存、重载并独立评估策略','基线 checkpoint 与训练曲线\n跟踪误差、跌倒率可统计'),
('A4 资源测量','逐步增加环境数\n记录吞吐、显存、内存和训练耗时','服务器容量与实验预算\n确定后续并行规模')],[2.25,5.3,3.95],1.66,1.08,14)
takeaway(s,'本阶段保留现成策略结构，用基线结果隔离资产、执行器和任务配置问题。')
footer(s,'04  实施计划','阶段A是后续算法改造的对照基线。完成条件不仅是场景加载，还包括执行器语义正确、checkpoint可重载和任务表现可评估。')

# 20 phase B
s=base('阶段 B：接入历史策略并验证跨 Trial 机制')
table(s,['工作项','具体实施','验收证据'],[
('统一数据与动作','导出真实观测张量和动作空间\n接策略编码器、输出解码与映射','字段形状 / 单位 / 顺序一致\n无效关节不产生执行命令'),
('PPO 训练接线','连接采集器、Actor / Critic 与优化器\n先在单一 Go2-W 上训练和重载','参数更新、损失与回报日志\n重新加载的推理行为一致'),
('跨段 / 跨 Trial 缓存','规定何时保留、何时清空和何时截断梯度\n区分物理复位与策略历史重置','边界小样例与缓存日志\n无跨任务信息泄漏'),
('机制对照','固定任务与预算，比较保留 / 清空历史\n记录扰动前后和后续 Trial 表现','适应曲线与恢复指标\n多随机种子重复')],[2.35,5.25,3.9],1.66,1.08,14)
takeaway(s,'先证明数据、更新和缓存机制正确，再评价长历史是否带来收益。')
footer(s,'04  实施计划','Trial是任务尝试，segment是序列计算分块，两者边界不能混同。身体与动力学切换到另一任务时应清空不相关历史；同任务不同Trial保留历史用于适应实验。SG限制反传，不等于清空数值历史。')

# 21 phase C
s=base('阶段 C：从少量身体扩展到跨本体实验')
labels=[('筛选少量资产','可加载、可站立、可控'),('冻结统一接口','槽位、mask、动作解码'),('共享策略训练','增加形态和动力学随机化'),('整机留出测试','测试身体不参与训练')]
for i,(a,b) in enumerate(labels):
    x=.92+i*3.05;node(s,a,x,1.85,2.55,.72,[BLUE,GREEN,GOLD_LIGHT,WINE_LIGHT][i],15)
    txt(s,b,x,2.73,2.55,.49,12.6,MUTED,align=PP_ALIGN.CENTER)
    if i<3:arrow(s,x+2.55,2.21,x+2.96,2.21)
table(s,['变量','计划设置','需要观察的结果'],[
('身体集合','先四足 / 轮足，再评估拓扑更大差异\n训练、验证、测试按完整机器人划分','训练内与未见身体分别报告\n不能只换环境随机种子'),
('训练变化','增加身体数量、质量 / 摩擦 / 电机变化\n控制总步数或同时报告计算量','泛化表现、失败类型与方差\n区分多样性收益和数据量收益'),
('历史适应','保留 / 清空历史，设置相同适应窗口','随交互时间和 Trial 编号变化\n恢复时间、位移和失败率')],[2.0,5.5,4.0],3.5,.83,13.7)
takeaway(s,'GenBot 提供多身体资源，轮足资产与统一动作语义仍需额外检查和适配。')
footer(s,'04  实施计划','多本体训练从少量合格模型开始，避免直接扩展千体造成难以定位的问题。GenBot人形/四足/六足不自动提供Go2W式车轮控制，轮足身体应明确来源或作为新增生成设计。',GEN)

# 22 phase D
s=base('阶段 D：从仿真合同迁移到 Go2-W 实机闭环')
labels=[('仿真策略重载','固定输入、输出与历史'),('仿真间交叉核对','可选 MuJoCo / 模型检查'),('SDK2 只读与影子推理','真实输入、输出留日志'),('分级实机闭环','约束、执行与反馈')]
for i,(a,b) in enumerate(labels):
    x=.92+i*3.05;node(s,a,x,1.85,2.55,.86,[BLUE,GREEN,GOLD_LIGHT,WINE_LIGHT][i],14)
    txt(s,b,x,2.88,2.55,.47,12.4,MUTED,align=PP_ALIGN.CENTER)
    if i<3:arrow(s,x+2.55,2.28,x+2.96,2.28)
table(s,['实机环节','适配内容','验收重点'],[
('状态与历史','SDK2 IMU / 电机消息、单位与时间戳\n部署期保持训练观测处理与缓存规则','输入张量可追踪\n异常数据可识别'),
('腿部与车轮命令','腿位置目标与轮速目标分别解码\n补齐默认姿态、增益与命令约束','通道、方向和单位正确\n限幅、动作平滑与终止机制'),
('周期与反馈','推理、低层发送、反馈采样分开计时\n记录网络延迟与设备响应','延迟 / 丢帧 / 命令反馈\n运动表现与中断事件')],[2.0,6.0,3.5],3.56,.82,13.6)
takeaway(s,'实机阶段沿用同一观测与动作合同，先记录输入输出，再逐步开放执行。')
footer(s,'04  实施计划','本页为未来实机步骤，并未执行。独立SDK适配器解决状态与命令转换，不能用高层内置运动控制代替学习策略的低层输出。需要协调SDK示例中的运动模式接管，保留人工中止和设备反馈。',SDK+'\nhttps://github.com/unitreerobotics/unitree_mujoco')

# 23 evaluation / risks
s=base('关键风险、验证指标与阶段产物')
table(s,['风险或问题','验证手段','记录的指标 / 产物'],[
('关节与动作不一致','SDK、URDF、任务三方映射核对\n逐路正反转换与动作检查','映射表、限值来源\n命令与状态轨迹'),
('历史边界或更新错误','跨段 / 跨 Trial 小样例\n保留与清空缓存对照','适应曲线、恢复时间\n缓存与 PPO 更新日志'),
('资产或泛化不足','先少量合格身体\n整机留出与多随机种子','逐身体结果与失败率\n速度误差、位移及离散程度'),
('计算与存储超预算','单卡起步，逐步增加环境数\n筛选资产、限制中间数据保存','环境步 / 秒、显存峰值\n总步数、训练耗时与磁盘占用')],[2.8,4.9,3.8],1.66,1.08,13.8)
takeaway(s,'每项结果关联代码版本、配置、随机种子和权重；先报告机制验证，再报告规模与性能差异。')
footer(s,'04  实施计划','本页不是已完成结果表。计划用可复查证据支撑每阶段结论。LocoFormer官方权重和完整工程尚未在核对的公开入口中找到，论文数值复刻程度应在实施后说明。')

# 24 closing planned tasks
s=base('启动后的任务顺序与预期交付')
lead(s,'当前保持在实施前规划阶段。建议启动后先完成平台和基线，再进入算法改造。')
table(s,['顺序','计划任务','交付'],[
('1','固定软件版本、设备配置与参考仓库来源','环境 / 硬件清单和版本记录'),
('2','加载 Go2-W，逐路核对状态与腿 / 轮动作','模型检查、数据合同、SDK 映射'),
('3','训练并重载现成 PPO，测量服务器吞吐','基线策略、评估结果、计算预算'),
('4','审查并接入 LocoFormer 历史策略管线','接口改造范围、缓存对照和训练记录'),
('5','扩展合格身体并按整机留出，再迁移实机','跨本体评测与 Go2-W 部署证据')],[1.0,6.7,3.8],2.02,.75,14)
txt(s,'阶段目标',1.0,6.25,1.45,.36,17,WINE,True)
txt(s,'形成可重复的仿真训练、可解释的适配接口，以及有对照的跨本体与实机验证。',2.57,6.16,9.5,.52,16,INK)
footer(s,'复现规划','汇报落脚到工作安排：从已有硬件条件与公开参考项目出发，先验收平台，再验收算法机制，最后扩大到多本体与真机。当前所有实施任务均为计划，不把资源调研表述成训练或部署成果。')

assert len(prs.slides)==TOTAL
from pptx.oxml.xmlchemy import OxmlElement
for slide in prs.slides:
    changes={'数据与控制合同':'数据与控制规范','数据合同':'接口规范','动作合同':'动作定义','控制合同':'控制约定','统一观测合同':'统一观测规范','同一观测与动作合同':'同一观测与动作规范','仿真合同':'仿真接口','训练接线':'训练集成','接线':'集成','接 LocoFormer':'集成 LocoFormer'}
    def fix_frame(tf):
        for p_ in tf.paragraphs:
            for run in p_.runs:
                for a_,b_ in changes.items():run.text=run.text.replace(a_,b_)
    for shape_ in slide.shapes:
        if getattr(shape_,'has_text_frame',False):fix_frame(shape_.text_frame)
        if getattr(shape_,'has_table',False):
            for row_ in shape_.table.rows:
                for cell_ in row_.cells:fix_frame(cell_.text_frame)
    for tag in ('a:rPr','a:defRPr','a:endParaRPr'):
        for rp in slide._element.xpath('.//'+tag):
            for kind in ('latin','ea','cs'):
                ns='{http://schemas.openxmlformats.org/drawingml/2006/main}'+kind
                nodes=rp.findall(ns)
                if nodes: node_=nodes[0]
                else: node_=OxmlElement('a:'+kind);rp.append(node_)
                node_.set('typeface',FONT)
OUT.parent.mkdir(parents=True,exist_ok=True)
prs.save(OUT)
print(f'saved={OUT} slides={len(prs.slides)}')
