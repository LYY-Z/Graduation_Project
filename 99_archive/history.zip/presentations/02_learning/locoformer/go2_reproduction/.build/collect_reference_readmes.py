from pathlib import Path
import json,urllib.request,concurrent.futures
root=Path(r'G:\毕设\02_learning\locoformer\go2_reproduction\.build\documentation_research')
root.mkdir(exist_ok=True)
manifest=json.loads(Path(r'G:\毕设\03_code\references\sources.json').read_text(encoding='utf-8'))
items=manifest['repositories']+manifest['deferred_references']
def fetch(it):
    repo=it['url'].replace('https://github.com/','').removesuffix('.git')
    for branch in [it.get('commit','main'),'main','master']:
        for file in ['README.md','readme.md','README.rst']:
            url=f'https://raw.githubusercontent.com/{repo}/{branch}/{file}'
            try:
                req=urllib.request.Request(url,headers={'User-Agent':'Research-documentation/1.0'})
                d=urllib.request.urlopen(req,timeout=12).read()
                out=root/(it['name']+'.README.txt');out.write_bytes(d)
                return {'name':it['name'],'readme_url':url,'file':out.name,'bytes':len(d),'requested_commit':it.get('commit'),'resolved_ref':branch}
            except Exception:pass
    return {'name':it['name'],'error':'README not retrieved'}
with concurrent.futures.ThreadPoolExecutor(max_workers=7) as ex:
    result=list(ex.map(fetch,items))
(root/'readme_audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
for r in result:print(r['name'],r.get('bytes',r.get('error')),r.get('resolved_ref',''))
