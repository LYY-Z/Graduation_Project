from pathlib import Path
P=Path(__file__).parent/'focused_workplan'
f=P/'build_reporting.py'
s=f.read_text(encoding='utf-8')
s=s.replace("OUT=Path(r'G:\\毕设\\02_learning\\04_review\\deliverables\\locoformer\\go2w_reproduction_report.CN.pptx')","OUT=P/'reporting_candidate.pptx'")
s=s.replace("SDKROOT='https://github.com/unitreerobotics/unitree_sdk2_python'", "import json\nTASKS=json.loads((ROOT/'.build/reporting_plan.json').read_text(encoding='utf-8'))\nSDKROOT='https://github.com/unitreerobotics/unitree_sdk2_python'")
s=s.replace("'建立单体基线，验证长历史与跨本体机制，完成实机接入。'", "'以 Go2-W 为验证平台，按现有实现确定开发任务与验证方法。'")
s=s.replace("'平台与SDK    /    参考项目与选型    /    分阶段工作计划'", "'平台与接口介绍    /    参考项目分析    /    实施与验证计划'")
s=s.replace("'首版策略使用本体状态；相机与点云独立记录，不作为基线训练的前置条件。'", "'由此确定：阶段 1 采集本体状态，阶段 3 统一观测，阶段 6 接入实机推理。'")
s=s.replace("'仿真关节、统一槽位和 SDK 编号显式映射，保证训练与部署的动作含义一致。'", "'阶段 6 参考此 SDK 调用链，新增观测转换与动作适配，以只读、影子和闭环逐步验证。'")
s=s.replace("'原论文尚缺的公开资源'", "'尚未获得的作者复现资料'")
s=s.replace("'按模块审查并移植必要实现，在选定的主训练管线中补齐任务与接口。'", "'阶段 4 参考 lucidrains 的 TXL 和 Baby 的训练集成；缓存及 PPO 更新由本项目验证。'")

a=s.index('# 07 source roles')
b=s.index('# 08 interface choice')
s=s[:a]+'''# 07 introduce supporting projects before the plan
s=base('环境、资产与部署项目：已有能力决定复用范围')
table(s,['项目','原项目作用与已有实现','选用理由与后续任务'],[
('Robot Lab','Isaac Lab 的多机器人任务扩展\\n包含 Go2-W 观测、12+4 动作及 PPO','具备单体任务，作为阶段 1–2 主环境\\n先核对模型，再建立基线'),
('MetaMorph / GenLoco','形态条件策略与跨形态四足控制\\n提供有效位、方向和初始化设计','为阶段 3 提供接口设计参考\\n本项目补统一槽位与轮速映射'),
('GenBot-1K','生成多种身体，训练专家并蒸馏\\n包含资产、转换与身体划分','为阶段 5 提供筛选资产\\n统一任务，补轮足变体，不沿用蒸馏'),
('SDK2 / rl_sar','设备通信与策略部署\\n提供消息、通道、模式与配置','为阶段 6 提供协议和部署参考\\n本项目编写历史策略运行与适配')],[2.35,4.6,4.55],1.55,1.0,13.6)
takeaway(s,'现有项目提供组件；本项目负责将模型、接口、历史训练和实机执行连接并验证。',6.58)
note('02  参考项目介绍','在介绍LocoFormer相关代码之后，这页说明外围项目。Robot Lab的优势是已有Go2-W任务，因此先用它建立基线。MetaMorph和GenLoco提供统一接口的设计参考，但槽位和轮速定义需要自己完成。GenBot提供身体资产，采用前要逐个检查并接入同一任务。SDK2和rl_sar帮助实现设备通信与部署，历史状态仍需自己管理。下面将这些来源落实到具体技术方案和计划。',LAB+'\\n'+GEN+'\\nhttps://github.com/agrimgupta92/metamorph\\nhttps://github.com/HybridRobotics/GenLoco\\nhttps://github.com/fan-ziqi/rl_sar\\n'+SDKROOT)

'''+s[b:]
s=s.replace("'论文未公开完整槽位表；方向、归一化和有效位需形成独立接口规范并验证。'", "'阶段 3 验证：单槽位与缺失位样例检查，再用同一权重比较改造前后的观测和动作。'")
s=s.replace("'策略计算','观测编码后进入 TXL\\nActor 输出动作，Critic 估值'", "'策略计算','参考 lucidrains 的 TXL\\n接入统一观测与动作输出'")
s=s.replace("'序列训练','按连续序列计算损失\\n记录真实 epoch 与更新次数'", "'序列训练','参考 Baby 的存储与 PPO 接入\\n补任务边界与多轮更新'")
s=s.replace("'先验证缓存和更新机制，再用恢复时间、失败率及各 Trial 表现检验适应效果。'", "'阶段 4 验证：逐步 / 分段输出一致性，缓存重置检查，再比较保留 / 清空历史。'")

a=s.index('# 11 plan first half')
b=s.index('# 13 evidence and immediate tasks')
s=s[:a]+'''# 11 plan with explicit references and verification
s=base('工作计划Ⅰ：参考哪个项目，如何实现，如何验证')
table(s,['阶段','参考来源','本项目实施工作','验证方法'],[
(str(t['id'])+' '+t['name'],t['ppt_ref'],t['ppt_how'],t['ppt_test']) for t in TASKS[:3]
],[2.15,3.15,3.2,3.0],1.75,1.18,13.5)
txt(s,'阶段衔接',.98,6.0,1.4,.36,16,WINE,True)
txt(s,'模型与通道检查通过后训练基线；保存基线后改统一接口，用同一权重验证转换。',2.65,5.92,9.4,.62,15,INK)
note('04  实施与验证计划','前三项工作分别对应前面介绍的平台与接口资料。第一项以Robot Lab和官方模型为依据，检查每路动作是否作用于正确关节，并通过SDK只读记录核对真实数据。第二项保留Robot Lab任务训练MLP，通过固定指令重载评估获得基线，同时测吞吐。第三项参考MetaMorph和GenLoco组织统一接口，先检查单槽位和缺失位，再用同一权重比较转换前后结果。只有接口通过检查，才引入历史网络。',LAB+'\\n'+SDK+'\\nhttps://github.com/agrimgupta92/metamorph\\nhttps://github.com/HybridRobotics/GenLoco')

# 12 core reproduction and deployment
s=base('工作计划Ⅱ：移植历史训练，扩展身体，接入实机')
table(s,['阶段','参考来源','本项目实施工作','验证方法'],[
(str(t['id'])+' '+t['name'],t['ppt_ref'],t['ppt_how'],t['ppt_test']) for t in TASKS[3:]
],[2.15,3.15,3.2,3.0],1.75,1.18,13.5)
txt(s,'阶段衔接',.98,6.0,1.4,.36,16,WINE,True)
txt(s,'先验证缓存与更新，再扩大身体集合；实机只读可提前，闭环执行依赖仿真和映射验收。',2.65,5.92,9.4,.62,15,INK)
note('04  实施与验证计划','第四项分别参考lucidrains的历史骨干和Baby的序列训练连接，补齐任务重置与PPO循环。验证分两层：先检查因果、缓存和更新，再比较历史的实际收益。第五项参考GenBot筛选资产，补轮足和统一任务，以完整身体留出检验泛化。第六项依据官方SDK协议，参考rl_sar部署组织，自己实现观测和动作适配。验证顺序是只读、影子推理、命令与反馈闭环。每项参考资料都有对应实施工作和检查结果。',LOCAL+'\\n'+BABY+'\\n'+GEN+'\\n'+SDK+'\\nhttps://github.com/fan-ziqi/rl_sar')

'''+s[b:]
s=s.replace("'首批任务','", "'首批任务','")
f.write_text(s,encoding='utf-8')
print('Connected project introductions to six implementation and verification tasks.')
