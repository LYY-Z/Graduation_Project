from pathlib import Path
R=Path(r'G:\毕设\02_learning\locoformer\go2_reproduction')

rows=[]
for leg,start,w in [('FR',0,12),('FL',3,13),('RR',6,14),('RL',9,15)]:
    for suffix,idx,desc,cmd in [('hip',start,'外展/内收','q位置目标'),('thigh',start+1,'大腿俯仰','q位置目标'),('calf',start+2,'膝部屈伸','q位置目标'),('foot',w,'车轮连续转动','dq速度目标，kp=0')]:
        rows.append(f'| {leg}_{suffix}_joint | {desc} | {idx} | {idx} | motor_state[{idx}] | motor_cmd[{idx}]：{cmd} |')
mapping='''### 1.2 16路关节驱动、候选槽位与SDK通道

每行对应一个独立驱动通道，关节名称取自模型命名。槽位是本项目四足/轮足原型的候选定义，SDK编号来自官方Go2-W常量表；两者在此版本中采用相同数值，但属于不同层次。其他模型的导入顺序仍需按名称映射。

| 模型关节/驱动通道 | 运动作用 | 候选槽位 | SDK编号i | 状态读取 | 命令写入 |
|---|---|---:|---:|---|---|
'''+ '\n'.join(rows)+'''

读取路径为`LowState.motor_state[i]`，可获得q、dq、ddq、tau_est、temperature等；写入路径为`LowCmd.motor_cmd[i]`，包含mode、q、dq、tau、kp、kd。消息通过`rt/lowstate`接收、`rt/lowcmd`发送。表中的腿位置与轮速是首版采用的命令方式，不代表驱动消息只有这两种字段。

这些编号表示控制通道，不是厂家电机产品型号或序列号。公开资料没有逐一给出16台电机的实体型号及内部传动参数；最大电机约45N·m不能推广为全部通道。产品能力、URDF限制、仿真执行器和实机约束分别记录。

'''
p=R/'01_go2w_hardware.CN.md';s=p.read_text(encoding='utf-8');s=s.replace('## 2. 硬件数据从哪里读取',mapping+'## 2. 硬件数据从哪里读取')
cap='''### 2.4 SDK中可读取、可控制和本阶段使用范围

| 对象 | 已确认的读取/调用能力 | 控制能力或边界 | 本阶段采用 |
|---|---|---|---|
| 腿与轮电机 | LowState.motor_state：q、dq、估计力矩、温度等 | LowCmd.motor_cmd：位置、速度、前馈力矩及增益字段 | 腿位置、轮速度；记录反馈 |
| IMU | LowState.imu_state：姿态、角速度、加速度 | 状态读取；不向IMU发送运动命令 | 构造角速度和投影重力 |
| 电源与遥控输入 | LowState含bms_state、power_v、power_a、wireless_remote | 消息字段不等于通用电源控制；遥控字节需按协议解析 | 记录状态，按协议接入人工控制逻辑 |
| 前部相机 | VideoClient.GetImageSample返回码与编码图像 | 已核对例程提供取帧；不推定额外曝光/云台控制 | Go2系列接口参考，验证Go2-W设备服务后记录 |
| 3D LiDAR | 对应型号驱动获取点云；L1 SDK另支持雷达IMU与参数配置 | 不经LowCmd控制；SDK必须与实际型号和连接方式匹配 | 设备识别与记录，首版策略不依赖点云 |
| 运动与模式服务 | MotionSwitcherClient.CheckMode；SportClient包含Move等服务 | ReleaseMode等管理控制权；高层Move使用厂商运动控制器 | 低层策略与厂商运动控制服务分开，明确交接 |

SDK公开代码证明接口定义存在，设备固件是否开放相机或特定运动服务仍需现场检查。相机和雷达未完成接入时，先推进本体感觉控制；不把其接口验证状态写成已经完成。

'''
s=s.replace('## 3. 策略输出怎样作用到电机',cap+'## 3. 策略输出怎样作用到电机')
s+='\n- [官方Go2-W电机编号](https://github.com/unitreerobotics/unitree_sdk2_python/blob/master/example/go2w/low_level/unitree_legged_const.py)。\n- [SportClient服务定义](https://github.com/unitreerobotics/unitree_sdk2_python/blob/master/unitree_sdk2py/go2/sport/sport_client.py)。\n'
p.write_text(s,encoding='utf-8')

adoption='''### 1.4 按工作计划区分复现、试验、复用与改造

| 采用层级 | 项目 | 准备开展的工作 | 需要改造或优化 | 是否作为前置条件 |
|---|---|---|---|---|
| 优先复现 | Robot Lab Go2-W平地PPO | 运行原任务，训练并重载评估；再扩展地形 | 先核对模型/配置，不急于改算法 | 是，形成后续对照 |
| 专项复验 | BabyLocoFormer | 在独立环境中小规模检查序列采集与更新，必要时短训练 | 任务重置、缓存清理与实际PPO多轮执行 | 主线需要同类机制验证，不要求复现其全部工程 |
| 模块移植 | lucidrains/locoformer | 参考TXL与mask实现，接入选定主训练管线 | 对齐张量、动作分布与缓存生命周期，筛选额外扩展 | 历史策略的实现来源之一 |
| 设计借鉴 | MetaMorph / GenLoco | 阅读表示、有效位、方向和初始化设计 | 本项目自行定义槽位及轮速语义 | 不安装完整原工程作为依赖 |
| 条件对照 | URMA | 固定槽位难覆盖目标拓扑时，比较逐关节方案 | 接入相同身体、任务、预算和历史模块 | 不阻塞首版 |
| 资产复用 | GenBot-1K | 筛选少量身体，导入并建立同一控制任务 | 轮足变体、映射、惯量/碰撞与执行器检查 | 多本体阶段需要合格资产，不要求全量数据 |
| 协议与部署参考 | SDK2 / rl_sar | 复用消息定义，参考动作/模式配置与部署组织 | 自建观测/动作适配、TXL运行、周期及异常处理 | 实机闭环前完成 |

当前优先的是工程正确性与机制复验，包括接口、缓存、更新和部署。奖励改进、网络结构优化等算法工作在基线与核心机制验收后再独立提出，避免把多个变化合并后无法归因。

Baby专项复验不以作者自述的弱结果为复现目标。若旧依赖或运行成本过高，保留源码审查与最小序列样例验证，在主管线中实现同类机制并报告差异。对URMA等备选项目，也不要求先完整复现全部论文再推进主线。

'''
p=R/'02_reference_projects.CN.md';s=p.read_text(encoding='utf-8').replace('## 2. LocoFormer已有资源与复现缺口',adoption+'## 2. LocoFormer已有资源与复现缺口');p.write_text(s,encoding='utf-8')

p=R/'04_reproduction_workplan.CN.md';s=p.read_text(encoding='utf-8')
s=s.replace('### 2.1 主训练与部署组合','''### 2.1 项目采用顺序

主线先复现Robot Lab Go2-W单体任务，取得控制与算力基线。随后借鉴MetaMorph/GenLoco设计统一接口，移植lucidrains历史模块，专项复验Baby的序列训练连接，再在同一主训练库中完善任务边界与更新。GenBot用于多本体资产，SDK2/rl_sar用于实机协议与部署组织；URMA仅在拓扑覆盖困难时开展条件对照。

其中，Robot Lab的基线结果是后续前置条件；Baby不要求完整复现全部原工程，但缓存和序列更新必须有可核查证据。若专项试跑依赖成本过高，转为主管线最小序列验证并记录差异。当前“优化”优先指工程完善，不提前承诺算法性能提升。

### 2.2 主训练与部署组合''')
s=s.replace('### 2.2 服务器与使用方式','### 2.3 服务器与使用方式')
s=s.replace('### 参考依据与采用方式\n\n| 参考来源 | 现有内容 | 在本项目中的使用方式 |', '### 参考依据与采用方式\n\n| 参考来源 | 现有内容 | 在本项目中的使用方式 |')
s=s.replace('参考集成位置；重写并验证任务重置、序列采样与多轮更新。','先小规模复验集成位置；在主训练库中完善并验证任务重置、序列采样与多轮更新。')
p.write_text(s,encoding='utf-8')

p=R/'LocoFormer_Go2W_reproduction_briefing.md';s=p.read_text(encoding='utf-8')
marker='## 3. 硬件怎样通过SDK接入策略'
summary='''### 2.1 关节驱动、槽位与SDK编号

每格为“候选槽位 / SDK电机编号”，行与列共同确定具体关节驱动。四条腿分别为FR右前、FL左前、RR右后、RL左后。

| 腿 | hip外展/内收 | thigh大腿俯仰 | calf膝部屈伸 | wheel连续转动 |
|---|---|---|---|---|
| FR | 0 / 0 | 1 / 1 | 2 / 2 | 12 / 12 |
| FL | 3 / 3 | 4 / 4 | 5 / 5 | 13 / 13 |
| RR | 6 / 6 | 7 / 7 | 8 / 8 | 14 / 14 |
| RL | 9 / 9 | 10 / 10 | 11 / 11 | 15 / 15 |

例如FR_hip_joint对应槽位0，读取motor_state[0]并写入motor_cmd[0]。轮模型可命名为FR_foot_joint，对应槽位12与SDK编号12。槽位属于项目设计，SDK编号属于协议；实际模型顺序仍需按名称转换。完整16路逐项表与命令字段见[硬件文档](01_go2w_hardware.CN.md)。

'''
s=s.replace(marker,summary+marker)
s=s.replace('## 5. 关键技术选择','''### 4.1 后续怎样采用这些项目

**优先复现Robot Lab单体任务**，建立可重载基线；**专项复验Baby**的序列训练连接，检查重置和更新次数；**移植lucidrains模块**并在主管线验证。MetaMorph/GenLoco为设计参考，GenBot为资产复用，SDK2/rl_sar为协议与部署参考。URMA为条件对照，不作为启动前置条件。

需要完善的是本项目槽位/动作语义、任务与缓存边界、序列PPO循环和状态化部署。算法结构和奖励优化等研究工作，在这些基础机制可验证后再单独展开。

## 5. 关键技术选择''')
p.write_text(s,encoding='utf-8')
print('Updated 16-channel map, SDK capabilities, adoption priorities and workplan dependencies.')
