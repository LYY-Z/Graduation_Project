from pathlib import Path
src = Path(__file__).with_name('build_deck.py').read_text(encoding='utf-8')
exec(src.split('# 1. Cover')[0])
OUT = Path(r'G:\毕设\02_learning\04_review\deliverables\locoformer\go2w_reproduction_workplan.CN.pptx')

def footer(slide, n=0, source=None):
    line(slide,.68,7.13,12.65,7.13,LINE,.7)
    txt(slide,f'{len(prs.slides):02d} / 14',11.8,7.16,.84,.2,9,MUTED,False,PP_ALIGN.RIGHT,margin=0)
    if source: slide.notes_slide.notes_text_frame.text = '资料依据：'+source

def reuse(start,end,replacements):
    block=src.split(start,1)[1].split(end,1)[0]
    for a,b in replacements.items(): block=block.replace(a,b)
    exec(block,globals())

def table(slide, heads, rows, widths, y=1.55, row_h=.76, fs=13):
    t=slide.shapes.add_table(len(rows)+1,len(heads),Inches(.85),Inches(y),Inches(sum(widths)),Inches(.48+row_h*len(rows))).table
    for col,w in zip(t.columns,widths): col.width=Inches(w)
    for i,row in enumerate([heads]+rows):
        t.rows[i].height=Inches(.48 if i==0 else row_h)
        for j,cell in enumerate(row):
            c=t.cell(i,j); c.text=str(cell)
            c.fill.solid(); c.fill.fore_color.rgb=rgb(WINE if i==0 else (WHITE if i%2 else 'EDEAE5'))
            c.margin_left=c.margin_right=Inches(.12)
            c.margin_top=c.margin_bottom=Inches(.06)
            c.vertical_anchor=MSO_ANCHOR.MIDDLE
            for p in c.text_frame.paragraphs:
                p.space_after=Pt(0)
                for r in p.runs:
                    r.font.name=FONT; r.font.size=Pt(13 if i==0 else fs)
                    r.font.bold=(i==0 or j==0); r.font.color.rgb=rgb(WHITE if i==0 else INK)

# 1 cover
s=base()
rect(s,.78,1.35,.07,3.75,WINE)
txt(s,'LocoFormer 复现工作计划',1.12,1.58,11,.7,36,INK,True)
txt(s,'Go2-W 平台、参考项目与实施路线',1.15,2.53,10.8,.52,24,WINE,True)
txt(s,'实机硬件与参数\n仿真软件和服务器条件\n可复用代码、适配任务与阶段产出',1.17,3.55,10.5,1.4,19,MUTED)
txt(s,'组会工作计划汇报  ·  2026.11',1.17,6.55,10.5,.3,12,MUTED)

# 2 hardware
reuse('# 8. Go2-W hardware','# 9. Mapping',{'七、实机对象：Go2-W 是 12 个腿关节 + 4 个轮电机':'Go2-W 实机平台与主要参数'})
txt(s,'尺寸约 70 × 43 × 50 cm\n标称负载约 8 kg，最大约 12 kg',.96,5.94,6.05,.63,14,INK)

# 3 motor map
reuse('# 9. Mapping','# 10. Reference project roles',{'八、硬件映射：策略槽位不能直接当作 SDK 电机编号':'Go2-W 执行器分布与控制接口'})

# 4 joint limits / sensors
s=base('Go2-W 关节模型参数与状态来源')
txt(s,'公开 URDF 的关节限位、力矩和速度字段用于检查仿真模型与接口。',.85,1.28,11.6,.38,17,INK,True)
table(s,['关节类型','位置范围（rad）','effort（N·m）','速度（rad/s）'],[
('髋关节 hip','−1.0472 ～ 1.0472','23.7','30.1'),
('前腿 thigh','−1.5708 ～ 3.4907','23.7','30.1'),
('后腿 thigh','−0.5236 ～ 4.5379','23.7','30.1'),
('小腿 calf','−2.7227 ～ −0.83776','35.55','20.07'),
('车轮 wheel','continuous，连续旋转','23.7','30.1')],[2.75,4.0,2.1,2.65],1.88,.55,13.5)
txt(s,'状态获取',.96,5.42,1.4,.34,17,WINE,True)
txt(s,'IMU 提供姿态和角速度，电机反馈提供关节位置与速度。\n初期运动控制优先使用本体状态。',2.45,5.32,9.3,.57,15,INK)
txt(s,'模型中 IMU 位于机身基座附近，LiDAR 位于机身前部。相机与扩展计算单元以设备实际配置为准。',.96,6.08,11.1,.42,13,MUTED)
txt(s,'URDF 模型限值与实机运行约束需分别记录。',.96,6.62,11.1,.28,13,WINE,True)
footer(s,source='Unitree Go2-W URDF: https://github.com/unitreerobotics/unitree_ros/blob/master/robots/go2w_description/urdf/go2w_description.urdf；产品规格：https://www.unitree.com/mobile/go2-w/')

# 5 software
reuse('# 11. software stack','# 12. Server',{'十、软件路线：仿真、学习框架、策略与实机接口各司其职':'复现软件栈与组件职责'})

# 6 resources
reuse('# 12. Server','# 13. Plan',{'十一、服务器判断：适合做分阶段复现，不等于论文训练规模':'服务器条件与训练规模规划'})
for sh in s.shapes:
    if getattr(sh,'has_text_frame',False) and '2 × RTX PRO 5000 Blackwell' in sh.text:
        for p in sh.text_frame.paragraphs:
            for r in p.runs:
                if '2 × RTX PRO 5000 Blackwell' in r.text: r.text=r.text.replace('2 × RTX PRO 5000 Blackwell','RTX PRO 5000 ×2')

# 7 reference projects
s=base('参考项目与选型：每个项目对应一个工作环节')
table(s,['工作环节','首选参考','可以复用的内容'],[
('Go2-W 仿真基线','Robot Lab 2.3.2','机器人资产、速度任务、观测 / 动作和奖励配置'),
('算法与训练接线','本地 locoformer + BabyLocoFormer','TXL / PPO 核心模块，Isaac Lab 训练管线样例'),
('多本体资产','GenBot-1K','形态生成、URDF / USD 资产、身体划分方法'),
('跨本体输入输出对照','URMA；MetaMorph','逐关节表示、共享编解码、形态条件化思路'),
('实机接口与部署','Unitree SDK2 + Unitree RL Lab','电机通道、状态消息、控制参数与部署流程'),
('模型交叉核对','Unitree MuJoCo / 官方 URDF','关节轴、轮连续性、执行器与模型约定')],[2.45,3.4,5.65],1.52,.72,12.7)
txt(s,'实施选择：Robot Lab 作为主仿真底座；第三方 LocoFormer 代码用于算法接入；SDK2 构建独立实机适配层。',.94,6.55,11.4,.36,13.3,WINE,True)
footer(s,source='Robot Lab https://github.com/fan-ziqi/robot_lab/tree/v2.3.2；BabyLocoFormer https://github.com/linden713/BabyLocoFormer；lucidrains https://github.com/lucidrains/locoformer；GenBot https://github.com/BoAi01/embodiment-scaling-laws；URMA https://proceedings.mlr.press/v270/bohlinger25a.html；MetaMorph https://metamorph-iclr.github.io/site/；Unitree RL Lab https://github.com/unitreerobotics/unitree_rl_lab')

# 8 implementation audit
s=base('算法参考代码：已有能力与需要补齐的工作')
table(s,['参考实现','已提供的组件','本项目的接入工作'],[
('本地 locoformer\n第三方 PyTorch 实现','TXL、Actor/Critic、PPO\n多输入宽度编码器、动作 selector','接入真实仿真环境与奖励\n复核跨 Trial 采集、缓存与更新边界'),
('BabyLocoFormer\n非官方学习版','Isaac Lab 训练 / 评估管线\n多形态四足生成、有限随机化','核查版本兼容性与 TXL 改动\n迁移 Go2-W 轮足任务与动作合同')],[2.7,4.25,4.55],1.7,1.52,14)
txt(s,'接口重点',.97,5.44,1.35,.34,17,WINE,True)
txt(s,'本地代码的 state_id 由调用者选择编码器。Go2-W 的关节顺序、动作类型和 SDK 通道映射仍需由项目明确实现。',2.46,5.29,9.38,.68,15,INK)
txt(s,'公开入口未找到作者完整训练仓库和官方 checkpoint。复现采用公开方法与参考实现，并记录实现差异。',.97,6.23,11.15,.49,13.5,MUTED)
footer(s,source='本地 locoformer/locoformer.py 的 StateEmbedder 和 selector；仓库 README；BabyLocoFormer README；作者项目页 https://generalist-locomotion.github.io/')

# 9 assets / IO
s=base('多本体扩展：资产筛选与统一输入输出')
table(s,['工作项','实施内容','阶段产物'],[
('身体资产','先选择少量四足 / 轮足模型\n检查惯量、碰撞、关节轴和可控性','合格资产清单\n训练 / 测试身体划分'),
('统一观测','定义关节槽位、方向、单位和归一化\n明确缺失关节占位与有效标记','观测字段表\n每台机器人的映射配置'),
('共享策略','优先沿用论文统一关节超集路线\nURMA 逐关节表示作为后续架构对照','共同输入 / 输出合同\n可独立比较的结构版本'),
('动作解码','统一动作映射到模型 joint 和 SDK index\n腿部与车轮按实际任务定义解码','动作转换与约束\n逐路映射检查')],[2.0,6.15,3.35],1.55,1.02,13.7)
txt(s,'GenBot-1K 提供资产来源。模型导入、控制适配和训练任务仍需逐项完成；统一空间长度在盘点目标身体后确定。',.98,6.38,11.15,.49,13.4,WINE,True)
footer(s,source='GenBot https://embodiment-scaling-laws.github.io/；LocoFormer §2.1；URMA https://proceedings.mlr.press/v270/bohlinger25a.html')

# 10 pipeline
s=base('计划建立的仿真训练与实机部署流程')
txt(s,'仿真训练',.95,1.4,2,.4,19,WINE,True)
labels=[('身体资产与任务','Robot Lab / GenBot'),('状态适配','统一观测合同'),('策略与历史','TXL + PPO'),('动作与物理反馈','训练 / 保存权重')]
for i,(a,b) in enumerate(labels):
    x=.95+i*3.02
    rect(s,x,2.12,2.57,1.12,[BLUE,GREEN,GOLD_LIGHT,WINE_LIGHT][i])
    txt(s,a,x+.1,2.24,2.37,.35,15,INK,True,PP_ALIGN.CENTER)
    txt(s,b,x+.1,2.75,2.37,.28,12,MUTED,False,PP_ALIGN.CENTER)
    if i<3: txt(s,'→',x+2.64,2.47,.3,.35,21,WINE,True,PP_ALIGN.CENTER)
txt(s,'实机部署',.95,3.85,2,.4,19,BLUE_DARK,True)
labels=[('SDK2 状态读取','IMU / 16 路电机'),('观测与策略','同一合同 + 历史'),('动作适配器','映射 / 类型 / 限幅'),('SDK2 命令执行','反馈回到下一周期')]
for i,(a,b) in enumerate(labels):
    x=.95+i*3.02
    rect(s,x,4.55,2.57,1.12,[BLUE,GREEN,GOLD_LIGHT,WINE_LIGHT][i])
    txt(s,a,x+.1,4.68,2.37,.35,15,INK,True,PP_ALIGN.CENTER)
    txt(s,b,x+.1,5.18,2.37,.28,12,MUTED,False,PP_ALIGN.CENTER)
    if i<3: txt(s,'→',x+2.64,4.9,.3,.35,21,BLUE_DARK,True,PP_ALIGN.CENTER)
txt(s,'部署前的一致性检查：观测顺序、坐标系、归一化、动作意义、控制周期和历史重置规则。',.98,6.35,11.2,.46,14,WINE,True)
footer(s,source='拟定工程路线；Unitree SDK2 https://github.com/unitreerobotics/unitree_sdk2_python')

# 11 roadmap
s=base('复现总计划与阶段依赖')
table(s,['阶段','主要工作','交付物 / 验收依据'],[
('01 仿真平台','固定 Isaac 版本，启动 Go2-W 资产','环境清单、模型检查、可重复启动'),
('02 单本体基线','运行 Go2-W 速度任务与 PPO','基线权重、训练曲线、评估日志'),
('03 算法接入','连接 LocoFormer 策略与统一 I/O','张量合同、映射检查、保存与加载'),
('04 长历史验证','接入 TXL 与跨 Trial 采集','缓存边界检查、保留 / 清空历史对照'),
('05 跨本体实验','加入合格身体，完整本体留出','数据划分、多种子结果、适应曲线'),
('06 Go2-W 实机','SDK2 状态 / 动作适配与闭环','时序、命令反馈、运动与恢复记录')],[2.3,4.65,4.55],1.52,.74,13.1)
txt(s,'阶段按依赖关系推进。首先验证模型与控制合同，再扩大网络、记忆和身体分布。',.98,6.54,11.1,.32,14,WINE,True)
footer(s)

# 12 first stage detailed
s=base('近期工作：仿真平台与 Go2-W 基线')
table(s,['任务','具体执行内容','完成标准'],[
('环境部署','独立 Conda 环境中部署锁定版本\n检查驱动、Isaac Sim、Isaac Lab、Robot Lab','单环境与小并行场景可启动\n记录依赖与代码版本'),
('模型核对','检查 12+4 关节及轮连续性\n核对初态、执行器、碰撞与接触','状态与模型关节一一对应\n逐路动作作用符合预期'),
('基线训练','先用现成 Go2-W 速度跟踪任务\n分开执行训练与评估','获得可加载 checkpoint\n记录误差、跌倒率和动作变化'),
('算力评估','逐步增加并行环境数量\n测量采样吞吐、显存和内存','确定当前服务器的环境数\n估算后续实验预算')],[2.15,5.35,4.0],1.56,1.06,13.5)
txt(s,'该阶段产出可运行的基线和资源测量，为后续算法接入提供对照。',.98,6.46,11.1,.4,14,WINE,True)
footer(s)

# 13 research and real stages
s=base('后续工作：长历史、多本体与实机验证')
table(s,['工作包','实施任务','核心对照 / 验收'],[
('长历史与跨 Trial','连接分段缓存与 PPO 序列采集\n规定倒地、重置和历史保留条件','保留 / 清空历史\n恢复时间与任务表现'),
('跨本体共享','先用少量四足 / 轮足资产\n固定槽位映射，再扩展随机化','整台机器人留出\n逐身体结果与多个随机种子'),
('Go2-W 实机','接 SDK2 状态、策略、动作解码\n对齐频率、延迟、约束与反馈','输入 / 命令 / 反馈可追踪\n稳定运行与异常记录')],[2.35,5.3,3.85],1.7,1.27,14)
txt(s,'每个工作包保留代码版本、配置、权重和日志。多本体训练规模按实测吞吐逐步扩展。',.98,6.3,11.1,.49,14,WINE,True)
footer(s)

# 14 near-term outputs
s=base('当前优先任务与预期产出')
txt(s,'下一阶段优先完成 Go2-W 仿真基线，形成后续复现工作的工程依据。',.9,1.36,11.55,.48,20,INK,True)
table(s,['优先级','工作内容','产出'],[
('P1','锁定环境与参考仓库版本，运行 Go2-W 场景','版本清单、启动记录、资产检查'),
('P2','核对 16 路状态和动作，训练现成 PPO 基线','I/O 字段表、基线策略、评估结果'),
('P3','审查 LocoFormer / BabyLocoFormer 接口兼容性','代码接入方案、修改范围与任务拆分'),
('P4','制定长历史和多本体实验配置','数据划分、对照方案与计算预算')],[1.35,6.35,3.8],2.17,.87,14)
txt(s,'计划约束',1.0,6.46,1.4,.34,16,WINE,True)
txt(s,'作者完整工程与权重尚未获取。当前服务器支持先验证核心机制，论文训练规模与性能对齐需在实验后评估。',2.56,6.32,9.12,.65,14,MUTED)
footer(s)

assert len(prs.slides)==14
from pptx.oxml.xmlchemy import OxmlElement
for slide in prs.slides:
    for tag in ('a:rPr','a:defRPr','a:endParaRPr'):
        for rp in slide._element.xpath('.//'+tag):
            for kind in ('a:latin','a:ea','a:cs'):
                nodes=rp.findall('{http://schemas.openxmlformats.org/drawingml/2006/main}'+kind.split(':')[1])
                if nodes: node=nodes[0]
                else: node=OxmlElement(kind); rp.append(node)
                node.set('typeface',FONT)
OUT.parent.mkdir(parents=True,exist_ok=True)
prs.save(OUT)
print(f'saved={OUT} slides={len(prs.slides)}')
