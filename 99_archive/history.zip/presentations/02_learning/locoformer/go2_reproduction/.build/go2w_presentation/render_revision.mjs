import fs from 'node:fs/promises';
import { FileBlob, PresentationFile } from '@oai/artifact-tool';
const src = 'G:/毕设/02_learning/04_review/deliverables/locoformer/go2w_reproduction_plan.revised.CN.pptx';
const out = 'G:/毕设/02_learning/locoformer/go2_reproduction/.build/go2w_presentation/revision_render';
await fs.mkdir(out, {recursive:true});
const p = await PresentationFile.importPptx(await FileBlob.load(src));
const info = await p.inspect({select:'$.slides[*]',include:['index','title','elements.text','elements.style'],fileName:'inspect.ndjson'});
await fs.writeFile(`${out}/inspect.ndjson`, info.ndjson, 'utf8');
const montage = await p.export({format:'png',montage:true,scale:0.35});
await fs.writeFile(`${out}/montage.png`, new Uint8Array(await montage.arrayBuffer()));
for (let i=0;i<p.slides.items.length;i++) {
  const blob = await p.export({slide:p.slides.items[i],format:'png',scale:1});
  await fs.writeFile(`${out}/slide-${String(i+1).padStart(2,'0')}.png`, new Uint8Array(await blob.arrayBuffer()));
}
console.log(JSON.stringify({slides:p.slides.items.length, inspect:info.ndjson.slice(0,200)},null,2));
