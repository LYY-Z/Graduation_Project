from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE, MSO_CONNECTOR
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.dml import MSO_THEME_COLOR
from pathlib import Path

ROOT = Path(r"G:\毕设\02_learning\locoformer\go2_reproduction")
OUT = Path(r"G:\毕设\02_learning\04_review\deliverables\locoformer\go2w_reproduction_plan.revised.CN.pptx")
ASSET = ROOT / "assets"

W, H = 13.333, 7.5
BG = "F6F4F0"
INK = "252A31"
MUTED = "555D66"
WINE = "78394C"
WINE_LIGHT = "F2E8EB"
BLUE = "E8F0F8"
BLUE_DARK = "3E6F9E"
GREEN = "E8F2ED"
GREEN_DARK = "467B61"
GOLD = "E5A13A"
GOLD_LIGHT = "FBF0DE"
LINE = "D9D5CE"
WHITE = "FFFFFF"
FONT = "Microsoft YaHei"

prs = Presentation()
prs.slide_width = Inches(W)
prs.slide_height = Inches(H)
blank = prs.slide_layouts[6]

def rgb(h):
    return RGBColor.from_string(h)

def rect(slide, x, y, w, h, fill, line=None, radius=False):
    shape = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE if radius else MSO_SHAPE.RECTANGLE,
                                   Inches(x), Inches(y), Inches(w), Inches(h))
    shape.fill.solid(); shape.fill.fore_color.rgb = rgb(fill)
    shape.line.fill.background() if line is None else None
    if line:
        shape.line.color.rgb = rgb(line); shape.line.width = Pt(1)
    if radius:
        try: shape.adjustments[0] = 0.08
        except Exception: pass
    return shape

def txt(slide, text, x, y, w, h, size=18, color=INK, bold=False, align=PP_ALIGN.LEFT,
        valign=MSO_ANCHOR.MIDDLE, margin=0.05, font=FONT, fit=True):
    box = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    tf = box.text_frame; tf.clear(); tf.word_wrap = True
    tf.margin_left = Inches(margin); tf.margin_right = Inches(margin)
    tf.margin_top = Inches(margin); tf.margin_bottom = Inches(margin)
    tf.vertical_anchor = valign
    for i, line in enumerate(str(text).split("\n")):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.text = line; p.alignment = align
        p.space_after = Pt(2)
        for r in p.runs:
            r.font.name = font; r.font.size = Pt(size); r.font.bold = bold; r.font.color.rgb = rgb(color)
    if fit:
        try: tf.fit_text(font_family=font, max_size=size)
        except Exception: pass
    return box

def line(slide, x1, y1, x2, y2, color=LINE, width=1.2, arrow=False):
    s = slide.shapes.add_connector(MSO_CONNECTOR.STRAIGHT, Inches(x1), Inches(y1), Inches(x2), Inches(y2))
    s.line.color.rgb = rgb(color); s.line.width = Pt(width)
    return s

def base(title=None, section=None):
    s = prs.slides.add_slide(blank)
    s.background.fill.solid(); s.background.fill.fore_color.rgb = rgb(BG)
    if title:
        txt(s, title, .68, .32, 11.95, .58, 27, INK, True)
        rect(s, .68, 1.03, .75, .045, WINE)
        line(s, 1.44, 1.055, 12.65, 1.055, LINE, .8)
    return s

def footer(slide, n, source=None):
    line(slide, .68, 7.13, 12.65, 7.13, LINE, .7)
    if source:
        txt(slide, source, .7, 7.16, 10.9, .18, 8, MUTED, False, valign=MSO_ANCHOR.MIDDLE, margin=0)
    txt(slide, f"{n:02d} / 15", 11.8, 7.15, .84, .2, 9, MUTED, False, PP_ALIGN.RIGHT, margin=0)

def card(slide, x, y, w, h, title, body, fill=WHITE, accent=WINE, title_size=17, body_size=13.5):
    rect(slide, x, y, w, h, fill, radius=True)
    rect(slide, x, y, .055, h, accent)
    txt(slide, title, x+.18, y+.12, w-.35, .34, title_size, accent, True)
    txt(slide, body, x+.18, y+.52, w-.35, h-.61, body_size, INK, False, valign=MSO_ANCHOR.TOP)

def pill(slide, text, x, y, w, fill, color=INK, size=12):
    rect(slide, x, y, w, .36, fill, radius=True)
    txt(slide, text, x+.03, y+.01, w-.06, .33, size, color, True, PP_ALIGN.CENTER, margin=.02)

def notes(slide, content):
    # Speaker notes are deliberately omitted from this proposal deck; source labels are visible on relevant slides.
    pass

# 1. Cover
s = prs.slides.add_slide(blank); s.background.fill.solid(); s.background.fill.fore_color.rgb = rgb(BG)
rect(s, .72, 1.1, .08, 4.8, WINE)
txt(s, "LocoFormer × Go2-W", 1.05, 1.28, 10.8, .8, 38, INK, True)
txt(s, "从论文机制到跨本体复现路线", 1.08, 2.18, 10.7, .48, 25, WINE, True)
txt(s, "研究问题｜方法与复现边界｜Go2-W 接口｜实施计划与验收", 1.08, 2.92, 10.9, .42, 17, MUTED)
rect(s, 1.08, 4.05, 10.8, 1.05, WHITE, radius=True)
txt(s, "汇报主线", 1.32, 4.2, 1.15, .3, 14, WINE, True)
txt(s, "论文提出了什么 → 现有资料能复现到哪里 → Go2-W 还需补齐什么 → 如何分阶段验证", 2.5, 4.15, 8.9, .52, 16, INK, True)
txt(s, "LocoFormer: Generalist Locomotion via Long-context Adaptation  |  CoRL 2025", 1.08, 6.45, 10.8, .3, 11, MUTED)
txt(s, "组会汇报  ·  2026.11", 1.08, 6.82, 10.8, .25, 10, MUTED)

# 2. Research question
s = base("一、复现目标：验证方法机制，而不只是让 Go2-W 动起来")
txt(s, "论文要解决的不是单台机器人的控制调参，而是两个相连的问题：", .78, 1.28, 11.5, .44, 19, INK, True)
card(s, .82, 2.02, 5.55, 2.05, "跨本体泛化", "训练身体与测试身体不同。\n目标：同一策略能否控制未见过的腿式 / 轮式机器人？", BLUE, BLUE_DARK, 19, 16)
card(s, 6.65, 2.02, 5.55, 2.05, "运行中适应", "新身体的动力学未知。\n目标：策略能否利用先前交互历史，逐渐调整后续动作？", GREEN, GREEN_DARK, 19, 16)
rect(s, .82, 4.58, 11.38, 1.12, WINE_LIGHT, radius=True)
txt(s, "本项目的验证对象", 1.08, 4.75, 1.95, .33, 16, WINE, True)
txt(s, "Go2-W 是实机落点；完整复现仍需多本体仿真训练、未见身体留出测试，以及跨 Trial 记忆对照。", 3.12, 4.65, 8.7, .58, 16, INK, True)
txt(s, "因此，“单机跑通”是必要的工程基线，不足以单独证明 LocoFormer 的核心主张。", .92, 6.15, 11.2, .38, 14, MUTED)
footer(s, 2, "依据：Liu et al., LocoFormer, CoRL 2025, Abstract / Method")

# 3. Contributions
s = base("二、论文方法：多样身体训练 + 跨 Trial 长上下文")
steps = [
    ("1  构造身体分布", "程序化生成不同腿式、轮式身体；随机化形态与动力学", BLUE, BLUE_DARK),
    ("2  共享统一接口", "把各机器人的状态与动作放入共同关节表示", BLUE, BLUE_DARK),
    ("3  PPO 训练策略", "在仿真交互中用奖励优化共享策略参数", GOLD_LIGHT, GOLD),
    ("4  TXL 读取历史", "分段缓存隐藏状态，让信息跨时间和 Trial 延续", GREEN, GREEN_DARK),
]
for i,(t,b,f,a) in enumerate(steps):
    x=.82+i*3.0
    card(s,x,2.0,2.62,2.22,t,b,f,a,15.5,13.5)
    if i<3: line(s,x+2.68,3.1,x+2.95,3.1,WINE,2,True)
rect(s,.82,4.68,11.38,1.1,WHITE,radius=True)
txt(s,"方法归类",1.08,4.84,1.28,.3,15,WINE,True)
txt(s,"大规模程序化强化学习策略；以 Transformer-XL 扩展历史上下文。创新点在机制组合、训练分布与跨身体评测，不是单独提出一个注意力算子。",2.55,4.76,9.25,.58,14.5,INK,True)
txt(s,"逻辑关系：身体分布提供泛化经验；统一接口让策略共享；长历史提供测试时适应信息。",.94,6.23,11.0,.35,14,MUTED)
footer(s, 3, "依据：论文 §§1–3；补充材料")

# 4. End-to-end train vs inference
s = base("三、完整闭环：训练更新参数，部署积累上下文")
txt(s,"训练阶段：在仿真中反复采样，PPO 根据奖励更新 θ",.82,1.3,11.7,.35,17,WINE,True)
train=[("身体 / 动力学\n采样","多身体任务"),("观测 + 历史\n输入策略","TXL"),("动作\n执行仿真","环境响应"),("奖励 / 轨迹\n进入 PPO","更新 θ")]
for i,(a,b) in enumerate(train):
    x=.9+i*3.0; rect(s,x,1.9,2.5,1.02,[BLUE,GREEN,GOLD_LIGHT,WINE_LIGHT][i],radius=True)
    txt(s,a,x+.08,2.0,2.34,.43,15,INK,True,PP_ALIGN.CENTER)
    txt(s,b,x+.08,2.49,2.34,.25,11.5,MUTED,False,PP_ALIGN.CENTER)
    if i<3: line(s,x+2.55,2.42,x+2.92,2.42,WINE,2,True)
line(s,11.45,3.08,2.2,3.08,GOLD,1.7,True)
txt(s,"训练循环持续产生新数据并更新 θ",4.5,3.1,4.1,.3,11.5,MUTED,False,PP_ALIGN.CENTER)
txt(s,"部署阶段：θ 固定；新观测和 KV 历史改变下一步动作",.82,3.8,11.7,.35,17,BLUE_DARK,True)
deploy=[("IMU / 关节反馈","当前观测"),("TXL + 缓存历史","上下文"),("策略输出","统一动作"),("适配器 / SDK2","Go2-W 执行")]
for i,(a,b) in enumerate(deploy):
    x=.9+i*3.0; rect(s,x,4.42,2.5,.98,[WHITE,BLUE,GREEN,GOLD_LIGHT][i],line=LINE,radius=True)
    txt(s,a,x+.08,4.52,2.34,.33,14,INK,True,PP_ALIGN.CENTER)
    txt(s,b,x+.08,4.9,2.34,.24,11.5,MUTED,False,PP_ALIGN.CENTER)
    if i<3: line(s,x+2.55,4.9,x+2.92,4.9,BLUE_DARK,2,True)
line(s,11.4,5.48,1.4,5.48,BLUE_DARK,1.5,True)
txt(s,"机体反馈形成新的上下文；部署不做 PPO 权重更新",3.7,5.56,5.2,.32,12.5,MUTED,False,PP_ALIGN.CENTER)
footer(s, 4, "依据：论文 Method；TXL / PPO 运行流程")

# 5. Paper benchmark
s = base("四、论文结果：未见机器人上，泛化接近专用策略")
txt(s,"测试协议：10 种未见机器人；每种 1,000 个随机仿真环境；Few-shot 提供 5 秒交互适应",.82,1.32,11.7,.42,15.5,INK,True)
vals=[("Zero-shot",.96,"±0.19",BLUE_DARK), ("Few-shot",.98,"±0.13",GREEN_DARK), ("GRU",.37,"±0.41",MUTED), ("Conditioning",.78,"±0.37",GOLD), ("Expert",.99,"±0.07",WINE)]
chart_x, chart_y, chart_w, chart_h = 1.15,2.15,7.7,3.65
for j in range(6):
    yy=chart_y+chart_h-j*chart_h/5
    line(s,chart_x,yy,chart_x+chart_w,yy,LINE,.7)
    txt(s,f"{j/5:.1f}",.62,yy-.13,.42,.24,9,MUTED,False,PP_ALIGN.RIGHT,margin=0)
for i,(label,v,err,c) in enumerate(vals):
    bw=.82; x=1.65+i*1.42; bh=v*chart_h
    rect(s,x,chart_y+chart_h-bh,bw,bh,c,radius=True)
    txt(s,f"{v:.2f}",x-.05,chart_y+chart_h-bh-.32,bw+.1,.25,12,INK,True,PP_ALIGN.CENTER,margin=0)
    txt(s,label,x-.32,5.92,1.48,.44,10.5,INK,True,PP_ALIGN.CENTER)
    txt(s,err,x-.05,6.32,bw+.1,.24,9.5,MUTED,False,PP_ALIGN.CENTER,margin=0)
card(s,9.25,2.02,2.95,1.42,"指标含义","朝随机目标移动的平均位移，归一化到 [0,1]。不是成功率。",WHITE,WINE,16,12.5)
card(s,9.25,3.72,2.95,1.42,"结果解读","Zero-shot 已较高；5 秒交互后略有提升，接近 Expert 基线。",GREEN,GREEN_DARK,16,12.5)
txt(s,"报告时应同时给出均值与标准差，不能只把 0.96 解释成 96% 成功。",9.32,5.48,2.82,.72,12.5,WINE,True)
footer(s, 5, "依据：论文 Table 1；误差值为论文报告的标准差")

# 6. Reproduction boundary
s = base("五、复现边界：论文机制明确，工程接口仍需补齐")
cols=[("论文明确给出","核心方法 / 评测",BLUE,BLUE_DARK),
      ("公开代码可参考","算法模块 / 管线",GREEN,GREEN_DARK),
      ("本项目必须实现","Go2-W 适配 / 验证",GOLD_LIGHT,GOLD)]
for i,(t,sub,fill,accent) in enumerate(cols):
    x=.82+i*3.9
    rect(s,x,1.55,3.55,.55,accent,radius=True); txt(s,t,x+.1,1.62,3.35,.32,16,WHITE,True,PP_ALIGN.CENTER)
    rect(s,x,2.2,3.55,3.08,fill,radius=True)
body=["• 程序化多本体训练\n• PPO + TXL 长上下文\n• 统一关节空间思路\n• 未见身体 / few-shot 结果",
      "• 本地 lucidrains 代码含 TXL、PPO、Actor/Critic\n• BabyLocoFormer 给出非官方 Isaac Lab 管线\n• Robot Lab 提供 Go2-W 仿真起点",
      "• canonical 关节顺序与字段单位\n• 缺失槽位 / 有效位约定\n• 腿与轮动作解码到 SDK2\n• 实际控制周期、软限幅与日志"]
for i,t in enumerate(body): txt(s,t,.98+i*3.9,2.45,3.22,2.55,14,INK,False,valign=MSO_ANCHOR.TOP)
rect(s,.82,5.68,11.35,.75,WINE_LIGHT,radius=True)
txt(s,"关键限制",1.03,5.83,1.2,.32,15,WINE,True)
txt(s,"公开材料未给出可直接照抄的 Go2-W 槽位表、SDK 映射、作者完整训练仓库或下载权重；第三方实现不能称作作者官方复现。",2.26,5.78,9.6,.42,14,INK,True)
footer(s, 6, "边界依据：论文、补充材料、公开仓库代码；详见技术资料中的来源表")

# 7. Cross-embodiment approaches
s = base("六、不同关节数如何共用策略：输入合同先于网络")
data=[
    ("LocoFormer：统一超集空间","每个关节放入预先约定的 canonical 槽位；策略输出统一动作，再由适配器取有效关节。","最贴近论文；Go2-W 首选","必须定义槽位语义 / 映射"),
    ("URMA：逐关节 token","每个关节带状态与结构描述，注意力在关节 token 间共享计算；动作逐 token 解码。","拓扑变化大时适合做对照","不是 LocoFormer 原方案"),
    ("本地代码：按已知宽度选 encoder","不同状态维度可用不同编码器映射到同宽 latent；由调用者传 state_id 选择。","理解模块复用、做接线原型","不会自动识别未见机器人"),
]
for i,(a,b,c,d) in enumerate(data):
    y=1.45+i*1.58
    rect(s,.82,y,11.38,1.35,[BLUE,GREEN,GOLD_LIGHT][i],radius=True)
    txt(s,a,1.02,y+.12,2.75,.38,15.5,[BLUE_DARK,GREEN_DARK,GOLD][i],True)
    txt(s,b,3.8,y+.1,4.55,.72,12.5,INK,False,valign=MSO_ANCHOR.TOP)
    txt(s,c,8.55,y+.14,1.72,.63,11.5,INK,True)
    txt(s,d,10.35,y+.14,1.65,.63,10.5,WINE,True)
rect(s,.82,6.25,11.38,.52,WHITE,radius=True)
txt(s,"零填充本身不携带语义：真实零状态可能与“关节不存在”混淆；需要固定槽位并设计有效位 / body descriptor，再做消融。",1.02,6.31,10.98,.34,12.5,INK,True)
footer(s, 7, "项目建议：先按论文统一超集建立可验证接口；URMA 作为后续架构比较")

# 8. Go2-W hardware
s = base("七、实机对象：Go2-W 是 12 个腿关节 + 4 个轮电机")
img=ASSET/"go2w_official_field.jpg"
s.shapes.add_picture(str(img), Inches(.82), Inches(1.45), width=Inches(6.3), height=Inches(3.92))
txt(s,"Unitree Go2-W 官方产品场景",.95,5.45,6.0,.26,10,MUTED)
cards=[("16 路执行器","12 路腿关节 + 4 路轮电机",BLUE,BLUE_DARK),
       ("机械与运动","约 18 kg；7 英寸充气轮胎；标称速度 0–2.5 m/s",GREEN,GREEN_DARK),
       ("传感器","IMU、电机反馈；官方规格列出 LiDAR 与广角相机",GOLD_LIGHT,GOLD),
       ("电源 / 计算","33.6 V、15 Ah；8 核 CPU；Orin NX 为选配",WINE_LIGHT,WINE)]
for i,(a,b,f,c) in enumerate(cards):
    y=1.48+i*1.13; card(s,7.45,y,4.72,.95,a,b,f,c,15,12.5)
txt(s,"产品页的最大扭矩数值不等于 16 路电机的统一限值；URDF 模型限制也不等于实机安全阈值。",7.56,6.18,4.55,.55,11.5,WINE,True)
footer(s, 8, "来源：Unitree Go2-W 官方产品页；Unitree Go2-W URDF")

# 9. Mapping
s = base("八、硬件映射：策略槽位不能直接当作 SDK 电机编号")
s.shapes.add_picture(str(ASSET/"go2w_joint_map.png"), Inches(.72), Inches(1.32), width=Inches(7.1), height=Inches(5.28))
card(s,8.08,1.55,4.08,1.24,"腿部 SDK 通道","FR 0–2  ·  FL 3–5\nRR 6–8  ·  RL 9–11",BLUE,BLUE_DARK,16,14)
card(s,8.08,3.03,4.08,1.13,"轮电机通道","FR 12  ·  FL 13\nRR 14  ·  RL 15",GOLD_LIGHT,GOLD,16,14)
card(s,8.08,4.4,4.08,1.52,"适配器要处理","统一语义 → URDF joint → SDK index\n方向 / 单位 / 归一化\n关节位置目标与轮动作分开解码",GREEN,GREEN_DARK,15.5,12.3)
txt(s,"顺序来自 Unitree SDK2 常量；仍需与实际模型、任务控制模式逐项验证。",8.18,6.18,3.85,.42,10.5,MUTED)
footer(s, 9, "来源：Unitree SDK2 Go2-W channel constants；官方 URDF")

# 10. Reference project roles
s = base("九、参考项目分工：借模块，不拼成“现成复现包”")
rows=[
    ("论文 / 补充材料","目标机制、基准与结论","研究定义；不能提供缺失工程细节",BLUE_DARK),
    ("本地 lucidrains locoformer","TXL、PPO、Actor/Critic、不同输入宽度 encoder","第三方算法学习代码；非作者训练工程",WINE),
    ("BabyLocoFormer","多形态四足生成与 Isaac Lab 训练接线","非官方学习版；改造 TXL，范围小于论文",GREEN_DARK),
    ("Robot Lab 2.3.2","Isaac Lab 任务、Go2-W 资产与基线","作为仿真底座；不包含 LocoFormer 跨 Trial 机制",BLUE_DARK),
    ("GenBot-1K / URMA","形态资产与逐关节表示对照","资产需物理筛选；URMA 与论文方法不同",GOLD),
    ("SDK2 / URDF / MuJoCo","真实硬件索引、模型字段、模型交叉核对","SDK 负责通信；MuJoCo 不替代主训练栈",MUTED),
]
for i,(a,b,c,col) in enumerate(rows):
    y=1.38+i*.82
    rect(s,.82,y,2.25,.62,col,radius=True); txt(s,a,.92,y+.07,2.05,.46,12.1,WHITE,True,PP_ALIGN.CENTER)
    rect(s,3.2,y,4.0,.62,WHITE,radius=True); txt(s,b,3.35,y+.06,3.7,.48,12.2,INK,True)
    rect(s,7.38,y,4.82,.62,[BLUE,GREEN,GOLD_LIGHT,WINE_LIGHT,WHITE,WHITE][i],radius=True); txt(s,c,7.53,y+.06,4.5,.48,11.5,MUTED,False)
txt(s,"主路线：Robot Lab 建 Go2-W 仿真 → 移植/核对 LocoFormer 算法 → SDK2 做实机适配；其余作为对照或资产来源。",.9,6.55,11.2,.34,12.4,WINE,True)
footer(s, 10, "项目链接与版本见《参考项目与选型》")

# 11. software stack
s = base("十、软件路线：仿真、学习框架、策略与实机接口各司其职")
layers=[
    ("Isaac Sim 5.1","物理、场景、刚体 / 接触仿真",BLUE,BLUE_DARK),
    ("Isaac Lab 2.3.2","并行环境与机器人学习接口",GREEN,GREEN_DARK),
    ("Robot Lab 2.3.2","Go2-W 资产、任务与奖励基线",GOLD_LIGHT,GOLD),
    ("LocoFormer / PyTorch","策略网络、TXL 历史与 PPO 训练",WINE_LIGHT,WINE),
]
for i,(a,b,f,c) in enumerate(layers):
    y=1.45+i*1.0; rect(s,1.02,y,5.25,.75,f,radius=True)
    txt(s,a,1.22,y+.09,2.25,.31,16,c,True); txt(s,b,3.32,y+.1,2.72,.45,12.5,INK)
    if i<3: line(s,3.64,y+.77,3.64,y+.96,c,1.8,True)
rect(s,7.0,1.55,4.9,2.15,WHITE,radius=True)
txt(s,"训练侧",7.28,1.73,1.15,.3,16,WINE,True)
txt(s,"Robot Lab 提供 Go2-W 环境\nLocoFormer 接入 policy / PPO / TXL\n输出 checkpoint 与可复现实验记录",7.3,2.18,4.2,1.15,14,INK)
line(s,9.45,3.85,9.45,4.35,WINE,2,True)
rect(s,7.0,4.45,4.9,1.35,GREEN,radius=True)
txt(s,"部署侧",7.28,4.63,1.15,.3,16,GREEN_DARK,True)
txt(s,"Unitree SDK2 读取状态 / 下发命令\n中间由 Go2-W adapter 做映射与约束",8.3,4.58,3.25,.76,13.5,INK)
txt(s,"MuJoCo 用于模型与控制约定交叉核对；主训练路线保持在 Isaac Sim / Isaac Lab / Robot Lab。",1.02,6.15,11.15,.44,13,MUTED,True)
footer(s, 11, "版本路线：Isaac Sim 5.1 + Isaac Lab 2.3.2 + Robot Lab 2.3.2；需先做兼容性安装验证")

# 12. Server
s = base("十一、服务器判断：适合做分阶段复现，不等于论文训练规模")
facts=[("GPU","2 × RTX PRO 5000 Blackwell\n单卡约 48 GiB 显存"),
       ("CPU / RAM","96 逻辑 CPU\n约 251 GiB RAM"),
       ("系统 / 磁盘","Ubuntu 22.04.5\n约 445 GiB 可用磁盘"),
       ("环境状态","Conda 隔离环境已建\nIsaac 仿真栈尚未完整部署")]
for i,(a,b) in enumerate(facts):
    x=.85+(i%2)*3.0; y=1.55+(i//2)*1.35
    card(s,x,y,2.72,1.08,a,b,[BLUE,GREEN,GOLD_LIGHT,WINE_LIGHT][i],[BLUE_DARK,GREEN_DARK,GOLD,WINE][i],15.5,12.5)
rect(s,7.15,1.55,4.98,3.2,WHITE,radius=True)
txt(s,"能力边界",7.43,1.8,1.35,.32,17,WINE,True)
txt(s,"适合：\n• Isaac Sim / Go2-W 基线\n• 小到中等规模 PPO 与 TXL 验证\n• 少量多本体与消融实验\n\n不能直接等同：\n• 论文最大规模训练\n• 与多 GPU 大规模数据吞吐相同",7.45,2.27,4.24,2.18,14,INK)
rect(s,.85,4.52,5.72,1.03,GOLD_LIGHT,radius=True)
txt(s,"论文补充材料给出 32 / 64 / 128 GPU 规模对比。\n两张 GPU 的显存不可简单合并成一张 96 GiB 卡。",1.05,4.69,5.25,.62,13,INK,True)
txt(s,"Isaac Sim 5.1 与 Isaac Lab 2.3.2 的版本选择基于规划中的兼容路线；NVIDIA 文档将 5.1 标为不再提供新功能 / 修复的版本，安装前应固定并记录具体依赖。",.95,5.97,11.1,.62,11.7,MUTED)
footer(s, 12, "服务器核查：2026-11-06；算力规模来源：LocoFormer Supplementary Material")

# 13. Plan
s = base("十二、工作计划：按依赖关系逐层搭建")
phases=[
    ("A  平台基线","安装并锁定仿真栈；加载 Go2-W；确认场景、关节、轮子与步进。","阶段门：模型可稳定复现",BLUE,BLUE_DARK),
    ("B  单本体 PPO","先跑 Go2-W 速度控制任务，记录观测、动作、奖励、训练曲线与 checkpoint。","阶段门：可重复 baseline",GREEN,GREEN_DARK),
    ("C  统一 I/O + TXL","逐字段定状态合同、槽位、mask、动作解码；接入分段缓存与跨 Trial PPO。","阶段门：保存/清空历史对照",GOLD_LIGHT,GOLD),
    ("D  多本体 + 留出测试","筛选身体资产；按整台机器人划分 train/test；最后迁移 Go2-W 实机。","阶段门：跨身体结果可比较",WINE_LIGHT,WINE),
]
for i,(a,b,c,f,accent) in enumerate(phases):
    y=1.45+i*1.24
    rect(s,.88,y,.62,.62,accent,radius=True); txt(s,str(i+1),.98,y+.1,.42,.42,16,WHITE,True,PP_ALIGN.CENTER)
    rect(s,1.67,y,10.46,.88,f,radius=True)
    txt(s,a,1.9,y+.1,2.2,.32,15.3,accent,True)
    txt(s,b,4.08,y+.08,5.35,.56,12.1,INK)
    txt(s,c,9.6,y+.12,2.27,.52,11.4,INK,True)
txt(s,"依赖顺序不能倒置：I/O 与单体闭环未验收前，不宜用多本体结果判断网络结构优劣。",1.0,6.55,11,.34,13.2,WINE,True)
footer(s, 13, "详细交付物、验收门槛与风险对策见《复现工作计划与验收标准》")

# 14. Experimental validation
s = base("十三、验收重点：每个核心主张都要有对照实验")
tests=[
    ("I/O 正确性","通道映射、方向、单位、归一化与 mask 单元检查；仿真与 SDK 逐字段对齐。",BLUE,BLUE_DARK),
    ("跨 Trial 记忆","相同任务分别保留 / 清空历史；比较跌倒后恢复时间、失败率与目标位移。",GREEN,GREEN_DARK),
    ("跨本体泛化","整机留出，而非同一机器人换随机种子；报告未见身体结果及方差。",GOLD_LIGHT,GOLD),
    ("训练效率与复现性","记录吞吐、GPU 显存、环境数、训练步数、种子、配置、代码版本与 checkpoint。",WINE_LIGHT,WINE),
]
for i,(a,b,f,c) in enumerate(tests):
    x=.85+(i%2)*5.95; y=1.55+(i//2)*2.05
    card(s,x,y,5.58,1.68,a,b,f,c,16.3,13.2)
rect(s,.85,5.9,11.55,.64,WHITE,radius=True)
txt(s,"指标至少包括：目标方向位移 / 速度误差、任务完成率、跌倒率、扰动恢复时间、推理延迟；对照必须使用相同任务与预算。",1.06,6.0,11.1,.42,12.8,INK,True)
footer(s, 14, "论文基准指标与本项目工程验收指标应分别报告，不直接混用")

# 15. Closing / next steps
s = base("结论：先建立可检验的 Go2-W 基线，再逐步复现论文机制")
summary=[
    ("论文主张","多样身体强化学习 + 统一关节表示 + TXL 跨 Trial 适应。",BLUE,BLUE_DARK),
    ("项目难点","同一网络并不自动解决本体差异；槽位、mask、单位和动作映射必须明确。",GREEN,GREEN_DARK),
    ("可借资源","Robot Lab / BabyLocoFormer / GenBot / URMA / SDK2 各自补不同环节，不存在可直接拼装的完整包。",GOLD_LIGHT,GOLD),
]
for i,(a,b,f,c) in enumerate(summary):
    y=1.55+i*1.22; card(s,.95,y,7.45,.96,a,b,f,c,15.5,13)
rect(s,8.85,1.55,3.22,3.42,WINE,radius=True)
txt(s,"下一步",9.12,1.86,2.65,.45,21,WHITE,True,PP_ALIGN.CENTER)
txt(s,"1  固定软件版本\n2  启动 Go2-W 仿真基线\n3  做通 I/O 与 PPO\n4  再接 TXL / 跨 Trial\n5  扩展多本体与实机",9.15,2.52,2.62,1.93,14,WHITE,True)
rect(s,.95,5.48,11.12,.78,WHITE,radius=True)
txt(s,"阶段性结论标准",1.2,5.67,1.83,.32,14.5,WINE,True)
txt(s,"先报告已复现的机制与证据；未完成的多本体训练和实机评测明确列为计划，不提前宣称完整复现。",3.1,5.6,8.65,.48,13.6,INK,True)
footer(s, 15, "核心技术依据与逐问答索引见随附复现资料")

OUT.parent.mkdir(parents=True, exist_ok=True)
prs.save(OUT)
print(f"saved={OUT} slides={len(prs.slides)} bytes={OUT.stat().st_size}")
