import fs from 'node:fs/promises';
import {pathToFileURL} from 'node:url';
process.env.RUNTIME_NODE_MODULES='C:/Users/laiyo/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules';
const skill='C:/Users/laiyo/.codex/plugins/cache/openai-primary-runtime/presentations/26.1105.12137/skills/presentations';
const root='G:/毕设/02_learning/locoformer/go2_reproduction/.build/go2w_presentation';
const finalPath='G:/毕设/02_learning/04_review/deliverables/locoformer/go2w_reproduction_workplan.CN.pptx';
const candidatePath=`${root}/workplan_candidate.pptx`;
try { await fs.access(finalPath); await fs.copyFile(finalPath,candidatePath); await fs.unlink(finalPath); } catch(e) { if(e.code!=='ENOENT') throw e; }
const {finalizePresentation}=await import(pathToFileURL(`${skill}/container_tools/artifact_tool_utils.mjs`).href);
const result=await finalizePresentation({
  workspaceDir:'G:/毕设',candidatePath,finalPath,
  pythonExecutable:'C:/Users/laiyo/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe',
  integrityValidatorPath:`${skill}/container_tools/inspect_presentation_package_integrity.py`,
  layoutValidatorPath:`${skill}/container_tools/inspect_presentation_layout_geometry.py`,
  layoutArgs:['--expected-slide-size-emu','12191695,6858000','--validate-heading-fit','--cover-role','none'],
  explicitTotalSlideCount:14,
  requiredNativeTableOwnerSlides:[],
  fontPolicy:{basis:'design',families:['Microsoft YaHei']},
  verifyArtifactToolImport:true,
  receiptPath:`${root}/workplan_validation.json`,
});
console.log(JSON.stringify(result));
