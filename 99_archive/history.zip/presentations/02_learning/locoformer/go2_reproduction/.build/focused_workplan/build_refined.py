from pathlib import Path
P=Path(__file__).parent
concise_src=(P/'build_concise.py').read_text(encoding='utf-8')
exec(concise_src.split('\n# 1\n',1)[0])
TOTAL=10
OUT=P/'reporting_candidate.pptx'

def reuse(a,b):exec(concise_src.split(a,1)[1].split(b,1)[0],globals())

# 1 Goal
reuse('# 1\n','# 2 Hardware:')

# 2 Hardware overview, preserve the corrected anatomy
hardware=concise_src.split('# 2 Hardware:',1)[1].split('# 3 SDK-to-policy',1)[0]
hardware='\n'.join(hardware.splitlines()[1:])
hardware=hardware.replace("'4 前部感知与本体状态','相机、3D LiDAR；IMU与电机反馈构成首版观测'","'4 前部感知','广角相机与 3D LiDAR；IMU位于机身内部'")
hardware=hardware.replace("约 18 kg，70 × 43 × 50 cm\\n7 英寸轮胎，标称速度 0–2.5 m/s","约 18 kg，70 × 43 × 50 cm；7 英寸轮胎\\n8 核 CPU，33.6 V / 15 Ah；标称速度 0–2.5 m/s")
exec(hardware)

# 3 All motor channels in a four-leg matrix
s=base('16 路驱动与统一槽位、SDK 通道的对应关系')
txt(s,'每格为“候选槽位 / SDK编号”；行与列共同确定关节驱动，编号从 0 开始。',.96,1.3,11.45,.42,16,INK)
table(s,['腿 / 电机组','hip 外展/内收','thigh 大腿俯仰','calf 膝部屈伸','wheel 轮驱动'],[
('FR 右前','0 / 0','1 / 1','2 / 2','12 / 12'),
('FL 左前','3 / 3','4 / 4','5 / 5','13 / 13'),
('RR 右后','6 / 6','7 / 7','8 / 8','14 / 14'),
('RL 左后','9 / 9','10 / 10','11 / 11','15 / 15')],[2.0,2.35,2.4,2.4,2.35],1.95,.66,16)
txt(s,'读取',.98,5.27,1.05,.36,17,WINE,True)
txt(s,'LowState.motor_state[i]：q、dq、估计力矩、温度等反馈',2.3,5.22,9.95,.47,15,INK)
txt(s,'控制',.98,5.92,1.05,.36,17,WINE,True)
txt(s,'LowCmd.motor_cmd[i]：腿发送 q 目标；轮发送 dq 目标并设置 kp = 0',2.3,5.84,9.95,.56,15,INK)
takeaway(s,'槽位是项目定义，SDK编号是设备协议；按模型关节名建立映射，不依赖导入顺序。',6.55)
finish('01  Go2-W硬件与SDK','这一页把16路驱动全部对应起来。每条腿有hip、thigh、calf，四个车轮编号为12到15。候选槽位采用相同数值，便于原型检查，但不能把两者视为同一概念。例如FR_hip_joint对应槽位0，读取motor_state[0]并写入motor_cmd[0]；FR_foot_joint为右前轮，对应12。所有电机反馈来自LowState，命令由LowCmd发布。q、dq、tau、kp、kd等字段存在，首版腿采用位置、轮采用速度。表中编号为控制通道，不能推断实体电机型号或共同扭矩。',URDF+'\n'+SDK+'\nhttps://github.com/unitreerobotics/unitree_sdk2_python/blob/master/example/go2w/low_level/unitree_legged_const.py')

# 4 Capability boundaries are made explicit
s=base('SDK 能力与采用范围：低层控制为主，感知独立接入')
table(s,['硬件 / 功能','可获取的数据','SDK入口与控制能力','本项目采用'],[
('电机','q、dq、估计力矩、温度','LowState / LowCmd\n位置、速度、力矩及增益字段','腿位置 + 轮速度\n核对目标与反馈'),
('IMU','姿态、角速度、加速度','LowState.imu_state\n状态读取','构造角速度与投影重力'),
('相机','返回码、编码图像','VideoClient.GetImageSample()\nGo2系列取帧参考接口','验证Go2-W服务后记录\n首版不作为策略输入'),
('LiDAR','点云；其他量依型号','对应型号SDK / 点云驱动\n配置能力按实际型号','设备识别与场景记录\n不经LowCmd接入'),
('模式 / 运动服务','控制模式与服务返回','CheckMode / ReleaseMode\nSportClient为厂商高层控制','管理控制权\n与低层策略分开'),
('电源 / 遥控','BMS、电压电流、遥控字节','LowState.bms_state\nwireless_remote等字段','状态记录\n按协议解析输入')],[1.45,2.65,4.1,3.3],1.48,.73,13.1)
takeaway(s,'先只读采集，再影子推理，最后闭环；视频与雷达的设备支持分别核对。',6.56)
finish('01  Go2-W硬件与SDK','SDK能力分为低层消息、服务调用和独立感知驱动。电机和IMU使用LowState，腿轮控制使用LowCmd；模式服务管理控制权，高层SportClient不能代替学得策略的关节执行。相机接口来自官方Go2示例，要在Go2-W验证；公开例程只证明取帧接口，不推定曝光或云台控制。雷达驱动必须匹配型号，L1 SDK不能直接用于未知型号。电源和遥控字段可记录，但消息存在不等于电源可远程控制。首版依赖IMU与关节反馈，感知记录独立推进。',SDK+'\nhttps://github.com/unitreerobotics/unitree_sdk2_python/blob/master/example/go2/front_camera/camera_opencv.py\nhttps://github.com/unitreerobotics/unilidar_sdk')

# 5 What to reproduce, verify and reuse
s=base('参考项目按采用方式分工，先建立基线再完善核心机制')
table(s,['采用方式','项目与可用内容','后续工作与验证'],[
('优先复现','Robot Lab：Go2-W任务、PPO','原任务训练并重载，形成单体与算力基线'),
('复验 / 移植','Baby：序列训练；lucidrains：TXL核心','复验重置与更新，再移植核心并检查因果'),
('设计 / 条件对照','MetaMorph / GenLoco：接口设计\nURMA：逐关节表示','先固定槽位；拓扑覆盖困难时再对照URMA'),
('资产复用','GenBot-1K：多本体生成与资产','筛选身体、统一任务，补轮足与模型检查'),
('部署参考','SDK2 / rl_sar：协议与部署组织','自建观测/动作适配、历史运行与周期管理')],[1.6,4.8,5.1],1.48,.84,13.2)
takeaway(s,'需要完善的是统一接口、任务与缓存边界、序列PPO及状态化部署；算法优化后置。',6.56)
finish('02  项目采用与改造','并非所有项目都要完整复现。Robot Lab单体任务优先复现，为主线提供基准。Baby做专项复验，重点核查重置、缓存和实际更新次数；若旧依赖成本过高，可在主管线用最小序列样例验证其接入思路。lucidrains按模块移植。MetaMorph和GenLoco借鉴设计，URMA仅在结构差异较大时对照。GenBot只取合格资产，不复制其蒸馏路线。SDK2和rl_sar参考协议和部署组织。工程机制可靠后再单独提出算法优化。',LAB+'\n'+BABY+'\n'+LOCAL+'\n'+GEN+'\n'+URMA+'\n'+SDK)

# 6 Interface decision, retain the compact comparison
reuse('# 5 Decision, contrast and concrete prototype on a single page','# 6 Method and compute')

# 7 Strategy, training and compute are one coherent route
reuse('# 6 Method and compute constrain the plan','# 7 reference, implementation')

# 8 Baseline and interface gates
s=base('阶段 1–3：平台验收、基线复现、共享接口验证')
table(s,['阶段与前置','参考与实施','验证与阶段产物'],[
('1 平台准备\n实施起点','Robot Lab + 官方URDF/SDK\n核对16通道与状态、动作字段','单环境与逐通道检查\n输出模型/SDK映射和观测表'),
('2 基线复现\n平台通过','运行Robot Lab Go2-W原任务\n训练、重载并测资源占用','固定指令评估与吞吐测量\n输出基线权重和评估记录'),
('3 统一接口\n基线可重载','参考MetaMorph / GenLoco\n实现16槽位，加入普通四足','映射、缺失位、原接口往返\n重新训练并评估共享策略')],[2.2,4.9,4.4],1.75,1.2,14.1)
txt(s,'推进条件',.98,6.07,1.5,.35,17,WINE,True)
txt(s,'每阶段保留配置与结果；接口检查通过后再接入历史，避免同时更改多个环节。',2.8,5.98,9.3,.65,15.5,INK)
finish('04  工作计划','前三阶段逐项形成下一步的输入。先完成平台验收，得到模型和SDK映射；再优先复现原Go2-W单体任务，取得可重载权重和算力记录；随后才实现固定槽位与共享策略。接口先做静态映射、缺失位和原接口往返检查，新73维输入层另行训练。共享策略逐身体评估，不以加载成功或单个视频代替控制结果。')

# 9 Core method, asset qualification and deployment in order
s=base('阶段 4–6：历史机制、多本体泛化与实机闭环')
table(s,['阶段与前置','参考与改造','验证与阶段产物'],[
('4 历史训练\n共享接口通过','lucidrains核心 + Baby专项复验\n补任务边界、缓存及序列PPO','因果/分段一致性、实际更新次数\n保留/清空历史，输出适应曲线'),
('5 多本体\n历史机制通过','筛选GenBot资产并统一任务\n冻结正式接口，必要时对照URMA','逐身体模型检查、完整身体留出\n输出共享权重和多种子指标'),
('6 实机闭环\n仿真与映射通过','SDK2协议 + rl_sar部署参考\n实现观测/动作转换、约束与运行器','只读 → 影子 → 受约束执行\n输出命令/反馈、周期和异常记录')],[2.2,4.9,4.4],1.75,1.2,13.9)
txt(s,'并行与范围',.98,6.07,1.6,.35,17,WINE,True)
txt(s,'硬件只读与资料核对可提前；运动执行依赖仿真验收，论文性能与工程打通分别报告。',2.85,5.98,9.25,.65,15.5,INK)
finish('04  工作计划','第四阶段将历史网络、采集、存储与PPO一起改造，先查正确性，再比较历史的作用。第五阶段以资产合格和接口冻结为前置条件，按完整身体留出检验泛化，避免把仅更换随机种子当成未见身体。第六阶段参考SDK协议和部署组织，自己实现状态化运行器，从只读到影子再到受约束闭环。当前阶段的完善以工程正确性为主，论文最终性能另作对齐。')

# 10 Evaluation and immediate work
reuse('# 9 summarize the decision criteria and the immediate next work','assert len(prs.slides)==TOTAL')

assert len(prs.slides)==TOTAL
from pptx.oxml.xmlchemy import OxmlElement
for slide in prs.slides:
    for tag in ('a:rPr','a:defRPr','a:endParaRPr'):
        for rp in slide._element.xpath('.//'+tag):
            for kind in ('latin','ea','cs'):
                nodes=rp.findall('{http://schemas.openxmlformats.org/drawingml/2006/main}'+kind)
                e=nodes[0] if nodes else OxmlElement('a:'+kind)
                if not nodes:rp.append(e)
                e.set('typeface',FONT)
prs.save(OUT)
print(f'Saved refined deck: {len(prs.slides)} slides')
