from pathlib import Path
P=Path(__file__).parent
original=(P/'build_focused.py').read_text(encoding='utf-8')
exec(original.split('\n# 01\n',1)[0])
TOTAL=9
OUT=P/'reporting_candidate.pptx'
import json
TASKS=json.loads((ROOT/'.build/reporting_plan.json').read_text(encoding='utf-8'))

def finish(section,speech,sources=''):
    footer(s,section,speech,sources)

# 1
s=base()
rect(s,.84,1.8,.065,3.55,WINE)
txt(s,'LocoFormer 复现工作计划',1.17,1.95,10.8,.8,36,INK,True)
txt(s,'Go2-W 平台与技术路线',1.2,3.02,10.6,.48,24,WINE,True)
txt(s,'建立单体基线，验证跨本体与长历史机制，完成实机验证。',1.21,4.13,10.8,.65,19,INK)
txt(s,'资料调研与方案规划阶段',1.21,6.3,10.7,.35,14,MUTED)
finish('复现工作计划','本次汇报聚焦复现方案。目标是在现有资源基础上，先建立Go2-W单体基线，再接入统一接口与长历史训练，扩展到不同身体，最终完成Go2-W实机验证。下面先说明平台和可复用资源，再介绍技术选择及阶段安排。目前工作处于资料调研和方案规划阶段。')

# 2 Hardware: one image, direct control requirements
s=base('Go2-W 平台：12 路腿部驱动与 4 路车轮驱动')
pic=s.shapes.add_picture(str(P/'go2w_front.png'), Inches(.85), Inches(1.45), width=Inches(5.2),height=Inches(5.2))
pic.crop_left=pic.crop_right=pic.crop_top=pic.crop_bottom=.08
def marker(n,x,y):
    o=s.shapes.add_shape(MSO_SHAPE.OVAL,Inches(x-.15),Inches(y-.15),Inches(.3),Inches(.3))
    o.fill.solid();o.fill.fore_color.rgb=rgb(WINE);o.line.color.rgb=rgb(WHITE)
    txt(s,str(n),x-.13,y-.13,.26,.26,10,WHITE,True,PP_ALIGN.CENTER,margin=0)
# Positions transformed from the audited full-image annotation.
marker(1,3.26,2.93);marker(2,2.81,3.85);marker(3,5.18,5.04);marker(4,4.56,3.08)
items=[('1 近端腿部电机组','每腿 3 路驱动，控制外展、大腿俯仰与膝屈伸'),('2 膝关节转轴','关节运动位置，与电机安装区域区分'),('3 轮端驱动','每腿 1 个独立驱动轮，采用轮速目标'),('4 前部感知与本体状态','相机、3D LiDAR；IMU与电机反馈构成首版观测')]
for i,(a,b) in enumerate(items):
    yy=1.58+i*1.03
    txt(s,a,6.55,yy,5.65,.35,18,WINE,True)
    txt(s,b,6.55,yy+.42,5.65,.55,15,INK)
txt(s,'约 18 kg，70 × 43 × 50 cm\n7 英寸轮胎，标称速度 0–2.5 m/s',6.55,5.88,5.65,.65,13.5,MUTED)
finish('01  平台与接口','Go2-W每条腿包含三个腿部自由度和一个驱动轮，总共16路主动通道。图中分别标出近端电机组、膝转轴和轮端驱动，近端布局依据现场说明，不把膝转轴当作电机安装位置。对策略而言，最重要的是腿部位置与车轮速度两种动作，以及IMU和关节反馈。相机和雷达先用于记录，暂不加入首版策略。由此可以确定接下来的SDK适配范围。',PRODUCT+'\n'+URDF)

# 3 SDK-to-policy path, no peripheral implementation detail
s=base('SDK 接入形成“状态—策略—命令—反馈”闭环')
steps=[('状态读取','rt/lowstate\nIMU、q、dq',BLUE),('观测与推理','重排、归一化\n策略与历史缓存',GREEN),('动作适配','12 路腿位置\n4 路轮速',GOLD_LIGHT),('命令发布','LowCmd、CRC\nrt/lowcmd',WINE_LIGHT)]
for i,(a,b,c) in enumerate(steps):
    x=.9+i*3.12;node(s,a,x,1.7,2.7,.65,c,18)
    txt(s,b,x,2.57,2.7,.8,16,INK,align=PP_ALIGN.CENTER)
    if i<3:arrow(s,x+2.76,2.03,x+3.04,2.03)
table(s,['已有接口','本项目适配工作','验证顺序'],[
('LowState：IMU与电机反馈','与训练一致的观测字段、坐标和缩放','只读采集，核对状态与周期'),
('LowCmd：腿 q、轮 dq','关节映射、动作解码、约束与控制模式','影子推理，再检查命令与反馈')],[3.2,5.1,3.2],3.75,.81,14.2)
takeaway(s,'SDK 提供通信；观测转换、历史推理与动作适配由本项目实现。',6.45)
finish('01  平台与接口','官方Go2-W示例已经给出低层状态和命令协议。我们需要在两者之间补齐自己的处理：把反馈变成训练时的观测，运行带历史的策略，再将动作解码为腿位置和轮速。SDK通道和仿真关节通过显式映射关联。验证按只读采集、影子推理和闭环执行推进，先检查数据与命令含义，再判断任务效果。下一步是确定这些工作可以参考哪些项目。',SDK)

# 4 Sources organized by ownership, only consequential limitations
s=base('参考项目提供组件，本项目负责集成与验证')
table(s,['任务','参考项目与已有能力','本项目工作'],[
('仿真基线','Robot Lab：Go2-W任务、混合动作与PPO','核对模型，建立可重载的单体基线'),
('历史训练','lucidrains：TXL核心；Baby：序列训练接入','补任务边界、缓存与PPO更新验证'),
('统一接口','MetaMorph / GenLoco：形态与控制配置\nURMA：逐关节表示','固定槽位为主，逐关节方案作对照'),
('身体资产','GenBot-1K：多本体资产与生成方法','筛选资产，统一任务并补轮足变体'),
('实机部署','SDK2 / rl_sar：通信、映射与部署组织','实现历史策略运行、动作约束及日志')],[1.65,5.25,4.6],1.5,.86,13.8)
takeaway(s,'尚未获得作者完整训练工程与权重；第三方实现需审查，不能直接视为论文复现。',6.55)
finish('02  参考项目与选型','现有资料按任务分工。Robot Lab用于建立Go2-W基线。lucidrains参考历史网络核心，Baby参考采集、存储和PPO的连接，但Baby的重置和更新循环需要检查。MetaMorph和GenLoco提供接口设计依据，URMA留作结构对照。GenBot提供经筛选的身体资产，SDK2与rl_sar提供部署参考。整体在一套主训练管线中集成，避免把不同项目全部混装。',LAB+'\n'+LOCAL+'\n'+BABY+'\n'+GEN+'\n'+URMA+'\n'+SDK)

# 5 Decision, contrast and concrete prototype on a single page
s=base('接口选择：首版固定槽位，先覆盖四足与轮足')
table(s,['路线','输入与输出组织','采用范围'],[
('固定语义槽位','同一位置含义固定，按映射取有效动作','首版采用，便于逐通道验证'),
('URMA逐关节表示','状态与结构描述共享编码，逐关节解码','结构差异扩大后的对照'),
('本地多编码器','选择输入编码器及预定义动作组','仅参考核心模块，不作为主接口')],[2.5,5.6,3.4],1.5,.75,14.1)
txt(s,'首版原型',.98,4.65,1.65,.37,18,WINE,True)
txt(s,'16 槽位：12 个腿关节 + 4 个轮通道\n普通四足轮通道无效；Go2-W 全部有效。',2.85,4.53,9.3,.86,16,INK)
txt(s,'73 维候选观测；16 路动作分别解码为腿位置和轮速。',2.85,5.55,9.3,.5,15,INK)
takeaway(s,'原型先验证接口与共享控制；扩大身体集合前审查覆盖范围，冻结正式接口。',6.52)
finish('03  技术路线','三种接口分别统一语义槽位、逐关节处理规则和内部特征宽度。首版选择固定槽位，因为普通四足与Go2-W的腿部对应明确，轮通道能单独处理。候选原型为16槽位和73维观测，普通四足轮通道置为无效，Go2-W轮位置按任务置零但轮速有效。无效通道同时在执行和相应训练项中处理。这是项目设计，不是论文原始配置。新增编码层需要训练，原57维权重不能按原形状直接装入。',URMA+'\n'+LOCAL+'\nhttps://github.com/agrimgupta92/metamorph\nhttps://github.com/HybridRobotics/GenLoco')

# 6 Method and compute constrain the plan
s=base('训练路线：单体 PPO 基线，逐步接入共享策略与长历史')
labels=[('MLP 单体基线',BLUE),('统一接口与共享控制',GREEN),('TXL 与跨 Trial',WINE_LIGHT)]
for i,(a,c) in enumerate(labels):
    x=.95+i*4.1;node(s,a,x,1.65,3.5,.68,c,17)
    if i<2:arrow(s,x+3.58,1.99,x+4.0,1.99)
table(s,['关键改造','实施要求'],[
('历史与序列训练','同任务跨 Trial 保留历史；任务切换清空；核查因果与更新次数'),
('主软件栈','Isaac Lab / Robot Lab 2.3.2；独立 Conda；先验证版本兼容'),
('计算预算','2 × RTX PRO 5000，各约48 GiB；先单卡测吞吐、显存与优化耗时')],[2.55,8.95],3.1,.82,14.3)
takeaway(s,'接口、历史与身体规模分步增加，每一步保留前一阶段作为对照。',6.5)
finish('03  技术路线','训练从原Go2-W的MLP基线开始，统一接口检查完成后再训练共享模型，最后增加TXL和跨Trial。历史改造同时涉及缓存、序列存储和PPO，不能只替换网络类。候选软件为Isaac Sim5.1配套Isaac Lab和Robot Lab2.3.2，旧版本与Blackwell兼容性首先验证。服务器已有记录为两张各约48GiB显卡，先单卡实测吞吐、优化和显存，再决定并行数与多卡规模，不预先承诺论文最大训练预算。',LAB+'\n'+LOCAL+'\n'+BABY)

# 7 reference, implementation and verification in the same table
s=base('阶段 1–3：完成平台、基线与统一接口')
table(s,['阶段','参考依据','实施工作','完成判断'],[
('1 平台准备','Robot Lab\n官方URDF / SDK2','启动模型，建立关节与SDK映射','逐通道与状态字段核对'),
('2 单体基线','Go2-W任务\nRSL-RL / PPO','保留原配置训练，记录资源占用','固定指令重载评估'),
('3 统一接口','MetaMorph / GenLoco\n本项目槽位定义','16槽位原型，加入普通四足','映射、缺失位和共享控制检查')],[1.85,3.2,3.5,2.95],1.75,1.15,14)
txt(s,'阶段交付',.98,6.02,1.5,.36,17,WINE,True)
txt(s,'可重载单体基线、观测/动作规范、逐机器人映射与共享控制结果。',2.8,5.94,9.3,.65,16,INK)
finish('04  工作计划','前三阶段先减少平台与接口的不确定性。第一阶段核对模型和SDK通道，硬件可只读检查。第二阶段用原任务训练并重载评估，形成控制与算力基线。第三阶段实现固定槽位，先检查原接口往返和缺失位，再训练新输入层及两身体共享策略。这样后续引入历史时，可以判断问题来自接口还是记忆。')

# 8 core method and deployment gates
s=base('阶段 4–6：验证历史适应，扩展身体并接入实机')
table(s,['阶段','参考依据','实施工作','完成判断'],[
('4 长历史','lucidrains：TXL\nBaby：序列训练','补缓存边界与序列PPO','推理一致性\n保留 / 清空历史对照'),
('5 多本体','GenBot-1K\n论文随机化思路','审查资产与正式接口，扩大训练','完整身体留出、多种子评估'),
('6 实机验证','SDK2协议\nrl_sar部署组织','观测/动作适配与受约束执行','只读、影子、命令与反馈闭环')],[1.85,3.2,3.5,2.95],1.75,1.15,14)
txt(s,'阶段依赖',.98,6.02,1.5,.36,17,WINE,True)
txt(s,'先验证接口和历史机制，再扩大训练；硬件只读可并行，运动执行依赖仿真验收。',2.8,5.94,9.3,.65,16,INK)
finish('04  工作计划','第四阶段先检查逐步与分段推理、因果性、缓存重置和PPO实际更新，再比较历史效果。第五阶段筛选多本体资产，确认原型槽位是否需要扩展，冻结正式接口后训练，并以完整身体留出测试泛化；URMA仅在结构表达困难时独立比较。第六阶段依据SDK协议接入真实状态与动作，从只读和影子推理开始，再进行受约束闭环。')

# 9 summarize the decision criteria and the immediate next work
s=base('验收重点与首批任务')
table(s,['验证目标','主要指标与证据'],[
('基础控制','速度跟踪误差、跌倒率、保存重载一致性'),
('历史适应','相同任务与预算下的恢复时间、各 Trial 表现'),
('跨本体泛化','训练内与完整留出身体分别报告，记录种子间差异'),
('实机闭环','带时间戳的观测、动作、命令与反馈，以及控制时延')],[3.1,8.4],1.5,.78,15)
line(s,.98,5.5,12.3,5.5,LINE,1)
txt(s,'首批任务',.98,5.8,1.6,.4,18,WINE,True)
txt(s,'完成环境兼容与Go2-W模型检查，取得可重载基线和吞吐记录，\n据此确定后续训练规模与日程。',2.85,5.7,9.4,.85,17,INK)
finish('工作安排','最后以四类证据报告进展。控制基线关注速度误差和跌倒率，历史适应比较相同条件下的恢复与后续Trial表现，跨本体采用完整身体留出，实机用输入命令反馈和时延支持结论。当前首批任务是环境兼容、模型检查和Go2-W基线，不同时启动所有模块改造。取得吞吐与基线后，再细化训练规模和时间安排。')

assert len(prs.slides)==TOTAL
from pptx.oxml.xmlchemy import OxmlElement
for slide in prs.slides:
    for tag in ('a:rPr','a:defRPr','a:endParaRPr'):
        for rp in slide._element.xpath('.//'+tag):
            for kind in ('latin','ea','cs'):
                nodes=rp.findall('{http://schemas.openxmlformats.org/drawingml/2006/main}'+kind)
                e=nodes[0] if nodes else OxmlElement('a:'+kind)
                if not nodes:rp.append(e)
                e.set('typeface',FONT)
prs.save(OUT)
print(f'Saved concise deck: {len(prs.slides)} slides')
