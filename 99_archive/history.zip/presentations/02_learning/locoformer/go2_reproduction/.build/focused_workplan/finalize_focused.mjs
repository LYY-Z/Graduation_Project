import fs from 'node:fs/promises';
import {pathToFileURL} from 'node:url';
process.env.RUNTIME_NODE_MODULES='C:/Users/laiyo/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules';
const skill='C:/Users/laiyo/.codex/plugins/cache/openai-primary-runtime/presentations/26.1105.12137/skills/presentations';
const root='G:/毕设/02_learning/locoformer/go2_reproduction/.build/focused_workplan';
let finalPath='G:/毕设/02_learning/04_review/deliverables/locoformer/go2w_reproduction_brief.refined.CN.pptx';
const candidatePath=`${root}/reporting_candidate.pptx`;
try {
  await fs.copyFile(finalPath,`${root}/report_before_alignment.pptx`);
  await fs.unlink(finalPath);
} catch(e) {
  if(e.code==='EPERM'||e.code==='EBUSY'||e.code==='EACCES') {
    finalPath=finalPath.replace('.CN.pptx','.revised.CN.pptx');
    try { await fs.unlink(finalPath); } catch(inner) { if(inner.code!=='ENOENT') throw inner; }
  } else if(e.code!=='ENOENT') throw e;
}
const {finalizePresentation}=await import(pathToFileURL(`${skill}/container_tools/artifact_tool_utils.mjs`).href);
const result=await finalizePresentation({
  workspaceDir:'G:/毕设',candidatePath,finalPath,
  pythonExecutable:'C:/Users/laiyo/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe',
  integrityValidatorPath:`${skill}/container_tools/inspect_presentation_package_integrity.py`,
  layoutValidatorPath:`${skill}/container_tools/inspect_presentation_layout_geometry.py`,
  layoutArgs:['--expected-slide-size-emu','12191695,6858000','--validate-heading-fit','--cover-role','none'],
  explicitTotalSlideCount:10,
  requiredNativeTableOwnerSlides:[],
  fontPolicy:{basis:'design',families:['Microsoft YaHei']},
  verifyArtifactToolImport:true,
  receiptPath:`${root}/focused_validation.${Date.now()}.json`,
});
const summary={finalPath:result.finalPath,slideCount:result.firstPartyImport.slideCount,package:result.packageIntegrity.status,findings:result.presentationLayout.findingCount};
await fs.writeFile(`${root}/latest_report.json`,JSON.stringify(summary,null,2));
console.log(JSON.stringify(summary));


