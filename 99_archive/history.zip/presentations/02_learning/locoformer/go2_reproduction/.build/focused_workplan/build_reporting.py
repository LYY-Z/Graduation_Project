from pathlib import Path
P=Path(__file__).parent
original=(P/'build_focused.py').read_text(encoding='utf-8')
exec(original.split('\n# 01\n',1)[0])
TOTAL=14
OUT=P/'reporting_candidate.pptx'
import json
TASKS=json.loads((ROOT/'.build/reporting_plan.json').read_text(encoding='utf-8'))
SDKROOT='https://github.com/unitreerobotics/unitree_sdk2_python'
REPORT=ROOT/'LocoFormer_Go2W_reproduction_briefing.md'

def note(section,text,sources=''):
    footer(s,section,text,sources)

def card(s,title,body,x,y,w=3.7,h=1.4,fill=WHITE):
    rect(s,x,y,w,h,fill,line=LINE)
    txt(s,title,x+.18,y+.14,w-.36,.36,18,WINE,True)
    txt(s,body,x+.18,y+.62,w-.36,h-.72,14,INK,valign=MSO_ANCHOR.TOP)

# 01 scope
s=base()
rect(s,.82,1.75,.065,3.7,WINE)
txt(s,'LocoFormer 复现工作计划',1.15,1.9,10.9,.75,36,INK,True)
txt(s,'Go2-W 硬件接口、参考实现与实施路线',1.18,2.92,10.7,.55,23,WINE,True)
txt(s,'以 Go2-W 为验证平台，按现有实现确定开发任务与验证方法。',1.19,4.0,10.7,.68,19,INK)
txt(s,'平台与接口介绍    /    参考项目分析    /    实施与验证计划',1.19,5.02,10.7,.4,16,MUTED)
txt(s,'当前阶段：资料调研与方案规划',1.19,6.3,10.7,.32,14,MUTED)
note('复现工作计划','本次汇报重点是后续复现安排。先介绍Go2-W提供哪些状态与控制接口，再说明现有代码能够复用到什么程度，最后给出六阶段计划。目标是在仿真中验证长历史和跨本体机制，再接入Go2-W实机。当前尚未开始环境部署和训练。')

# 02 use the corrected editable hardware annotations
block=original.split('# 02 annotated product image',1)[1].split('# 03 motors',1)[0]
exec(block)

# 03 preserve audited joint data, improve language
block=original.split('# 03 motors and compact platform specs',1)[1].split('# 04 sensors',1)[0]
block=block.replace('模型 effort / 速度','模型力矩上限 / 速度').replace('首版动作定义','策略动作类型')
block=block.replace('表中限值来自 URDF。厂商约 45 N·m 指最大规格电机，实机限幅需独立设置。','关节范围取自 URDF；产品最大电机扭矩约 45 N·m，各通道限制分别设置。')
exec(block)

# 04 hardware-to-SDK mapping
s=base('感知与状态接口：IMU 和电机反馈构成首版输入')
table(s,['硬件','SDK / 数据入口','得到的数据','复现用途'],[
('机身 IMU','LowState.imu_state\n订阅 rt/lowstate','姿态、角速度、加速度','角速度与投影重力'),
('16 路电机','LowState.motor_state[i]\n同一低层状态消息','q、dq、估计力矩等','关节状态与执行反馈'),
('广角相机','VideoClient.GetImageSample()\nGo2 系列官方参考接口','编码图像字节\n需检查返回码和解码','记录场景\nGo2-W 服务待设备验证'),
('3D LiDAR','匹配型号的驱动 / 点云接口\n与 LowState 分开接入','点云及设备时间','环境记录\n后续感知扩展')],[1.6,4.25,2.8,2.85],1.55,.96,13.2)
txt(s,'机载计算与供电',.98,6.04,2.05,.35,15,WINE,True)
txt(s,'8 核 CPU，Orin NX 可选；33.6 V / 15 Ah，标称续航 1.5–3 h。',3.15,6.0,8.98,.45,14,INK)
takeaway(s,'由此确定：阶段 1 采集本体状态，阶段 3 统一观测，阶段 6 接入实机推理。',6.61)
note('01  平台与SDK','首版输入主要依赖两类硬件：IMU和电机反馈。它们由同一条LowState消息提供，程序通过回调保存反馈，再在策略周期内构造观测。相机采用独立服务，官方Go2示例提供VideoClient，但尚未在该台Go2-W上验证。雷达需要按实际型号选择驱动，不能直接从LowState读取点云。接下来说明观测和输出如何连接。',PRODUCT+'\n'+SDKROOT+'/blob/master/example/go2/front_camera/camera_opencv.py\n'+SDK)

# 05 SDK pipeline
s=base('控制接入：状态订阅、策略推理与低层命令发布')
nodes=[('状态订阅','rt/lowstate\nIMU + 16 路 q、dq',BLUE),('观测与策略','重排、归一化\n当前观测 + 历史',GREEN),('动作适配','12 路腿位置\n4 路车轮速度',GOLD_LIGHT),('命令发布','LowCmd + CRC\nrt/lowcmd',WINE_LIGHT)]
for i,(a,b,c) in enumerate(nodes):
    x=.85+i*3.15
    node(s,a,x,1.62,2.7,.65,c,18)
    txt(s,b,x,2.43,2.7,.76,14,INK,align=PP_ALIGN.CENTER)
    if i<3:arrow(s,x+2.73,1.95,x+3.08,1.95)
table(s,['部位','FR 右前','FL 左前','RR 右后','RL 左后'],[
('hip / thigh / calf','0 / 1 / 2','3 / 4 / 5','6 / 7 / 8','9 / 10 / 11'),
('wheel','12','13','14','15')],[2.5,2.25,2.25,2.25,2.25],3.5,.62,13.8)
txt(s,'调用关系',.98,5.6,1.45,.35,16,WINE,True)
txt(s,'ChannelSubscriber.Init(callback) 接收状态；ChannelPublisher.Write(cmd) 发送命令。\nMotionSwitcherClient 管理控制模式；腿填写 q 目标，轮填写 dq 目标并设置 kp = 0。',2.62,5.45,9.55,.9,14,INK)
takeaway(s,'阶段 6 参考此 SDK 调用链，新增观测转换与动作适配，以只读、影子和闭环逐步验证。',6.62)
note('01  平台与SDK','真实状态先按模型约定重排、变换坐标并缩放，再送入策略。网络输出通过独立适配器变成12个腿位置和4个轮速，经过约束后填入LowCmd，计算CRC并发布。表中的索引来自官方Go2-W示例，不能直接用仿真导入顺序替代。控制前检查模式，避免与厂商运动服务同时控制。接口明确后，下一步判断哪些项目可以复用。',SDK+'\n'+SDKROOT+'/blob/master/unitree_sdk2py/comm/motion_switcher/motion_switcher_client.py')

# 06 Locoformer implementations
s=base('现有 LocoFormer 实现可供参考，但尚不能直接复现')
table(s,['项目及定位','已有实现','可复用部分','主要缺口'],[
('lucidrains/locoformer\n第三方 PyTorch 实现','TXL、Actor / Critic、PPO\n多编码器、动作选择器\nMicroduck 示例','历史模型、掩码\n动作概率与更新逻辑','无 Go2-W 完整任务\n编码器由调用者选择\n缺完整跨本体接口'),
('BabyLocoFormer\n非官方 Isaac Lab 工程','四足尺寸生成与随机化\nTXL、自定义 PPO\n训练与评估入口','环境与 runner\nstorage、PPO 的连接','作者报告效果较弱\nreset 为空，需补任务边界\nTXL 多轮更新需核查')],[2.65,3.15,2.65,3.05],1.6,1.6,13.4)
txt(s,'尚未获得的作者复现资料',.98,5.74,3.05,.4,16,WINE,True)
txt(s,'完整训练工程、官方权重、逐机器人关节映射与全部评测配置。',4.05,5.73,8.0,.55,14,INK)
takeaway(s,'阶段 4 参考 lucidrains 的 TXL 和 Baby 的训练集成；缓存及 PPO 更新由本项目验证。',6.55)
note('02  参考项目与选型','两份第三方实现有实际参考价值，但作用不同。lucidrains便于阅读历史网络和强化学习核心，不能提供Go2-W整套环境。Baby接近Isaac Lab训练集成，但作者自述结果较弱，源码中的重置和更新循环也需要独立检查。这里的风险来自静态审查，并非本项目运行结论。计划参考模块，不直接继承它们的性能结论。',LOCAL+'\n'+BABY)

# 07 introduce supporting projects before the plan
s=base('环境、资产与部署项目：已有能力决定复用范围')
table(s,['项目','原项目作用与已有实现','选用理由与后续任务'],[
('Robot Lab','Isaac Lab 的多机器人任务扩展\n包含 Go2-W 观测、12+4 动作及 PPO','具备单体任务，作为阶段 1–2 主环境\n先核对模型，再建立基线'),
('MetaMorph / GenLoco','形态条件策略与跨形态四足控制\n提供有效位、方向和初始化设计','为阶段 3 提供接口设计参考\n本项目补统一槽位与轮速映射'),
('GenBot-1K','生成多种身体，训练专家并蒸馏\n包含资产、转换与身体划分','为阶段 5 提供筛选资产\n统一任务，补轮足变体，不沿用蒸馏'),
('SDK2 / rl_sar','设备通信与策略部署\n提供消息、通道、模式与配置','为阶段 6 提供协议和部署参考\n本项目编写历史策略运行与适配')],[2.35,4.6,4.55],1.55,1.0,13.6)
takeaway(s,'现有项目提供组件；本项目负责将模型、接口、历史训练和实机执行连接并验证。',6.58)
note('02  参考项目介绍','在介绍LocoFormer相关代码之后，这页说明外围项目。Robot Lab的优势是已有Go2-W任务，因此先用它建立基线。MetaMorph和GenLoco提供统一接口的设计参考，但槽位和轮速定义需要自己完成。GenBot提供身体资产，采用前要逐个检查并接入同一任务。SDK2和rl_sar帮助实现设备通信与部署，历史状态仍需自己管理。下面将这些来源落实到具体技术方案和计划。',LAB+'\n'+GEN+'\nhttps://github.com/agrimgupta92/metamorph\nhttps://github.com/HybridRobotics/GenLoco\nhttps://github.com/fan-ziqi/rl_sar\n'+SDKROOT)

# 08 compare the three routes and make a decision
s=base('统一接口选型：先固定槽位，再验证是否需要结构化表示')
table(s,['方案与参考','输入如何统一','输出如何对应关节','本项目选择'],[
('固定语义槽位\nMetaMorph / GenLoco 供参考','规定槽位、方向和有效位\n原始数据先重排为同一格式','同一槽位有固定含义\n适配器选有效通道并解码','首版采用\n先覆盖普通四足与 Go2-W'),
('逐关节表示\nURMA','每关节提供状态与结构描述\n共享编码并汇总整体信息','整体特征 + 各关节描述\n共享解码得到对应关节动作','后续架构对照\n用于较大结构差异'),
('多编码器\n本地 locoformer 示例','32 / 16 维各用一套编码器\n共同特征进入共享 TXL','调用者用 selector 选动作组\n示例分别取 12 路 / 6 路','参考网络与训练核心\n不直接采用为主接口')],[2.65,3.0,3.0,2.85],1.55,1.18,13.0)
txt(s,'选择依据',.98,6.02,1.5,.35,16,WINE,True)
txt(s,'四足与轮足对应关系清楚，便于逐通道检查；先稳定接口，再研究历史适应。',2.65,5.95,9.4,.62,15,INK)
note('03  接口选择与原型','统一接口有三种路线。固定槽位统一输入输出的位置含义；URMA统一逐关节描述和共享编解码；本地多编码器统一内部特征宽度。第三种需要调用者选择编码器和动作组，不能自动接入任意未见身体。首版选择固定槽位，是因为普通四足和Go2-W的腿部对应明确，轮通道可以单独表达。MetaMorph原实现包含模块/肢体表示，并不等于我们提出的平面数组。URMA留作身体结构差异扩大后的对照。',URMA+'\n'+LOCAL+'\nhttps://github.com/agrimgupta92/metamorph\nhttps://github.com/HybridRobotics/GenLoco')

# 09 concrete interface prototype and its limits
s=base('首版接口原型：16 个关节槽位，73 维观测，16 路动作')
txt(s,'验证范围：普通 12 关节四足与 Go2-W；候选普通四足为 Go2，资产先核对。',.95,1.3,11.5,.48,16,INK,True)
node(s,'槽位 0–11：四腿各 3 关节',.95,2.0,7.15,.6,BLUE,17)
node(s,'槽位 12–15：四个车轮',8.35,2.0,4.05,.6,GOLD_LIGHT,17)
table(s,['身体','腿部状态','轮部状态','有效位'],[
('普通四足','12 路腿位置 / 速度','4 路占位，动作不执行','腿为 1，轮为 0'),
('Go2-W','12 路腿位置 / 速度','4 路轮速；轮位置按任务置零','16 路均为 1')],[2.0,3.2,3.9,2.4],2.95,.72,13.8)
txt(s,'统一输入',.98,5.15,1.5,.35,16,WINE,True)
txt(s,'机体与指令 9 + 相对位置 16 + 速度 16 + 上一动作 16 + 有效位 16 = 73',2.65,5.08,9.55,.54,14,INK)
txt(s,'输出解码',.98,5.85,1.5,.35,16,WINE,True)
txt(s,'腿：默认姿态 + 缩放偏移；轮：缩放轮速。缺失轮通道不执行，也不计入相应训练项。',2.65,5.77,9.55,.64,14,INK)
takeaway(s,'这是项目原型，非论文原始配置；扩大身体集合前审查槽位覆盖并冻结正式接口。',6.58)
note('03  接口选择与原型','这页给出可实施的第一版设计。前12槽位按右前、左前、右后、左后的hip、thigh、calf排列，后4槽位为四轮。普通四足轮通道不存在，Go2-W轮通道存在但不用绝对轮角，二者由有效位区分。观测共73维，比Robot Lab基础57维增加16个有效位。Actor输出16路动作分布，并不表示只有16个分布参数。腿目标相对默认姿态，轮输出速度。先做数据、单槽位和缺失位检查，再训练统一编码层和两身体共享策略。原57维输入层不能直接加载到73维结构。原型只覆盖当前两类身体，正式训练前检查是否需要更大超集或URMA对照。')

# 09 memory and training
s=base('长历史适应需要同时改造策略、采集和 PPO 更新')
card(s,'策略计算','参考 lucidrains 的 TXL\n接入统一观测与动作输出',.9,1.5,3.65,1.65,BLUE)
card(s,'历史边界','segment 间传递历史\n同任务跨 Trial 保留，任务切换清空',4.84,1.5,3.65,1.65,GREEN)
card(s,'序列训练','参考 Baby 的存储与 PPO 接入\n补任务边界与多轮更新',8.78,1.5,3.65,1.65,GOLD_LIGHT)
table(s,['开发内容','必须验证的行为'],[
('任务与缓存','一个环境重置不影响其他环境；任务切换无历史泄漏'),
('因果与梯度','不读取未来观测；旧段 SG 仅截断反传，仍提供历史数值'),
('PPO 与评估','区分失败、超时和任务结束；匹配预算比较保留 / 清空历史')],[2.55,8.95],3.65,.65,14)
takeaway(s,'阶段 4 验证：逐步 / 分段输出一致性，缓存重置检查，再比较保留 / 清空历史。',6.58)
note('03  核心方案','历史适应不仅是给策略增加一个Transformer。采集器要记录任务和Trial边界，缓存按环境维护，PPO也要保持连续序列。SG控制旧计算链的反传范围，不删除历史数值。实现正确性先通过小样例检查，再通过相同任务和预算下保留或清空历史的实验判断效果。')

# 10 resources
s=base('软件与服务器：从单卡基线测量确定训练规模')
table(s,['层次','拟采用配置 / 已有资源','实施安排'],[
('仿真任务','Isaac Sim 5.1 + Isaac Lab 2.3.2\nRobot Lab 2.3.2','先整体验证版本与 Blackwell 兼容\n独立 Conda Python 3.11'),
('服务器','2 × RTX PRO 5000，各约 48 GiB\n96 逻辑 CPU，约 251 GiB 内存','单卡启动，测环境步 / 秒\n记录优化耗时与峰值显存'),
('存储与可视化','Ubuntu 22.04.5\n资源记录时约 445 GiB 空闲','优先少量资产与必要权重\nVNC 查看场景，headless 训练'),
('部署','SDK2 Python + 状态化策略运行器','先检查真实观测和推理耗时\n通过仿真验收后开放执行')],[2.1,5.0,4.4],1.55,.98,13.6)
takeaway(s,'硬件资源支持逐步开展实验；训练预算由测量确定，论文最大规模结果另行对齐。',6.58)
note('04  工作计划','服务器资源来自已有记录，实施时重新登记。候选旧版本组合是为了匹配Robot Lab，Isaac Sim5.1已标记unsupported，需要先验证Blackwell兼容性。首先单卡测量采样、优化和显存，再决定环境并行度与多卡开发。两张显卡不会自动成为一张96GiB显卡，也不预先承诺论文最大规模性能。',LAB+'\nhttps://isaac-sim.github.io/IsaacLab/v2.3.2/source/setup/installation/index.html')

# 11 plan with explicit references and verification
s=base('工作计划Ⅰ：参考依据、实施任务与验证方法')
table(s,['阶段','参考来源','本项目实施工作','验证方法'],[
(str(t['id'])+' '+t['name'],t['ppt_ref'],t['ppt_how'],t['ppt_test']) for t in TASKS[:3]
],[2.15,3.15,3.2,3.0],1.75,1.18,13.5)
txt(s,'阶段衔接',.98,6.0,1.4,.36,16,WINE,True)
txt(s,'模型与通道检查通过后训练基线；保存基线后改统一接口，在原网络上验证状态与动作的往返转换。',2.65,5.92,9.4,.62,15,INK)
note('04  实施与验证计划','前三项工作分别对应前面介绍的平台与接口资料。第一项以Robot Lab和官方模型为依据，检查每路动作是否作用于正确关节，并通过SDK只读记录核对真实数据。第二项保留Robot Lab任务训练MLP，通过固定指令重载评估获得基线，同时测吞吐。第三项参考MetaMorph和GenLoco组织统一接口，先检查单槽位和缺失位，再用同一权重比较转换前后结果。只有接口通过检查，才引入历史网络。',LAB+'\n'+SDK+'\nhttps://github.com/agrimgupta92/metamorph\nhttps://github.com/HybridRobotics/GenLoco')

# 12 core reproduction and deployment
s=base('工作计划Ⅱ：移植历史训练，扩展身体，接入实机')
table(s,['阶段','参考来源','本项目实施工作','验证方法'],[
(str(t['id'])+' '+t['name'],t['ppt_ref'],t['ppt_how'],t['ppt_test']) for t in TASKS[3:]
],[2.15,3.15,3.2,3.0],1.75,1.18,13.5)
txt(s,'阶段衔接',.98,6.0,1.4,.36,16,WINE,True)
txt(s,'原型验证后审查正式身体与接口；缓存和更新通过后扩大训练，实机执行依赖仿真验收。',2.65,5.92,9.4,.62,15,INK)
note('04  实施与验证计划','第四项分别参考lucidrains的历史骨干和Baby的序列训练连接，补齐任务重置与PPO循环。验证分两层：先检查因果、缓存和更新，再比较历史的实际收益。第五项参考GenBot筛选资产，补轮足和统一任务，以完整身体留出检验泛化。第六项依据官方SDK协议，参考rl_sar部署组织，自己实现观测和动作适配。验证顺序是只读、影子推理、命令与反馈闭环。每项参考资料都有对应实施工作和检查结果。',LOCAL+'\n'+BABY+'\n'+GEN+'\n'+SDK+'\nhttps://github.com/fan-ziqi/rl_sar')

# 13 evidence and immediate tasks
s=base('阶段成果以实验支持，首批先完成平台和基线')
table(s,['需要证明的内容','计划采用的证据'],[
('Go2-W 控制基线','速度跟踪误差、跌倒率、保存重载一致性'),
('历史适应','同任务、同预算下保留 / 清空历史；恢复时间与 Trial 表现'),
('跨本体泛化','完整身体留出，逐身体指标与随机种子间差异'),
('实机接入','带时间戳的观测、动作、命令和反馈；周期与任务表现')],[3.15,8.35],1.55,.73,14.3)
rect(s,.92,5.35,11.5,1.08,WINE_LIGHT,line=LINE)
txt(s,'首批任务',1.13,5.48,1.6,.36,18,WINE,True)
txt(s,'完成版本兼容与模型核对，运行 Go2-W 短训练，\n形成可重载基线和吞吐记录后，细化后续训练规模与日程。',2.9,5.48,9.15,.73,16,INK)
note('工作安排','最终按四类证据报告进展：基础控制、历史适应、跨本体和实机。当前先不并行改造全部模块，启动后完成版本兼容、模型检查和Go2-W短训练，得到可重载基线与吞吐测量，再细化规模和日程。官方未公开的训练细节作为实现差异记录，不用单个视频代替完整复现结论。')

assert len(prs.slides)==TOTAL
from pptx.oxml.xmlchemy import OxmlElement
for slide in prs.slides:
    for tag in ('a:rPr','a:defRPr','a:endParaRPr'):
        for rp in slide._element.xpath('.//'+tag):
            for kind in ('latin','ea','cs'):
                ns='{http://schemas.openxmlformats.org/drawingml/2006/main}'+kind
                nodes=rp.findall(ns)
                if nodes:e=nodes[0]
                else:e=OxmlElement('a:'+kind);rp.append(e)
                e.set('typeface',FONT)
prs.save(OUT)
print(f'Saved {TOTAL} reporting slides: {OUT}')
