import fs from 'node:fs/promises';
import { FileBlob, PresentationFile } from 'file:///C:/Users/laiyo/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/@oai/artifact-tool/dist/artifact_tool.mjs';
const {finalPath:src}=JSON.parse(await fs.readFile('G:/毕设/02_learning/locoformer/go2_reproduction/.build/focused_workplan/latest_report.json','utf8'));
const out = 'G:/毕设/02_learning/locoformer/go2_reproduction/.build/focused_workplan/rendered';
await fs.mkdir(out, {recursive:true});
const p = await PresentationFile.importPptx(await FileBlob.load(src));
const info = await p.inspect({select:'$.slides[*]',include:['index','title','elements.text','elements.style'],fileName:'inspect.ndjson'});
await fs.writeFile(`${out}/inspect.ndjson`, info.ndjson, 'utf8');
const montage = await p.export({format:'png',montage:true,scale:0.35});
await fs.writeFile(`${out}/montage.png`, new Uint8Array(await montage.arrayBuffer()));
for (let i=0;i<p.slides.items.length;i++) {
  const blob = await p.export({slide:p.slides.items[i],format:'png',scale:1});
  await fs.writeFile(`${out}/slide-${String(i+1).padStart(2,'0')}.png`, new Uint8Array(await blob.arrayBuffer()));
}
console.log(JSON.stringify({slides:p.slides.items.length, inspect:info.ndjson.slice(0,200)},null,2));



