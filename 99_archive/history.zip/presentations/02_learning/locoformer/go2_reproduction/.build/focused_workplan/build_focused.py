from pathlib import Path
P=Path(__file__).parent
expanded=P.parent/'expanded_workplan'/'build_expanded.py'
exec(expanded.read_text(encoding='utf-8').split('# 01')[0])
TOTAL=12
OUT=Path(r'G:\毕设\02_learning\04_review\deliverables\locoformer\go2w_reproduction_proposal.CN.pptx')
PHOTO='https://uploads.unchainedrobotics.de/media/products/Go2_W_PB5_456b21c6.png'

def info(s,heading,body,x,y,w=3.0):
    txt(s,heading,x,y,w,.34,17,WINE,True)
    txt(s,body,x,y+.43,w,.72,14,INK,valign=MSO_ANCHOR.TOP)

# 01
s=base()
rect(s,.8,1.8,.065,3.2,WINE)
txt(s,'LocoFormer 复现工作计划',1.12,1.95,10.95,.73,36,INK,True)
txt(s,'Go2-W 平台、参考实现与技术选型',1.15,2.94,10.8,.52,24,WINE,True)
txt(s,'平台条件 → 实现缺口 → 方案选择 → 分阶段交付',1.17,4.0,10.6,.47,19,MUTED)
txt(s,'当前状态：资料调研与方案规划，实施尚未启动',1.17,5.0,10.6,.36,16,INK)
footer(s,'复现工作计划','本次汇报围绕后续工作安排展开，论文原理已在前次汇报完成。说明硬件、可复用实现与选型理由后，落到阶段计划。')

# 02 annotated product image
s=base('Go2-W 硬件组成与部件定位')
pic=s.shapes.add_picture(str(P/'go2w_front.png'),Inches(3.15),Inches(1.3),width=Inches(5.6),height=Inches(5.6))
pic.crop_left=pic.crop_right=pic.crop_top=pic.crop_bottom=.08
def mark(num,px,py,lx,ly,title,body,side):
    # Editable annotation leaders and numbered component markers.
    anchor=lx+2.65 if side=='left' else lx
    line(s,anchor,ly+.2,px,py,WINE,1.1)
    c=s.shapes.add_shape(MSO_SHAPE.OVAL,Inches(px-.14),Inches(py-.14),Inches(.28),Inches(.28))
    c.fill.solid();c.fill.fore_color.rgb=rgb(WINE);c.line.color.rgb=rgb(WHITE)
    txt(s,str(num),px-.13,py-.13,.26,.26,10,WHITE,True,PP_ALIGN.CENTER,margin=0)
    txt(s,f'{num}  {title}',lx,ly,2.8,.35,16,WINE,True)
    txt(s,body,lx,ly+.42,2.8,.66,13,INK,valign=MSO_ANCHOR.TOP)
mark(1,7.17,2.74,9.15,1.6,'广角相机','前部视觉感知\n可用于环境记录与扩展任务','right')
mark(2,6.97,3.53,9.15,3.0,'3D LiDAR','前部空间感知\n点云与环境几何','right')
mark(3,5.75,2.89,.85,2.7,'腿部近端电机组','每腿 3 路腿部驱动\n安装区域与关节转轴分开标注','left')
mark(4,5.26,3.88,.85,4.35,'膝关节转轴','小腿相对大腿的转动位置\n此标记不表示电机安装位置','left')
mark(5,7.81,5.16,9.15,4.9,'轮电机与轮胎','每腿 1 个独立驱动轮\n7 英寸充气轮胎','right')
mark(6,5.28,2.41,.85,1.35,'机身内部模块','IMU、机载计算与供电\n内部位置仅作组成示意','left')
takeaway(s,'4 条轮足链，每条 3 个腿关节 + 1 个轮电机，共 16 路主动控制通道。',6.66)
footer(s,'01  实机平台','腿部电机集中在近端的表述依据现场提供的说明，内部传动形式尚无独立剖面资料。图中膝部标记只定位关节转轴，不表示电机装在此处。轮端电机单独标注。机身内部模块只说明系统组成，不标定其精确安装坐标。下一页按hip、thigh、calf、wheel解释运动与控制通道。',PHOTO+'\n'+PRODUCT+'\n'+URDF)

# 03 motors and compact platform specs
s=base('关节与驱动：12 路腿位置、4 路轮速')
table(s,['关节 / 通道数','位置范围（rad）','模型 effort / 速度','首版动作定义'],[
('hip ×4\n外展 / 内收','−1.0472 ～ 1.0472','23.7 N·m / 30.1 rad/s','相对默认姿态的偏移'),
('前 thigh ×2\n大腿俯仰','−1.5708 ～ 3.4907','23.7 N·m / 30.1 rad/s','相对默认姿态的偏移'),
('后 thigh ×2\n大腿俯仰','−0.5236 ～ 4.5379','23.7 N·m / 30.1 rad/s','相对默认姿态的偏移'),
('calf ×4\n膝部屈伸','−2.7227 ～ −0.83776','35.55 N·m / 20.07 rad/s','相对默认姿态的偏移'),
('wheel ×4\n轮轴转动','continuous，连续转动','23.7 N·m / 30.1 rad/s','轮速目标')],[2.35,3.3,3.4,2.45],1.55,.65,12.8)
txt(s,'平台规格',.97,5.4,1.3,.33,16,WINE,True)
txt(s,'约 18 kg，70 × 43 × 50 cm；载荷约 8 kg（最大约 12 kg）\n标称速度 0–2.5 m/s；爬坡 35°；越障高度 ＜70 cm',2.46,5.32,9.58,.75,14,INK)
takeaway(s,'表中限值来自 URDF。厂商约 45 N·m 指最大规格电机，实机限幅需独立设置。')
footer(s,'01  实机平台','这些是公开模型范围，不能当作实机安全运行范围。SDK索引腿部按FR0–2、FL3–5、RR6–8、RL9–11，车轮依次12–15。RobotLab v2.3.2和官方SDK例子均区分腿位置与轮速。RobotLab动作scale为髋0.125、其他腿关节0.25、轮速5.0，腿目标为默认姿态加缩放偏移，不是每步累计到当前角度。',URDF+'\n'+PRODUCT+'\n'+SDK+'\n'+LAB.replace('/tree/','/blob/')+'/source/robot_lab/robot_lab/tasks/manager_based/locomotion/velocity/config/wheeled/unitree_go2w/rough_env_cfg.py')

# 04 sensors / compute / power
s=base('感知、计算与供电：哪些数据进入首版策略')
table(s,['硬件','可获取的信息 / 已公开条件','本项目用途'],[
('IMU','机身姿态、角速度、加速度等反馈','构造机体状态与重力方向'),
('电机反馈','16 路 q、dq 等状态','腿 / 轮状态输入及动作跟踪'),
('超广角 3D LiDAR','前部空间感知、点云\n型号、量程等需以实机设备资料核对','保留环境感知能力\n首版本体感觉策略不依赖点云'),
('高清广角相机','前部图像输入\n公开型号页未给分辨率和标定参数','记录场景与测试过程\n不直接加入首版策略输入')],[2.25,5.2,4.05],1.55,.89,13.6)
txt(s,'计算与通信',.98,5.75,1.65,.35,16,WINE,True)
txt(s,'8 核 CPU，Orin NX 为选配；Wi-Fi 6 / 4G / Bluetooth，开发通信采用 SDK2。',2.84,5.68,9.25,.5,13.7,INK)
txt(s,'电源',.98,6.32,1.65,.33,16,WINE,True)
txt(s,'33.6 V、15 Ah；标称续航 1.5–3 h；充电器 33.6 V / 9 A。',2.84,6.27,9.25,.42,13.7,INK)
footer(s,'01  实机平台','雷达和相机是平台资源，但论文的本体感觉运动控制复现首版以IMU和电机状态为主。公开产品页没有可靠列出该台设备的雷达型号/量程/频率、相机分辨率和内外参，不套用普通Go2的参数。设备接入阶段读取型号及SDK元数据。IMU和电机读取字段以实际SDK版本为准。',PRODUCT+'\n'+URDF+'\nhttps://github.com/unitreerobotics/unitree_sdk2_python')

# 05 critical implementation assessment
s=base('LocoFormer 相关实现：已具备什么，质量与缺口在哪里')
table(s,['项目定位','已包含的实现','可用价值与限制'],[
('lucidrains/locoformer\n第三方 PyTorch 实现','TXL、Actor / Critic、PPO\n多输入宽度编码器、动作 selector\nMicroduck 双足训练示例','适合复核算法核心模块\nstate_id 选择已知编码器\n仍缺 Go2-W 和统一跨本体任务'),
('BabyLocoFormer\n非官方 Isaac Lab 学习版','四足形态生成、有限随机化\nTXL 缓存、自定义 PPO 训练 / 评估','最接近训练集成参考\nTXL 含 RoPE 等改动\n作者自述结果较弱，不能性能对齐')],[3.0,4.0,4.5],1.6,1.47,13.7)
txt(s,'需要重点改造',.98,5.38,1.8,.36,16,WINE,True)
txt(s,'Baby 的 reset() 为空：需补任务切换清空规则，不能将“缓存一直保留”直接等同于正确的跨 Trial 适应。',2.94,5.28,9.1,.72,14,INK)
takeaway(s,'复用模块前先审查边界；官方完整训练工程、权重、统一槽位表和实机映射仍未获取。')
footer(s,'02  参考实现','质量判断区分证据类型：Baby结果较弱来自作者README；reset为空来自本地源码静态检查，不能据此断言所有训练一定错误，保留历史可能是有意设计，但缺少明确任务重置合同。完整复现仍需身体分布、输入动作映射、跨Trial任务组织、论文评测和Go2W部署。',LOCAL+'\n'+BABY+'\n本地审查：rsl_rl/rsl_rl/modules/actor_critic_transformerxl.py reset()；rsl_rl/rsl_rl/algorithms/ppo.py process_env_step()；快照 commit f2dadf8eb13826f449387ecc9970593a9af141bc')

# 06 projects and selections
s=base('环境、资产与部署项目：原始用途与复用选择')
table(s,['项目 / 原始用途','值得复用的具体内容','本项目选择'],[
('Robot Lab\nIsaac Lab 多机器人任务扩展','Go2-W 模型、平地 / 粗糙地形\n12 位置 + 4 轮速动作及奖励、PPO 配置','主仿真底座\n先复用现成单体基线'),
('GenBot-1K / Scaling Laws\n研究身体数量与泛化的关系','约千种身体、生成与转换工具\n专家训练、URMA 蒸馏与留出评测','借少量合格资产和生成方法\n沿用 LocoFormer 在线 PPO'),
('Unitree RL Lab / SDK2\n厂商学习、部署与硬件通信','观测缩放、控制配置、部署流程\n状态消息、低层命令和电机编号','实机适配依据\n核对普通 Go2 与轮足差异'),
('Unitree MuJoCo\n厂商模型与仿真控制参考','关节、执行器、接触和模型定义','可选 sim-to-sim 交叉检查\n主训练继续使用 Isaac Lab')],[3.2,4.7,3.6],1.55,1.02,13.2)
takeaway(s,'GenBot 的专家和蒸馏权重属于另一方法，可作参考验证，不能当作 LocoFormer 权重。')
footer(s,'02  参考实现','GenBot工程采用专家RL加URMA蒸馏，不能将其训练流程或权重直接视为LocoFormer。资产需要惯量、碰撞、关节、初态和执行器检查。UnitreeRL用于部署结构，SDK负责通信。MuJoCo可作辅助模型检查，不同时维护两套主训练栈。',LAB+'\n'+GEN+'\nhttps://github.com/unitreerobotics/unitree_rl_lab\nhttps://github.com/unitreerobotics/unitree_sdk2_python\nhttps://github.com/unitreerobotics/unitree_mujoco')

# 07 input and output selection
s=base('统一输入输出选型：优先保持论文的关节超集路线')
table(s,['候选与参考','如何统一输入 / 输出','适用性与选择'],[
('固定关节超集\nLocoFormer；MetaMorph 作补充参考','固定语义槽位，缺失位约定 / mask\n输出按机器人映射取有效通道','优先采用，贴近论文\n需补齐槽位、方向和归一化'),
('逐关节表示\nURMA；BoT 提供结构注意力参考','每个关节携带状态和结构描述\n共享计算后为对应关节解码动作','关节 / 拓扑变化更灵活\n作为后续架构对照'),
('按输入宽度分编码器\n本地 locoformer 示例','调用者选 state_id 和动作 selector\n编码成同宽特征，后续网络共享','适合已知输入类型的原型\n不作为未见本体泛化的依据')],[3.25,4.8,3.45],1.68,1.13,13.8)
txt(s,'拟实施接口',.98,5.82,1.65,.36,16,WINE,True)
txt(s,'角速度 / 重力方向 / 速度指令 + 统一槽位的 q、dq、上一动作与有效位\n输出按独立映射解码为 Go2-W 的 12 路位置目标与 4 路轮速目标。',2.83,5.73,9.25,.78,14,INK)
footer(s,'03  技术选型','方案选择的理由是复现方法一致性和初期实现成本。MetaMorph原研究形态条件化控制，可借mask和结构表示；URMA原研究跨腿式身体共享控制，借逐关节描述和共享编解码；BodyTransformer原研究利用身体拓扑学习策略，借关节信息交换。GenLoco原研究形态随机化和动作模仿，可借MOTOR_NAMES、JOINT_DIRECTIONS、初态与PD配置，其12关节四足设置需扩展车轮。mask是项目设计，需单独标明并做消融，不称为论文已公开的精确合同。',URMA+'\nhttps://github.com/agrimgupta92/metamorph\nhttps://github.com/carlosferrazza/BodyTransformer\nhttps://github.com/HybridRobotics/GenLoco\n'+LOCAL+'\nhttps://generalist-locomotion.github.io/')

# 08 policy memory training choices
s=base('策略、记忆与训练：在一套 PPO 管线内接入历史模型')
stages=[('统一观测','机体状态 + 关节状态'),('共享策略','MLP 编码 + Transformer-XL'),('动作解码','Actor 的统一动作映射')]
for i,(a,b) in enumerate(stages):
    x=.95+i*4.1;node(s,a,x,1.52,3.5,.62,[BLUE,GREEN,GOLD_LIGHT][i],16)
    txt(s,b,x,2.28,3.5,.39,13,MUTED,align=PP_ALIGN.CENTER)
    if i<2:arrow(s,x+3.5,1.83,x+3.99,1.83)
table(s,['环节','拟采用方案','理由 / 必须补齐'],[
('策略骨干','单体 MLP 作基线，目标策略采用 TXL\nlucidrains 核对模块，Baby 参考集成','控制对照清楚，保持论文主线\n不直接接受第三方性能结论'),
('记忆边界','跨 segment 传递历史\n同任务跨 Trial 保留，任务切换清空','补任务标识、reset、mask\n检查数值缓存与反传边界'),
('训练流程','Robot Lab 的 PPO 管线内集成历史策略\n按序列组织采集与更新','沿用论文 RL 训练方向\n不切换到 GenBot 的蒸馏流程')],[1.7,5.15,4.65],3.05,.91,13.6)
footer(s,'03  技术选型','TXL为Transformer-XL。拟先用RobotLab现成MLP完成单体基线，再修改策略和序列采集，不同时替换所有组件。跨Trial缓存保留需要任务一致性约束。PPO、rollout storage和runner必须遵循同一序列和重置合同。Baby自定义rsl_rl不能与RobotLab随意混装。',LAB+'\n'+BABY+'\n'+LOCAL+'\nhttps://generalist-locomotion.github.io/')

# 09 runtime conditions
s=base('运行条件与软件组合：先测容量，再确定训练预算')
table(s,['层次','拟使用的组件 / 现有资源','实施安排'],[
('仿真与任务','Isaac Sim 5.1 → Isaac Lab 2.3.2\nRobot Lab 2.3.2、Python 3.11','独立 Conda，整体锁定版本\n先兼容检查和小并行启动'),
('训练与部署','PyTorch / PPO / TXL\nSDK2 实机适配，MuJoCo 可选对照','先单体基线，再集成历史策略\n仿真与实机共用观测处理'),
('服务器','2 × RTX PRO 5000（各约 48 GiB）\n96 逻辑 CPU，约 251 GiB RAM','单卡起步，测环境步 / 秒和显存\n再评估双卡与身体数量'),
('系统与存储','Ubuntu 22.04.5\n资源记录时约 445 GiB 可用','选取少量资产，控制日志与权重占用\nVNC 用于场景查看和操作')],[2.15,5.4,3.95],1.56,1.02,13.5)
takeaway(s,'当前是实施前规划；论文最大训练规模和最终性能不预先承诺对齐。')
footer(s,'04  工作计划','资源来自2026-11-06既有服务器记录，不表示本项目已启动训练。IsaacSim5.1在官方文档被标为unsupported，拟定版本是Lab2.3.2配套兼容起点，启动时仍须验证。两GPU显存不能视为单个96GiB空间。connect.md只提供SSH隧道和VNC桌面访问方法，不将个人连接命令写入技术路线，也没有据此启动任何远程程序。',LAB+'\nhttps://isaac-sim.github.io/IsaacLab/v2.3.2/source/setup/installation/index.html\nhttps://docs.isaacsim.omniverse.nvidia.com/5.1.0/installation/requirements.html\n既有服务器资源记录；connect.md')

# 10 implementation gaps -> tasks
s=base('完整复现的关键缺口及对应开发任务')
table(s,['缺口','计划补齐的实现','可检查的交付物'],[
('统一关节空间未冻结','盘点目标身体，固定槽位与有效位\n逐机器人记录 joint / SDK / 动作类型','统一接口规范\n映射表与往返校验'),
('历史保留缺少任务规则','区分任务切换、Trial 重置和 segment\n改造采集器、缓存与 PPO 序列更新','任务 / 缓存状态图\n保留与清空历史对照'),
('多本体训练分布不完整','先筛选少量四足与轮足资产\n补形态 / 动力学随机化和整机留出','合格资产、生成参数\n训练 / 验证 / 测试划分'),
('原版工程与权重缺失','按公开方法重建并记录实现偏离\n训练自己的模型，开展匹配预算实验','版本、配置、权重与日志\n复现范围及数值差异说明')],[2.75,5.2,3.55],1.55,1.04,13.5)
takeaway(s,'先补齐输入、任务与训练规范，再扩大身体数量和随机化范围。')
footer(s,'04  工作计划','原版完整训练仓库、checkpoint、关节槽位细节和全部部署设置没有在已核对公开入口中找到。缺口转化为工程任务，停止依赖尚未获得的官方资源。多身体资产可借GenBot，但车轮变体和轮速动作需专门适配。',LOCAL+'\n'+BABY+'\n'+GEN+'\nhttps://generalist-locomotion.github.io/')

# 11 evaluation and simreal gates
s=base('验证安排：每个核心环节都有独立对照')
table(s,['验证内容','计划对照 / 检查','进入下一步的证据'],[
('单体控制与算力','Go2-W 现成 PPO，平地起步\n逐路检查腿 / 轮动作与资源占用','可重载基线策略\n速度误差、跌倒率、吞吐'),
('历史适应','相同任务和预算下保留 / 清空历史\n比较早期与后续 Trial','恢复时间、失败率、适应曲线\n缓存没有跨任务泄漏'),
('跨本体泛化','完整机器人留出，多个随机种子\n区分身体多样性与数据量','逐身体与汇总统计\n训练内 / 未见身体分开报告'),
('实机部署','仿真重载 → 可选 sim-to-sim\nSDK2 只读 / 影子推理 → 分级执行','输入、动作、通道反馈一致\n周期、延迟、限幅与异常日志')],[2.3,5.5,3.7],1.56,1.02,13.6)
takeaway(s,'实机采用同一观测与动作规范，先验证输入输出，再逐步开放腿部和车轮执行。')
footer(s,'04  工作计划','PPO基线用于隔离环境与模型问题。历史对照固定任务与计算预算。跨本体测试按完整身体留出，不只换同一机器人随机种子。实机阶段先影子推理记录，再开放执行，状态、动作映射、更新周期和异常终止必须一起验证。所有阶段为未来计划。',SDK+'\n'+LAB)

# 12 complete roadmap ending on plan
s=base('完整工作计划与阶段交付')
table(s,['阶段 / 前置依赖','实施工作与主要参考','交付与验收'],[
('1 平台准备','独立环境、版本与 Go2-W 资产\nIsaac Lab / Robot Lab','可重复启动\n模型与设备检查表'),
('2 单体基线\n依赖 1','运行现成 PPO，校验 12+4 动作\n测服务器吞吐与训练成本','基线权重、评估曲线\n后续实验计算预算'),
('3 统一接口与策略\n依赖 2','冻结关节映射，接共享骨干和解码\nLocoFormer / URMA / 厂商接口参考','统一接口与动作映射\n策略保存、重载一致'),
('4 长历史与跨 Trial\n依赖 3','TXL 缓存、任务边界与序列 PPO\nBaby 参考集成，独立验证 reset','保留 / 清空历史对照\n缓存与更新日志'),
('5 多本体复现\n依赖 4','筛选 / 生成身体，扩大随机化\nGenBot 资产，整机留出评测','共享策略与泛化结果\n多种子适应曲线'),
('6 Go2-W 实机\n依赖仿真验收','SDK2 状态与混合动作适配\n影子推理后分级闭环','实机运行及反馈证据\n性能、延迟与复现边界')],[2.65,5.35,3.5],1.5,.72,12.8)
takeaway(s,'启动后首先完成阶段 1–2；后续规模和时间安排依据基线测量细化。',6.48)
footer(s,'工作计划与交付','本次给出前置依赖和验收驱动的完整计划。当前尚未开始实施，因此不将环境安装、基线训练或硬件部署写成已完成成果。整体路线为RobotLab环境+PPO主训练管线，统一关节超集+TXL目标策略，GenBot筛选资产，SDK2混合动作部署。')

assert len(prs.slides)==TOTAL
from pptx.oxml.xmlchemy import OxmlElement
for slide in prs.slides:
    for tag in ('a:rPr','a:defRPr','a:endParaRPr'):
        for rp in slide._element.xpath('.//'+tag):
            for kind in ('latin','ea','cs'):
                nodes=rp.findall('{http://schemas.openxmlformats.org/drawingml/2006/main}'+kind)
                if nodes: e=nodes[0]
                else:e=OxmlElement('a:'+kind);rp.append(e)
                e.set('typeface',FONT)
prs.save(OUT)
print(f'saved={OUT} slides={len(prs.slides)}')
