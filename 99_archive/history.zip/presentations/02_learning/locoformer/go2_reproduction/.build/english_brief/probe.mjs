import fs from 'node:fs/promises';
import {FileBlob,PresentationFile} from 'file:///C:/Users/laiyo/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/@oai/artifact-tool/dist/artifact_tool.mjs';
const root='G:/毕设/02_learning/locoformer/go2_reproduction/.build/english_brief';
const p=await PresentationFile.importPptx(await FileBlob.load('G:/毕设/02_learning/04_review/deliverables/locoformer/go2w_reproduction_brief.refined.CN.pptx'));
await fs.writeFile(root+'/source-inspect.ndjson',(await p.inspect({kind:'slide,textbox,table,notes',maxChars:1000000})).ndjson);
for(let i=0;i<p.slides.items.length;i++){
 const s=p.slides.items[i]; console.log(i,s.shapes.items.length,s.tables.items.length);
}
const s=p.slides.items[0];for(const sh of s.shapes.items)console.log(sh.id,String(sh.text),JSON.stringify(sh.text?.style));
await fs.writeFile(root+'/source-montage.png',new Uint8Array(await (await p.export({format:'png',montage:true,scale:.4})).arrayBuffer()));
