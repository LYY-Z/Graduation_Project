import fs from 'node:fs/promises';
import {FileBlob,PresentationFile} from 'file:///C:/Users/laiyo/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/@oai/artifact-tool/dist/artifact_tool.mjs';
const root='G:/毕设/02_learning/locoformer/go2_reproduction/.build/english_brief';
const src='G:/毕设/02_learning/04_review/deliverables/locoformer/go2w_reproduction_brief.refined.CN.pptx';
const pairs=(await fs.readFile(root+'/translations.txt','utf8')).trim().split('\n').map(l=>l.trim().split('=>'));
const p=await PresentationFile.importPptx(await FileBlob.load(src));
const tableSpecs=(await fs.readFile(root+'/source-inspect.ndjson','utf8')).trim().split('\n').map(l=>JSON.parse(l)).filter(r=>r.kind==='table');
const missing=[];
function translateText(t){
 const before=String(t);
 if(!/[\u3400-\u9fff]/.test(before))return;
 for(const [a,b] of [...pairs].sort((a,b)=>b[0].length-a[0].length)){
  if(String(t).includes(a))t.replace(a,b);
 }
 if(/[\u3400-\u9fff]/.test(String(t)))missing.push(String(t));
}
const notes=[
 'This plan begins with the Go2-W platform, identifies reusable software, and defines staged validation of a shared policy and long-context adaptation. The work described is planned research rather than completed reproduction.',
 'Go2-W has twelve leg drives and four independent wheel drives. The proximal motor assembly must be distinguished from the knee joint axis. Camera, LiDAR and internal IMU have separate roles. These specifications describe the reviewed platform.',
 'The proposed policy slot and the SDK channel are separate identifiers even where their numerical values match. Each physical joint is mapped by name. Leg joints use position targets, while wheels use velocity targets with zero proportional position gain.',
 'LowState and LowCmd support the primary control loop. The IMU provides angular velocity and orientation for proprioceptive observations. Camera and LiDAR access require separate device and service checks. Their data are excluded from the initial locomotion policy.',
 'Robot Lab provides the first baseline. BabyLocoFormer and the lucidrains implementation provide training and Transformer-XL references that require verification before reuse. MetaMorph, GenLoco and URMA inform interface design. GenBot-1K supplies candidate assets rather than a complete reproduction pipeline.',
 'The initial interface uses sixteen fixed semantic slots and explicit validity masks. Ordinary quadrupeds mask the wheel channels. Go2-W uses all sixteen. The proposed seventy-three-dimensional observation is a project prototype, not a confirmed reconstruction of the original author interface. Larger morphology sets require a coverage review.',
 'Begin with a single-robot MLP PPO baseline. Add a shared interface before introducing Transformer-XL and cross-trial memory. Retain memory only within the same task and clear it on task changes. Profile one GPU before selecting training scale.',
 'Stages one to three establish the platform, produce a reloadable baseline, and test the shared interface. Each stage has explicit verification outputs. Memory is introduced only after interface checks pass, so failures can be attributed to individual changes.',
 'Stages four to six validate memory and sequence PPO, expand embodiment diversity, and integrate hardware control. Hold out complete robot bodies for generalization tests. Hardware progresses through read-only acquisition, shadow inference and constrained execution after simulation verification.',
 'Evaluation distinguishes baseline control, adaptation with memory, cross-embodiment generalization and hardware integration. The initial tasks establish software compatibility, model integrity and compute measurements. These results determine the subsequent scale and schedule.'
];
for(let i=0;i<p.slides.items.length;i++){
 const s=p.slides.items[i];
 for(const sh of s.shapes.items)if(sh.text)translateText(sh.text);
 for(const tb of s.tables.items){
  const spec=tableSpecs.find(x=>x.slideIndex===i);
  for(let r=0;r<spec.rows;r++)for(let c=0;c<spec.cols;c++){
   const cell=tb.getCell(r,c); translateText(cell.text);
   cell.text.style={fontFamily:'Arial',fontSize:[3,4,7,8].includes(i)?18:20};
  }
 }
 const old=String(s.speakerNotes.text||'');
 const urls=[...new Set(old.match(/https?:\/\/[^\s]+/g)||[])];
 s.speakerNotes.text=notes[i]+(urls.length?'\n\nReferences:\n'+urls.join('\n'):'');
}
if(missing.length)throw new Error('Untranslated text: '+JSON.stringify(missing));
await fs.writeFile(root+'/english-inspect.ndjson',(await p.inspect({kind:'slide,textbox,table',maxChars:1000000})).ndjson);
await (await PresentationFile.exportPptx(p)).save(root+'/candidate.pptx');
for(let i=0;i<p.slides.items.length;i++)await fs.writeFile(root+`/slide-${i+1}.png`,new Uint8Array(await (await p.export({slide:p.slides.items[i],format:'png',scale:1})).arrayBuffer()));
await fs.writeFile(root+'/english-montage.png',new Uint8Array(await (await p.export({format:'png',montage:true,scale:.5})).arrayBuffer()));
console.log('Translated and rendered '+p.slides.items.length+' slides');
