import path from 'node:path';
import {pathToFileURL} from 'node:url';
process.env.RUNTIME_NODE_MODULES='C:/Users/laiyo/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules';
const skill='C:/Users/laiyo/.codex/plugins/cache/openai-primary-runtime/presentations/26.1105.12137/skills/presentations';
const root='G:/毕设/02_learning/locoformer/go2_reproduction/.build/english_brief';
const {finalizePresentation}=await import(pathToFileURL(path.join(skill,'container_tools/artifact_tool_utils.mjs')).href);
const result=await finalizePresentation({
 workspaceDir:'G:/毕设',candidatePath:root+'/candidate.pptx',
 finalPath:'G:/毕设/02_learning/04_review/deliverables/locoformer/go2w_reproduction_brief.refined.EN.pptx',
 pythonExecutable:'C:/Users/laiyo/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe',
 integrityValidatorPath:skill+'/container_tools/inspect_presentation_package_integrity.py',
 layoutValidatorPath:skill+'/container_tools/inspect_presentation_layout_geometry.py',
 layoutArgs:['--expected-slide-size-emu','12191695,6858000','--validate-heading-fit','--cover-role','none',...[3,4,5,6,7,8,9,10].flatMap(n=>['--require-native-table-slide',String(n)])],
 explicitTotalSlideCount:10,requiredNativeTableOwnerSlides:[3,4,5,6,7,8,9,10],
 verifyArtifactToolImport:true,receiptPath:root+'/validation.json'
});
console.log(JSON.stringify({path:result.finalPath,package:result.packageIntegrity.status,slides:result.firstPartyImport.slideCount,findings:result.presentationLayout.findingCount}));
