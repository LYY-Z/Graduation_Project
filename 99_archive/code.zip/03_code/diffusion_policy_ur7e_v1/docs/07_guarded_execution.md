# Guarded first-motion execution

## 1. Scope and decision

2026-10-25 用户明确要求将推理输出接入真实机械臂，每次必须限幅和平滑，并回复确认现场看护、急停条件、机械臂/相机/线缆周围无障碍，以及激活 TCP 为 `[0,0,0.244,0,0,0]` m/rad。

本阶段是平台执行链首测，不是 Push-T 效果验证。checkpoint 只输出二维绝对推具位置，没有夹爪开度；夹爪保持原状，不建立夹爪控制连接、不激活或开合。平面映射仍未标定，只使用预测指向生成极小平面位移，高度、旋转均固定为本次起始实际 TCP。

选择单目标异步 `moveL`、到位静止后再推理；暂不选择需严格周期的 `servoL`，也不执行原始 8 步动作块。每次只取最新动作块第一项，每轮重新采集。保留原 capture/shadow；新增独立执行模块和入口，原论文源码、checkpoint、normalizer 不改。

## 2. Hard limits for this release

| 项目 | 首测硬上限 |
|---|---:|
| 单条目标相对实际位置的欧氏距离 | 1 mm |
| 全程累计命令路径长度 | 3 mm |
| 起始 TCP 周围包络半径 | 3 mm |
| 平移速度 / 加速度 | 2 mm/s / 5 mm/s² |
| 单次首测目标数量 | 3 |
| 目标平滑 | 有界位移的指数平均，系数 0.5，初值 0 |
| 高度 / 姿态 | 固定，不接受模型生成 |
| 原始观察至发送目标的最长时间 | 1.5 s；首次 GPU 预热预测丢弃 |
| 单条运动完成超时 | 3 s |
| 监控周期 | 20 ms（非安全认证实时监控） |

先对原始方向进行向量限幅，再平滑，最后重新执行单步、累计路径、起始包络约束。拒绝 NaN/Inf、维度/越界预测、过期观察、反馈停更、非正常机器人模式、非正常安全模式、TCP 偏移不符、异常速度/力变化、IK 分支大跳变、控制器安全检查不通过、超时、跟踪偏差或外部位移。失败后停止并退出，不自动恢复、不解除保护停止、不自动回起点。正常结束也不回起点。

软件约束不是碰撞规划或安全认证；现场确认和 UR 控制柜安全功能仍是必要条件。TCP 小位移不等于任意机器人姿态下所有连杆都安全，故另检查近邻 IK 和实测关节变化。

上表对应用户随后明确要求“限幅放大一点、肉眼可见”的 `MotionLimits.visible()` 档位。早期 0.2 mm/0.6 mm、平滑系数 0.2 的测试记录保留，不能与本档位混淆。新档位首步平面命令约 0.5 mm，再经相同的最终单步/累计路径/固定高度和姿态检查。`MotionLimits()` 的原保守默认值保留以便回归测试和后续选择。

## 3. Implementation plan

Goal: connect the existing policy to a separately gated, audited, bounded first-motion executor.

Architecture: pure numerical safety filter; explicit RTDE motion boundary; sequential prediction/monitor runner; persistent run artifacts. No hardware imports at module import time. Default CLI remains receive-only; live execution requires a separate explicit command and operator-readiness flag.

- [ ] Write failing numerical tests: norm rather than component limits; smoothing; NaN/Inf/bounds; total displacement budget; fixed height/rotation; source age; mode, force, joint and timestamp checks; inability to widen hard limits.
- [ ] Implement the filter and show those tests passing.
- [ ] Write failing execution-boundary tests with an injected hardware double: no call on rejection; bounded `moveL`; IK/safety rejection; actual feedback completion; timeout/interrupt/error calls stop; no automatic recovery or gripper API.
- [ ] Implement the separate execution boundary and runner; keep import/help/shadow behavior side-effect free.
- [ ] Full tests, lint, upstream/checkpoint integrity, independent review. Upload only this package with before/after hashes and backups.
- [ ] On server: receive-only preflight; real input dry-run with no control client; compare raw and filtered targets; check remote-control mode and existing controller ownership.
- [ ] Only after preflight passes: at most three fresh predicted, filtered targets. Record measured before/after poses, timing and safety state. Stop on first failed guard; download evidence and update this document.

## 4. API evidence

The report's `ur_rtde` path is retained. Official docs distinguish Receive and Control; `moveL` uses metres and rotation-vector radians and accepts speed/acceleration, with asynchronous execution allowing a monitored stop. Control creation can upload a controller program, so existing running programs must be checked before creating it.

- [ur_rtde Quick Start](https://sdurobotics.gitlab.io/ur_rtde/pages/getting_started/quick_start.html)
- [ur_rtde API](https://sdurobotics.gitlab.io/ur_rtde/pages/reference/api.html)

These pages describe 1.6.5. The receive-only server survey confirmed that the isolated inference environment also uses **ur-rtde 1.6.5** and inspected its method signatures without constructing a control client. The upstream paper's original dependency pin is not the installed deployment version.

## 5. Isolated no-retry backend

原版 `ur-rtde==1.6.5` 在控制接收线程和 `sendCommand` 的异常分支会自动重连；后者还会重发旧命令。默认命令执行等待可达 300 s，不能仅靠 Python 的 3 s 循环声称已经限制其时长。因此在实机首测前增加了**项目私有控制模块**，不替换服务器现有库，也不改变现有 conda 环境。

- 原始官方源码包：`references/ur_rtde-1.6.5.tar.gz`，SHA256 `3d5b6c6bf73346b806d146f128537abd2afb1d769f4a9c8b3ef5a884fab0bcfa`。
- 独立源码：`vendor/ur_rtde_guarded/`，保留其许可证。去掉两处自动恢复/重发路径；连接故障锁存后命令失败，旧的异步完成状态也不能再作为有效反馈。
- `MOVEL` 不等待控制脚本变为 ready，也不等待 socket 可写：不是 ready 就失败，单次非阻塞发送未完整写入整个包就失败，不排队或重试旧目标。其他控制命令 ready/ack 使用同一个浮点 steady-clock 计时起点，阈值 1 s；发送单个 RTDE 包使用 500 ms 绝对期限。异步接收超时降到 500 ms；断开不再发送需要等待回复的 pause 握手。
- `stopL`、`stopScript` 的未确认结果会抛错并记录，不能静默宣称停止成功。停止减速度与运动加速度同为 5 mm/s²。
- 私有模块名 `dp_ur7e_rtde_control`；只编译到 `runtime/control_backend/`。`artifacts/control_backend.json` 记录编译源码、二进制哈希和能力标记。`guarded_backend.py` 验证它们之后才创建控制接口；没有原 SDK 回退路径。
- 编译在 `.cache/guarded_control/` 的源码副本上进行，以免 CMake 生成头文件改变归档的私有源码。使用现有 g++/CMake/Boost 和推理 Python；没有 pip install、apt install 或修改其他人的环境。归档随包保留 vendored pybind11 2.5.0，Python3.9 编译有弃用告警；另做与原 Receive 模块共存的导入验证。

控制创建阶段尚保留上游连接/版本协商过程；此时尚无运动目标，外层有进程超时。不能把整个 TCP 初始化或普通 Linux 的调度描述为经过认证的硬实时安全机制。实际运动使用有限的极短绝对目标，不发送持续速度指令。

审计记录先落盘，然后**重新检查**反馈、静止、目标、累计限额和原始观察年龄，之后才发送。运动中的反馈先保存在内存，停止或到位后再落盘，避免磁盘卡顿阻塞正在运行的监控。到位同时要求异步完成状态变更、低速度以及相对该条位移足够小的位置误差（`min(50 µm, 0.4 × 目标距离)`），不能以零位移误判 40 µm 首条命令完成。

## 6. Manual entry points

使用已隔离的 inference Python 和原手册中的 ROS 相机桥接。`--config` 应指向本次 `runs/` 内的配置快照，图像路径必须由本次桥接更新，禁止复用旧帧。现场确认后在该快照内设置 `robot.active_tcp_offset_verified_on_pendant: true`；实际控制器 TCP 还会逐条读回核对，代码不调用 setTcp。

```bash
# 默认预演：只读状态+模型预测+数值过滤，不创建控制客户端
.envs/inference/bin/python -m dp_ur7e.execution --config /absolute/path/to/trial.yaml

# 现场看护、急停与空间/TCP 条件确认后才使用
.envs/inference/bin/python -m dp_ur7e.execution --config /absolute/path/to/trial.yaml --execute --site-ready
```

首轮 GPU 预测只作预热并丢弃，之后重新采集两帧，检查所有图像（包括 ROS 回调前延迟）及对应机器人状态中的最早有效时间。每条新预测只选择 `action[0,0]`，不是 `action_pred` 中可能对应历史时刻的首项。每条运动结束、静止后才产生下一条目标，最多三条，不自动重跑或回到起点。`runtime/guarded_execution.lock` 防止本包两个执行器同时工作；控制柜正常/空闲/远程模式还需读回验证。

## 7. Evidence

早期首次预演：服务器原权重生成了 3 条过滤目标；没有创建控制客户端或下发指令。源代码随后经过审查修正，因此首轮预演不是后续修改版本的实机放行证据。

2026-10-25 首次 live 在 `moveL` 确认处失败，记录于 `runs/guarded_execution/20261025T084508Z_live/`，没有确认完成的运动。程序停止、退出，没有自动重发。检查控制状态协议后，在所有 IK/安全查询之后增加 `output_int_register_0` 的 ready 读回：连续稳定 20 ms、总等待不超过 300 ms；**等待发生在最终新鲜度/位姿/限幅检查之前**。native 仍不排队运动。增加两项就绪时序回归，本地 104 项通过；新版本必须重新预演，并使用全新观察/预测开始一次新 live，不能重用失败目标。

第二次 live `20261025T084946Z_live` 在发送前失败：原 Receive API 的 `getOutputIntRegister()` 只支持 [12,19]，即使订阅寄存器 0，也不能用该 getter 读取。最终修正为在私有 Control 模块暴露已有的**缓存只读** `guarded_ready()`，由控制模块自身读取其状态寄存器，避免跨连接时序差。没有扩大原库的任意寄存器写权限。私有模块重建、哈希和导入检查成功，未替换原环境库。新增可见档位回归后本地 105 项通过。

**最终实机验收通过：** `20261025T085457Z_live` 完成 3 条真实运动，命令距离分别为 0.5004/0.7740/0.8446 mm，实测起止位移为 0.4950/0.7510/0.8314 mm，到目标误差均小于 0.05 mm。累计命令距离 2.1190 mm，净实测位移 2.0223 mm；每条都通过状态、新鲜度、限幅、IK/控制柜安全检查以及异步完成和连续到位反馈。执行、桥接、本次相机驱动均正常退出，无自有残留，主配置/其他环境元数据未变。夹爪保持不动。详见 [完整验收记录与输入输出](../runs/guarded_execution/20261025T085457Z_live/README.md)。
