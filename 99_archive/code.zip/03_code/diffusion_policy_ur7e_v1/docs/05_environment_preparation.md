# 05 服务器独立环境准备记录

日期：2026-10-24。当前状态：**独立环境安装与不接设备的检查已通过**。服务器安装脚本退出码 0；`pip check` 通过，纯适配层测试 47 项通过。未加载模型、未运行推理、未启动或连接设备。证据见 `artifacts/environment/verification.json`、`tests.txt` 与本页完成记录。

## 1. 本轮授权与边界

原部署准备阶段仅上传文件。本轮用户进一步授权在服务器准备与现有环境隔离的运行环境，因此可以执行本项目的环境安装与依赖检查。仍不构建模型、不读取 checkpoint pickle、不运行推理、不启动相机或 ROS 节点、不连接控制柜、不下发运动或夹爪命令。

本次所有软件安装目标均在：

```text
/home/robotic_arm/lyy_ws/diffusion_policy_ur7e/
  .envs/inference/              新建 conda 环境
  .cache/conda_pkgs/            本项目 conda 下载/解包缓存
  .cache/pip/                   本项目 pip 缓存
  .cache/tmp/                   安装临时文件
  .cache/xdg/                   工具缓存
  artifacts/environment/        解决方案、安装日志、版本与隔离检查结果
```

使用现有 conda 命令创建新前缀；不在 conda base、`libero-agent`、`env_ur7e_example_code` 或 ROS 系统 Python 中安装/升级包。没有使用 sudo/apt，没有升级 GPU 驱动或系统 CUDA。conda 可能按自身机制登记新的前缀；这与修改已有环境的安装包不同。

这里的“环境”是一套独立的 Python 解释器和第三方库，不是重装服务器，也不是创建另一套机械臂控制系统。模型使用本项目 Python；相机桥接使用已有 ROS 系统 Python，二者通过 NPZ 文件交换图像，不把 ROS 的 Python 包混进模型环境。

这是**软件依赖隔离，不是硬件资源隔离**：磁盘、CPU、GPU 和内核驱动仍由服务器上的进程共享。安装占用本项目磁盘空间；将来人工运行推理前还需检查 GPU 使用情况，再决定使用哪张卡，不能据此宣称其他任务完全不受资源占用影响。

## 2. 服务器先验检查

只读检查得到：Ubuntu 22.04.5 LTS；两张 Quadro RTX 6000，各 24576 MiB，计算能力 7.5；驱动 580.142；conda 26.9.3；项目所在磁盘有约 358 GiB 可用空间。检查时目标 `.envs/inference` 不存在。

模型环境采用原论文主要版本：Python 3.9、PyTorch 1.12.1、torchvision 0.13.1、CUDA runtime 11.6、NumPy 1.23.3、diffusers 0.11.1、robomimic 0.2.0。最终实际安装版本由环境导出文件确认，不能仅凭 YAML 声称已安装。

额外兼容性约束：`huggingface-hub==0.25.2` 保留旧 diffusers 所需接口；`mkl==2023.1.0` 避免旧 PyTorch 与新 MKL 的已知 `iJIT_NotifyEvent` 导入冲突。参见 [PyTorch 历史版本说明](https://pytorch.org/get-started/previous-versions/) 和 [上游 MKL 问题记录](https://github.com/pytorch/pytorch/issues/123097)。参考技术报告新增的 [ur_rtde 官方接口文档](https://sdurobotics.gitlab.io/ur_rtde/)，本环境固定 `ur-rtde==1.6.5`；这不是声称技术报告指定了该版本。

## 3. 隔离方法

`scripts/prepare_environment.sh` 使用绝对环境前缀与该前缀下的 `bin/python -m pip`，不会调用模糊的系统 pip。设置 `PYTHONNOUSERSITE=1`，清除继承的 `PYTHONPATH`、`PYTHONHOME` 和 `LD_LIBRARY_PATH`，避免其他项目或 ROS 的 Python 路径进入模型环境。

conda 配置通过进程变量指向 `configs/conda-isolated.yaml`，不写入用户 `.condarc`。关闭自动更新 conda，使用项目独有缓存并复制包。具体包源以 `solve_plan.json` 和实际 `conda-explicit.txt` 为准；不能把配置文件中的源列表当作安装结果。没有改 `.bashrc`、`.profile` 或设置自动激活。

开始前，`check_environment.py baseline` 对现有 base 与两个命名环境的 `conda-meta` 文件逐一记录哈希，同时记录用户和 base 的 conda 配置及 `.bashrc` 哈希。结束后再次计算并比较；差异不会被自动覆盖或还原，而会导致检查报错并保留证据。

## 4. 检查范围

* `pip check`：安装依赖一致性。
* 依赖导入：NumPy、SciPy、OpenCV、PyYAML、PyTorch、torchvision、diffusers、robomimic、Hydra、dill、einops、RTDE Receive 扩展。
* 导入原论文两种 policy 的类定义，不实例化类，不调用 `torch.load`。
* 确认所有上述第三方依赖来自新环境前缀，用户 site-packages 被禁用。
* 查询 CUDA 可用性、设备名称、计算能力和 PyTorch 编译架构，不执行神经网络前向或 GPU 计算基准。
* 在独立子进程运行纯适配层测试和 `dp_ur7e inspect`；inspect 只校验配置和文件哈希。
* 使用 `/usr/bin/python3` 和 ROS Humble 现有路径检查相机桥接所需库能否导入；不调用 `rclpy.init`、不创建节点、不订阅话题，不安装 ROS 系统包。

## 5. 证据文件

`protected_before.json`、`protected_after.json`：旧环境和用户配置的比较依据；只存文件哈希，不保存配置中的潜在密钥。

`solve_plan.json`、`install.log`、`adapter_install.log`：求解、安装和适配包 editable 安装结果。

本次恢复安装另保留 `cuda_archive_recovery.json`、`cache_recovery.log`、`conda-solved-explicit.txt`、`install_resumed.log` 和 `pip_install.log`。原 conda-forge CUDA 包下载仅约几十 KB/s；TUNA 镜像小段测试明显更快，因此仅中断本项目本次下载，保留原求解版本与已有缓存。627,909,365 字节的 CUDA 11.6.2 包经完整 SHA-256 核验后使用；哈希为 `5990db3504da9ffc8656c86b3684db9aec25a6462c966e37d0c046fc5745e574`。不是换成其他版本，也不是改系统 CUDA。镜像使用依据为 [TUNA Anaconda 说明](https://mirrors.tuna.tsinghua.edu.cn/help/anaconda/)，但没有按其示例修改用户 `.condarc`。

恢复时 conda 离线模式起初不能将手工下载的归档识别为已登记缓存，因此改用已核验归档的 `file://` URL，继续离线安装原求解的 266 个 conda 包。`conda-solved-explicit.txt` 和最终 `conda-explicit.txt` 中 CUDA 条目可能包含服务器本地缓存路径；跨机器复现时需要先按恢复记录取回并校验此归档，不能把这个路径当作公共下载地址。

最初 ROS 只读预检查还记录了一次 `AMENT_TRACE_SETUP_FILES: unbound variable`：它来自 Bash `set -u` 与 ROS setup 脚本的兼容性，不等于 ROS 缺包。后续 ROS 检查在子进程中关闭 nounset，再导入现有 ROS 库；最终结果以 `ros_imports.json` 为准。

首次类定义导入检查在上游 `model/common/normalizer.py` 报 `ModuleNotFoundError: No module named 'zarr'`。即使不训练、也不调用 normalizer.fit，Python 仍会执行文件顶部的 `import zarr`。因此补回上游原规格中的 `zarr==2.12.0` 与 `numcodecs==0.10.2`，只安装到新环境；没有为绕过检查修改上游 normalizer，也没有加载模型来“试试看”。

`verification.json`、`ros_imports.json`、`pip_check.txt`、`tests.txt`、`inspect.json`：依赖/隔离/CUDA/测试检查结果。

`conda-explicit.txt` 和 `pip-freeze.txt`：实际安装环境导出，供复现使用。它们比未安装前的候选 YAML 更具体。

## 6. 准备完成后怎样使用

模型环境的手动激活形式为（在模型专用终端使用，不在相机 ROS 终端使用）：

```bash
DP_ROOT=/home/robotic_arm/lyy_ws/diffusion_policy_ur7e
unset PYTHONPATH PYTHONHOME LD_LIBRARY_PATH
export PYTHONNOUSERSITE=1
source /home/robotic_arm/miniconda3/etc/profile.d/conda.sh
conda activate "$DP_ROOT/.envs/inference"
cd "$DP_ROOT"
```

退出用 `conda deactivate`。相机桥接继续使用独立终端中的 ROS 系统 Python，按文档 03 操作。环境检查通过不等于已完成模型加载、实时传感器连接或真实任务效果验证；这些仍留给后续人工验收。

如果以后要增加依赖，只在确认 `python -c 'import sys; print(sys.prefix)'` 输出本项目 `.envs/inference` 后，用 `python -m pip` 操作，并先记录新旧版本。不要使用 `sudo pip`、系统 pip 或在 base 中安装。若出现错误，先保留完整 traceback 和当前导出文件，不通过升级团队共享环境来试错。

## 7. 本次完成结果

服务器独立前缀为 `/home/robotic_arm/lyy_ws/diffusion_policy_ur7e/.envs/inference`，Python 3.9.18。PyTorch 查询得到 CUDA 可用，runtime 版本为 11.6，并识别到两张 Quadro RTX 6000，计算能力均为 7.5。此结果只证明依赖可导入、驱动/设备可被查询，不等于 GPU 算子、checkpoint 加载或任务推理验证。

`pip check` 输出 `No broken requirements found.`；两个上游图像策略模块的类定义导入成功，但没有构造模型。服务器纯适配层测试输出 `47 passed in 0.27s`。`dp_ur7e inspect` 完成配置、输入契约与 checkpoint 文件哈希检查，不加载权重对象。

已有 base、`libero-agent`、`env_ur7e_example_code` 共三个环境的 `conda-meta` 安装记录哈希前后一致；保护范围内的用户 `.bashrc`、`.condarc` 与 base `.condarc` 状态前后一致。检查记录是包管理元数据层面的对比，不夸大为全磁盘逐文件审计。

ROS 桥接所需现有库在 `/usr/bin/python3` 中导入成功：rclpy / sensor_msgs 来自 ROS Humble，NumPy 1.21.5、PyYAML 5.4.1、OpenCV 4.5.4 来自系统包。没有重装这些库，没有创建 ROS 节点。

后续仍按文档 03 依次做现场配置核对、相机桥接、capture 和人工允许的 shadow。**本轮到此停止，不自动开始下一阶段。**
