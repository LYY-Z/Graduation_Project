# UR7e single-wrist-camera adaptation implementation plan

Date: 2026-10-24. Status: local implementation/verification complete; actual server staging result is recorded in `artifacts/staging_receipt.json`. Execution: local preparation followed by SFTP staging only.

## Goal and constraints

Prepare an independently copied Diffusion Policy codebase, a read-only UR7e/Gemini 335L adapter, an official Push-T checkpoint, and a reproducible manual runbook. The user authorized implementation and staging in `/home/robotic_arm/lyy_ws`; no additional design gate is needed. No model inference is permitted locally. No project, ROS node, dependency installation, or robot program is to run remotely during preparation. Remote filesystem inspection and file transfer use SFTP.

## Architecture and file ownership

* `upstream/`: byte-preserving copy of tracked files from local upstream revision `5ba07ac6661db573af695b419a7947ecb704690f`.
* `src/dp_ur7e/`: configuration, coordinate conversion, image decoding, timestamped history, atomic frame exchange, receive-only RTDE access, checkpoint loading, logging, and explicit manual CLI.
* `configs/platform.yaml`: current platform and engineering input mapping; inferred and verified values are distinguished.
* `models/`: official image Transformer checkpoint and original config, provenance and SHA-256.
* `references/`: latest technical report and selected current server source/configuration snapshots, with origin metadata.
* `tests/`: local numerical/contract tests only; no checkpoint loading, inference or hardware access.
* `docs/`: design/evidence, implementation record, manual runbook, validation limits.
* `artifacts/`: preparation test record, upstream preservation and file manifests. Runtime outputs are under `runs/` only after manual execution.

## Tasks

- [x] 1. Read all 12 report pages; collect current relevant server files. Record discrepancies, not just defaults.
- [x] 2. Copy tracked upstream files without altering the original. Fetch official sidecar configs.
- [x] 3. Write failing tests for TCP conversion (including nonzero rotation), image stride/encoding, coordinate scale, timestamp freshness and causal alignment, atomic storage and output contracts.
- [x] 4. Implement pure adapters and receive-only RTDE wrapper; run local contract tests.
- [x] 5. Implement explicit ROS camera bridge, checkpoint loader and manual shadow runner. All hardware and ML imports are lazy; no initialization during import.
- [x] 6. Complete checkpoint download, size/ZIP CRC/hash verification without deserialization.
- [x] 7. Write detailed Chinese documentation and manual commands; record what was and was not validated.
- [x] 8. Review the complete adapter, fix consequential defects, run local tests and static checks, verify original/copy hashes.
- [x] 9. Prepare the SFTP-only staging procedure and manifest. Completion of the transfer itself is certified only by `artifacts/staging_receipt.json`; no remote application is run.

## Review focus

1. Active TCP differs from report TCP: apply `T_base_active @ inverse(T_flange_active) @ T_flange_report`, never add 244 mm twice.
2. ROS frame timestamps and RTDE controller uptime use different clocks: align host monotonic acquisition times and retain native timestamps as evidence.
3. Repeated/old sensor data: controller packet timestamp and frame sequence must advance; reject stale, future or skewed observations.
4. Simulation pixel coordinates are not metres: reversible engineering mapping is explicitly uncalibrated and outputs never enter a motion controller.
5. Existing source/config contains provisional values and gripper inconsistencies: report evidence and server evidence remain independently traceable.

## Execution record

* Source copy and report snapshot created locally; original Git status clean.
* SSH public-key authentication unavailable; password used interactively, never persisted in this package.
* Ruling: use official image Transformer checkpoint (412,727,949 bytes) as the initial prepared model. The image CNN checkpoint is approximately 4.29 GB and single-connection transfer was slow. Both expose the same observation/action schema; architectural performance is not being compared here.
* Ruling: no automatic environment installation or hardware startup scripts. Only explicit manual commands will be documented, as required by the user.
* Ruling: retain the user-requested physical source copy rather than substituting a shared Git worktree. Original-source preservation is checked by hashes; no original files are edited.
* Local adapter tests: 47 passed after the review regression fixes. No checkpoint deserialization or neural inference was performed.
* Final review: one independent read-only reviewer. Startup cache poisoning was reproduced and fixed. Metadata creation time and integer prediction limit defects were also reproduced and fixed. The whole suite is green after the fixes.
* Review boundaries: runtime model loading, live ROS/RTDE behavior, physical calibration, motion execution and target GPU compatibility are deliberately unverified under the user's no-execution constraint. Final docs and staging are verified by the implementer, not claimed as independently hardware-tested.
