# 02 代码与实现记录

## 1. 模块组织

代码位于 `src/dp_ur7e/`。包导入、CLI `--help` 和 `inspect` 都不会创建 ROS 节点、RTDE 连接或模型。硬件和深度学习依赖放在明确的运行函数内延迟导入。

| 模块 | 单一职责 | 关键接口 |
|---|---|---|
| `config.py` | 读取并校验配置、将路径固定到项目根目录 | `load_config(path)` |
| `geometry.py` | UR 位姿变换、报告 TCP、二维工程映射 | `pose_matrix`、`report_tcp_position`、`PlanarMapping` |
| `images.py` | ROS Image 字节解码、裁剪缩放、CHW float 转换 | `decode_rgb_image`、`resize_for_policy`、`image_tensor` |
| `frame_store.py` | 完整帧和元数据的原子文件交换 | `CameraFrame`、`FrameStore` |
| `camera_bridge.py` | 系统 Python 中订阅 RGB 话题并产出帧文件 | `run_camera_bridge(cfg)` |
| `robot.py` | 显式创建 Receive 客户端，读取和转换机械臂状态 | `ReceiveOnlyRobot.connect/read/close` |
| `observations.py` | 去重、新鲜度检查、因果选样和观测张量 | `RobotSample`、`ObservationHistory` |
| `session.py` | 并发采集、异常传递、资源关闭 | `SensorSession` |
| `model.py` | checkpoint 哈希、结构契约、EMA 参数加载 | `load_policy`、`validate_model_config`、`validate_predictions` |
| `recording.py` | 独立会话目录、事件与观测归档、候选位置预览 | `RunWriter`、`preview_actions` |
| `runner.py` | 手动 capture/shadow 主循环 | `run(cfg, inference=...)` |
| `cli.py` / `__main__.py` | 命令分派 | `python -m dp_ur7e ...` |

上游副本没有被注入这些逻辑。加载器使用 `upstream/` 的原 policy 类，而不调用 `eval_real_robot.py`、`RealEnv` 或原来的机械臂插值控制器。后者的初始化可能创建控制客户端，不能拿来当纯状态读取器。

## 2. 机械臂数据边界

状态客户端仅请求以下 RTDE 输出：

```text
timestamp          控制柜启动至今的秒数
actual_TCP_pose    当前激活 TCP 位姿，6 个数，米/旋转向量弧度
actual_q           6 个实际关节角，弧度
safety_mode        控制柜报告的模式编码
robot_mode         控制柜报告的机器人模式编码
```

读取单个样本时，在若干 getter 前后各取一次 `timestamp`；如果期间更换了包，就重试，最多 5 次。这用于减少同一软件样本混入不同包的字段，不把它称为控制柜提供的原子快照或硬件同步。状态请求频率是 125 Hz，主机的 Python 采样间隔也按此设置，实际速率由以后运行记录确认。

`RobotSample` 保留：主机 monotonic 接收时间、原始控制柜时间、报告 TCP 三维位置、原始激活 TCP 六维位姿、关节角和模式。浮点数必须有限，维度必须正确。

报告 TCP 变换见文档 01。代码使用 Rodrigues 公式将 UR 旋转向量转为矩阵，处理零旋转和半周旋转；计算 `T_base_active @ inverse(T_flange_active) @ T_flange_report` 后取平移，不重复补偿工具长度。

## 3. 相机数据边界

采用 ROS 的 `sensor_msgs/Image` 输入，支持 `rgb8` 和 `bgr8`。代码明确使用 `height`、`width`、`step`，先按每行真实字节长度解码，移除行末 padding；BGR 再换成 RGB。缓冲区长度或 stride 不一致、编码不支持就拒绝。

没有配置 ROI 时使用中心正方形裁剪，再以 OpenCV `INTER_AREA` 缩放到 96×96。可以把 `roi_xywh` 配成 `[x,y,width,height]`，但必须在原图范围内。这个选择是工程预处理，不等于论文训练图像视角；若目标经常离开裁剪区域，应先调整 ROI 或相机安装并保存配置版本。

桥接帧保存 `rgb` uint8 数组，以及 sequence、stream UUID、主机接收时间、ROS header 时间、光学 frame_id、原图大小、原图编码、ROS 接收时的数据年龄。最后送入策略时才转成 RGB CHW float32 并除以 255。

`FrameStore` 以普通数值数组和 JSON 字符串存 NPZ；读取 `allow_pickle=False`。临时文件完成 flush/fsync 后通过 `os.replace` 发布，读取方不会把半帧当作完整输入。

## 4. 观测组织和同步

相机桥接进程和模型进程必须在同一服务器运行，共用 monotonic 时基。不得将桥接运行到 Windows 本地后，直接把其 monotonic 时间与 Linux 的状态时间比较。

构造 `T_o=2` 的窗口时，主线程先排空两个采集队列，更新历史，再取最新图像对应的两个 10 Hz 目标时刻。每个目标选最近且不晚于目标的图片；每张图选不晚于图片接收时刻的机械臂状态。输出：

```text
image       float32 [B=1, To=2, C=3, H=96, W=96]
agent_pos   float32 [B=1, To=2, D=2]
```

`agent_pos` 中每帧的 TCP 对应自己的图像时刻，不能把最新一个 TCP 复制给两张历史图。`n_obs_steps` 不能靠复制同一帧满足。采集线程会在主线程进行推理时继续收集数据，防止下一轮只能拿到两张相隔一整次推理时长的图。

错误处理：

| 情况 | 行为 |
|---|---|
| 首次运行尚无帧文件 | 等待，相机桥接可在启动等待期内提供数据 |
| 磁盘有旧帧 | 过期帧在采集端丢弃，不污染启动历史 |
| 首个有效观测前相机流更换 | 清除旧的临时图片历史，接纳新 stream |
| 已成功形成观测后相机桥接重启 | 拒绝混合两个 stream，要求重启本轮采集/影子会话 |
| 控制柜 timestamp 重复 | 不把重复包当新状态 |
| 控制柜 timestamp 倒退 | 报错，由操作者重启采集 |
| 图像 ROS header 不前进、已经过期或超前太多 | 相机桥接报错退出 |
| 历史不足、时差过大或过期 | 暂不生成模型输入；超过等待时限退出并记失败 |
| 维度、编码、NaN/Inf、未知模型类不对 | 拒绝并记录，不隐式补齐 |

## 5. 模型加载和动作含义

`load_policy` 先核对 `models/checkpoint_manifest.json` 中的字节数和 SHA-256，再调用官方 policy 类。仅支持原仓库的 U-Net hybrid image 与 Transformer hybrid image 两种类；当前权重对应后者。

当前 checkpoint 的 `T_p=10`；CNN 官方配置的 `T_p=16` 只作为另一个变体参考。实现不把时域写死到 16。原 policy 已经从 `action_pred` 中选取 `action`，所以 runner 直接记录两者，不再次从第零步做不一致的切片。

`use_ema=true` 时必须找到 `state_dicts.ema_model`；不静默退回随机初始化或另一个权重。`strict=True` 会检查参数键和形状。normalizer 跟随权重加载，其状态中含训练数据的尺度；图像 `[0,1]` 和仿真像素 `agent_pos` 作为原始输入交给它处理。

推理使用 `policy.eval()` 和 `torch.inference_mode()`，保留官方噪声日程、100 个推理迭代和 sampler。没有把 DDPM 改成 DDIM，也没有为了“更快”临时更换系数。后续如果比较加速，应单独版本化配置并记录实际 sampler 和步数。

预测的二维坐标仍是仿真尺度。`preview_actions` 保存所有原始二维预测，对 0–512 外的候选标记 false 并将逆变换置 null，不裁剪伪装成合理动作。范围内的逆变换也只是未标定的三维日志预览。没有机械臂命令队列、发送端或执行类。

## 6. 运行记录

每次 capture/shadow 新建 `runs/<UTC时间>_<短UUID>/`：

```text
metadata.json       配置快照、环境版本、映射原点、模型配置、哈希、TCP 核验状态
events.jsonl        逐事件、逐预测记录；executed 始终为 false
observations/       需要时保存传给 policy 的两帧数值输入，普通 NPZ
  000000.npz
  000001.npz
```

事件中包含图像序号、原图尺寸、三个时钟的时间、主机采集偏差、TCP、关节、模式、原始动作、预测耗时及结束时图像年龄。`created_utc` 在会话元数据更新后仍保留。记录的 Python/依赖版本来自已安装包元数据，而不是假定环境文件已经生效。

未调用在线 wandb、训练器或 Agent/MCP。后续整理实验时，每次会话应连同发布文件清单、平台配置和操作条件归档。

## 7. 实现过程记录

1. 完整阅读最新 12 页报告，并核对第 3 页表格的 TCP/单位/频率。
2. 以只读文件访问重新获取当前服务器示例、相机 launch、平台配置和标定材料；没有运行其中的示例。
3. 复制本地原仓库的全部 Git 跟踪文件，保留提交、许可和逐文件哈希。
4. 先写纯数据契约测试，再实现 TCP、图像、原子文件、坐标映射和时间窗；初始测试因适配模块尚不存在失败，随后通过。
5. 增加只读状态适配、手动入口、EMA 加载、并发采集、记录和模型输出校验；没有调用模型加载函数。
6. 下载官方权重，使用验证过的 HTTP byte range 重组，校验字节数、完整文件 SHA-256 和 ZIP CRC；没有反序列化 checkpoint。
7. 图像预处理测试暴露本机 NumPy 2.0.2 与 OpenCV 4.8.1 二进制不兼容；仅在准备工具依赖目录装入 NumPy 1.23.5，未改本机全局 Python 或服务器环境。项目推理规格沿用 NumPy 1.x。
8. 独立只读代码审查发现启动旧帧阻碍新流接入的问题；以旧/新 stream 回归测试复现后修复，已有效观测后的重启保护仍保留。
9. 一并以回归测试修复元数据更新时间丢失和预测次数浮点截断问题。
10. 最终数值/接口测试、静态检查和上游/模型/发布清单检查结果见 `artifacts/`；随后只通过 SFTP 放入 `lyy_ws` 并逐文件读回校验。

实现测试中的 RTDE double 只模拟已知 getter 的数值边界，不模拟控制调用；测试不加载神经网络，因此不能替代后续真实环境的连接与推理验收。
