# 03 手动运行手册

下列是独立环境中的手动操作步骤，不会自动执行。初次准备仅上传文件，之后分别获准安装环境、测试设备和运行推理。2026-10-25 已完成 capture 与 1+5 次 shadow，结果及退出告警见 [文档 06](06_inference_validation.md)；从未下发机械臂或夹爪动作。建议按本页顺序逐级确认，保留输出，不把所有命令一次性粘贴执行。

## 0. 文件位置与包完整性

在服务器新终端：

```bash
DP_ROOT=/home/robotic_arm/lyy_ws/diffusion_policy_ur7e
cd "$DP_ROOT"
/usr/bin/python3 scripts/verify_bundle.py --zip-crc
```

此步骤仅需 Python 标准库：检查发布文件清单、复制上游、checkpoint 大小与哈希、ZIP CRC 和适配代码语法。预期 `model_loaded=false`、`inference_run=false`、`hardware_connected=false`。

`artifacts/staging_receipt.json` 是传输结束时生成的回执；`artifacts/file_manifest.json` 是发布内容清单。回执和清单自身因避免循环哈希，不放进内容清单。

## 1. 独立模型环境

`environment.inference.yml` 是推理依赖规格：保留原论文 PyTorch/torchvision/diffusers/robomimic 的主要版本，省去只在仿真/训练/原 RealSense 路径中使用的依赖。后续独立环境安装记录见文档 05；实际导出版本保存在 `artifacts/environment/`，YAML 本身不等同于完整环境锁文件。

已准备的模型环境采用工作空间独立前缀。不要在团队已有环境重新安装依赖。打开干净终端后激活：

```bash
DP_ROOT=/home/robotic_arm/lyy_ws/diffusion_policy_ur7e
unset PYTHONPATH PYTHONHOME LD_LIBRARY_PATH
export PYTHONNOUSERSITE=1
source /home/robotic_arm/miniconda3/etc/profile.d/conda.sh
conda activate "$DP_ROOT/.envs/inference"
cd "$DP_ROOT"
```

若需重新准备或复查环境，使用 `bash scripts/prepare_environment.sh` 或 `bash scripts/prepare_environment.sh --verify-only`；脚本只针对上述独立前缀，不应把安装命令换到 base 中。日常可以先手动检查解释器和基础依赖，不运行模型：

```bash
python -c 'import sys,numpy,torch,torchvision,diffusers,robomimic,yaml; print(sys.version); print(numpy.__version__,torch.__version__,torchvision.__version__,diffusers.__version__); print("CUDA available:",torch.cuda.is_available())'
python -m dp_ur7e inspect --config "$DP_ROOT/configs/platform.yaml"
```

`inspect` 读取官方配置和文件哈希，不反序列化或实例化模型。不要用旧 `eval_real_robot.py` 来替代这一检查。若 CUDA 不支持当前 GPU，先记录 GPU、驱动和版本错误，再为本工作空间确定新的兼容依赖；不要直接升级其他人的环境。

若 pip 报 diffusers 的 `cached_download` 导入错误，核对 `huggingface-hub==0.25.2` 是否真的安装在当前解释器中；该 pin 是旧 diffusers 兼容性安排。若出现 NumPy ABI 报错，先核对 `numpy<2` 和 OpenCV，而不是修改图像算法。

纯适配层测试可手动运行：

```bash
cd "$DP_ROOT"
python -m pytest -q
```

pytest 的根配置只收集 `tests/`；不收集上游包含真实设备访问的测试目录。测试不加载 checkpoint。

## 2. 核对平台配置

打开 `configs/platform.yaml`，确认 IP、图像话题、光学 frame 和 TCP 声明与现场相符。默认值源自报告和服务器代码，不是本轮的现场测量结果。

示教器当前激活 TCP 若为 `[0,0,244] mm`、旋转 `[0,0,0]`，可在核对后将 `active_tcp_offset_verified_on_pendant` 设为 true。若实际偏移不同，应将实际值换算为米/旋转向量弧度，填写 `declared_active_tcp_offset_m_rad`。`report_tcp_offset_m_rad` 保持报告目标值。只改 YAML 不会设置机器人 TCP。

默认映射将每次会话首个报告 TCP 放到 `[256,256]`，比例 `1000 px/m`。本次 capture/shadow 运行期间应保持机器人静止，先验证数据链路。默认比例和轴方向是工程选择，未做桌面标定。不要为了让日志“更好看”静默改比例或裁剪预测。

## 3. 相机 ROS 环境与话题

另开终端 A，使用 ROS 系统 Python，不激活模型 conda 环境：

```bash
DP_ROOT=/home/robotic_arm/lyy_ws/diffusion_policy_ur7e
source /opt/ros/humble/setup.bash
export PYTHONNOUSERSITE=1
export PYTHONPATH="$DP_ROOT/src${PYTHONPATH:+:$PYTHONPATH}"
/usr/bin/python3 -c 'import rclpy,numpy,yaml,cv2; print("ROS RGB bridge dependencies import successfully")'
ros2 topic list -t
ros2 topic info /wrist_camera/color/image_raw --verbose
```

如果当前 driver 已经提供话题，不再启动第二个相机 driver。如果确实未启动，应在已验证的 Orbbec ROS 环境中由操作者启动**单只腕部相机**。服务器已有双相机 launch 的两个序列号不可原样照搬；根据其使用的官方 launch，单相机候选命令为：

```bash
ros2 launch orbbec_camera gemini_330_series.launch.py \
  camera_name:=wrist_camera serial_number:=CP285630005V \
  device_num:=1 depth_registration:=true
```

这是待现场确认的启动命令，未在本轮执行。若 `orbbec_camera` 不在当前 overlay 中，使用原来已验证的驱动工作空间环境，不改动安装或重装 SDK。当前模型只消费 RGB；开启深度配准不代表模型使用深度。

在另一个已 source ROS 的终端运行桥接（或将上述 driver 留在独立终端）：

```bash
DP_ROOT=/home/robotic_arm/lyy_ws/diffusion_policy_ur7e
source /opt/ros/humble/setup.bash
export PYTHONNOUSERSITE=1
export PYTHONPATH="$DP_ROOT/src${PYTHONPATH:+:$PYTHONPATH}"
/usr/bin/python3 -m dp_ur7e camera-bridge \
  --config "$DP_ROOT/configs/platform.yaml"
```

成功时会持续原子更新 `runtime/wrist_rgb.npz`。桥接不创建机器人连接，也不启动相机驱动。若 frame_id 不匹配、ROS 时间戳过期或编码不支持，程序报错退出；先核对实际消息和配置。不要把一个错误 frame 名称改成“看起来像正确”的值而不核实来源。

## 4. 先 capture，再手动允许推理

终端 B 激活模型环境，保留终端 A 的桥接：

```bash
DP_ROOT=/home/robotic_arm/lyy_ws/diffusion_policy_ur7e
unset PYTHONPATH PYTHONHOME LD_LIBRARY_PATH
source /home/robotic_arm/miniconda3/etc/profile.d/conda.sh
conda activate "$DP_ROOT/.envs/inference"
export PYTHONNOUSERSITE=1
python -m dp_ur7e capture --config "$DP_ROOT/configs/platform.yaml"
```

capture 只连接 RTDE Receive，读取状态并保存一组满足两帧/10 Hz/新鲜度条件的模型输入；不加载 checkpoint。会话默认最多等待 20 s 形成有效观测。成功后检查 `runs/<session>/metadata.json`、`events.jsonl` 和 `observations/000000.npz`。

重点检查图像是否包含目标、裁剪是否正确、两帧序号不同、图像原生时间和接收时间合理、TCP 数值/单位与示教器相符、`agent_pos` 是否接近会话锚点。不能仅凭张量维度正确，就认为坐标标定或任务感知已正确。

之后若操作者决定手动开始影子推理，运行：

```bash
python -m dp_ur7e shadow --config "$DP_ROOT/configs/platform.yaml"
```

**这条命令会真正加载模型并推理。** 默认最多记录 20 轮，最大会话时间 120 s。保留原 sampler 和 100 次 DDPM 迭代。它不创建控制客户端，所有记录 `executed=false`。

当前 release 没有自动启动服务、后台守护、定时任务、ROS publisher 或动作接口。退出本包程序不会给其他已有机器人程序发 stop 指令；本包从未取得机械臂控制权。

## 5. 日志解释

每轮记录 `inference_s`，以及预测结束时最新图像的年龄。不能将其中的推理耗时称为完整端到端控制时延，因为它不含真正执行反馈。`preview.raw_action_px` 是 checkpoint 原始动作段；`unverified_base_xyz_m` 是工程逆映射预览，尚不是可执行 TCP 指令。

| 现象 | 优先检查 |
|---|---|
| 等待帧文件 | camera-bridge 是否运行、是否同一主机与同一 `DP_ROOT` |
| optical frame 不匹配 | 实际 Image header、相机 namespace、配置 |
| ROS header 过期 | driver 时间设置、ROS 时钟、消息堆积 |
| 图像/状态 skew 太大 | 摄像头和 RTDE 的实际接收速率、主机负载；记录后再考虑调整阈值 |
| 状态 timestamp 不前进 | RTDE 状态连接是否仍在更新 |
| bridge 重启提示 | 停止并重新启动当前 capture/shadow 会话，避免混合两个流 |
| normalizer/参数 shape 不匹配 | 是否换了权重但未对应配置和源码，禁止 `strict=False` 掩盖 |
| 预测超出工程范围 | 保留失败输出，检查输入与映射；不直接裁剪后执行 |

## 6. 环境与实验快照

第一次人工成功运行后，在本工作空间保存真实环境版本：

```bash
mkdir -p "$DP_ROOT/runs/environment"
conda list --explicit > "$DP_ROOT/runs/environment/conda-explicit.txt"
python -m pip freeze > "$DP_ROOT/runs/environment/pip-freeze.txt"
```

初次环境安装的实际导出在 `artifacts/environment/`。上面的 `runs/environment/` 用于后续人工实验时另存当时版本；不要覆盖初次安装证据。
