# 01 设计与证据

## 1. 本阶段要解决的问题

目标是建立可复核的部署基础：从 Gemini 腕部相机获得真实 RGB，从 UR7e 获得 TCP 与关节状态，按原论文公开模型的契约组成观测，提供后续手动运行的模型加载和预测入口。实现先在本地完成并验证纯数据处理，随后仅上传文件到指定服务器工作空间。

本次用户约束：原始源码不直接修改；复制一份开发；参考最新技术报告和服务器进展；本地不推理；服务器不安装、不启动、不运行项目；已有服务器代码不修改；运行由操作者之后手动执行。机器人的执行接口在后续阶段扩展。

以上是初次代码准备阶段的边界。2026-10-24 用户追加授权服务器独立环境安装，当时尚未加载模型或连接设备，见 [文档 05](05_environment_preparation.md)。2026-10-25 又明确授权设备测试与 capture/shadow 推理，现已完成真实输入和原权重的 1+5 次影子预测，见 [文档 06](06_inference_validation.md)。运动执行和训练仍未授权或实施。

## 2. 证据来源与采用原则

主报告是 `references/technical_report_manipulator.pdf`，对应 2026-10-24 收到的 `Technical_Report_Manipulator (1).pdf`，12 页。第 3 页 TCP/控制频率表已另外渲染核对，避免文本提取导致单位或列对应错误。用户追加的官方文档截图保存在 `references/technical_report_rtde_update.jpg`。

服务器材料于本次准备期间重新读取，并保留有关文件，而不是只沿用旧快照。读取来源见 `references/server_sources.json`；每项记录远端路径、文件大小、修改时间和 SHA-256。材料中的命令均作为待核对内容，未被自动执行。

| 项目 | 证据 | 本次采用方式 |
|---|---|---|
| UR7e，六轴 | 报告 §§2.1–2.2 | 机器人型号和状态字段按此记录 |
| 控制柜 IP `192.168.1.100` | 报告 Table 1；最新 RTDE 示例相同 | 放入平台配置，只供以后手动状态连接 |
| PolyScope 5.23.0，CB5 v5.5 | 报告 Table 1 | 记录版本，不将 CB5 硬件命名误判为旧 CB-series 125 Hz 限制 |
| 内部 500 Hz、RTDE 输出 1–500 Hz、示例外部控制 125 Hz | 报告 Table 2 | 本次状态请求 125 Hz；不据此声称达到 125 Hz，也不创建控制循环 |
| TCP `[0,0,244] mm`，零旋转 | 报告 Table 2 | 换算为 `[0,0,0.244,0,0,0]` 米/弧度 |
| 初始关节角与负载 1.2 kg | 报告 Table 2 | 只归档；不回初始位、不设置负载 |
| 工作区四角 | 报告 Table 3 明确为 preliminary estimates | 不作为标定、安全范围或可达性证明 |
| Gemini 335L，腕部序列号 `CP285630005V` | 报告；最新 `dual_camera.launch.py` 与 `real_hardware.yaml` | 选择这一只相机；不复制双相机启动行为 |
| RGB 话题 `/wrist_camera/color/image_raw` | 最新 `real_hardware.yaml` | 用作默认订阅路径；该文件仍含 TODO，因此标为本轮未现场验证 |
| 光学 frame `wrist_camera_color_optical_frame` | 标定元数据与平台配置 | 回调检查 frame_id，一旦不同就报错，由操作者修订配置 |
| tool0→camera 手眼变换 | 最新标定文件 | 保存来源和验证状态；本轮不用于把 RGB 像素投到世界平面 |
| 夹爪型号 | 报告写 2F-85，服务器配置写 2F-140 | 明确保留冲突；本轮没有夹爪输入或控制，不选一个猜测替代实物确认 |

服务器手眼材料写明：177 个样本、同一次采集的时间抽样 holdout、独立验证尚未通过、TF attachment 未验证。不能因为有一个数值变换就称之为已完成全部现场标定。

用户新增链接已按官方文档核对：

- [ur_rtde 文档首页](https://sdurobotics.gitlab.io/ur_rtde/)
- [Quick Start](https://sdurobotics.gitlab.io/ur_rtde/pages/getting_started/quick_start.html)
- [API](https://sdurobotics.gitlab.io/ur_rtde/pages/reference/api.html)
- [Robotiq 使用指南](https://sdurobotics.gitlab.io/ur_rtde/pages/core_concepts/guides/use_with_robotiq_gripper.html)

本次核对时页面版本为 1.6.5。Quick Start 区分 Receive、Control、IO 三个独立接口；适配层仅使用 Receive。API 的 `getTimestamp()` 是控制柜启动后的秒数，不是 Unix 时间。`getTCPOffset()` 属于 Control API，本轮不为读取偏移而创建控制接口。Robotiq 指南涉及脚本、RS485 和 URCap 63352 等不同方法，不能把示例中的激活/开合动作混入本轮状态读取。

## 3. 目录和复制策略

在 `03_code/diffusion_policy_ur7e` 新建独立目录，将 `03_code/diffusion_policy` 的 Git 跟踪文件完整复制到 `upstream/`。复制后为每个文件比较 SHA-256，结果保存在 `artifacts/upstream_manifest.json`。

新增代码放在 `src/dp_ur7e/`；配置、权重、参考、文档、测试分开。这样能够直接看出哪些是原论文代码，哪些是当前平台适配，不需要在原仓库中寻找混杂改动。复制版仍保留原算法、训练与环境文件供查阅，但手动入口指向新增适配包。

服务器采用 `/home/robotic_arm/lyy_ws/diffusion_policy_ur7e`，与已有 `diffusion_policy_reproduction` 并列。传输不覆盖已有目录。文件校验采用 SFTP 读取，不借助服务器 Python 或 shell 执行项目。

## 4. 数据流及进程划分

```mermaid
flowchart LR
  C[已有 Gemini ROS 2 RGB 话题] --> B[系统 Python 相机桥接]
  B --> F[原子更新 runtime/wrist_rgb.npz]
  F --> H[策略进程相机采集线程]
  R[UR7e RTDE 状态输出] --> S[Receive-only 状态采集线程]
  H --> O[主线程构造两帧观测]
  S --> O
  O --> P[官方 policy.predict_action]
  P --> L[runs 中的输入、预测和时间证据]
```

相机桥接留在 ROS 2 系统 Python 中；模型环境使用独立 conda Python。两者通过本机原子 NPZ 文件交换 96×96 RGB 和元数据，避免将 ROS Humble 的 rclpy、旧论文 PyTorch 以及不同版本 NumPy 强行装进同一个解释器。

原子交换指先完成临时文件，再用 `os.replace` 替换最新帧。读者只会看到完整旧帧或完整新帧，不会看到写入一半的图片。这里是单机进程通信，不是相机和机械臂硬件触发同步。

模型推理可能阻塞主线程，因此相机与机械臂各有采集线程；它们仅收集样本。主线程取出完整队列后再更新观测历史，避免在遍历历史时被另一个线程修改。

## 5. TCP 与坐标约定

UR 返回 `[x,y,z,rx,ry,rz]`：前三项单位米，后三项是旋转向量、单位弧度，不是欧拉角。`actual_TCP_pose` 已经是当前激活 TCP 的位姿，不能再无条件加 244 mm。

记 `B` 为 UR 控制器基坐标、`F` 为真实法兰、`C` 为当前激活 TCP、`R` 为报告 TCP：

$$T_{BR}=T_{BC}\,(T_{FC})^{-1}\,T_{FR}.$$

`T_FR` 使用报告的 244 mm 偏移；`T_FC` 来自配置中对当前激活 TCP 的声明。两者相同时，报告 TCP 的位置就是实际读数，不重复添加偏移。两者不同则先移除当前 TCP 偏移，再转换到报告 TCP；旋转也必须参与计算。

例如法兰绕 X 轴转 90° 后，法兰 Z 方向的 244 mm 会指向基坐标系负 Y，而不是基坐标系正 Z。测试覆盖了这个情况。

`declared_active_tcp_offset_m_rad` 默认按报告填写，但 `active_tcp_offset_verified_on_pendant: false`。这是有来源的配置假设，不是本轮从示教器读回的证明。以后运行前应核对实际激活 TCP；若不同，填写实际偏移。代码不调用 `setTcp()`。

RTDE 使用 `ur_base` 坐标标识；不将其未经变换称为 ROS `base_link`，也不把 `tool0` 自动当作物理法兰。报告中的手眼矩阵因此不直接乘入本轮 RTDE 状态路径。

## 6. 官方权重和模型输入

初始选择官方仿真 Push-T 图像 Transformer checkpoint：

- 官方[模型目录](https://diffusion-policy.cs.columbia.edu/data/experiments/image/pusht/diffusion_policy_transformer/train_0/checkpoints/)。
- 文件 `epoch=0100-test_mean_score=0.748.ckpt`，下载后重命名为 `models/pusht_image_transformer.ckpt`。
- 412,727,949 字节；SHA-256 `d68cdbcf9c21df724fb60f2573aa28a22a333f555225a2ec29cb6b7890608c56`。
- `T_o=2`、`T_p=10`、`T_a=8`、100 次 DDPM 推理迭代，均来自其官方 sidecar 配置。
- `image` 为 float32 `[1,2,3,96,96]`，值域 `[0,1]`；`agent_pos` 为 float32 `[1,2,2]`，使用仿真像素尺度。
- `action_pred` 对应 `[1,10,2]`；`action` 对应 `[1,8,2]`，是上游按观测偏移选出的动作段。

分数 0.748 是该 checkpoint 文件名标出的仿真测试 mean score，不能叫真实 UR7e 成功率。CNN 的官方配置另存作 `models/cnn_config.yaml`，其 `T_p=16`；CNN 权重本轮未打包。

加载时只实例化 checkpoint 的 policy，不创建训练 workspace、优化器或环境 runner。严格加载 `ema_model`（原配置使用 EMA），包含视觉编码器、去噪网络和 normalizer。不重新估计归一化参数，不用实时两帧数据替换训练统计。

## 7. 真实 TCP 如何接到仿真位置输入

当前没有桌面平面标定，报告中的候选四角也不是可直接使用的边界。本轮采用明确标记的工程映射，保证数据结构可接入，避免偷偷把米数当像素数：

$$u=u_0+\operatorname{diag}(s)\,E\,(p-p_0).$$

`p` 是报告 TCP 的 UR base 三维位置；`p_0` 是本次会话首个位置；`u_0=[256,256]`；`E` 默认选择基坐标 X、Y；`s=[1000,1000] px/m`。因此从会话起点移动 1 cm 的 X，对应 `agent_pos` X 增加 10 像素。观测仍由 checkpoint 自带 normalizer 处理。

这个映射没有使用图像特征或相机外参进行标定。它不能保证腕部图像中的物体关系与仿真状态一致，也不能称为 sim-to-real 算法。原始动作保持像素单位；逆变换只生成标为 `unverified_base_xyz_m` 的日志预览，不构造控制命令。越界状态拒绝进入模型，越界预测保留原值并标记，不静默裁剪。

## 8. 时间对齐的真实能力

保留三类时间：相机 header ROS 时间、控制柜 uptime、主机 `time.monotonic()` 接收时间。不同时间源不直接相减；跨传感器选样只比较同一台服务器上的 monotonic 时间。

两帧目标间隔 0.1 s；对每个目标选择不晚于目标时刻的相机帧，再选不晚于该图像接收时刻的机械臂状态。最大主机采集偏差配置为 0.05 s，最大数据年龄为 0.5 s，这两个数是初始工程阈值，不是测得性能。

桥接端还使用本进程 ROS 时钟检查图像 header 是否已经过期。重复图像序号、相机或控制柜时间倒退、历史不足、状态与图片偏差过大、损坏数据会阻止构造观测。不会通过复制第一帧凑齐两帧。

## 9. 本轮范围的界限

现阶段提供真实传感器到模型的适配代码与运行资料；尚无模型加载/推理或真实机器人连接验证。未来若接执行，需要独立完成物理坐标标定、动作意义、时序、工具高度与状态检查。当前 `execution.enabled` 必须为 false，修改成 true 只会被配置校验拒绝，不会隐式打开运动控制。
