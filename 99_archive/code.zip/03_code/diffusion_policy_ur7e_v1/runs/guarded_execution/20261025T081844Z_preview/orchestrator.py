
import copy, hashlib, importlib.util, json, os, signal, subprocess, sys, time, traceback
from pathlib import Path
import numpy as np, rclpy, yaml
root=Path('/home/robotic_arm/lyy_ws/diffusion_policy_ur7e')
out=Path.cwd().resolve()
assert root/'runs/guarded_execution' in out.parents
request=json.loads((out/'request.json').read_text())
live=request['mode']=='live'
result={'mode':request['mode'],'all_stages_passed':False,'started_unix_s':time.time(),
        'training_run':False,'gripper_command_sent':False,'motion_count':0}
source_paths=['src/dp_ur7e/motion_safety.py','src/dp_ur7e/motion_robot.py','src/dp_ur7e/execution.py','configs/platform.yaml','models/checkpoint_manifest.json']
result['source_hashes']={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in source_paths}
original=(root/'configs/platform.yaml').read_bytes()
cfg=yaml.safe_load(original)
owned=[];node=None
env=dict(os.environ,DP_UR7E_TEST_RUN=str(out),PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1')
spec=importlib.util.spec_from_file_location('snapshot',root/'scripts/check_environment.py')
snapshot=importlib.util.module_from_spec(spec);spec.loader.exec_module(snapshot)
protected_before=snapshot.protected_snapshot()
(out/'protected_before.json').write_text(json.dumps(protected_before,indent=2))

def launch(name,command,environment):
    handle=(out/(name+'.log')).open('wb')
    p=subprocess.Popen([str(x) for x in command],cwd=out,env=environment,stdout=handle,stderr=subprocess.STDOUT,start_new_session=True)
    owned.append((name,p,handle));return p

def stop_owned(p):
    if p.poll() is not None:return
    if os.getpgid(p.pid)!=p.pid:raise RuntimeError('Refusing unexpected process group')
    for sig,delay in [(signal.SIGINT,6),(signal.SIGTERM,5),(signal.SIGKILL,1)]:
        if p.poll() is not None:return
        os.killpg(p.pid,sig)
        try:p.wait(timeout=delay)
        except subprocess.TimeoutExpired:pass

def marked():
    rows=[]
    for p in Path('/proc').iterdir():
        if not p.name.isdigit() or int(p.name)==os.getpid():continue
        try:
            if ('DP_UR7E_TEST_RUN='+str(out)).encode() in (p/'environ').read_bytes().split(b'\0'):
                rows.append({'pid':int(p.name),'pgid':os.getpgid(int(p.name))})
        except (OSError,ProcessLookupError):pass
    return rows

def interrupted(signum,frame):raise KeyboardInterrupt('trial interrupted '+str(signum))
signal.signal(signal.SIGTERM,interrupted)
try:
    if live:
        preview_path=Path(request['preview_run']).resolve()
        if root/'runs/guarded_execution' not in preview_path.parents:raise ValueError('Preview evidence is outside workspace')
        previous=json.loads((preview_path/'trial_result.json').read_text())
        if previous['mode']!='preview' or previous['all_stages_passed'] is not True:raise ValueError('A passing preview is required')
        if previous['source_hashes']!=result['source_hashes']:raise ValueError('Execution source changed since preview')
        if not 0 <= time.time()-previous['completed_unix_s'] <= 1200:raise ValueError('Preview evidence is too old')
    gpu_text=subprocess.check_output(['nvidia-smi','--query-gpu=uuid,memory.free,utilization.gpu','--format=csv,noheader,nounits'],text=True)
    choices=[]
    for line in gpu_text.splitlines():
        uuid,free,use=[x.strip() for x in line.split(',')]
        if int(free)>=6000 and int(use)<=10:choices.append((int(free),uuid))
    if not choices:raise RuntimeError('No idle GPU; other jobs will not be disturbed')
    gpu=max(choices)[1]
    model_env=dict(env,CUDA_VISIBLE_DEVICES=gpu,OMP_NUM_THREADS='4',MKL_NUM_THREADS='4',
        XDG_CACHE_HOME=str(root/'.cache/xdg'),TORCH_HOME=str(root/'.cache/torch'),HF_HOME=str(root/'.cache/huggingface'))
    for key in ['PYTHONPATH','PYTHONHOME','LD_LIBRARY_PATH','VIRTUAL_ENV']:model_env.pop(key,None)
    python=root/'.envs/inference/bin/python'
    # Safe to import and query without constructing any motion interface.
    preflight=subprocess.run([str(python),'-c',
        'import json;from dp_ur7e.motion_robot import dashboard_status,require_dashboard_ready; s=dashboard_status("192.168.1.100"); print(json.dumps(s));'+('require_dashboard_ready(s)' if live else '')],
        env=model_env,capture_output=True,text=True,timeout=15)
    (out/'dashboard_preflight.txt').write_text(preflight.stdout+preflight.stderr)
    if preflight.returncode:raise RuntimeError('Dashboard preflight rejected execution')
    if not live:
        tests=subprocess.run([str(python),'-m','pytest','-q',str(root/'tests')],cwd=root,env=model_env,capture_output=True,text=True,timeout=60)
        (out/'server_pytest.txt').write_text(tests.stdout+tests.stderr)
        if tests.returncode:raise RuntimeError('Server adapter tests failed')
    experiment=copy.deepcopy(cfg)
    experiment['project_root']=str(root)
    experiment['paths']['frame_store']=str(out/'frames/wrist_rgb.npz')
    experiment['paths']['runs']=str(out/'records')
    experiment['robot']['active_tcp_offset_verified_on_pendant']=True
    experiment['inference']['device']='cuda:0'
    config=out/'trial.yaml'
    config.write_text(yaml.safe_dump(experiment,sort_keys=False))
    (out/'platform_before.yaml').write_bytes(original)
    rclpy.init(args=[]);node=rclpy.create_node('dp_ur7e_guarded_trial_setup')
    start=time.monotonic()
    while time.monotonic()-start<3:rclpy.spin_once(node,timeout_sec=.2)
    publishers=node.get_publishers_info_by_topic(cfg['camera']['topic'])
    result['camera_publishers_before']=len(publishers)
    if not publishers:
        for p in Path('/proc').iterdir():
            if not p.name.isdigit() or int(p.name)==os.getpid():continue
            try:
                names=[Path(x.decode(errors='replace')).name.lower() for x in (p/'cmdline').read_bytes().split(b'\0')[:3] if x]
                if any('orbbec' in x for x in names):raise RuntimeError('Existing Orbbec process; refusing duplicate driver')
            except (FileNotFoundError,PermissionError):pass
        command=['ros2','launch','orbbec_camera','gemini_330_series.launch.py','camera_name:=wrist_camera',
                 'serial_number:=CP285630005V','device_num:=1','enable_color:=true','color_width:=640','color_height:=480',
                 'color_fps:=30','color_format:=MJPG','enable_depth:=false','enable_left_ir:=false','enable_right_ir:=false',
                 'enable_point_cloud:=false','enable_colored_point_cloud:=false','enable_accel:=false','enable_gyro:=false',
                 'publish_tf:=false','enumerate_net_device:=false']
        launch('camera_driver',command,env)
        result['owned_camera_started']=True
    node.destroy_node();node=None;rclpy.try_shutdown()
    ros_env=dict(env,PYTHONPATH=str(root/'src')+':'+env.get('PYTHONPATH',''))
    bridge=launch('camera_bridge',['/usr/bin/python3','-m','dp_ur7e','camera-bridge','--config',config],ros_env)
    start=time.monotonic()
    while not (out/'frames/wrist_rgb.npz').is_file():
        if bridge.poll() is not None:raise RuntimeError('Camera bridge exited before first frame')
        if time.monotonic()-start>25:raise TimeoutError('No camera frame in 25 seconds')
        time.sleep(.1)
    print('CAMERA_READY; MODE',request['mode'],flush=True)
    command=[python,'-m','dp_ur7e.execution','--config',config]
    if live:command+=['--execute','--site-ready']
    worker=launch('guarded_'+request['mode'],command,model_env)
    start=time.monotonic();last=start
    while worker.poll() is None:
        if time.monotonic()-start>100:raise TimeoutError('Bounded worker exceeded 100 seconds')
        if time.monotonic()-last>15:
            print('RUNNING',request['mode'],'seconds',round(time.monotonic()-start,1),flush=True);last=time.monotonic()
        time.sleep(.2)
    result['worker_exit_code']=worker.returncode
    print((out/('guarded_'+request['mode']+'.log')).read_text(errors='replace')[-5000:],flush=True)
    if worker.returncode:raise RuntimeError('Guarded worker rejected or failed; no automatic retry')
    dirs=list((out/'records').glob('*/metadata.json'))
    if len(dirs)!=1:raise RuntimeError('Expected one auditable run')
    records=dirs[0].parent
    events=[json.loads(line) for line in (records/'events.jsonl').read_text().splitlines()]
    complete=[e for e in events if e['event']=='completed']
    if len(complete)!=1:raise RuntimeError('Missing completed event')
    proposals=[e for e in events if e['event']=='filtered_prediction']
    if len(proposals)!=3:raise RuntimeError('Expected exactly three fresh filtered predictions')
    if any(e['candidate']['gripper_action']!='hold_no_command' for e in proposals):raise RuntimeError('Unexpected gripper action')
    motions=[e for e in events if e['event']=='motion']
    result.update(motion_count=len(motions),records_directory=str(records),
        source_ages_s=[e['candidate']['source_age_s'] for e in proposals],
        inference_s=[e['inference_s'] for e in proposals],
        proposals=proposals,motions=motions)
    if not live and (motions or any(e['event']=='control_connected' for e in events)):raise RuntimeError('Preview must not create control or send motion')
    if live and (not motions or not all(e['completed'] for e in motions)):raise RuntimeError('No confirmed completed motion')
    result['all_stages_passed']=True
except BaseException as exc:
    result['error']=repr(exc);result['traceback']=traceback.format_exc()
    print('TRIAL_FAILED',repr(exc),flush=True)
finally:
    if node is not None:node.destroy_node()
    rclpy.try_shutdown()
    cleanup=[]
    for name,p,handle in reversed(owned):
        try:
            stop_owned(p);cleanup.append({'name':name,'exit_code':p.poll(),'stopped':p.poll() is not None})
        except Exception as exc:cleanup.append({'name':name,'error':repr(exc),'stopped':False})
        handle.close()
    remaining=marked()
    for pgid in {p['pgid'] for p in remaining}:
        try:os.killpg(pgid,signal.SIGTERM)
        except ProcessLookupError:pass
    if remaining:time.sleep(1)
    result['cleanup']=cleanup;result['owned_processes_remaining']=marked()
    result['protected_environment_unchanged']=protected_before==snapshot.protected_snapshot()
    result['platform_config_unchanged']=(root/'configs/platform.yaml').read_bytes()==original
    if result['owned_processes_remaining'] or not result['protected_environment_unchanged'] or not result['platform_config_unchanged']:result['all_stages_passed']=False
    result['completed_unix_s']=time.time()
    (out/'trial_result.json').write_text(json.dumps(result,indent=2))
    print('RESULT',json.dumps({k:v for k,v in result.items() if k not in ['proposals','traceback']},indent=2),flush=True)
sys.exit(0 if result['all_stages_passed'] else 1)
