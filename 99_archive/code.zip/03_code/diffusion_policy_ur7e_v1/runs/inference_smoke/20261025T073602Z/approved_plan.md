# Approved operational plan: capture and receive-only shadow

Authorization: user approved the discussed capture -> one shadow prediction -> five shadow predictions on 2026-10-25. This does not authorize robot motion, gripper control, changing camera angle, training, or changes to other projects/environments.

1. Check package hashes, robot state, camera ownership and GPU availability.
2. Use a new runs/inference_smoke/<UTC>/ directory; copy the platform settings into independent experiment configs. Preserve the primary config and all source files. Use a unique frame-exchange path to avoid stale frames or interference with another bridge.
3. Start only the specified wrist RGB driver if it is not already publishing; do not duplicate an existing Orbbec process. Start an owned camera-bridge. All owned processes have bounded lifetimes and are cleaned up.
4. Invoke the existing capture entry and validate one completed observation: image [1,2,3,96,96], agent_pos [1,2,2], finite values, distinct frames, original freshness/skew limits.
5. Invoke existing shadow with max_predictions=1. Preserve original checkpoint, strict EMA loading, embedded normalizer, and 100 DDPM iterations. Check action_pred [1,10,2], action [1,8,2] and executed=false.
6. Only after step 5 passes, invoke existing shadow with max_predictions=5; validate all five records and save raw arrays/timing.
7. Stop only owned processes; verify primary config, source files and protected environment metadata remain unchanged. Preserve success and failure evidence locally and in the project workspace.

Ruling: this is operational acceptance of existing code, not a production feature implementation; no development branch/source changes are planned. If a code defect appears, preserve the failed run and use diagnosis and regression testing before a scoped adapter repair.

Ruling: TCP offset remains unverified and mapping remains explicitly uncalibrated; this run demonstrates computation and I/O only. Neither predicted simulation pixels nor numerical metric previews are executable robot targets.

Ruling: initialization duration includes interpreter imports and model loading; do not label it as pure loading time or benchmark the first inference as steady-state latency. Use a short sequence, not an unattended long run.
