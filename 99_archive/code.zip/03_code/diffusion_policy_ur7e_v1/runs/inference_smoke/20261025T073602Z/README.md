# Capture / shadow 首次运行记录

2026-10-25（America/New_York）。服务器上实际执行 `capture`、单轮 `shadow`、五轮 `shadow`，均产生预期 completed 记录。**共 1 组采集、6 次预测，零动作执行。**

| 阶段 | 子目录 | 记录数 |
|---|---|---:|
| capture | `capture_runs/20261025T073645Z_25ae3379` | 1 |
| shadow_single | `shadow_single_runs/20261025T073651Z_4b65b2f2` | 1 |
| shadow_five | `shadow_five_runs/20261025T073659Z_cb452f6a` | 5 |

每个子目录保留 `metadata.json`、`events.jsonl` 和 `observations/*.npz`。本目录的 `*_predictions.npz` 是由日志保存的原始预测值整理出的数组，不是另一轮推理。

## 复核结果

* 输入 `[1,2,3,96,96]` / `[1,2,2]`，不同图像帧、float32、有限值。
* 输出 `[1,10,2]` / `[1,8,2]`，有限值；所有 executed 标记为 false。
* 原官方 Transformer 严格加载 EMA，保留 normalizer 和 100 步 DDPM。
* 最大主机采集配对差 8.418 ms，不作硬件曝光同步精度声明。
* 每进程首轮推理约 2.1 s；连续运行后四次为 0.5633–0.5708 s，均值 0.5670 s。
* 所用最近图像在预测结束时已约 0.590–0.622 s，冷启动首轮约 2.08–2.09 s；输入检查通过不意味着输出时效已满足闭环要求。
* TCP 偏移未现场核验、映射未标定，图像视野不作任务验收。本次只确认计算链路可运行。

## 原始结果与图

![五轮数值输出，仅仿真坐标、无动作执行](predicted_actions_sim_coordinates.png)

该图不是机械臂轨迹，不与真实图像叠加。五种颜色分别表示五轮完整 10 点预测；红十字为输入工程映射的 `[256,256]` 锚点。没有根据图形重新裁剪或修改模型数值。

* [服务器流程结果](smoke_result.json)、[过程记录](progress.json)。
* [下载后独立核验](independent_validation.json)，不加载本地模型。
* [执行来源与文件哈希](transport_summary.json)。
* [相机驱动日志](camera_driver.log)、[桥接日志](camera_bridge.log)。
* [批准的操作计划](approved_plan.md)。
* [前置校验](../../preflight/20261025T073014Z/summary.json)。
* [结束后校验](../../preflight/20261025T074026Z/summary.json)：无 GPU 计算进程，未发现匹配的相机/ROS 进程，发布文件校验通过。

## 已知告警与未修改项

桥接在全部预测完成、收到 SIGINT 退出后，重复调用 `rclpy.shutdown()`，产生 `rcl_shutdown already called`，退出码 1。问题未隐去；所有本次 owned 进程已结束，`owned_processes_remaining=[]`。后续单独修复幂等退出，**本轮没有修改适配层或上游算法代码**。

权重构造时还有原 robomimic 调用 torchvision `pretrained` 参数的弃用警告；本次等效 weights=None，随后严格加载 checkpoint。没有为消除警告升级依赖或改原模型。

主平台配置未改，已有环境包管理元数据和受保护设置前后一致。`smoke_result.json` 的 all_stages_passed 指三个功能阶段，不代表退出过程没有告警，也不代表任务效果或运动执行已验收。

详见 [项目级验收说明](../../../docs/06_inference_validation.md)。
