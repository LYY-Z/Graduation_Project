# 2026-10-25 服务器只读现场预检查

## 范围与结论

按用户要求在服务器直接执行项目 inspect、控制柜可达性/只读状态入口检查、相机话题检查。发现通信前置条件不满足后，仅追加网卡、路由、USB 和已有 ROS 进程的只读诊断。

**软件文件检查通过；机器人网络未连通；目标腕部相机已枚举，但没有所需 ROS 图像话题。尚不能进入 capture 或 shadow。**

服务器：`10.108.1.251`。项目：`/home/robotic_arm/lyy_ws/diffusion_policy_ur7e`。日期按用户所在 America/New_York 记为 2026-10-25；各原始记录使用 UTC 时间。

## 1. 项目与 checkpoint

`dp_ur7e inspect` 退出码 0。官方 Push-T 图像 Transformer checkpoint SHA-256 核验通过；预期输入为 `image=[1,2,3,96,96]`、`agent_pos=[1,2,2]`。

`model_loaded=false`，本轮没有构造模型、反序列化 checkpoint 或执行推理。

## 2. 机器人通信与 TCP

配置中的控制柜地址是 `192.168.1.100`；RTDE 端口 30004 与 Dashboard 端口 29999 的连接探测均在 2 秒超时，ping 两次均无响应。未成功建立 RTDE 状态连接，因而没有读到当前 TCP 位姿、TCP 偏移或程序运行状态。配置地址本身尚不能因此视为现场确认过的控制柜地址。

追加诊断得到：

* 机器人候选网口 `enp2s0` 的管理标志包含 `UP`，但同时为 `NO-CARRIER`，操作状态 `DOWN`。
* NetworkManager 报该设备 `unavailable`，`WIRED-PROPERTIES.CARRIER=off`；没有 IPv4 地址。
* 办公网口 `enp0s31f6` 保持 `10.108.1.251/23`。
* 到 `192.168.1.100` 的实际路由是经办公网网关 `10.108.0.1`，不是机器人专网直连路由。

因此，已观察到的阻塞是**机器人专网没有检测到以太网物理链路，且当前不存在该网口上的直连地址/路由**。不能仅凭这一结果判定究竟是网线、控制柜供电、对端端口或接线位置造成；需要现场确认。不尝试通过修改默认路由、关闭防火墙或远程启动机器人程序来绕过。

现场应核对网线两端、控制柜是否已开机，以及示教器显示的 IP 和当前激活 TCP 偏移。无需为此移动机械臂或运行运动程序。平台配置中的 TCP 核验标记仍为 false；没有把默认 `[0,0,0.244,0,0,0]` 声称为测得值。

## 3. 相机与 ROS

USB/sysfs 已识别两台 Gemini 335L，其中配置目标腕部相机序列号为 `CP285630005V`；另一台为 `CP2N163000A2`。本轮不使用或启动另一台相机。

ROS 查询使用系统 Python / ROS Humble，并采用 `--no-daemon`，没有启动 ROS CLI daemon。发现的话题仅有 `/parameter_events` 与 `/rosout`；目标 `/wrist_camera/color/image_raw` 返回 `Unknown topic`。本次进程检查未发现匹配的 Orbbec/ROS 相机进程。ROS 查询环境未显式设置 ROS_DOMAIN_ID；上述结果仅代表本次环境可见的 ROS 图。

`ros2 pkg prefix orbbec_camera` 返回 `/opt/ros/humble`，说明该包可被当前 ROS 环境定位；这不等于驱动已启动或已收到图像。相机 `frame_id`、编码、实际图像质量和时间戳均未验证。下一阶段需要在明确允许后启动单只腕部相机驱动，再验证消息；本轮没有启动驱动或 camera-bridge。

## 4. 未执行的动作

没有修改平台 YAML、已有代码或软件环境；没有改网卡地址/路由/NetworkManager 配置；没有启停其他人的进程；没有启动相机驱动、UR 驱动、相机桥接、capture 或 shadow；没有导入/创建 RTDE Control 客户端、上传 URScript、修改 TCP、下发运动或夹爪命令。

项目内仅新增本轮运行证据。原始输出与配置快照保留，不把“诊断脚本正常退出”混同于“硬件通过验收”：机器人探测 JSON 中的 `reachable=false` 和相机查询退出码 1 均是未通过项。

## 5. 原始证据索引

* [第一轮：inspect、端口和 ROS 查询](summary.json)，同目录包含各步骤 stdout/stderr 与平台配置快照。
* [第二轮：接口、路由、ping、USB 与 ROS 进程](../20261025T045316Z/summary.json)。
* [第三轮：物理链路、NetworkManager 与相机包定位](../20261025T045455Z/summary.json)。

三个目录在服务器和本地均有副本，目录名使用 UTC 时间。
