import os

from launch import LaunchDescription
from launch.actions import (
    IncludeLaunchDescription,
    GroupAction,
)
from launch.launch_description_sources import (
    PythonLaunchDescriptionSource,
)
from ament_index_python.packages import get_package_share_directory

WRIST_SERIAL = "CP285630005V"
FIXED_SERIAL = "CP2N163000A2"


def generate_launch_description():

    package_dir = get_package_share_directory(
        "orbbec_camera"
    )

    camera_launch = os.path.join(
        package_dir,
        "launch",
        "gemini_330_series.launch.py"
    )

    wrist_camera = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(camera_launch),
        launch_arguments={
            "camera_name": "wrist_camera",
            "serial_number": WRIST_SERIAL,
            "device_num": "2",
            "depth_registration": "true",
        }.items()
    )

    fixed_camera = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(camera_launch),
        launch_arguments={
            "camera_name": "fixed_camera",
            "serial_number": FIXED_SERIAL,
            "device_num": "2",
            "depth_registration": "true",
        }.items()
    )

    return LaunchDescription([
        GroupAction([wrist_camera]),
        GroupAction([fixed_camera]),
    ])