"""ROS snapshot collection adapted from the local Libero_Agent_real implementation.

Self-contained: no imports or subprocesses from the sibling checkout.
"""
import json
import time
from .observation import (ObservationBuffer, camera_info_dict, depth_to_metres,
                          joint_state_dict, save_snapshot, stamp_ns, validate_frames)
from .transforms import pose_matrix

def pose_dict(msg):
    t, q = msg.transform.translation, msg.transform.rotation
    pose = {'translation_m': [t.x, t.y, t.z], 'quaternion_xyzw': [q.x, q.y, q.z, q.w],
            'parent_frame': msg.header.frame_id, 'child_frame': msg.child_frame_id,
            'tf_header_stamp_ros_s': stamp_ns(msg) / 1e9}
    pose['matrix_4x4'] = pose_matrix(pose['translation_m'], pose['quaternion_xyzw']).tolist()
    return pose


def discover(node, rclpy, timeout):
    deadline = time.monotonic() + min(timeout, 3.0)
    while time.monotonic() < deadline:
        rclpy.spin_once(node, timeout_sec=0.1)
    supported = {'sensor_msgs/msg/Image', 'sensor_msgs/msg/CameraInfo', 'sensor_msgs/msg/JointState'}
    topics = {name: types for name, types in sorted(node.get_topic_names_and_types()) if supported.intersection(types)}
    print(json.dumps({'topics': topics, 'note': '话题名不能证明深度配准或尺度；需现场验证后填入配置'}, ensure_ascii=False, indent=2))


def capture(node, rclpy, hw, args):
    from cv_bridge import CvBridge, CvBridgeError
    from rclpy.qos import qos_profile_sensor_data, QoSProfile, DurabilityPolicy, ReliabilityPolicy
    from rclpy.time import Time
    from sensor_msgs.msg import Image, CameraInfo, JointState
    from tf2_ros import Buffer, TransformListener, TransformException

    c, r = hw['camera'], hw['robot']
    buffer = ObservationBuffer()
    tf_buffer = Buffer()
    listener = TransformListener(tf_buffer, node)
    subscriptions = []
    topics = {'rgb': c['color_topic'], 'depth': c['depth_topic'],
              'info': c['camera_info_topic'], 'joints': c['joint_states_topic']}
    types = {'rgb': Image, 'depth': Image, 'info': CameraInfo, 'joints': JointState}
    for key in topics:
        subscriptions.append(node.create_subscription(types[key], topics[key],
            lambda msg, key=key: buffer.add(key, msg), qos_profile_sensor_data))
    if args.allow_static_camera_info:
        # 额外兼容在采集进程启动前只发布过一次的 transient-local 内参。
        # 保留上方 volatile 订阅，仍能接收普通流式 CameraInfo。
        latched_qos = QoSProfile(depth=1, reliability=ReliabilityPolicy.RELIABLE,
                                 durability=DurabilityPolicy.TRANSIENT_LOCAL)
        subscriptions.append(node.create_subscription(CameraInfo, topics['info'],
            lambda msg: buffer.add('info', msg), latched_qos))
    deadline = time.monotonic() + args.timeout
    reason = '等待话题消息；检查驱动、ROS_DOMAIN_ID 与 QoS'
    selected = None
    tcp_tf = None
    tcp_error = None
    while rclpy.ok() and time.monotonic() < deadline:
        rclpy.spin_once(node, timeout_sec=0.05)
        now_ns = node.get_clock().now().nanoseconds
        candidates = buffer.candidates(now_ns, c['max_sync_skew_s'], c['max_age_s'], args.allow_static_camera_info)
        found_candidate = False
        for messages in candidates:
            found_candidate = True
            validate_frames(messages, c['optical_frame'])
            at = Time.from_msg(messages['rgb'].header.stamp, clock_type=node.get_clock().clock_type)
            try:
                camera_tf = tf_buffer.lookup_transform(r['base_frame'], c['optical_frame'], at)
            except TransformException as exc:
                reason = f'图像采集时刻相机 TF 不可用：{exc}'
                continue
            tcp_tf = None
            tcp_error = None
            if r.get('tcp_frame'):
                try:
                    tcp_tf = tf_buffer.lookup_transform(r['base_frame'], r['tcp_frame'], at)
                except TransformException as exc:
                    tcp_error = str(exc)
            else:
                tcp_error = 'robot.tcp_frame 未配置'
            if tcp_tf is None and not args.allow_missing_tcp:
                reason = f'图像采集时刻 TCP TF 不可用：{tcp_error}；仅检查视觉可加 --allow-missing-tcp'
                continue
            selected = messages
            break
        if selected is not None:
            break
        if not found_candidate:
            reason = '尚无满足时效和时间差的 RGB/深度/CameraInfo/关节组合；检查 header 时间戳与主机时钟'
    if selected is None:
        diagnostic = buffer.diagnostics(node.get_clock().now().nanoseconds)
        raise TimeoutError(f'{reason}\n话题诊断：{json.dumps(diagnostic, ensure_ascii=False)}')
    bridge = CvBridge()
    try:
        rgb = bridge.imgmsg_to_cv2(selected['rgb'], desired_encoding='rgb8')
        raw = bridge.imgmsg_to_cv2(selected['depth'], desired_encoding='passthrough')
    except CvBridgeError as exc:
        raise ValueError(f'图像转换失败：{exc}') from exc
    if rgb.ndim != 3 or rgb.shape[2] != 3 or rgb.shape[:2] != raw.shape[:2]:
        raise ValueError('RGB 与配准深度图尺寸不匹配')
    depth, valid = depth_to_metres(raw, selected['depth'].encoding, c['depth_scale_m'])
    info = camera_info_dict(selected['info'], depth.shape)
    joints = joint_state_dict(selected['joints'])
    times = {key: stamp_ns(msg) / 1e9 for key, msg in selected.items()}
    sync_times = [stamp_ns(msg) for key, msg in selected.items() if not (key == 'info' and args.allow_static_camera_info)]
    camera = {**info, 'rgb': 'wrist_rgb.png', 'depth_raw': 'wrist_depth_raw.npy',
              'depth_m': 'wrist_depth_m.npy', 'depth_valid': 'wrist_depth_valid.npy',
              'depth_encoding': selected['depth'].encoding, 'depth_scale_m': c['depth_scale_m'],
              'valid_depth_ratio': float(valid.mean()), 'invalid_depth_value': 'NaN',
              'optical_frame': c['optical_frame'], 'T_base_camera': pose_dict(camera_tf)}
    metadata = {'schema_version': 'libero.real.observation.v1', 'source': 'real_ros_snapshot',
                'hardware_motion_commanded': False, 'captured_at_unix_s': time.time(),
                'sample_age_s': (node.get_clock().now().nanoseconds - stamp_ns(selected['rgb'])) / 1e9,
                'captured_at_monotonic_s': time.monotonic(),
                'timestamps_ros_s': times, 'sync_skew_s': (max(sync_times) - min(sync_times)) / 1e9,
                'topics': topics, 'base_frame': r['base_frame'], 'quaternion_order': 'xyzw',
                'length_unit': 'metre', 'camera_coordinates': 'OpenCV: +X right, +Y down, +Z forward',
                'camera_info_static_reuse_allowed': args.allow_static_camera_info,
                **joints, 'tcp_pose': pose_dict(tcp_tf) if tcp_tf else None,
                'tcp_available': tcp_tf is not None, 'tcp_unavailable_reason': tcp_error,
                'available_cameras': ['wrist'], 'cameras': {'wrist': camera}, 'gripper_status': None,
                'gripper_status_available': False}
    return save_snapshot(args.output_dir, rgb, raw, depth, valid, metadata)

