"""
Usage: 

conda create -n env_ur7e_example_code python=3.11 -y
conda activate env_ur7e_example_code
pip install -r requirements.txt
python example_use_rtde.py


The Python package is named ur-rtde, while its Python modules are imported as rtde_control, rtde_receive, and rtde_io.

1. Recommended — Official documentation for the third-party `ur_rtde` library: 
   (1) https://sdurobotics.gitlab.io/ur_rtde/ 
   (2) https://sdurobotics.gitlab.io/ur_rtde/pages/getting_started/quick_start.html

2. Optional — Official Universal Robots documentation for the RTDE communication protocol: 
   https://docs.universal-robots.com/tutorials/communication-protocol-tutorials/rtde-guide.html
"""
import math
from rtde_control import RTDEControlInterface
from rtde_receive import RTDEReceiveInterface


def main():
    robot_ip = "192.168.1.100"  # Replace with your robot's IP

    # Initial joint configuration (degrees)
    initial_deg = [45, -90, -30, 245, 90, 0]
    initial_q = [math.radians(x) for x in initial_deg]

    # Connect to robot
    rtde_r = RTDEReceiveInterface(robot_ip)
    rtde_c = RTDEControlInterface(robot_ip)

    try:
        actual_q = rtde_r.getActualQ()
        print("Current joints (deg):",
              [round(math.degrees(x), 2) for x in actual_q])

        # Check initial configuration (1-degree tolerance)
        tolerance = math.radians(1)
        at_initial = all(
            abs(a - b) < tolerance
            for a, b in zip(actual_q, initial_q)
        )

        if not at_initial:
            # Move to initial configuration
            print("Moving to initial configuration...")
            target_q = initial_q
        else:
            # Rotate base joint by +30 degrees
            print("Rotating base joint by +30 degrees...")
            target_q = actual_q.copy()
            target_q[0] += math.radians(30)

        # Execute joint-space movement
        # Uses a speed of 0.2 rad/s and acceleration of 0.2 rad/s^2.
        rtde_c.moveJ(target_q, 0.2, 0.2)

        print("Final joints (deg):",
              [round(math.degrees(x), 2)
               for x in rtde_r.getActualQ()])

    finally:
        rtde_c.stopScript()


if __name__ == "__main__":
    main()