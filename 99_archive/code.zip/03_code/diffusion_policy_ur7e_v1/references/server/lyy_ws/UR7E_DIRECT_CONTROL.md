# UR7e 机械臂直接控制

本文只说明 UR7e 本体的手动控制和 ROS 2 关节控制，不涉及策略或算法。本机已安装 ROS 2 Humble 的 Universal Robots 驱动，且有 `ur7e` 启动文件。

## 方式一：示教器手动 Jog

在 UR 示教器上进入手动/移动页面，用 Freedrive 或 Jog 控制机器人。开始前确认工作模式、速度滑块、工具负载和运动范围；这是最直接的单独运动方式，不需要主机上的 ROS 节点。

## 方式二：主机 ROS 2 关节轨迹

### 1. 启动驱动

先在示教器上按现场配置运行 External Control 程序，并确认控制柜网络地址。主机与机器人应在可互通的网络中。在主机终端运行：

```bash
source /opt/ros/humble/setup.bash
ROBOT_IP=填示教器上显示的控制柜IP
ros2 launch ur_robot_driver ur_control.launch.py \
  ur_type:=ur7e robot_ip:=$ROBOT_IP
```

该启动命令连接 UR 驱动和 ROS 控制器，本身不发送关节轨迹。若驱动已经运行，不要再启动第二个驱动实例。

### 2. 只读检查

另开终端并 source ROS 环境：

```bash
source /opt/ros/humble/setup.bash
ros2 control list_controllers
ros2 topic echo /joint_states --once
ros2 action list | rg follow_joint_trajectory
```

确认 `scaled_joint_trajectory_controller` 为 `active`，关节状态是当前值，Action 列表中有：

```text
/scaled_joint_trajectory_controller/follow_joint_trajectory
```

### 3. 发送关节目标

使用 `control_msgs/action/FollowJointTrajectory`。控制器顺序为肩 pan、肩 lift、肘、腕 1、腕 2、腕 3；`positions` 是六个关节的**绝对目标角度，单位弧度**。先从 `/joint_states` 读取当前值，保持五个关节不变，仅给一个关节设置小幅目标，设置足够长的运动时间，并确认整条轨迹的扫掠空间。

目标格式如下；将 `Q1`…`Q6` 替换为实际的六个弧度值后才是可发送的目标：

```yaml
trajectory:
  joint_names: [shoulder_pan_joint, shoulder_lift_joint, elbow_joint,
                wrist_1_joint, wrist_2_joint, wrist_3_joint]
  points:
    - positions: [Q1, Q2, Q3, Q4, Q5, Q6]
      time_from_start: {sec: 5}
```

推荐使用 `scaled_joint_trajectory_controller`，它会考虑示教器速度滑块和 UR 的速度缩放。ROS 2 驱动文档将其作为缩放安全相关速度的轨迹控制器；不要把其他控制器同时切换为活动状态。[驱动控制器说明](https://github.com/UniversalRobots/Universal_Robots_ROS2_Driver/blob/main/ur_robot_driver/doc/controllers.md)

## 运动坐标和控制接口

- 上面的 FollowJointTrajectory 控制的是六个关节角，不是 TCP 的 XYZ 坐标。
- 需要 TCP 直线或 XYZ 运动时，使用 UR ROS 2 驱动配合 MoveIt 规划/笛卡尔控制；不要把 XYZ 数值直接当作关节角发送。
- UR RTDE 也是直接控制接口，但不要让 RTDE 控制程序与 ROS 控制器同时向机械臂发送运动目标。一次只保留一个运动命令来源。[UR RTDE 指南](https://docs.universal-robots.com/tutorials/communication-protocol-tutorials/rtde-guide.html)
- 取消轨迹或断开网络不能代替示教器停止/硬件急停；操作者应能立即触达急停。

## 本机驱动文件

- UR7e 启动文件：`/opt/ros/humble/share/ur_robot_driver/launch/ur7e.launch.py`
- 控制器配置：`/opt/ros/humble/share/ur_robot_driver/config/ur_controllers.yaml`
- 官方驱动启动说明：[Universal Robots ROS 2 Driver](https://github.com/UniversalRobots/Universal_Robots_ROS2_Driver/blob/main/ur_robot_driver/doc/usage/startup.rst)

本机检查只确认了驱动包和 UR7e 配置存在，没有连接机器人或发送运动命令。
