# Diffusion Policy：PushT 图像基准复现方案

## 目标

使用官方 `DiffusionPolicy-C` 视觉策略，在 PushT 仿真任务上完成训练和评估。代码使用本机上游仓库 `/home/robotic_arm/diffusion_policy`（当前提交 `5ba07ac`），不把数据、训练日志、视频或 checkpoint 写进源码仓库。

## 复现设置

- 官方配置：`image_pusht_diffusion_policy_cnn.yaml`
- 训练数据：官方 `pusht.zip`，解压为 `pusht_cchi_v7_replay.zarr`
- 训练划分：90 个 episode，validation ratio 0.02
- 输入和动作：96×96 RGB + 2D agent position；观测 horizon 2，预测 horizon 16，每次执行 8 步
- 优化：batch size 64，AdamW，学习率 1e-4，cosine scheduler，500 warmup steps
- 扩散：DDPM，100 个训练与推理去噪步
- 随机种子：42、43、44；使用官方配置训练并保存周期 checkpoint
- 设备：优先使用 GPU 1，避开正在显示桌面的 GPU 0。主机有两张 24 GB Quadro RTX 6000，隔离外已确认 CUDA 可用。
- 训练日志使用 W&B offline 模式，避免依赖账号登录；配置、指标、视频和 checkpoint 均保存在本地。

上游 YAML 设置 `training.num_epochs=3050`，论文正文将视觉任务描述为 3000 epochs。复现时先保留上游 YAML 原值，并在结果报告中注明该配置差异。

## 评估和对照

PushT 报告的是目标区域覆盖率（`test/mean_score`），不是二元成功率。每个 checkpoint 按官方 runner 在 50 个固定初始条件上评估；按三种子汇总 `max` 和最后 10 个 checkpoint 的平均分。论文视觉 PushT 的 DiffusionPolicy-C 参考值为 `0.91 / 0.84`（max / last-10 average）。将该值作为复现对照，不作为单次随机种子必须达到的硬门槛。

## 目录约定

所有实验产物统一放在：

```text
/home/robotic_arm/lyy_ws/diffusion_policy_reproduction/
├── PLAN.md
├── data/
│   ├── pusht.zip
│   └── pusht/pusht_cchi_v7_replay.zarr/
├── runs/
│   ├── seed42/
│   ├── seed43/
│   └── seed44/
└── report/
```

Conda 环境 `robodiff` 由官方 `conda_environment.yaml` 创建，存放在 Miniconda 的环境目录中；训练产生的数据和结果仍全部放在上述 `lyy_ws` 路径。

## 执行步骤

1. 在源码仓库环境中创建官方 `robodiff` Conda 环境。
2. 将官方数据下载到 `data/pusht.zip`，确认压缩包完整后解压到 `data/`。
3. 运行官方训练配置；通过 Hydra 覆盖绝对数据路径、`training.device=cuda:1`、每个种子的输出目录和 `logging.mode=offline`。先完成 seed 42 的完整训练与评估，再运行 seed 43、44。
4. 汇总每个种子的 `test/mean_score`，计算三种子 max 与 last-10 average；保存汇总表、配置快照和训练曲线到 `report/`。
5. 检查各 run 中的 checkpoint、`logs.json.txt`、rollout 视频以及最终汇总结果。

## 当前状态

- 上游代码仓库干净，提交为 `5ba07ac`。
- 两张 RTX 6000 和 CUDA 已在隔离外确认可用。
- `robodiff` 环境尚未创建。
- 下载曾被中断；当前 `data/pusht.zip.partial` 位于本目录，但压缩包中央目录不完整，不能用于训练。执行时应重新下载完整文件。

## 参考

- [官方仓库与训练说明](https://github.com/real-stanford/diffusion_policy)
- [官方 PushT 训练数据目录](https://diffusion-policy.cs.columbia.edu/data/training/)
- [Diffusion Policy 论文（视觉 PushT 指标及评估方法）](https://diffusion-policy.cs.columbia.edu/diffusion_policy_2023.pdf)
