# Diffusion Policy 与 UR7e 直接控制方案

## 范围

只涉及 Diffusion Policy、UR7e 直接运动接口和相机观测适配，不使用 Agent 或 MCP 控制链。目标任务沿用前序选择的真实桌面 PushT。当前文件是方案，尚未向机械臂发送命令。

## 代码路径

本机上游代码在 `/home/robotic_arm/diffusion_policy`：

```text
eval_real_robot.py
  加载 checkpoint → policy.predict_action(obs)
  → 把二维 PushT action 映射成 TCP XY 目标
  → RealEnv.exec_actions(actions, timestamps)
  → RTDEInterpolationController.schedule_waypoint(...)
  → RTDEControlInterface.servoL(...) → UR 控制器
```

- [eval_real_robot.py](/home/robotic_arm/diffusion_policy/eval_real_robot.py)：实机推理、动作映射和时间安排。默认 10 Hz；模型动作是二维平面目标，当前脚本把它写入 TCP pose 的 x/y，并用原始 UR5 场景的固定范围裁剪。
- [real_env.py](/home/robotic_arm/diffusion_policy/diffusion_policy/real_world/real_env.py)：观测对齐、轨迹记录和 `exec_actions`；按时间戳把目标送给控制进程。
- [rtde_interpolation_controller.py](/home/robotic_arm/diffusion_policy/diffusion_policy/real_world/rtde_interpolation_controller.py)：独立进程读取 `RTDEReceiveInterface` 状态，插值动作并调用 `RTDEControlInterface.servoL`。当前配置频率为 125 Hz。
- [demo_real_robot.py](/home/robotic_arm/diffusion_policy/demo_real_robot.py)：用 SpaceMouse 操作并记录示教，但依赖仓库自带的 RealSense `RealEnv`，不能直接采 Gemini 335L 数据。

## UR7e 适配判断

UR 官方文档说明 e-Series / ur-Series 的 RTDE 输出最高可到 500 Hz；`ur_rtde` 文档说明其接口适用于提供 RTDE 的 UR 机器人。[UR RTDE 指南](https://docs.universal-robots.com/tutorials/communication-protocol-tutorials/rtde-guide.html) · [`ur_rtde` 文档](https://sdurobotics.gitlab.io/ur_rtde/)

这说明可以评估将 Diffusion Policy 的直接 RTDE 路径接到 UR7e，但不能原样照搬默认值：当前 DP 控制器注释和参数主要针对 UR5/旧款控制周期，实机配置默认 TCP Z 偏移 0.13 m、位置速度上限 0.25 m/s、旋转速度上限 0.6 rad/s，负载/重心为空；`eval_real_robot.py` 还写死了原实验的 XY 裁剪范围。这些都必须改成实测值并验证。DP 环境锁定 `ur-rtde==1.5.5`，需在 UR7e 当前 PolyScope 版本上先确认连接和脚本兼容性。

**一次只能有一个运动控制客户端。** 若选择 DP 的 RTDE 控制，就不能同时让 ROS 控制器/其他 RTDE 客户端向机械臂发送运动目标。相机可以继续由 Gemini 的 ROS 2 驱动采集，但它只提供图像；机械臂运动仍由选定的 RTDE 客户端负责。

## 观测和模型

1. 官方 real PushT 配置使用两路 240×320 RGB (`camera_1`、`camera_3`) 和二维 `robot_eef_pose`；本机 Gemini 是单腕相机，需要自定义相机观测适配、单路 shape metadata 和数据转换。[官方 real PushT 配置](https://github.com/real-stanford/diffusion_policy/blob/main/diffusion_policy/config/task/real_pusht_image.yaml)
2. `MultiRealsense` 不能直接读取 Gemini 话题；实现一个 ROS 2 图像订阅适配器，将时间戳 RGB 和 RTDE 读取的 TCP XY 对齐后送入策略。图像 resize、crop、颜色顺序和训练数据必须一致。
3. 仿真 PushT checkpoint 不直接用于真机。先记录本机真实示教，再从官方 `train_diffusion_unet_real_image_workspace.yaml` / `real_pusht_image.yaml` 派生单相机配置训练。
4. 先录制约 20 条 pilot episodes 检查遮挡、坐标、动作标签和数据回放，再扩充到约 100–140 条示教；论文真实 PushT 使用 136 条 proficient-human 示教作为参考数据量级。[论文](https://diffusion-policy.cs.columbia.edu/diffusion_policy_2023.pdf)

## 直接控制动作契约

- 模型输出先解释为**桌面平面内的绝对 TCP x/y 目标**，明确米制单位和参考坐标系；通过实测变换映射到 UR base。训练标签、观测状态和 RTDE 控制必须使用同一坐标约定。
- 保持 z 和工具姿态在经过验证的值；策略初期每次只下发一个新目标，执行后重新取图/状态再推理。只有低速单步验证通过后，才逐步增加 action chunk 长度。
- `RTDEInterpolationController` 通过 `schedule_waypoint` 产生平滑插值；动作过期、输入状态过期、推理超时、坐标越界或状态异常时，取消当前控制并进入停止/保持流程，不自动重试或回零。
- 设置唯一的 TCP、负载/重心、工作空间、最大单步位移、速度/加速度和停止行为；数值必须来自当前工具和现场测量，不沿用原 UR5 示例值。
- 实机操作期间急停应可达，使用 UR Reduced Mode/现场确认的低速开始；程序停止或网络断开不等于机械臂已物理停止。

## 实施和验收顺序

| 阶段 | 内容 | 通过条件 |
| --- | --- | --- |
| 0. 离线 | 加载 checkpoint；回放数据；检查图像和 action shape、坐标单位、推理延迟 | 与训练配置一致；动作只写入日志 |
| 1. RTDE 只读 | 连接 UR7e，读取 TCP、关节、模式和状态；不创建运动目标 | 状态持续新鲜；PolyScope/`ur_rtde` 版本兼容 |
| 2. 控制链单测 | 在 UR 仿真器先验证 RTDE waypoint/停止；再现场低速验证单个已审核目标 | 速度、TCP、方向、停止行为和边界均通过 |
| 3. 数据采集 | 适配 Gemini RGB；直接 RTDE 记录 TCP XY；人工示教并保存 episode | 图像/状态同步，标签可回放，坐标一致 |
| 4. Shadow mode | 在线推理并显示/记录候选 XY，不发送给 RTDE | 候选动作方向与幅度合理，延迟稳定，均在实测工作区内 |
| 5. 单步闭环 | 人工监督，每次只执行一个低速目标，再重新观测 | 无越界/碰撞；急停和停止流程通过 |
| 6. 小批评估 | 从少量 episode 起逐步扩大 | 记录覆盖率、成功率、人工干预和失败原因后再扩量 |

## 开始运动前的检查项

1. 确认 UR7e 当前 PolyScope 的 RTDE 服务可用，网络与 External Control/控制状态满足控制要求。
2. 确认唯一运动控制客户端；DP 的 RTDE 运动控制与其他 UR/ROS 运动控制器不可并行。
3. 实测安装后的 TCP、夹爪/推具几何、负载和重心；检查工具、相机、线缆的完整扫掠空间。
4. 建立桌面工作区和禁止区，替换脚本中的旧 UR5 XY 裁剪范围。
5. 用 UR7e 实际 TCP 与安全配置验证 RTDE `servoL` 和停止行为；再启用策略动作。
6. Gemini 图像订阅和时间戳同步通过回放检查后，才接入实时推理。

## 产物位置

真实示教、相机适配、配置、checkpoint、推理日志和评估结果统一写入 `lyy_ws/diffusion_policy_reproduction/`，不写入上游源码仓库。
