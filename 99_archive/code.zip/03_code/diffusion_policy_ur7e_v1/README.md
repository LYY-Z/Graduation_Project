# Diffusion Policy on UR7e with a single wrist camera

本目录是独立部署准备包，面向 **UR7e + 单个 Orbbec Gemini 335L 腕部相机**。原始代码来自 Chi 等人的 Diffusion Policy；当前实现完成相机输入、机械臂只读状态、模型输入组织与影子推理入口，准备了官方公开 checkpoint。

新增独立的微幅执行入口：默认仍为只读预演，显式启用后只允许最多 3 条经平滑、限幅和反馈监控的平面目标，夹爪保持不动。设计、硬上限、执行条件和本轮验收状态见 [微幅执行](docs/07_guarded_execution.md)。此入口不改变原 capture/shadow 的只读性质。

**最新状态：已打通真实输入 → 原权重推理 → 平滑限幅 → UR7e 实机执行。** 2026-10-25 完成 3 条有实测到位反馈的运动，命令累计 2.119 mm、净实测位移约 2.022 mm；试验随后停止，夹爪未动。见 [实机完整链路验收](runs/guarded_execution/20261025T085457Z_live/README.md)。这是部署链路通过，尚未验证 Push-T 任务效果。

**2026-10-25 已在服务器完成真实输入 capture、单轮及五轮 shadow 推理；没有训练或控制机械臂。** 使用原官方 EMA 权重与 100 步 DDPM，预测仅保存。此结果是计算链路验收，不是 Push-T 任务效果或实时闭环验收。首次退出时的桥接重复 shutdown 问题已随后修复，通过 5 项真实 ROS 生命周期回归及 3 次真实 SIGINT 退出验证；原始告警记录保留。当前状态见文档 06。本地未运行模型推理。

## 阅读顺序

1. [设计与证据](docs/01_design_and_evidence.md)：依据什么适配、报告与现有代码有哪些差异、坐标/时钟/模型的契约。
2. [代码与实现记录](docs/02_code_and_implementation.md)：各模块、数据结构、关键公式、错误处理和实现过程。
3. [手动运行手册](docs/03_manual_runbook.md)：环境准备、检查、相机桥接、采集和影子推理的明确顺序。
4. [验证记录与后续工作](docs/04_validation_and_next_steps.md)：已完成的本地测试、未进行的验证、后续实验记录规范。
5. [服务器独立环境](docs/05_environment_preparation.md)：安装边界、隔离方法、版本证据与激活方式。
6. [首次服务器推理验收](docs/06_inference_validation.md)：真实输入、原权重加载、1+5 次预测、耗时与已知问题。
7. [微幅执行](docs/07_guarded_execution.md)：独立执行入口、每条目标的安全处理、现场条件和实测证据。
8. [实施计划](docs/implementation_plan.md)：初次准备的任务记录与设计决定。

## 目录

```text
diffusion_policy_ur7e/
  upstream/                  原论文代码的独立完整副本，保持原文件不变
  src/dp_ur7e/               新增适配代码
  configs/platform.yaml      机器人、相机、时序和输入映射配置
  models/                    官方 checkpoint、原配置、下载来源和校验值
  references/                最新 technical report、更新截图、相关服务器文件快照
  tests/                     不访问硬件、不加载模型的适配层测试
  scripts/verify_bundle.py   纯文件/语法/哈希检查
  environment.inference.yml 独立推理环境依赖规格
  docs/                      设计、代码、运行和验证文档
  artifacts/                 原代码清单、测试证据、文件清单和传输回执
```

`runtime/` 与 `runs/` 是运行产物，不纳入发布文件清单；当前 `runs/` 中已保留实际测试的输入、输出和日志，不将旧观测当作新的实时输入。

本地：`G:\毕设\03_code\diffusion_policy_ur7e`。服务器目标：`/home/robotic_arm/lyy_ws/diffusion_policy_ur7e`。服务器已有的 `diffusion_policy_reproduction/`、上游仓库及其他人的 Agent 工作保持原状。

## 当前模型

官方 **Push-T 图像 Transformer**，输入 `image: [1,2,3,96,96]` 和 `agent_pos: [1,2,2]`。原配置 `T_o=2, T_p=10, T_a=8`，100 次 DDPM 去噪，使用 checkpoint 的 EMA 参数和原 normalizer。权重 412,727,949 字节，具体来源见 [checkpoint_manifest.json](models/checkpoint_manifest.json)。

它是在仿真 Push-T 上训练的公开权重。当前相机到模型的接入用于部署链路检查；真实任务效果尚无实验数据。输入映射、候选动作和日志均标明 `engineering_mapping_not_calibrated`，不把仿真坐标直接解释为已验证的机械臂目标。

## 手动入口

| 命令 | 作用 | 模型 | 硬件 |
|---|---|---|---|
| `python scripts/verify_bundle.py --zip-crc` | 文件清单、ZIP CRC、上游副本与语法检查 | 不加载 | 不连接 |
| `python -m dp_ur7e inspect` | 配置与 checkpoint 哈希检查 | 不加载 | 不连接 |
| `python -m dp_ur7e camera-bridge` | ROS RGB → 原子帧文件 | 不加载 | 订阅已有相机话题 |
| `python -m dp_ur7e capture` | 保存一组真实图像/状态模型输入 | 不加载 | 相机订阅结果 + RTDE 只读 |
| `python -m dp_ur7e shadow` | 保存模型预测，不下发动作 | 加载并推理 | 相机订阅结果 + RTDE 只读 |

上表是**以后手动执行的入口**；依赖与终端配置见运行手册。

## 代码来源与发表说明

原论文仓库：<https://github.com/real-stanford/diffusion_policy>，复制提交 `5ba07ac6661db573af695b419a7947ecb704690f`。原许可保存在 `upstream/LICENSE`。新增代码的作者信息、发布许可证和论文署名需在正式公开前按团队要求确定；当前不虚构贡献者或实验结果。
