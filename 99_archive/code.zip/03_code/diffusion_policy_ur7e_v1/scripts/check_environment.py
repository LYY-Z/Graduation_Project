"""Environment-only validation: no model construction, checkpoint loading or devices."""

from __future__ import annotations

import argparse
import hashlib
import importlib
import importlib.metadata
import json
import site
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PREFIX = ROOT / ".envs/inference"
REPORTS = ROOT / "artifacts/environment"
BASE = Path("/home/robotic_arm/miniconda3")


def sha256(path):
    result = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            result.update(block)
    return result.hexdigest()


def protected_snapshot():
    prefixes = [BASE]
    if (BASE / "envs").is_dir():
        prefixes += sorted(p for p in (BASE / "envs").iterdir() if p.is_dir())
    registry = Path("/home/robotic_arm/.conda/environments.txt")
    if registry.is_file():
        prefixes += [
            Path(line.strip())
            for line in registry.read_text().splitlines()
            if line.strip()
        ]
    packages = {}
    for prefix in sorted(set(p.resolve() for p in prefixes)):
        if prefix == PREFIX.resolve() or not (prefix / "conda-meta").is_dir():
            continue
        packages[str(prefix)] = {
            p.name: sha256(p)
            for p in sorted((prefix / "conda-meta").glob("*"))
            if p.is_file()
        }
    settings = {}
    for path in [
        Path("/home/robotic_arm/.condarc"),
        Path("/home/robotic_arm/.bashrc"),
        BASE / ".condarc",
    ]:
        settings[str(path)] = sha256(path) if path.is_file() else None
    return {"protected_prefixes": packages, "protected_settings": settings}


def save(name, data):
    REPORTS.mkdir(parents=True, exist_ok=True)
    (REPORTS / name).write_text(
        json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8"
    )


def verify():
    if Path(sys.prefix).resolve() != PREFIX.resolve():
        raise RuntimeError("Validation must use the new workspace environment's Python")
    if site.ENABLE_USER_SITE:
        raise RuntimeError("User site-packages must be disabled for isolation")
    sys.path.insert(0, str(ROOT / "upstream"))
    sys.path.insert(0, str(ROOT / "src"))
    modules = {}
    for name in [
        "numpy",
        "scipy",
        "cv2",
        "yaml",
        "torch",
        "torchvision",
        "diffusers",
        "robomimic",
        "hydra",
        "dill",
        "einops",
        "rtde_receive",
    ]:
        module = importlib.import_module(name)
        origin = Path(module.__file__).resolve()
        if PREFIX.resolve() not in origin.parents:
            raise RuntimeError(
                f"Dependency escaped the isolated prefix: {name}: {origin}"
            )
        modules[name] = {
            "file": str(origin),
            "version": str(getattr(module, "__version__", "see package versions")),
        }
    # Import class definitions only. Do not construct a policy or call torch.load.
    for name in [
        "diffusion_policy.policy.diffusion_transformer_hybrid_image_policy",
        "diffusion_policy.policy.diffusion_unet_hybrid_image_policy",
    ]:
        module = importlib.import_module(name)
        modules[name] = {
            "file": str(Path(module.__file__).resolve()),
            "class_definitions_imported_only": True,
        }
    torch = sys.modules["torch"]
    cuda_available = bool(torch.cuda.is_available())
    if not cuda_available:
        raise RuntimeError("CUDA is not available in the isolated environment")
    gpus = [
        {
            "name": torch.cuda.get_device_name(i),
            "capability": list(torch.cuda.get_device_capability(i)),
        }
        for i in range(torch.cuda.device_count())
    ]
    versions = {
        d.metadata["Name"]: d.version
        for d in importlib.metadata.distributions()
        if d.metadata.get("Name")
    }
    baseline = json.loads((REPORTS / "protected_before.json").read_text())
    current = protected_snapshot()
    save("protected_after.json", current)
    if baseline != current:
        raise RuntimeError(
            "Existing environment metadata or protected settings changed; inspect the snapshots"
        )
    result = {
        "checked_utc": datetime.now(timezone.utc).isoformat(),
        "sys_prefix": sys.prefix,
        "python": sys.version,
        "user_site_enabled": site.ENABLE_USER_SITE,
        "modules": modules,
        "package_versions": versions,
        "cuda_available": cuda_available,
        "torch_cuda_version": torch.version.cuda,
        "compiled_cuda_architectures": torch.cuda.get_arch_list(),
        "gpus": gpus,
        "protected_environments_unchanged": True,
        "protected_prefix_count": len(current["protected_prefixes"]),
        "policy_constructed": False,
        "checkpoint_deserialized": False,
        "inference_run": False,
        "robot_connected": False,
        "camera_started": False,
    }
    save("verification.json", result)
    print(
        json.dumps(
            {
                k: result[k]
                for k in [
                    "sys_prefix",
                    "python",
                    "cuda_available",
                    "torch_cuda_version",
                    "gpus",
                    "protected_environments_unchanged",
                    "policy_constructed",
                    "checkpoint_deserialized",
                    "inference_run",
                    "robot_connected",
                    "camera_started",
                ]
            },
            indent=2,
        )
    )


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("mode", choices=["baseline", "verify", "ros"])
    args = p.parse_args()
    if args.mode == "baseline":
        target = REPORTS / "protected_before.json"
        if target.exists():
            raise FileExistsError(
                "Preserve the original isolation baseline: " + str(target)
            )
        snapshot = protected_snapshot()
        save("protected_before.json", snapshot)
        print("Protected existing prefixes:", len(snapshot["protected_prefixes"]))
    elif args.mode == "ros":
        modules = {}
        for name in ["rclpy", "numpy", "yaml", "cv2", "sensor_msgs.msg"]:
            module = importlib.import_module(name)
            modules[name] = {
                "file": module.__file__,
                "version": str(getattr(module, "__version__", "ROS system package")),
            }
        result = {
            "python": sys.executable,
            "sys_prefix": sys.prefix,
            "user_site_enabled": site.ENABLE_USER_SITE,
            "modules": modules,
            "ros_node_created": False,
            "camera_started": False,
        }
        save("ros_imports.json", result)
        print(json.dumps(result, indent=2))
    else:
        verify()


if __name__ == "__main__":
    main()
