"""Offline filesystem/AST/ZIP validation. Does not import ML, ROS, or robot libraries."""

from __future__ import annotations

import argparse
import ast
import hashlib
import json
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SKIP_PARTS = {
    ".git",
    "__pycache__",
    ".pytest_cache",
    ".ruff_cache",
    ".envs",
    ".cache",
    "runtime",
    "runs",
}


def digest(path):
    result = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            result.update(block)
    return result.hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument(
        "--write-manifest", action="store_true", help="Local release preparation only"
    )
    p.add_argument("--zip-crc", action="store_true")
    args = p.parse_args()
    source_count = 0
    forbidden = {"rtde_control", "rtde_io", "subprocess", "diffusion_policy.real_world"}
    for path in sorted((ROOT / "src").rglob("*.py")):
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        for node in ast.walk(tree):
            names = (
                [a.name for a in node.names]
                if isinstance(node, ast.Import)
                else [node.module or ""]
                if isinstance(node, ast.ImportFrom)
                else []
            )
            forbidden_match = any(
                name == prefix or name.startswith(prefix + ".")
                for name in names
                for prefix in forbidden
            )
            permitted_control_boundary = (
                path == ROOT / "src/dp_ur7e/motion_robot.py"
                and isinstance(node, ast.ImportFrom)
                and node.module == "rtde_control"
                and [a.name for a in node.names] == ["RTDEControlInterface"]
                and any(
                    isinstance(parent, ast.FunctionDef)
                    and parent.name == "connect_control"
                    and node in parent.body
                    for parent in tree.body
                )
            )
            if forbidden_match and not permitted_control_boundary:
                raise ValueError(
                    "forbidden hardware/control import in adapter: " + str(path)
                )
        source_count += 1
    manifest = json.loads(
        (ROOT / "models/checkpoint_manifest.json").read_text(encoding="utf-8")
    )
    checkpoint = ROOT / "models" / manifest["file"]
    if (
        checkpoint.stat().st_size != manifest["bytes"]
        or digest(checkpoint) != manifest["sha256"]
    ):
        raise ValueError("checkpoint checksum/size mismatch")
    if args.zip_crc:
        with zipfile.ZipFile(checkpoint) as archive:
            bad = archive.testzip()
            if bad is not None:
                raise ValueError("checkpoint ZIP CRC mismatch: " + bad)
    preserved = json.loads(
        (ROOT / "artifacts/upstream_manifest.json").read_text(encoding="utf-8")
    )
    for entry in preserved["files"]:
        if digest(ROOT / "upstream" / entry["path"]) != entry["sha256"]:
            raise ValueError("upstream copy modified: " + entry["path"])
    release_path = ROOT / "artifacts/file_manifest.json"
    if args.write_manifest:
        entries = []
        for path in sorted(ROOT.rglob("*")):
            relative = path.relative_to(ROOT)
            if (
                not path.is_file()
                or any(
                    part in SKIP_PARTS or part.endswith(".egg-info")
                    for part in relative.parts
                )
                or path == release_path
                or relative.as_posix() == "artifacts/staging_receipt.json"
                or path.suffix in {".part", ".pyc"}
            ):
                continue
            entries.append(
                {
                    "path": relative.as_posix(),
                    "bytes": path.stat().st_size,
                    "sha256": digest(path),
                }
            )
        release_path.write_text(
            json.dumps(
                {"schema_version": 1, "files": entries}, ensure_ascii=False, indent=2
            ),
            encoding="utf-8",
        )
    else:
        entries = json.loads(release_path.read_text(encoding="utf-8"))["files"]
        for entry in entries:
            path = ROOT / entry["path"]
            if path.stat().st_size != entry["bytes"] or digest(path) != entry["sha256"]:
                raise ValueError("release file mismatch: " + entry["path"])
    print(
        json.dumps(
            {
                "adapter_python_files_parsed": source_count,
                "forbidden_control_imports": 0,
                "checkpoint_sha256_verified": True,
                "checkpoint_zip_crc_checked": args.zip_crc,
                "upstream_files_preserved": len(preserved["files"]),
                "release_files": len(entries),
                "model_loaded": False,
                "inference_run": False,
                "hardware_connected": False,
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
