"""Download official weights with validated byte ranges; never deserialize weights."""

import argparse
import hashlib
import json
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import requests


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("url")
    p.add_argument("output", type=Path)
    p.add_argument("--workers", type=int, default=16)
    args = p.parse_args()
    head = requests.head(args.url, timeout=30, allow_redirects=True)
    head.raise_for_status()
    size = int(head.headers["Content-Length"])
    chunks = args.output.with_suffix(".parts")
    chunks.mkdir(parents=True, exist_ok=True)
    part_size = 2 * 1024 * 1024
    jobs = [
        (i, start, min(start + part_size, size) - 1)
        for i, start in enumerate(range(0, size, part_size))
    ]

    def fetch(job):
        index, start, end = job
        path = chunks / f"{index:05}.part"
        if path.exists() and path.stat().st_size == end - start + 1:
            return
        for attempt in range(5):
            try:
                response = requests.get(
                    args.url,
                    headers={
                        "Range": f"bytes={start}-{end}",
                        "Accept-Encoding": "identity",
                    },
                    timeout=(20, 90),
                )
                if (
                    response.status_code != 206
                    or response.headers.get("Content-Range")
                    != f"bytes {start}-{end}/{size}"
                ):
                    raise RuntimeError("HTTP server did not honor the exact byte range")
                if len(response.content) != end - start + 1:
                    raise RuntimeError("Truncated range")
                path.write_bytes(response.content)
                return
            except (requests.RequestException, RuntimeError):
                if attempt == 4:
                    raise
                time.sleep(attempt + 1)

    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures = [pool.submit(fetch, job) for job in jobs]
        for number, future in enumerate(as_completed(futures), 1):
            future.result()
            if number % 20 == 0 or number == len(jobs):
                print(f"Completed ranges {number}/{len(jobs)}", flush=True)
    digest = hashlib.sha256()
    temp = args.output.with_suffix(args.output.suffix + ".part")
    with temp.open("wb") as output:
        for index, _, _ in jobs:
            data = (chunks / f"{index:05}.part").read_bytes()
            output.write(data)
            digest.update(data)
    if temp.stat().st_size != size:
        raise RuntimeError("Assembled size mismatch")
    temp.replace(args.output)
    args.output.with_suffix(".download.json").write_text(
        json.dumps(
            {
                "url": args.url,
                "bytes": size,
                "sha256": digest.hexdigest(),
                "etag": head.headers.get("ETag"),
                "server_last_modified": head.headers.get("Last-Modified"),
                "deserialized": False,
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    for part in chunks.glob("*.part"):
        part.unlink()
    chunks.rmdir()
    print("DOWNLOAD VERIFIED", size, digest.hexdigest(), flush=True)


if __name__ == "__main__":
    main()
