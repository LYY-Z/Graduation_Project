#!/usr/bin/env bash
# Explicit environment preparation only. Does not run capture, shadow, ROS or motion.
set -euo pipefail

DP_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)"
EXPECTED_ROOT=/home/robotic_arm/lyy_ws/diffusion_policy_ur7e
if [[ "$DP_ROOT" != "$EXPECTED_ROOT" ]]; then
  printf 'Refusing environment preparation outside %s\n' "$EXPECTED_ROOT" >&2
  exit 2
fi
DP_PREFIX="$DP_ROOT/.envs/inference"
DP_REPORTS="$DP_ROOT/artifacts/environment"
DP_CONDA=/home/robotic_arm/miniconda3/bin/conda

mkdir -p "$DP_REPORTS" "$DP_ROOT/.cache/conda_pkgs" "$DP_ROOT/.cache/pip" "$DP_ROOT/.cache/tmp" "$DP_ROOT/.cache/xdg"
export CONDA_PKGS_DIRS="$DP_ROOT/.cache/conda_pkgs"
export CONDA_ENVS_PATH="$DP_ROOT/.envs"
export CONDA_AUTO_UPDATE_CONDA=false
export CONDA_ALWAYS_COPY=true
export CONDARC="$DP_ROOT/configs/conda-isolated.yaml"
export PIP_CACHE_DIR="$DP_ROOT/.cache/pip"
export PIP_CONFIG_FILE=/dev/null
export PIP_USER=false
export PIP_NO_INPUT=1
export TMPDIR="$DP_ROOT/.cache/tmp"
export XDG_CACHE_HOME="$DP_ROOT/.cache/xdg"
export PYTHONNOUSERSITE=1
export PYTHONDONTWRITEBYTECODE=1
unset PYTHONPATH PYTHONHOME LD_LIBRARY_PATH PIP_TARGET PIP_PREFIX PIP_ROOT

if [[ "${1:-}" != "--verify-only" ]]; then
  if [[ ! -f "$DP_REPORTS/protected_before.json" ]]; then
    /usr/bin/python3 "$DP_ROOT/scripts/check_environment.py" baseline
  fi
  if [[ ! -e "$DP_PREFIX" ]]; then
    if [[ "${1:-}" == "--resume-solved" ]]; then
      /usr/bin/python3 "$DP_ROOT/scripts/prepare_environment_cache.py" | tee "$DP_REPORTS/cache_recovery.log"
      "$DP_CONDA" create --prefix "$DP_PREFIX" --file "$DP_REPORTS/conda-solved-explicit.txt" --offline --yes 2>&1 | tee "$DP_REPORTS/install_resumed.log"
    else
      printf 'Solving independent environment: %s\n' "$DP_PREFIX"
      "$DP_CONDA" env create --prefix "$DP_PREFIX" --file "$DP_ROOT/environment.inference.yml" --dry-run --json > "$DP_REPORTS/solve_plan.json"
      printf 'Installing into independent prefix\n'
      "$DP_CONDA" env create --prefix "$DP_PREFIX" --file "$DP_ROOT/environment.inference.yml" --yes 2>&1 | tee "$DP_REPORTS/install.log"
    fi
  elif [[ ! -f "$DP_PREFIX/conda-meta/history" ]]; then
    printf 'Prefix exists without a valid conda environment; inspect before resuming.\n' >&2
    exit 3
  fi
  "$DP_PREFIX/bin/python" -c 'import sys,yaml; d=yaml.safe_load(open(sys.argv[1])); print("\n".join(p for e in d["dependencies"] if isinstance(e,dict) for p in e.get("pip",[])))' "$DP_ROOT/environment.inference.yml" > "$DP_REPORTS/pip-requirements.txt"
  "$DP_PREFIX/bin/python" -m pip install --requirement "$DP_REPORTS/pip-requirements.txt" 2>&1 | tee "$DP_REPORTS/pip_install.log"
  "$DP_PREFIX/bin/python" -m pip install --no-deps --no-build-isolation --editable "$DP_ROOT" 2>&1 | tee "$DP_REPORTS/adapter_install.log"
fi

printf 'Checking dependency consistency and imports; no model construction\n'
"$DP_PREFIX/bin/python" -m pip check | tee "$DP_REPORTS/pip_check.txt"
"$DP_PREFIX/bin/python" "$DP_ROOT/scripts/check_environment.py" verify | tee "$DP_REPORTS/verification_output.txt"
(
  set +u
  source /opt/ros/humble/setup.bash
  /usr/bin/python3 "$DP_ROOT/scripts/check_environment.py" ros
) | tee "$DP_REPORTS/ros_imports.txt"
"$DP_PREFIX/bin/python" -m pytest -q "$DP_ROOT/tests" -c "$DP_ROOT/pyproject.toml" | tee "$DP_REPORTS/tests.txt"
"$DP_PREFIX/bin/python" -m dp_ur7e inspect --config "$DP_ROOT/configs/platform.yaml" > "$DP_REPORTS/inspect.json"
"$DP_CONDA" list --prefix "$DP_PREFIX" --explicit > "$DP_REPORTS/conda-explicit.txt"
"$DP_PREFIX/bin/python" -m pip freeze > "$DP_REPORTS/pip-freeze.txt"
printf 'Environment prepared; model and devices have not been run.\n'
