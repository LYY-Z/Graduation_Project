"""Resume the saved conda solve; verify a mirrored CUDA archive before caching it."""

from __future__ import annotations

import hashlib
import json
import time
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXPECTED_ROOT = Path("/home/robotic_arm/lyy_ws/diffusion_policy_ur7e")
REPORTS = ROOT / "artifacts/environment"
CACHE = ROOT / ".cache/conda_pkgs"


def digest(path):
    result = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            result.update(block)
    return result.hexdigest()


def main():
    if ROOT != EXPECTED_ROOT:
        raise RuntimeError("Only the authorized server project is supported")
    plan = json.loads((REPORTS / "solve_plan.json").read_text())
    fetch = plan["actions"]["FETCH"]
    links = plan["actions"]["LINK"]
    by_name = {p["name"]: p for p in fetch}
    if not plan.get("success") or len(by_name) != len(links):
        raise ValueError("Saved solve must contain every linked archive")
    explicit = ["@EXPLICIT"]
    for link in links:
        item = by_name[link["name"]]
        if (item["version"], item["build"]) != (
            link["version"],
            link["build_string"],
        ):
            raise ValueError("Saved fetch/link mismatch")
        if not item["url"].startswith(
            (
                "https://conda.anaconda.org/conda-forge/",
                "https://conda.anaconda.org/pytorch/",
            )
        ):
            raise ValueError("Unexpected package origin in saved solve")
        # The manually verified archive has no conda cache record yet. A local
        # file URL lets conda register/extract it without a network request.
        url = (
            (CACHE / item["fn"]).as_uri()
            if item["name"] == "cudatoolkit"
            else item["url"]
        )
        explicit.append(url + "#" + item["md5"])
    item = by_name["cudatoolkit"]
    if item["fn"] != "cudatoolkit-11.6.2-hfc3e2af_13.conda":
        raise ValueError("This recovery targets only the measured slow CUDA archive")
    destination = CACHE / item["fn"]
    mirror = (
        "https://mirrors.tuna.tsinghua.edu.cn/anaconda/cloud/conda-forge/linux-64/"
        + item["fn"]
    )
    if not destination.is_file() or digest(destination) != item["sha256"]:
        temporary = ROOT / ".cache/tmp" / (item["fn"] + ".verified-download")
        if temporary.exists():
            raise FileExistsError("Inspect prior temporary download before retrying")
        started = time.monotonic()
        completed = 0
        next_report = 16 * 1024 * 1024
        print("Downloading identical CUDA archive from TUNA mirror", flush=True)
        request = urllib.request.Request(
            mirror, headers={"User-Agent": "dp-ur7e-environment/0.1"}
        )
        with (
            urllib.request.urlopen(request, timeout=30) as response,
            temporary.open("xb") as stream,
        ):
            if response.status != 200:
                raise ValueError("Expected full HTTP 200 archive response")
            while True:
                block = response.read(1024 * 1024)
                if not block:
                    break
                stream.write(block)
                completed += len(block)
                if completed >= next_report:
                    print(f"CUDA archive: {completed}/{item['size']} bytes", flush=True)
                    next_report += 16 * 1024 * 1024
        if completed != item["size"] or digest(temporary) != item["sha256"]:
            raise ValueError(
                "Mirror archive size/SHA-256 failed; not added to conda cache"
            )
        temporary.replace(destination)
        (REPORTS / "cuda_archive_recovery.json").write_text(
            json.dumps(
                {
                    "original_url": item["url"],
                    "download_url": mirror,
                    "bytes": completed,
                    "sha256": item["sha256"],
                    "sha256_verified": True,
                    "download_seconds": time.monotonic() - started,
                    "version_changed": False,
                },
                indent=2,
            ),
            encoding="utf-8",
        )
    (REPORTS / "conda-solved-explicit.txt").write_text(
        "\n".join(explicit) + "\n", encoding="utf-8"
    )
    print("Verified archive and explicit saved solve ready", flush=True)


if __name__ == "__main__":
    main()
