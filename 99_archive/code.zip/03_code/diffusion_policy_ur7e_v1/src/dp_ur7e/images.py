"""RGB handling independent of ROS and torch imports."""

from __future__ import annotations

import numpy as np


def decode_rgb_image(message) -> np.ndarray:
    """Decode a sensor_msgs/Image-like object, including padded row stride."""
    height, width, step = int(message.height), int(message.width), int(message.step)
    if message.encoding not in {"rgb8", "bgr8"}:
        raise ValueError(f"unsupported RGB encoding: {message.encoding}")
    if height <= 0 or width <= 0 or step < width * 3:
        raise ValueError("invalid image dimensions or row stride")
    raw = np.frombuffer(bytes(message.data), dtype=np.uint8)
    if raw.size != height * step:
        raise ValueError("image buffer size does not match height * step")
    image = raw.reshape(height, step)[:, : width * 3].reshape(height, width, 3)
    if message.encoding == "bgr8":
        image = image[..., ::-1]
    return np.ascontiguousarray(image)


def resize_for_policy(rgb: np.ndarray, size_hw=(96, 96), roi_xywh=None) -> np.ndarray:
    """Explicit ROI or centre-square crop, then area resize. Requires OpenCV at runtime."""
    import cv2

    if rgb.ndim != 3 or rgb.shape[2] != 3 or rgb.dtype != np.uint8:
        raise ValueError("RGB must be HWC uint8")
    height, width = rgb.shape[:2]
    if roi_xywh is None:
        side = min(height, width)
        x, y, w, h = (width - side) // 2, (height - side) // 2, side, side
    else:
        if len(roi_xywh) != 4 or any(int(v) != v for v in roi_xywh):
            raise ValueError("ROI must be integer [x,y,width,height]")
        x, y, w, h = map(int, roi_xywh)
        if min(x, y) < 0 or min(w, h) <= 0 or x + w > width or y + h > height:
            raise ValueError("ROI lies outside source image")
    out_h, out_w = map(int, size_hw)
    if min(out_h, out_w) <= 0:
        raise ValueError("output image size must be positive")
    return np.ascontiguousarray(
        cv2.resize(
            rgb[y : y + h, x : x + w], (out_w, out_h), interpolation=cv2.INTER_AREA
        )
    )


def image_tensor(rgb: np.ndarray) -> np.ndarray:
    if rgb.shape != (96, 96, 3) or rgb.dtype != np.uint8:
        raise ValueError("checkpoint requires RGB uint8 shape (96,96,3)")
    return np.ascontiguousarray(rgb.transpose(2, 0, 1), dtype=np.float32) / 255.0
