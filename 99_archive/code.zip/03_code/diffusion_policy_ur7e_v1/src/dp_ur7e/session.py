"""Concurrent acquisition while neural inference blocks the main thread."""

from __future__ import annotations

import threading
import time
from collections import deque

from .frame_store import FrameStore
from .geometry import PlanarMapping
from .observations import ObservationHistory
from .robot import ReceiveOnlyRobot


class SensorSession:
    def __init__(self, cfg):
        self.cfg = cfg
        self.robot = None
        self.history = None
        self.mapping = None
        self.stop_event = threading.Event()
        self.lock = threading.Lock()
        self.frames, self.states = deque(maxlen=512), deque(maxlen=2048)
        self.failure = None
        self.threads = []

    def __enter__(self):
        self.robot = ReceiveOnlyRobot.connect(self.cfg["robot"])
        try:
            initial = self.robot.read()
            mapping = self.cfg["mapping"]
            self.mapping = PlanarMapping(
                initial.report_tcp_position_m,
                mapping["axes_in_ur_base"],
                mapping["pixels_per_m"],
                mapping["anchor_px"],
                mapping["model_bounds_px"],
            )
            obs = self.cfg["observation"]
            self.history = ObservationHistory(
                self.mapping,
                obs["n_obs_steps"],
                1 / obs["rate_hz"],
                obs["max_age_s"],
                obs["max_acquisition_skew_s"],
            )
            self.history.add_robot(initial)
            for target in [self._robot_loop, self._camera_loop]:
                thread = threading.Thread(
                    target=self._guard, args=(target,), daemon=True
                )
                self.threads.append(thread)
                thread.start()
            return self
        except BaseException:
            self.__exit__(None, None, None)
            raise

    def _guard(self, operation):
        try:
            operation()
        except Exception as exc:
            with self.lock:
                self.failure = exc
            self.stop_event.set()

    def _robot_loop(self):
        while not self.stop_event.is_set():
            sample = self.robot.read()
            with self.lock:
                self.states.append(sample)
            self.stop_event.wait(1 / self.cfg["robot"]["receive_hz"])

    def _camera_loop(self):
        store = FrameStore(self.cfg["paths"]["frame_store"])
        previous = None
        while not self.stop_event.is_set():
            try:
                frame = store.read()
            except FileNotFoundError:
                self.stop_event.wait(0.02)
                continue
            identity = (frame.stream_id, frame.sequence)
            if identity != previous:
                age = time.monotonic() - frame.host_monotonic_s
                if (
                    age < 0
                    or age + max(0, frame.ros_age_at_receive_s)
                    > self.cfg["observation"]["max_age_s"]
                ):
                    self.stop_event.wait(0.01)
                    continue
                if frame.frame_id != self.cfg["camera"]["expected_frame_id"]:
                    raise ValueError(
                        "camera frame_id differs from platform configuration"
                    )
                with self.lock:
                    self.frames.append(frame)
                previous = identity
            self.stop_event.wait(1 / self.cfg["camera"]["frame_store_poll_hz"])

    def observation(self):
        with self.lock:
            if self.failure is not None:
                raise RuntimeError("sensor acquisition failed") from self.failure
            frames, states = list(self.frames), list(self.states)
            self.frames.clear()
            self.states.clear()
        for state in states:
            self.history.add_robot(state)
        for frame in frames:
            self.history.add_frame(frame)
        return self.history.build(time.monotonic())

    def __exit__(self, *_):
        self.stop_event.set()
        for thread in self.threads:
            thread.join(timeout=3)
        if self.robot is not None:
            self.robot.close()
