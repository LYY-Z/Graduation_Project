"""Load only the project-private audited no-retry control extension."""

from __future__ import annotations

import hashlib
import importlib.util
import json
from pathlib import Path


def load_backend(root):
    root = Path(root).resolve()
    report = root / "artifacts/control_backend.json"
    if not report.is_file():
        raise ValueError("private guarded backend has not been prepared")
    manifest = json.loads(report.read_text(encoding="utf-8"))
    binary = (root / manifest["binary"]).resolve()
    if root / "runtime/control_backend" not in binary.parents:
        raise ValueError("guarded backend binary is outside its private directory")
    if (
        not binary.is_file()
        or hashlib.sha256(binary.read_bytes()).hexdigest() != manifest["sha256"]
    ):
        raise ValueError("guarded backend binary hash mismatch")
    for relative, expected in manifest["source_hashes"].items():
        source = (root / relative).resolve()
        if root / "vendor/ur_rtde_guarded" not in source.parents:
            raise ValueError("backend source is outside the audited vendor directory")
        if hashlib.sha256(source.read_bytes()).hexdigest() != expected:
            raise ValueError("backend sources differ from the verified build")
    spec = importlib.util.spec_from_file_location("dp_ur7e_rtde_control", binary)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    if (
        module.guarded_no_reconnect is not True
        or module.guarded_immediate_motion_dispatch is not True
        or not callable(getattr(module.RTDEControlInterface, "guarded_ready", None))
        or module.guarded_command_timeout_s != 1.0
        or module.guarded_send_timeout_s != 0.5
    ):
        raise ValueError("control backend does not expose audited guarded capabilities")
    return module
