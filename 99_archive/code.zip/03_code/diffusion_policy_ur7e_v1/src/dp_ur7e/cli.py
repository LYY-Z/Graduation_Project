"""Manual entry points. --help and inspect never initialize sensors or a model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from .config import load_config


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "command", choices=["inspect", "camera-bridge", "capture", "shadow"]
    )
    parser.add_argument(
        "--config",
        type=Path,
        default=Path(__file__).resolve().parents[2] / "configs/platform.yaml",
    )
    args = parser.parse_args(argv)
    cfg = load_config(args.config)
    if args.command == "inspect":
        import yaml

        from .model import sha256_file, validate_model_config

        sidecar = yaml.safe_load(
            cfg["paths"]["official_config"].read_text(encoding="utf-8")
        )
        validate_model_config(sidecar)
        manifest = json.loads(
            cfg["paths"]["checkpoint_manifest"].read_text(encoding="utf-8")
        )
        actual_hash = sha256_file(cfg["paths"]["checkpoint"])
        if actual_hash != manifest["sha256"]:
            raise ValueError("checkpoint SHA-256 mismatch")
        print(
            json.dumps(
                {
                    "root": str(cfg["_root"]),
                    "checkpoint": manifest,
                    "checkpoint_sha256_verified": True,
                    "input_shapes": {
                        "image": [1, 2, 3, 96, 96],
                        "agent_pos": [1, 2, 2],
                    },
                    "model_loaded": False,
                    "hardware_connected": False,
                },
                indent=2,
                ensure_ascii=False,
            )
        )
    elif args.command == "camera-bridge":
        from .camera_bridge import run_camera_bridge

        run_camera_bridge(cfg)
    else:
        from .runner import run

        run(cfg, inference=args.command == "shadow")


if __name__ == "__main__":
    main()
