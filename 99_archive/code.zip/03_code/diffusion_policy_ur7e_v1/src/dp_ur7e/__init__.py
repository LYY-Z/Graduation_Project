"""UR7e/Gemini adapters. Importing this package opens no devices or models."""

__version__ = "0.1.0"
