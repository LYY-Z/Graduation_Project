"""Atomic local frame exchange across ROS system-Python and model conda processes."""

from __future__ import annotations

import json
import os
import uuid
from dataclasses import dataclass
from pathlib import Path

import numpy as np


@dataclass(frozen=True)
class CameraFrame:
    rgb: np.ndarray
    sequence: int
    host_monotonic_s: float
    ros_stamp_s: float
    frame_id: str
    stream_id: str = "default"
    source_shape_hw: tuple = (96, 96)
    source_encoding: str = "rgb8"
    ros_age_at_receive_s: float = 0.0

    def validate(self):
        if self.rgb.dtype != np.uint8 or self.rgb.shape != (96, 96, 3):
            raise ValueError("frame must be 96x96 uint8 RGB")
        if (
            self.sequence < 0
            or not np.isfinite(self.host_monotonic_s)
            or not np.isfinite(self.ros_stamp_s)
        ):
            raise ValueError("invalid sequence or timestamp")
        if not self.frame_id or not self.stream_id:
            raise ValueError("frame_id and stream_id are required")
        if (
            not np.isfinite(self.ros_age_at_receive_s)
            or self.ros_age_at_receive_s < -0.05
        ):
            raise ValueError("invalid ROS image age")


class FrameStore:
    def __init__(self, path):
        self.path = Path(path)

    def write(self, frame: CameraFrame):
        frame.validate()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temp = self.path.with_name(self.path.name + "." + uuid.uuid4().hex + ".tmp")
        metadata = {
            "schema_version": 1,
            "sequence": int(frame.sequence),
            "host_monotonic_s": float(frame.host_monotonic_s),
            "ros_stamp_s": float(frame.ros_stamp_s),
            "frame_id": frame.frame_id,
            "stream_id": frame.stream_id,
            "source_shape_hw": list(frame.source_shape_hw),
            "source_encoding": frame.source_encoding,
            "ros_age_at_receive_s": float(frame.ros_age_at_receive_s),
        }
        try:
            with temp.open("wb") as f:
                np.savez(
                    f, rgb=frame.rgb, metadata_json=np.asarray(json.dumps(metadata))
                )
                f.flush()
                os.fsync(f.fileno())
            os.replace(temp, self.path)
        finally:
            if temp.exists():
                temp.unlink()

    def read(self) -> CameraFrame:
        with np.load(self.path, allow_pickle=False) as content:
            metadata = json.loads(str(content["metadata_json"].item()))
            if metadata.pop("schema_version") != 1:
                raise ValueError("unsupported frame schema")
            frame = CameraFrame(rgb=content["rgb"].copy(), **metadata)
        frame.validate()
        return frame
