"""Explicit manual capture/shadow workflow. Contains no robot motion client."""

from __future__ import annotations

import time

import numpy as np

from .model import load_policy, validate_predictions
from .recording import RunWriter, environment_versions, preview_actions
from .session import SensorSession


def run(cfg, *, inference: bool):
    details, policy = None, None
    if inference:
        import torch

        torch.manual_seed(int(cfg["inference"]["seed"]))
        np.random.seed(int(cfg["inference"]["seed"]))
        policy, details = load_policy(cfg)
    metadata = {
        "mode": "shadow" if inference else "capture",
        "execution_enabled": False,
        "environment": environment_versions(),
        "platform_config": cfg,
        "model": details,
        "active_tcp_offset_source": "operator_declaration_from_report",
        "active_tcp_offset_verified_on_pendant": cfg["robot"][
            "active_tcp_offset_verified_on_pendant"
        ],
        "calibration_status": cfg["mapping"]["calibration_status"],
    }
    writer = RunWriter(cfg["paths"]["runs"], metadata)
    print("Run directory:", writer.directory, flush=True)
    completed, last_sequence = 0, None
    start = last_success = time.monotonic()
    last_message = None
    limit = int(cfg["inference"]["max_predictions"]) if inference else 1
    try:
        with SensorSession(cfg) as sensors:
            metadata["mapping_origin_ur_base_m"] = sensors.mapping.origin_m.tolist()
            writer.metadata(metadata)
            while (
                completed < limit
                and time.monotonic() - start < cfg["inference"]["max_duration_s"]
            ):
                try:
                    observation, evidence = sensors.observation()
                except ValueError as exc:
                    reason = str(exc)
                    if reason != last_message:
                        writer.append(
                            {"event": "waiting_for_valid_observation", "reason": reason}
                        )
                        print(reason, flush=True)
                        last_message = reason
                    if (
                        time.monotonic() - last_success
                        > cfg["observation"]["startup_timeout_s"]
                    ):
                        raise TimeoutError(
                            "no valid observation within configured timeout"
                        ) from exc
                    time.sleep(0.01)
                    continue
                if evidence["camera_sequences"][-1] == last_sequence:
                    time.sleep(0.005)
                    continue
                last_sequence = evidence["camera_sequences"][-1]
                last_message = None
                t0 = time.monotonic()
                record = {
                    "event": "prediction" if inference else "observation",
                    "index": completed,
                    "observation": evidence,
                    "agent_pos_px": observation["agent_pos"].tolist(),
                    "executed": False,
                }
                if inference:
                    import torch

                    tensors = {
                        name: torch.from_numpy(array).to(
                            device=policy.device, dtype=policy.dtype
                        )
                        for name, array in observation.items()
                    }
                    if policy.device.type == "cuda":
                        torch.cuda.synchronize(policy.device)
                    inference_start = time.monotonic()
                    with torch.inference_mode():
                        tensor_output = policy.predict_action(tensors)
                    output = {
                        name: tensor_output[name].detach().cpu().numpy()
                        for name in ["action", "action_pred"]
                    }
                    validate_predictions(
                        output, details["horizon"], details["n_action_steps"]
                    )
                    record.update(
                        {
                            "inference_s": time.monotonic() - inference_start,
                            "action_pred_px": output["action_pred"][0].tolist(),
                            "preview": preview_actions(
                                output["action"][0], sensors.mapping
                            ),
                        }
                    )
                record["latest_image_host_age_at_completion_s"] = (
                    time.monotonic() - evidence["camera_host_monotonic_s"][-1]
                )
                if cfg["inference"]["save_observations"]:
                    writer.observation(completed, observation)
                writer.append(record)
                completed += 1
                last_success = time.monotonic()
                print(f"Recorded {completed}/{limit}; executed=False", flush=True)
                time.sleep(
                    max(0, 1 / cfg["observation"]["rate_hz"] - (time.monotonic() - t0))
                )
            if completed != limit:
                raise TimeoutError(f"session ended after {completed}/{limit} records")
        writer.append({"event": "completed", "records": completed, "executed": False})
    except KeyboardInterrupt:
        writer.append({"event": "interrupted", "records": completed, "executed": False})
    except Exception as exc:
        writer.append(
            {
                "event": "failed",
                "error_type": type(exc).__name__,
                "message": str(exc),
                "executed": False,
            }
        )
        raise
    finally:
        writer.close()
    return writer.directory
