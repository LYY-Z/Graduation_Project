# Independent adapter review record

Date: 2026-10-24. Review mode: read-only, separate reviewer context.

The reviewer read the adapter source, configuration, tests, original upstream policy/normalizer contracts and official model configuration. The reviewer ran 41 local pure contract tests with cache/bytecode writes disabled. The model, ROS, hardware, network and remote commands were not run.

## Findings and disposition

* Critical: none identified by this source review.
* Important: persisted old camera frames can contaminate startup stream identity. Fixed: stale/future cache entries are dropped before queuing; provisional stream may be replaced before a valid observation; restart guard remains after first successful observation. Two regression tests cover cache rejection and provisional stream replacement.
* Minor functional defect: updating metadata removed `created_utc`. Fixed with a regression test preserving the timestamp.
* Minor functional defect: fractional `max_predictions` silently truncated, including a possible zero-record success. Fixed with integer-only validation and tests for 0.5, 1.5 and bool.

All new regression tests failed against the previous implementation and passed after the fixes. Final local suite: 47 passed. Formatting and import cleanup were applied afterward only to new source/tests/scripts; upstream was not reformatted.

## Boundaries explicitly not judged by runtime evidence

* Checkpoint deserialization, strict parameter loading and inference compatibility: source contracts only; execution prohibited during preparation.
* Actual RTDE compatibility, live ROS topics/frame identity, measured timing and active pendant TCP: require later manual validation.
* Physical calibration and task performance: the engineering map is explicitly uncalibrated and the weights are simulation-trained.
* Motion execution: not implemented in this release.
* Final documentation and server contents: completed and verified separately by the primary implementer; not misrepresented as part of the earlier independent review.

Assessment: appropriate for preparation and staging after fixes, not evidence of a validated live deployment.
